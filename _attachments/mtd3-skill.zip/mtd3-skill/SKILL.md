---
name: mtd3-skill
description: 使用MTD组件库生成、修改、还原页面、解决MTD组件报错的综合工具包。支持根据需求选择合适的MTD组件、生成新页面代码、修改现有页面、解析现有页面结构，以及进行组件配置优化。当要使用MTD组件来 生成/修改/还原页面或者要解决MTD组件报错问题的时候要调用该方法。触发关键词：MTD、MTD还原页面、修复MTD组件报错。

metadata:
  skillhub.creator: "limengfei09"
  skillhub.updater: "limengfei09"
  skillhub.version: "V7"
  skillhub.source: "FRIDAY Skillhub"
  skillhub.skill_id: "1411"
  skillhub.high_sensitive: "true"
---

# MTD 组件页面工具包

## 概述

本工具包提供了一套完整的解决方案，用于：

### 增量场景（生成新页面）
- **页面生成**：根据用户提供的文字和图片描述，按照用户要求，使用MTD组件库生成新页面。
- **页面还原**：解析用户提供的图片和文字描述，按照用户的要求，使用MTD组件库还原页面。

### 存量场景（修改现有页面）
- **页面修改**：基于用户提供的现有页面代码，根据用户的修改需求（文字描述、图片参考等），对现有页面进行修改和优化。
- **功能增强**：在现有页面基础上，添加新的功能、组件或交互逻辑。
- **样式调整**：根据用户需求调整现有页面的样式、布局或主题。

### 错误修复场景
- **代码修复**：根据用户提供的代码和报错信息，对报错问题进行修复。
- **组件报错处理**：针对MTD组件使用不当导致的报错，通过学习组件知识库进行修复。

---

> ⚠️ **强制要求**：无论何种场景，**必须严格按照对应工作流程的每一个 Step 顺序执行，不得跳过任何步骤**。每个 Step 完成后需确认检查点全部通过，方可进入下一步。



## 工作流程

### 场景一：增量场景（生成新页面）

**适用条件**：用户要求"创建"、"生成"新页面，或提供设计稿要求从头实现。

---

**Step 1（Plan）：意图识别与框架判断**

1. **检查 MTD 组件库安装与配置状态**：
   - 检查项目的 `package.json` 文件
   - 确认是否已安装 MTD 组件库（`@ss/mtd-react3`、`@ss/mtd-vue2` 或 `@ss/mtd-vue3`）
   - **如果未安装**：
     - 参考安装指南：`references/INSTALLATION.md`
     - 识别项目框架（React 或 Vue）
     - 根据框架选择对应的包名并执行安装命令
     - 安装完成后继续后续步骤
   - **检查样式引入与主题配置**：
     - 检查项目入口文件（如 `src/index.js`、`src/main.js`）是否已引入样式
     - 确认当前引入的主题（默认蓝色 / 黄色 / leez-yellow / leez-blue / leez-huixiao-blue 等）
     - **如果用户有主题要求或样式未引入**：参考 `references/INSTALLATION.md` 中对应框架的样式引入示例，更新或补充入口文件中的样式导入语句
   - **检查组件注册**（仅 Vue 项目）：
     - 确认入口文件中已通过 `Vue.use(Mtd)` 或 `app.use(Mtd)` 全局注册组件库
     - 若未注册，参考 `references/INSTALLATION.md` 补充注册代码
   - **检查点**：确认 MTD 组件库已正确安装、样式已按所需主题引入、Vue 项目组件库已注册

2. **解析用户需求**：
   - 仔细阅读用户的文字描述和图片参考
   - 识别页面需要包含的功能和组件
   - 明确用户的特殊要求（如样式、布局、交互等）

3. **识别所需组件**：
   - 根据需求列出可能用到的 MTD 组件
   - 参考组件列表、组件使用场景、组件搭配注意事项：`references/component_name.md`
   - **检查点**：确认所有组件名都存在于组件全集
   - ⚠️ **Tabs 特别预警**：如果组件列表中包含 `Tabs`，必须在此处立即标记「Tabs 强制样式待核查」，并在 Step 4 生成代码后、Step 5 验证前，主动找到每一处 `<Tabs` 标签，确认其 style 包含 `paddingTop: 12` 和 `width: '100%'`，两个属性缺一不可。

4. **识别项目框架**：
   - 检查 `package.json` 中的依赖包
   - 查看是否有现有代码文件及其导入语句
   - **检查点**：确认是 `mtd-react` 还是 `mtd-vue`

5. **输出 Step 1 结果**：
   - 组件列表（用于 Step 2 的命令参数）
   - 框架标识（用于 Step 2 的 --target 参数）

---

**Step 2（Execute）：获取组件知识库**

1. **执行命令**：
   ```bash
   # 单个组件（React，不指定版本则默认最新版）
   node scripts/mtd-rag.js query_components_direct --components=Button --target=mtd-react --quiet

   # 多个组件（逗号分隔，无空格）
   node scripts/mtd-rag.js query_components_direct --components=Button,Form,Input,Select --target=mtd-react --quiet

   # 指定版本号（推荐：从项目 package.json 读取）
   node scripts/mtd-rag.js query_components_direct --components=Button --target=mtd-react --mtd-version=0.12.9 --quiet

   # Vue 框架
   node scripts/mtd-rag.js query_components_direct --components=Button --target=mtd-vue --quiet
   ```

2. **验证输出**：
   - 确认知识库内容正确返回
   - 记录每个组件的 API、示例和注意事项

3. **参考文档**：
   - 详细用法：`scripts/HOW_TO_USE.md`

**检查点**：
- [ ] 命令使用了 `--quiet` 参数
- [ ] 多个组件用逗号分隔且无空格
- [ ] Vue 框架使用了 `--target=mtd-vue`

---

**Step 3（Plan）：检查注意事项与特殊规则**

1. **查看注意事项文档**：
   - 打开 `references/precautions.md`
   - 查找涉及组件的特殊使用规则

2. **重点关注**：
   - `Form`：第一层节点限制
   - `InputNumber`：toFormItem 使用方式
   - `message`/`notification`：大小写差异
   - `Grid`：实际是 Row 和 Col

3. **记录特殊规则**：
   - 将需要特殊处理的组件和规则记录下来
   - 确保在生成代码时遵循这些规则

**检查点**：
- [ ] 已查阅 `references/precautions.md`
- [ ] 已识别涉及的特殊组件及其规则

---

**Step 4（Execute）：生成代码**

1. **学习组件知识**：
   - 仔细阅读每个组件的 API 文档
   - 参考基础示例代码
   - 应用注意事项中的特殊规则

2. **基础风格规范**：读取 `styles/base.md`，严格遵循其中的所有基础风格规范

3. **生成页面代码**：
   - 根据用户需求组织组件结构
   - 设置组件的正确属性和配置
   - 遵循框架的最佳实践

4. **代码规范**：
   - React：使用函数组件或类组件，遵循 React 规范
   - Vue：使用 Vue 2 或 Vue 3 的正确语法
   - 保持代码清晰、可读、可维护

**检查点**：
- [ ] 所有必需属性都已设置
- [ ] 特殊组件遵循了使用规则
- [ ] 代码风格符合框架规范
- [ ] 已遵循基础风格规范

---

**Step 5（Validate）：验证与修复**

1. **验证代码**：
   - 检查是否有语法错误
   - 确认组件使用是否正确
   - 验证是否符合用户需求

2. **基础风格规范自查**：
   - **必须**读取 `styles/base.md`，将其中每一条规范与生成的代码逐一对照检查
   - 发现任何不符合规范的地方，立即修正后再继续

3. **处理报错**：
   - 如果有组件报错，进入错误修复流程
   - 识别错误涉及的组件
   - 重新获取该组件的知识库
   - 对比知识库修复错误

4. **重试机制**：
   - 最多重试 3 次
   - 如果仍然无法解决，向用户说明情况

**检查点**：
- [ ] 代码无语法错误
- [ ] 组件使用符合知识库要求
- [ ] 基础风格规范自查全部通过
- [ ] 报错已修复或已说明情况

### 场景二：存量场景（修改现有页面）

**适用条件**：用户要求"修改"、"调整"、"优化"现有页面，或提供了现有代码文件。

---

**Step 1（Plan）：分析现有代码与识别需求**

1. **检查 MTD 组件库安装与配置状态**：
   - 检查项目的 `package.json` 文件
   - 确认是否已安装 MTD 组件库（`@ss/mtd-react3`、`@ss/mtd-vue2` 或 `@ss/mtd-vue3`）
   - **如果未安装**：
     - 参考安装指南：`references/INSTALLATION.md`
     - 识别项目框架（React 或 Vue）
     - 根据框架选择对应的包名并执行安装命令
     - 安装完成后继续后续步骤
   - **检查样式引入与主题配置**：
     - 检查项目入口文件（如 `src/index.js`、`src/main.js`）是否已引入样式
     - 确认当前引入的主题（默认蓝色 / 黄色 / leez-yellow / leez-blue / leez-huixiao-blue 等）
     - **如果用户有主题要求或样式未引入**：参考 `references/INSTALLATION.md` 中对应框架的样式引入示例，更新或补充入口文件中的样式导入语句
   - **检查组件注册**（仅 Vue 项目）：
     - 确认入口文件中已通过 `Vue.use(Mtd)` 或 `app.use(Mtd)` 全局注册组件库
     - 若未注册，参考 `references/INSTALLATION.md` 补充注册代码
   - **检查点**：确认 MTD 组件库已正确安装、样式已按所需主题引入、Vue 项目组件库已注册

2. **分析现有代码**：
   - 读取用户提供的现有页面代码
   - 理解当前的组件使用情况和代码结构
   - 识别现有的导入语句、状态管理、事件处理等

3. **识别修改需求**：
   - 解析用户的修改需求（文字描述、图片参考等）
   - 明确需要修改、新增或删除的内容
   - 理解用户的期望效果

4. **识别涉及组件**：
   - 列出需要修改或新增的 MTD 组件
   - 参考组件列表：`references/component_name.md`
   - **检查点**：确认所有组件名都存在于组件全集

5. **识别项目框架**：
   - 从现有代码的导入语句中确认框架
   - **检查点**：确认是 `mtd-react` 还是 `mtd-vue`

6. **输出 Step 1 结果**：
   - 修改内容摘要
   - 涉及的组件列表
   - 框架标识

---

**Step 2（Execute）：获取组件知识库**

1. **执行命令**：
   ```bash
   # 修改涉及的组件（React）
   node scripts/mtd-rag.js query_components_direct --components=Button,Form,Input --target=mtd-react --quiet

   # 指定版本号（推荐：从项目 package.json 读取）
   node scripts/mtd-rag.js query_components_direct --components=Button,Form,Input --target=mtd-react --mtd-version=0.12.9 --quiet

   # Vue 框架
   node scripts/mtd-rag.js query_components_direct --components=Button --target=mtd-vue --quiet
   ```

2. **重点关注**：
   - 对于需要修改的组件，重点了解其 API 和使用方法
   - 对于新增的组件，学习其基础用法和示例

3. **参考文档**：
   - 详细用法：`scripts/HOW_TO_USE.md`

**检查点**：
- [ ] 命令使用了 `--quiet` 参数
- [ ] 涉及的组件都已获取知识库

---

**Step 3（Plan）：检查注意事项与评估影响**

1. **查看注意事项文档**：
   - 打开 `references/precautions.md`
   - 查找涉及组件的特殊使用规则

2. **分析修改影响**：
   - 评估修改对现有代码的影响
   - 确认修改不会破坏现有功能
   - 识别可能需要调整的相关代码

3. **保持代码风格**：
   - 观察现有代码的风格和规范
   - 确保修改后的代码风格一致

**检查点**：
- [ ] 已查阅 `references/precautions.md`
- [ ] 已评估修改对现有功能的影响
- [ ] 代码风格将与现有代码保持一致

---

**Step 4（Execute）：应用修改**

1. **应用修改**：
   - 基于组件知识库和用户需求，对现有代码进行修改
   - 新增需要的组件和功能
   - 调整或删除不需要的内容

2. **基础风格规范**：读取 `styles/base.md`，严格遵循其中的所有基础风格规范

3. **保持一致性**：
   - 保持与现有代码风格一致
   - 遵循项目的代码规范
   - 确保导入语句、命名规范等一致

4. **代码质量**：
   - 保持代码清晰、可读
   - 避免引入不必要的复杂性

**检查点**：
- [ ] 修改内容符合用户需求
- [ ] 代码风格与现有代码一致
- [ ] 没有破坏现有功能
- [ ] 已遵循基础风格规范

---

**Step 5（Validate）：验证与修复**

1. **验证修改结果**：
   - 检查修改后的代码是否符合用户需求
   - 确认新增功能正常工作
   - 验证现有功能未受影响

2. **基础风格规范自查**：
   - **必须**读取 `styles/base.md`，将其中每一条规范与生成的代码逐一对照检查
   - 发现任何不符合规范的地方，立即修正后再继续

3. **检查组件报错**：
   - 如果出现组件报错，进入错误修复流程
   - 识别错误涉及的组件
   - 重新获取该组件的知识库
   - 对比知识库修复错误

4. **重试机制**：
   - 最多重试 3 次
   - 如果仍然无法解决，向用户说明情况

**检查点**：
- [ ] 修改内容已正确实现
- [ ] 基础风格规范自查全部通过
- [ ] 组件报错已修复或已说明情况

### 场景三：错误修复场景

**适用条件**：用户提供了错误信息或报错截图，或明确表示代码有问题需要修复。

---

**Step 1（Plan）：识别错误与定位问题**

1. **检查 MTD 组件库安装与配置状态**：
   - 检查项目的 `package.json` 文件
   - 确认是否已安装 MTD 组件库（`@ss/mtd-react3`、`@ss/mtd-vue2` 或 `@ss/mtd-vue3`）
   - **如果未安装**：
     - 参考安装指南：`references/INSTALLATION.md`
     - 识别项目框架（React 或 Vue）
     - 根据框架选择对应的包名并执行安装命令
     - 安装完成后继续后续步骤
   - **检查样式引入与主题配置**：
     - 检查项目入口文件（如 `src/index.js`、`src/main.js`）是否已引入样式
     - 确认当前引入的主题（默认蓝色 / 黄色 / leez-yellow / leez-blue / leez-huixiao-blue 等）
     - **如果用户有主题要求或样式未引入**：参考 `references/INSTALLATION.md` 中对应框架的样式引入示例，更新或补充入口文件中的样式导入语句
   - **检查组件注册**（仅 Vue 项目）：
     - 确认入口文件中已通过 `Vue.use(Mtd)` 或 `app.use(Mtd)` 全局注册组件库
     - 若未注册，参考 `references/INSTALLATION.md` 补充注册代码
   - **检查点**：确认 MTD 组件库已正确安装、样式已按所需主题引入、Vue 项目组件库已注册

2. **分析错误信息**：
   - 仔细阅读错误信息或查看报错截图
   - 判断错误类型：
     - 组件使用错误（API、属性、结构等）
     - 逻辑错误（条件判断、数据处理等）
     - 其他类型错误

3. **定位问题组件**：
   - 从错误信息中识别涉及的 MTD 组件
   - 在代码中定位问题组件的使用位置
   - **检查点**：确认问题组件的准确名称

4. **识别项目框架**：
   - 从代码的导入语句中确认框架
   - **检查点**：确认是 `mtd-react` 还是 `mtd-vue`

5. **输出 Step 1 结果**：
   - 错误类型描述
   - 问题组件列表
   - 框架标识

---

**Step 2（Execute）：获取组件知识库**

1. **执行命令**：
   ```bash
   # 获取问题组件的知识库（React）
   node scripts/mtd-rag.js query_components_direct --components=Form,InputNumber --target=mtd-react --quiet

   # 指定版本号（推荐：从项目 package.json 读取）
   node scripts/mtd-rag.js query_components_direct --components=Form,InputNumber --target=mtd-react --mtd-version=0.12.9 --quiet

   # Vue 框架
   node scripts/mtd-rag.js query_components_direct --components=Form --target=mtd-vue --quiet
   ```

2. **重点关注**：
   - API 说明和正确用法
   - 注意事项和常见错误
   - 特殊属性和配置要求

3. **参考文档**：
   - 详细用法：`scripts/HOW_TO_USE.md`

**检查点**：
- [ ] 命令使用了 `--quiet` 参数
- [ ] 问题组件的知识库已获取

---

**Step 3（Plan）：分析错误原因与检查规则**

1. **对比知识库和代码**：
   - 仔细对比知识库中的正确用法和现有代码
   - 找出与知识库不符的地方
   - 识别可能的错误原因

2. **查看注意事项文档**：
   - 打开 `references/precautions.md`
   - 确认是否违反了特殊组件的使用规则
   - 重点检查 Form、InputNumber 等特殊组件

3. **记录分析结果**：
   - 错误原因分析
   - 需要修改的具体内容
   - 修复方案

**检查点**：
- [ ] 已查阅 `references/precautions.md`
- [ ] 已明确错误原因和修复方案

---

**Step 4（Execute）：修复错误**

1. **应用修复**：
   - 根据分析结果修复代码中的错误
   - 如果是组件使用错误，按照知识库中的正确用法修改
   - 确保所有必需的属性都已正确设置

2. **基础风格规范**：读取 `styles/base.md`，严格遵循其中的所有基础风格规范

3. **遵循组件规则**：
   - 遵循组件的结构要求（如 Form.Item 的嵌套规则）
   - 应用特殊组件的使用规则
   - 确保代码符合框架规范

**检查点**：
- [ ] 错误原因已修复
- [ ] 组件使用符合知识库要求
- [ ] 已遵循基础风格规范

---

**Step 5（Validate）：验证与重试**

1. **验证修复结果**：
   - 确认错误已被修复
   - 检查是否有新的错误或警告

2. **基础风格规范自查**：
   - **必须**读取 `styles/base.md`，将其中每一条规范与生成的代码逐一对照检查
   - 发现任何不符合规范的地方，立即修正后再继续

3. **重试机制**：
   - 如果仍然报错，重复 Step 2-4
   - 每次重试重新获取知识库，获取更详细的信息
   - **最多重试 3 次**

4. **无法解决时**：
   - 如果重试 3 次后仍然无法解决
   - 向用户说明情况
   - 建议其他解决方案（如查看官方文档、寻求技术支持等）

**检查点**：
- [ ] 错误已修复或已说明情况
- [ ] 基础风格规范自查全部通过
- [ ] 重试次数不超过 3 次

### 重试机制规范

当生成的代码存在组件层面的报错时，按照以下规范进行重试：

1. **错误识别**：
   - 识别错误信息中涉及的MTD组件
   - 判断错误类型（API使用错误、属性配置错误、结构错误等）

2. **知识库重新获取**：
   - 回到Step 2，重新获取问题组件的知识库
   - 命令：`node scripts/mtd-rag.js query_components_direct --components=<问题组件名> --target=<框架> --quiet`

3. **深度分析**：
   - 仔细阅读组件知识库，重点关注：
     - 组件的正确用法和API说明
     - 特殊属性和配置要求
     - 常见错误和注意事项
   - 对比现有代码，找出与知识库不符的地方

4. **修复实施**：
   - 根据知识库中的正确用法修改代码
   - 确保所有必需的属性都已正确设置
   - 遵循组件的结构要求（如Form.Item的嵌套规则等）

5. **验证循环**：
   - 修复后验证是否还有报错
   - 如果仍有报错，重复上述步骤
   - 最多重试3次，如果仍然无法解决，向用户说明情况并建议其他解决方案

## 重要提示

### 1. 框架识别（必须在 Step 1 中完成）

**判断方法**：
- 检查项目的 `package.json` 文件中的依赖
- 查看代码中的导入语句

**判断标准**：
| 包名 | 框架标识 | 命令参数 |
|------|----------|----------|
| `@ss/mtd-react3` | mtd-react | 可省略 `--target` 或使用 `--target mtd-react` |
| `@ss/mtd-vue2` | mtd-vue | 必须使用 `--target mtd-vue` |
| `@ss/mtd-vue3` | mtd-vue | 必须使用 `--target mtd-vue` |

**重要**：React 和 Vue 组件库的组件存在差异，绝对不要混用！

---

### 2. 场景识别（决定使用哪个工作流程）

**增量场景**（使用场景一的工作流程）：
- 用户要求"创建"、"生成"新页面
- 用户提供设计稿或描述，要求从头开始实现
- 用户没有提供现有代码

**存量场景**（使用场景二的工作流程）：
- 用户要求"修改"、"调整"、"优化"现有页面
- 用户提供了现有代码文件
- 用户要求在现有基础上添加功能

**错误修复场景**（使用场景三的工作流程）：
- 用户提供了错误信息或报错截图
- 用户明确表示代码有问题需要修复
- 用户提到"报错"、"警告"、"错误"等关键词

---

### 3. 组件名格式

**正确格式**：
- ✅ 单个组件：`Button`
- ✅ 多个组件（无空格）：`"Button,Form,Input"`
- ✅ 组件名首字母大写

**错误格式**：
- ❌ 组件名小写：`button`
- ❌ 多个组件有空格：`"Button, Form, Input"`
- ❌ 不存在的组件名：`MyComponent`

**组件名全集**：参考 `references/component_name.md`，确保使用的是存在的组件名

---

### 4. 命令执行规范

**基础命令格式**：
```bash
node scripts/mtd-rag.js query_components_direct --components=<组件名> --target=<框架> [--mtd-version=<版本号>] --quiet
```

**参数说明**：
| 参数 | 说明 | 必填 | 示例 |
|------|------|------|------|
| `--components` | 单个或多个组件（逗号分隔，无空格） | 是 | `--components=Button` 或 `--components=Button,Form,Input` |
| `--target` | 目标框架：`mtd-react` 或 `mtd-vue` | 是 | `--target=mtd-vue` |
| `--mtd-version` | MTD 组件库版本号，从 package.json 读取 | 否（默认最新版） | `--mtd-version=0.12.9` |
| `--quiet` | 静默模式，只输出知识库内容 | 建议 | `--quiet` |

**为什么使用 `--quiet`**：
- 减少 AI 上下文中的无关信息
- 确保输出的是纯净的知识库内容
- 避免日志信息干扰 AI 的理解和决策

---

### 5. 注意事项文档

在 Step 3 中，**必须**查看 `references/precautions.md`，重点关注：
- 特殊组件的使用规则（如 Form、InputNumber 等）
- React 和 Vue 组件库的差异
- 常见错误和陷阱

**常见特殊组件**：
- `Form`：第一层节点仅支持 Form.Item，否则需设置 `useContext`
- `InputNumber`：必须使用 `toFormItem` 方法，与 `onChange`/`value` 互斥
- `message`/`notification`：React 中使用小写，Vue 中使用 `this.$mtd.message`
- `Grid`：实际是 `Row` 和 `Col` 组件，不是 `Grid`

---

### 6. 基础风格规范

在所有场景的 Step 4 中生成或修改代码时，**必须**读取并严格遵循 `styles/base.md` 中的所有基础风格规范。

---

### 7. 重试机制

当出现组件报错时，按照以下步骤重试：
1. 识别错误涉及的组件
2. 重新获取该组件的知识库
3. 对比知识库和代码，找出差异
4. 修复代码
5. 验证结果

**最多重试 3 次**，如果仍然无法解决，向用户说明情况。

---

### 8. AI 执行检查清单

在执行每个步骤前，请确认：
- [ ] 已正确识别用户场景（增量/存量/错误修复）
- [ ] 已正确识别框架（mtd-react 或 mtd-vue）
- [ ] 已验证组件名存在于组件全集
- [ ] 已检查注意事项文档中的特殊规则
- [ ] 已读取 `styles/base.md` 并遵循其中的基础风格规范
- [ ] 命令格式正确（`mtd-rag.js query_components_direct`），使用了 `--quiet` 参数
- [ ] 代码风格与现有代码保持一致（存量场景）

## 全部文档参考
- **完整示例**：查看 `references/EXAMPLE.md` 了解实际使用场景
- **组件列表**：查看 `references/component_name.md` 了解所有可用组件
- **注意事项**：查看 `references/precautions.md` 了解特殊组件的使用注意事项
- **安装指南**：查看 `references/INSTALLATION.md` 了解如何安装和配置 MTD 组件库
- **使用指南**：查看 `scripts/HOW_TO_USE.md` 了解命令行工具详细用法
- **图标速查**：查看 `references/icon.md` 了解所有可用图标。
- **基础UI规范**：查看 `styles/base.md` 了解所有基础UI规范。
