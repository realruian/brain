---
name: design-system-skill
description: "用自然语言生成符合美团设计规范的界面方案，输出 HTML 原型并保存到本地。支持：用自然语言描述页面结构直接生成 HTML、组件设计、Token 查询、规范合规性检查、设计方案审查。只要用户描述了页面布局、列表条目结构、按钮/图标/间距需求，就应激活此 skill。触发词：生成页面、描述一个页面、做设计稿、按照规范、Token、界面原型、列表页、详情页、首页、设置页、设计系统、Design System、generate page、UI prototype、design token、component spec、HTML mockup。NOT for：Skill 质量评估、代码规范检测、纯文本设计审查。"
version: "2026.04.29.2"
appkey: com.sankuai.raptor.iconfont.websdk
tags: 设计系统,UI设计,前端开发,产品设计
visibility: public

metadata:
  skillhub.creator: "likaimeng"
  skillhub.updater: "likaimeng"
  skillhub.version: "V22"
  skillhub.source: "FRIDAY Skillhub"
  skillhub.skill_id: "24862"
  skillhub.high_sensitive: "false"
---

# Design System Skill

---

## 🗺️ 速读导航（AI 读取时优先看此表，直接跳转目标章节）

> **用法**：根据当前工作步骤，用 `offset` 参数跳到对应行，无需从头扫描。

### 🎨 PHASE 1 — DESIGN（设计阶段）

| 章节 | 内容摘要 |
|------|---------|
| 工作姿态 / SVCS 架构 / 设计哲学 | 分层协议、硬边界定义、设计哲学、四类禁改内容 |
| 🚫 反模板清单 | 禁止的 AI 味特征 + 替代方案（每次输出前检查）|
| 场景映射表（高频词直通） | 命中即跳过提问，直接进 D2 |
| **D1 需求解析** | 单轮补充提问、豁免规则、页面类型映射表 |
| **D2 规范检索** | 默认走 Fast Path 最小读取；命中高风险再升级到 Full Harness；🚨 所有颜色/字号/间距/圆角数值**唯一来源** `references/semantic/` |
| **D3 方案生成** | 信息层级、🚨 组件选型**必须且只能**来自 `references/component/`；默认内部保留精简声明，命中高风险再升级完整声明表 |

### 🌐 PHASE 2 — WEB GENERATE（网页生成阶段）

| 章节 | 内容摘要 |
|------|---------|
| **W1 HTML 输出** | 内联资源保全 / 重注入、CSS 规则、尺寸换算；脚本 → `references/demo-generate/inject-fonts-script.md`；金刚区 → `references/templates/icon-grid.md` |
| **W1-stabilize（编辑后稳定化）** | W1-edit 每次写回后自动执行：重注入 `ds-font-inject` 资源块 + 资源完整性回归 |
| **W1 后内部验收** | HTML 写完后内部执行 `checklist.md §B`，发现问题先修正再交付 |
| 参考入口 | 图标速查 / 高频组件尺寸 / checklist → `references/component/atoms/icon-quickref.md` / `references/component/component-quickref.md` / `references/checklist.md` |
| 输出格式模板 | 每次 HTML 输出只保留必要结果 |
| 错误处理 | Token / 图标 / 价格字体错误处理方式 |

### 🧪 PHASE 3 — REPAIR（修复）

| 章节 | 内容摘要 |
|------|---------|
| **显式 Repair Loop** | `R-D2-01 / R-D3-01 / R-D3-02 / R-D3-03 / R-W1-01 / R-W1-02` 回退矩阵，不得跨层偷修 |

> ❌ **禁止顺序读完整文件**——读完「速读导航」后，按工作步骤跳转对应章节，W1 生成 HTML 时再按需读 `references/component/atoms/icon-quickref.md` / `references/component/component-quickref.md` / `references/demo-generate/image-keywords.md`。

---

## SVCS 架构（提高组件调用成功率的分层协议）

> **目标**：所有设计任务先走 `SVCS` 路由，再进入规范检索与 HTML 输出。`SVCS` 是**控制面**，只定义“先看什么、谁说了算、什么时候必须停”，**不是新的样式来源**，不得重复组件细节或 Token 数值。

| 层 | 负责什么 | 明确不负责什么 |
|----|---------|---------------|
| **S = Scenario / Schema** | 判定页面模式、主目标、主信息、模块有无、CTA 优先级、业务阶段 | ❌ 不决定组件内部样式；❌ 不提供 px/hex 等数值 |
| **V = Visual Language** | 判定布局构图、信息层级、业务氛围、模块关系、页面层位置规律 | ❌ 不替代组件规范；❌ 不决定组件内部 size / variant / state；❌ 不作为 Token 数值来源 |
| **C = Component** | 判定组件选型、variant / size / state、slot 结构、组件内部 spacing / radius / icon / 交互限制 | ❌ 不负责业务页面模式；❌ 不允许被 `visual-language` 覆写内部样式 |
| **S = Semantic** | 判定 color / font / spacing / radius / stroke / shadow 等 Token，消灭裸值 | ❌ 不决定是否使用某个组件；❌ 不改写组件结构 |

**决策顺序（不得跳步）**：
1. **先 `Scenario`**：先产出页面模式与模块清单；未完成业务语义解析，不得进入组件选型。
2. **再 `Visual`**：只决定页面层布局与信息层级，不触碰组件内部样式。
3. **再 `Component`**：所有可命中组件的区域，必须且只能从 `references/component/` 选型；一旦命中，内部样式所有权归组件 `.md`。
4. **最后 `Semantic`**：仅为页面层和未被组件正文覆盖的样式落 Token；任何数值都必须能回溯到 `references/semantic/` 或组件正文。

**冲突处理（组件调用成功率的硬规则）**：
- **模块有无 / 页面目标冲突**：以 `Scenario` 为准
- **布局构图 / 信息层级冲突**：以 `Visual` 为准
- **组件结构 / variant / size / state / 内部样式冲突**：以 `Component` 为准；`visual-language` 不得越权
- **颜色 / 字号 / 间距 / 圆角 / 描边 / 阴影数值冲突**：以 `Semantic` 或组件正文中的显式值为准；❌ 禁止裸值
- **图标冲突裁决**：先看是否命中组件正文的固定 icon 约束；命中则以组件 `.md` 为准；未命中固定约束时，图标名称/字重只能按 `icon-quickref.md` → `icon.md §3` → `assets/iconfont.css` 顺序收敛；❌ 禁止跳过存在性核验直接猜类名
- **间距冲突裁决**：按 `组件正文显式值 > grid-layout.md（页面容器/卡片层） > component-spacing.md（组件内部） > spacing-semantic.md（页面/模块语义间距）` 处理；若同一间距位点同时命中两层以上且无法唯一归属，必须停止并回 `D3` 重做 ownership，不得折中取中间值

**阻断规则（命中即停止，不得猜）**：
- `references/component/` 找不到对应组件 → 停止，不得自造组件
- 样式词无法映射到 `visual-language` / `component` / `semantic` 的合法来源 → 停止，不得近似替代
- `visual-language` 与组件内部样式冲突 → 直接服从组件正文，不得折中
- 任一数值无法追溯来源 → 视为裸值，停止输出

---

## 工作姿态

你的工作遵循严格的两层约束，**组件和 Token 没有自由裁量空间**，只有布局构图和信息层级上才需要做设计判断：

> **设计哲学**：好的界面不是从零开始画的。先理解已有的视觉体系——配色、字阶、间距、卡片风格、信息密度——然后**在这个体系内**做设计，而不是每次都重新发明一套视觉规则。每个元素都必须有清晰的存在理由，不为填满空间而添加内容。

### 运行模式

> **默认目标**：先恢复吞吐，再用升级条件守住质量。**普通生成默认走 Fast Path，不得默认上 Full Harness。**

| 模式 | 适用场景 | 默认动作 | 明确不做 |
|---|---|---|---|
| `Fast Path` | 新页面常规生成、低歧义需求、首次尝试 | 最小必要读取 + `A0` 模块/槽位盘点 + 内部精简决策 + 只跑 `§B` | 不对外输出完整声明表；不跑 `§A` |
| `Full Harness` | 命中高风险歧义词、组件家族易串型、局部修改高风险、同类问题反复失败 | 补齐完整声明表 + `§A` + 严格 repair loop | 不外溢到所有普通任务 |

> **升级到 Full Harness 的触发条件**（命中任一条即可）：
> - 用户描述命中高风险歧义词：`footer / alert / card / navbar / tag / picker`
> - 任务是已有 HTML 局部修改，且会触碰系统栏、导航栏、底部栏、价格字体、内联资源、全局 `<style>`
> - 任务是已有 HTML 局部修改，且修改范围内有 base64 内联资源（iconfont / 价格字体 / `data:` 图片 / 系统栏内联 SVG）或隐式依赖 `<style>` 全局块的局部 CSS（最容易导致内联资源丢失）
> - 任务是已有 HTML 局部修改，且修改区包含**可见控件槽位**（如箭头、单选/多选、标签、角标、行尾操作、状态 icon）；此时必须从现有 DOM 反推组件归属并升级自检，不能只按用户原话关键词决定是否查组件正文
> - 同一类问题在最近一次修复后仍复发，或已知存在组件家族串型 / 资源丢失 / 标题偏移历史
> - 无法用最小读取快速确定 `page_mode`、主组件家族或 CTA 位置

> **禁止**：
> - ❌ 普通新页面默认启用 Full Harness
> - ❌ 为了防幻觉而要求每次都向用户展示完整声明表

**🧠 执行准则（每次工作时内化，不是核查清单）**：

- **先判定再动手**：生成前必须先完成 `biz_line / page_stage / density_mode` 三项输入的确认或内判。`biz_line` / `page_stage` 无法唯一确定时才补充提问；`density_mode` 默认按 `grid-layout.md` 的页面类型映射自动落档，仅在用户明确要求「更紧凑/更宽松」或当前页面密度无法唯一判断时才重判，并在 D3 写明原因。❌ 禁止在场景映射已命中时重复发问；❌ 禁止默默假设、默默选择。
- **最小实现**：只写解决问题必须的代码。每一个额外的 DOM 层、CSS 属性、动效都需要理由；能用 2 层嵌套实现的不写 3 层；没有被要求的功能不写。❌ 禁止"顺手"加动画、加配置项、加兜底逻辑。
- **精准修改**：收到「改 XX」的指令时，只动被点名的部分。❌ 禁止顺手重构周边代码、调整无关间距、重新生成整页。
- **先审后改**：局部修改已有 HTML 时，必须先把修改区拆成宿主模块 + 叶子槽位，再按 `A0/A3` 回查组件与 icon 来源；❌ 禁止把现有 DOM/CSS 直接当作正确实现继续修补。
  > 🚨 **修改后内联资源保全是强制流程，不是可选项**：任何 `string_replace` / `MultiEdit` / `write` 指令写回 HTML 后，都可能破坏已注入的字体/图片资源；若重写范围过大，还可能误删 `<style id="ds-font-inject">`、已有 `data:` 图片、`{B64:...}` 占位符，甚至误删 Status Bar / Home Indicator 的内联 SVG。改完一步不跳过：**先确认这些内联资源仍在，再立即运行注入脚本，然后再告知用户结果**。
- **自我验收**：每次 HTML 生成完毕，在输出前必须过一遍 `references/checklist.md §B HTML 输出验收`，逐项核对。执行顺序固定为：先跑 `§B` 中「第二轮组件调用轮询（P0/P1 高风险组件）」→ 再跑其余条目；任一 `P0/P1` 未通过都必须继续 repair loop。`§A` 仅在 **Full Harness / 高风险任务** 时执行；普通 Fast Path 不默认跑 `§A`。发现问题就地修正，不得只记录不修复。

**🚨 硬边界（100% 遵守，不可违反，无例外）**：
- **组件**：必须且只能来自 `references/component/`，❌ 禁止自造、禁止用原生标签替代
  - **模块/槽位命中 → 强制读组件规范**：只要用户描述、A0 模块盘点、槽位拆解或现有 HTML 痕迹命中筛选 / 标题栏 / 导航 / 标签页 / 弹窗 / 步进器 / 评分 / 搜索框 / 底部操作栏 / 标签 / 单选多选 / 行尾箭头等组件语义，**必须先打开对应组件 `.md` 文件确认规范再动手**，不可凭记忆或经验直接写（此处「经验」特指通用前端经验，如"按钮大概 44px"等；`visual-language` 中的业务场景知识不在禁止范围内，应正常参考）
  - **`references/component/` 无对应组件时**：**立即停止当前生成并告知用户「该交互/模块无组件规范覆盖，需先补组件规范后再生成」**。❌ 禁止自行补一个新组件；❌ 禁止继续输出该区域 HTML；❌ 禁止用业务理解偷偷模拟已有组件
- **Token**：颜色/字号/间距/圆角必须来自 `references/semantic/`，❌ 禁止裸写 hex/px 原始值
- **组件规范值**：高度/圆角/内边距必须从对应 `.md` 文件逐字复制，❌ 禁止估算、微调、插值
- **组件样式所有权**：一旦某区域命中组件规范，该组件的内部样式所有权归对应组件 `.md` 文件；页面层只允许做**布局放置**（如区块顺序、外层栅格、组件之间间距），❌ 禁止覆写组件内部已定义的高度/圆角/字号/字重/描边/背景/阴影/图标规格/状态样式
- **变体/状态**：只能从规范列出的选项中选取，❌ 禁止新增未定义的变体
- **🚫【P0】商品图 / 内容图禁止圆形**：❌ **严禁**对商品图、食物图、Banner 图、内容配图等任何**非头像**图片使用 `border-radius: 50%` 或等效的 `border-radius: 9999px/5000px`。商品图统一使用规范圆角（小尺寸用 `radius-xs`/`12px`，中尺寸用 `radius-m`/`16px`），`50%` 只允许出现在**用户头像（avatar）**上。写完 CSS 必须全局扫描 `border-radius.*50%`，凡命中非头像类元素必须改回规范圆角值。
- **🚫【P0】按钮禁止缩小动效**：❌ **严禁**在任何按钮（`<button>`、`.btn-*`、Stepper add-button、FAB、底部 CTA、行内操作按钮等所有按钮形态）上添加点击/按压缩小动效。禁止写 `transform: scale(...)` / `:active { transform: ... }` / `transition: transform` / 任何 `@keyframes` 缩放动画。按压态只能用白色半透明遮罩（`::after { background: rgba(255,255,255,0.2) }`）或 `opacity` 实现。**写完 CSS 必须全局扫描 `:active`、`transform`、`scale` 关键词，逐一确认无缩放写法，才能进入写入阶段**

**布局构图层（在硬边界内做判断）**：信息层级划分、区块排列顺序、视觉强调位置。这是唯一允许设计判断的范围，依据来自 `visual-language` 对应业务线文件。
🚨 **布局默认规则（不可违反）**：所有内容区块默认使用**单列卡片栅格**（白色留边圆角卡片 + `#F5F5F5` 页面背景），❌ 禁止默认使用通栏；通栏仅限 `grid-layout.md` 第四章明确列出的四种场景（顶部全屏 Hero 横幅 / 地图区 / 底部操作栏 / 系统设置分割线列表）。
⚠️ **`visual-language` 用途锁定**：只读业务场景（颜色语义、布局特征、组件位置约束），**不是数值来源**。❌ 禁止从中提取或推断任何 px/pt/hex/Token 数字段，所有数值须来自 `semantic/` 或 `component/` 规范文件。

---

### 🚫 反模板清单

> **核心原则**：元素必须有存在理由；具体禁止项见 `references/checklist.md §A 反模板核查`。仅 Full Harness / 高风险任务逐项执行，Fast Path 只内化原则。

---

## 场景映射表

| 用户说 | 执行方式 |
|--------|---------|
| 生成页面 / 做列表页 / 做详情页 / 做首页 | 执行完整四步工作流（按 D1 单轮补充提问；命中豁免时可直接跳过提问） |
| 按照设计系统 / 用组件库规范 | 先读 `references/INDEX.md`，再执行四步工作流 |
| 检查设计是否合规 / 审查设计方案 | 执行规范检索 + 合规性校验，输出问题清单 |
| 这个 Token 叫什么 / 对应什么颜色值 | 执行 semantic → reference 链路查询 |
| 生成 HTML / 给我看看效果 / 做原型 | 执行四步工作流 + **HTML 原型输出**，生成独立 `.html` 保存到 `~/Desktop/Design Demo/` |
| 搜索页 / 搜索结果页 / 搜索全链路 / 搜索空态 / 搜索联想 | 业务线=美团平台 + 阶段=发现/浏览，直接查§九，跳过提问 |
| 打车选车页 | 业务线=美团平台 + 阶段=发现/浏览，直接查§三十二，跳过提问 |
| 地图搜索 / POI 详情 | 业务线=美团平台 + 阶段=发现/浏览，直接查§三十五，跳过提问 |
| 外卖 POI 主页 / 外卖店铺页 | 业务线=外卖履约 + 阶段=商品/商家详情，直接查§六，跳过提问 |
| 拼好饭 / 拼团 | 业务线=美团平台 + 阶段=发现/浏览，直接查§二十，跳过提问 |
| 团购到店 / 核销码 | 业务线=团购软硬件 + 阶段=交易后/履约，直接查§七，跳过提问 |
| 到店自取 / 取餐 | 业务线=外卖履约 + 阶段=交易转化，直接查§九，跳过提问 |
| 写评价 / 发布评价 | 业务线=外卖履约 + 阶段=内容互动，直接查§七；若美团平台则查§二十七，跳过提问 |
| 个人主页 / 我的主页 | 业务线=美团平台 + 阶段=账户/工具，直接查§十三+§十八，跳过提问 |
| 收银台 / 支付页 / 支付确认 / 订单结算 / 结算页 | 业务线=金融服务 + 阶段=支付结算，直接查§六～§十一，跳过提问 |
| 酒店下单 / 民宿预订 | 业务线=酒店旅行 + 阶段=交易转化，直接查§十六，跳过提问 |
| 出票成功 / 购票成功 | 业务线=酒店旅行 + 阶段=交易后/履约，直接查§十七，跳过提问 |
| 问诊 / 问医生 | 业务线=医药健康 + 阶段=商品/商家详情，直接查§八，跳过提问 |
| 药品详情 / 买药 | 业务线=医药健康 + 阶段=商品/商家详情，直接查§十一，跳过提问 |
| 拍药 / 拍药识药 | 业务线=医药健康 + 阶段=账户/工具，直接查§十四，跳过提问 |
| 小象超市 / 食杂超市首页 | 业务线=食杂零售 + 阶段=发现/浏览，直接查§六，跳过提问 |
| 外卖订单详情 / 外卖订单页 / 外卖履约详情 | 业务线=外卖履约 + 阶段=交易后/履约，直接查 `外卖履约平台设计中心.md §8`，跳过提问 |
| 外卖退款 / 申请退款 / 外卖售后 | 业务线=外卖履约 + 阶段=交易后/履约，直接查 `外卖履约平台设计中心.md §15.1`，跳过提问 |
| 跑腿 / 帮我跑腿 / 发布跑腿 | 业务线=外卖履约 + 阶段=交易转化，直接查 `外卖履约平台设计中心.md §15.2`，跳过提问 |
| 到餐 / 美食团购 / 门店团购详情 | 业务线=团购软硬件 + 阶段=商品/商家详情，直接查 `团购软硬件服务设计中心.md §9.1`，跳过提问 |
| 特价团 / 抢购 / 特团频道 | 业务线=团购软硬件 + 阶段=发现/浏览，直接查 `团购软硬件服务设计中心.md §9.3`，跳过提问 |
| 骑行 / 共享单车 / 扫码骑行 | 业务线=金融服务 + 阶段=交易转化，直接查 `金融服务设计中心.md §13.1`，跳过提问 |
| 充电宝 / 扫码充电宝 | 业务线=金融服务 + 阶段=交易转化，直接查 `金融服务设计中心.md §13.1`，跳过提问 |
| 美团保险 / 投保 / 续保 | 业务线=金融服务 + 阶段=商品/商家详情，直接查 `金融服务设计中心.md §13.2`，跳过提问 |
| AI 助手 / 美团 AI / AI 对话 | 业务线=美团平台 + 阶段=发现/浏览，直接查 `美团平台设计中心.md §38.1`，跳过提问 |
| 小美评审团 / 评审团 / 评测任务 | 业务线=美团平台 + 阶段=内容互动，直接查 `美团平台设计中心.md §38.2`，跳过提问 |
| 这个按钮怎么做 / 按钮 CSS | 直接读 `button.md §8` 复制，不手动推导 |

---

---

## 🎨 PHASE 1 — DESIGN（设计阶段）

> **本阶段目标**：在不写任何代码的前提下，完成需求解析、规范检索、组件选型与布局决策。**默认只产出内部精简决策结果；仅在 Full Harness 时才升级为完整声明表。**
>
> **阶段完成标志**：Fast Path 下，已能唯一确定 `page_mode + 主组件家族 + CTA 位置 + 栅格档位`；Full Harness 下，完整声明表填写完毕且来源可验证。
>
> **Harness Contract（Phase 1）**：
> - **输入**：用户任务描述 + 业务线/页面类型线索 + 已加载的 `SVCS` 分层规则
> - **输出**：Fast Path 为内部精简决策；Full Harness 为完整声明表
> - **Gate**：`D1` 未完成页面模式解析、`D2` 未完成必要规范检索、`D3` 未完成最小组件声明与样式回溯时，❌ 禁止进入 `W1`
> - **Repair Loop**：本阶段不允许“边错边写”。**路由错回 `D2`，声明错回 `D3`**：
>   - **回 `D2`**：业务语义词 → `page_mode` 判错、`tone_source` / `module_order` / `forbidden_order` 所属章节判错、组件别名归一错误、样式词找不到合法来源、组件家族选错、**组件自检时发现别名未归一 / 候选集合未收敛 / 排除理由无法成立**
>   - **回 `D3`**：声明表缺字段、来源缺失、`variant/size/state` 缺失、`density_mode` / `cta_priority` / `module_order` 与前文不一致、声明表与实际准备输出的结构冲突、**模块未写出 `合法组件名 + 来源文件 § + variant/size/state` 的完整绑定，或 `component_audit_map` / `②.6` 自检结论未全部通过**
>   - **回退后的强制动作**：回 `D2` 后必须补完规范检索并重做路由判断；回 `D3` 后按当前模式重做设计决策：**Fast Path** 重新确认最小决策集，**Full Harness** 整表重写并重新通过 `checklist.md §A`。
> - **Exit Criteria**：**Fast Path** 下最小决策集已收敛且所有组件都能回溯到 `references/component/*.md`；**Full Harness** 下 `checklist.md §A` 通过 + 声明表无空项/无估算/无近似实现 + 所有组件都能回溯到 `references/component/*.md`

### D1：需求解析

需求解析最多发起**一次补充提问**。默认只询问**仍无法唯一确定**的字段；已能从用户描述或场景映射表唯一确定的字段，❌ 不得重复发问。

> **字段处理规则**：
> - **必须确认**：`biz_line`（业务线）、`page_stage`（流程阶段）
> - **默认内判，不单独发问**：`density_mode`。先按 `grid-layout.md` 的默认映射自动落档：首页 / 首页化频道首屏 / 高频高密流量入口 → `compact`；列表 / 搜索 / 详情 / 交易 / 支付 / 履约 / 订单等绝大多数页面 → `balanced`；设置 / 个人中心 / 品牌专题等低频末端页面 → `relaxed`
> - **仅在两类情况重判 `density_mode`**：用户明确要求「更紧凑 / 更宽松 / 间距更大 / 信息更疏」，或当前页面不属于上述默认映射且布局密度无法唯一判断

**豁免规则（优先级从高到低，匹配第一条即停止）**：
1. **场景映射表命中（最高优先级）**：需求直接命中「场景映射表」中的高频词（如「打车选车页」「外卖店铺页」「收银台」「核销码」），**提问全部跳过**，直接进入第二步。
2. **跳过业务线问题**：需求中已含业务线关键词（见下方细分词表），则业务线问题不发出，仅问页面类型。
   **业务线关键词细分词表（优先匹配更具体的词）**：
   | 业务线代码 | 触发关键词（任意一词命中即可） |
   |-----------|--------------------------|
   | `waimai` | 外卖、外卖流量、外卖交易、外卖搜索、外卖履约、外卖售后、拼好饭、神抢手、跑腿C、到家、骑手接单 |
   | `tuangou` | 团购、到餐、特价团、特团、团购频道、服务零售、门店导购、秒提、核销码、到店、搜索体验（团购场景） |
   | `medical` | 医药、健康、问诊、问医生、买药、药品、健保、医美、互医、消费医疗、拍药 |
   | `shangou` | 闪购、即时零售、频道营销、基础选购 |
   | `hotel` | 酒店、旅行、民宿、度假、大交通、飞机票、火车票、景点、游玩、出行、境外酒店 |
   | `grocery` | 食杂、小象超市、小象、超市首页、买菜、营销增长（食杂场景） |
   | `finance` | 金融、收银台、支付、钱包、余额、微贷、月付、先用后付、保险、亲情卡、骑行、充电宝 |
   | `platform` | 美团首页、美团平台、搜索结果、推荐、AI助手、评价、小美评审团、消息、账号、个人主页、架构、商场、附近、直播、短视频、拼团、晚8清仓、网约车、打车、地图、POI |
3. **跳过页面类型问题**：业务线已明确，且需求中已含页面类型关键词且阶段可唯一确定，则页面类型问题不发出，仅问业务线（若也已知则全部跳过）。常见映射：
   - 「订单详情 / 订单页」→ `fulfillment`
   - 「写评价 / 发布评价」→ `content`
   - 「出票成功 / 购票成功」→ `fulfillment`
   - 「个人主页 / 我的主页 / 账户设置」→ `account`
   - 「收银台 / 支付页 / 结算页」→ `payment`
   - 「首页 / 发现页 / 浏览页 / 列表页 / 搜索结果」→ `discover`
   - 「商品详情 / 店铺页 / POI 详情」→ `detail`
   - 「下单页 / 确认订单 / 提交订单」→ `transaction`
   - ⚠️ 描述中含「平台 / 美团 / 通用」等词但**无法唯一确定阶段时，必须发出页面类型问题，不得默认 `discover`**
4. **补充提问**：以上条件均不满足时，**用 AskQuestion 工具一次性发出所有仍缺失的问题（1～2 个）**，等待用户回答后再继续。

---

#### 需求确认（单轮补充提问，使用 AskQuestion 工具）

当 `biz_line` 和/或 `page_stage` 仍不确定时，调用 `AskQuestion` 工具；一次性发出所有仍缺失的问题，最多 2 个。`density_mode` 不在 AskQuestion 中单独询问，按上方默认映射在 D3 内部确定；若需要偏离默认映射，必须在 D3 写明原因。

**问题 1 — 业务线**（仅在 `biz_line` 未确定时发出；id: `biz_line`）：
> 请问这个页面属于哪个业务线？

选项：
- `platform`：美团平台
- `waimai`：外卖履约
- `tuangou`：团购软硬件服务
- `medical`：医药健康
- `hotel`：酒店旅行
- `shangou`：闪购
- `grocery`：食杂零售
- `finance`：金融服务
- `generic`：不确定 / 通用

**问题 2 — 流程阶段**（仅在 `page_stage` 未确定时发出；id: `page_stage`）：
> 请问这个页面处于哪个业务流程阶段？

选项：
- `discover`：发现 / 浏览
- `detail`：商品 / 商家详情
- `transaction`：交易转化
- `payment`：支付结算
- `fulfillment`：交易后 / 履约
- `content`：内容互动
- `account`：账户 / 工具

收到补充答案后，**必须立即读 `references/templates/visual-language/page-chapter-map.md`**，查出「业务线 × 流程阶段」对应的**精确章节号**，再用 `offset` 跳读该章节；❌ 禁止泛读整个 visual-language 文件。同时按上方默认映射写入 `density_mode`，若需偏离则在 D3 说明原因，然后进入第二步读取规范文件。

---

#### 页面类型 → 规范章节映射表

> 🚨 **完整映射表（60+ 条，业务线 × 流程阶段 → 精确章节）** → **必须读** `references/templates/visual-language/page-chapter-map.md`；❌ 不得仅凭摘要猜章节，必须打开文件确认章节号。

> **跨业务通用规则**：未列出的页面类型，降级使用 visual-language §五「组件位置规律」自行拼合骨架。


---

#### 受控业务语义词字典（命中先判页面模式，再决定信息层级/布局/组件，不得直接落视觉）

> **用法**：业务语义词描述的是**页面任务目标、转化强度、信息主次、业务气质**，不是组件名、不是样式名、也不是直接的颜色指令。命中后，必须先归一成一个**页面模式（page mode）**，再据此决定信息层级、模块顺序、CTA 强度、布局密度和 visual-language 的使用位置。

| 用户常说 | 归一后的页面模式 | 决策影响 |
|---------|----------------|---------|
| 「大促 / 活动会场 / 营销会场 / 节日活动」 | `promo-campaign` | 强氛围 + 强转化；允许顶部 Hero / 金刚区 / 推荐模块前置；CTA 与主色强调更靠前 |
| 「交易转化 / 下单 / 立即购买 / 抢购 / 强转化区」 | `conversion-focused` | 价格、权益、CTA 前置；弱化辅助信息；优先形成购买闭环 |
| 「商品详情 / 商家详情 / 详情页」 | `detail-decision` | 第一优先级是核心商品/商家信息与购买决策支撑；信息完整但不应喧宾夺主 |
| 「履约进度 / 配送进度 / 订单跟踪 / 骑手到了哪」 | `fulfillment-status` | 状态信息绝对前置；节点/时间/地址/操作次序清晰；弱化营销信息 |
| 「支付成功 / 下单成功 / 购买成功 / 结果页」 | `result-feedback` | 结果确认优先；状态区可前置；后续动作明确但不抢主结果 |
| 「支付页 / 收银台 / 结算页」 | `payment-checkout` | 金额、优惠、支付方式、提交动作闭环最重要；冗余内容压缩 |
| 「种草内容 / 攻略 / 内容详情 / 直播内容 / 图文内容」 | `content-browse` | 内容消费优先；转化存在但不能压过内容本身；强调信息节奏与阅读体验 |
| 「搜索结果 / 列表页 / 筛选页 / 分类页」 | `list-browse` | 列表效率优先；筛选/排序/信息密度优先于氛围装饰 |
| 「首页 / 频道页 / 首页推荐」 | `discovery-home` | 高密度浏览与快速分发；可用金刚区/推荐流；栅格偏紧凑 |
| 「设置页 / 个人中心 / 工具页 / 账户页」 | `account-tools` | 结构清晰、操作稳定、视觉克制；宽松度可提升，装饰性降低 |
| 「服务保障 / 规则说明 / 权益说明 / 帮助说明」 | `assurance-explanation` | 说明与信任感优先；层级清楚，CTA 若存在应后置且克制 |
| 「评价 / 打分 / 满意度 / 调研反馈」 | `feedback-collection` | 反馈动作优先；选项清晰，辅助说明简短；不做营销化包装 |

> 🚨 **高风险业务语义词**：`大促`、`会场`、`结果页`、`履约`、`强转化`、`种草`、`服务保障`、`支付成功`、`收银台`。这些词若未先归一到页面模式，禁止直接决定色彩、布局或组件。
>
> 🚨 **页面模式优先级**：页面模式一旦确定，必须先约束三件事：
> 1. **第一优先级信息是什么**（结果 / 价格 / 状态 / 内容 / 操作）
> 2. **CTA 应该前置还是后置**
> 3. **页面更偏密度效率还是氛围转化**
>
> 🚫 **阻断规则**：若用户描述中的业务语义词无法唯一映射到某个页面模式，**必须立即停止当前生成并告知用户「该业务语义在当前规范中无唯一页面模式，需要补充页面目标或流程阶段」**。❌ 禁止把「大促」直接翻成大面积黄底；❌ 禁止把「履约」直接翻成多列表堆叠；❌ 禁止把「结果页」直接等同于普通详情页。

#### 页面模式 Schema（D3 声明表前必须内部确定，不得留空）

> **目标**：把业务语义判断结果压成一份轻量、可核验的 schema，避免模型只“感觉上像”。

| 字段 | 允许值 / 填写规则 |
|------|------------------|
| `page_mode` | 只能从：`promo-campaign` / `conversion-focused` / `detail-decision` / `fulfillment-status` / `result-feedback` / `payment-checkout` / `content-browse` / `list-browse` / `discovery-home` / `account-tools` / `assurance-explanation` / `feedback-collection` 中选一 |
| `primary_goal` | 该页唯一首要目标；只能写一个，如「促转化 / 看结果 / 看进度 / 做选择 / 看内容 / 做反馈」 |
| `primary_info` | 第一优先级信息；只能写一个主对象，如「价格金额 / 订单状态 / 支付结果 / 商品标题 / 内容主体 / 反馈选项」 |
| `cta_priority` | `front` / `middle` / `back` / `weak` 四选一；表示 CTA 在页面中的优先级位置 |
| `density_mode` | `compact` / `balanced` / `relaxed`；需与 `grid-layout.md` 的紧凑/适中/宽松有明确映射 |
| `tone_source` | 只能写对应 `visual-language` 文件名 + 章节，说明业务气质来源 |
| `forbidden_bias` | 必填；写明当前页面模式最容易犯的 1 条错误，如「不可营销氛围压过结果信息」 |

> 🚨 **Schema 使用规则**：`page_mode` 决定页面策略，`business_line` 决定业务语义来源，`page_stage` 决定流程位置。三者必须互相一致；若冲突，以「用户描述 + page_stage」优先，并回查 `visual-language` 校正。

#### 页面模式 → 默认模块排序 / 禁忌排序（先定骨架，再选组件）

> **目标**：让模型先确定页面骨架，再进入组件选型，避免“组件都合法但整页不像”。

| `page_mode` | 默认模块顺序（从上到下） | CTA 建议 | 禁忌排序 |
|-------------|--------------------------|---------|---------|
| `promo-campaign` | `Hero/会场头部` → `金刚区/频道入口` → `核心促销区` → `推荐模块` → `辅助说明` | `front` 或 `middle` | ❌ 禁止把规则说明/辅助信息放在会场前面；❌ 禁止 CTA 弱化到页尾不可见 |
| `conversion-focused` | `核心卖点/价格权益` → `CTA` → `决策支撑信息` → `补充说明` | `front` | ❌ 禁止把大段说明、评价摘要、推荐流放在 CTA 前 |
| `detail-decision` | `核心标题/主信息` → `价格或关键决策信息` → `CTA` → `支撑信息（评价/保障/说明）` → `推荐模块` | `middle` 或 `front` | ❌ 禁止推荐模块前置到主信息前；❌ 禁止辅助说明压过标题和价格 |
| `fulfillment-status` | `当前状态` → `时间/节点进度` → `地址/联系人/订单摘要` → `可执行操作` → `补充说明` | `middle` 或 `back` | ❌ 禁止营销模块或推荐流出现在状态信息之前 |
| `result-feedback` | `结果确认` → `关键信息摘要` → `后续动作` → `补充说明/推荐` | `back` 或 `middle` | ❌ 禁止促销氛围或推荐模块压过结果确认；❌ 禁止把 CTA 放到结果标题之前 |
| `payment-checkout` | `金额摘要` → `优惠与权益` → `支付方式` → `提交动作` → `说明` | `back` 或 `middle` | ❌ 禁止把推荐流/内容模块插入支付闭环中间 |
| `content-browse` | `内容标题/作者信息` → `内容主体` → `互动/转化动作` → `相关推荐` | `weak` 或 `back` | ❌ 禁止开场先放强 CTA；❌ 禁止营销模块打断内容主体连续性 |
| `list-browse` | `筛选/排序` → `结果摘要` → `列表内容` → `补充操作` | `weak` 或 `middle` | ❌ 禁止大面积 Hero 或长说明前置；❌ 禁止 CTA 抢占筛选和列表首屏 |
| `discovery-home` | `Nav/搜索` → `金刚区/频道入口` → `推荐流` → `运营位/活动位` → `辅助区` | `weak` 或 `middle` | ❌ 禁止把单个 CTA 做成首页第一优先级；❌ 禁止宽松低密度布局 |
| `account-tools` | `账户概览` → `高频工具` → `功能列表` → `说明/设置项` | `weak` 或 `back` | ❌ 禁止营销氛围前置；❌ 禁止把促销模块压到工具区前面 |
| `assurance-explanation` | `核心说明/保障标题` → `条目化说明` → `补充规则` → `辅助动作` | `back` 或 `weak` | ❌ 禁止把 CTA 或营销模块前置到说明之前 |
| `feedback-collection` | `问题/标题` → `反馈选项` → `提交动作` → `补充说明` | `middle` | ❌ 禁止推荐流、营销模块或长说明插到问题与选项之间 |

> 🚨 **排序规则**：默认模块顺序不是建议，而是**页面骨架基线**。若要偏离，必须在 D3 声明表中说明理由；没有理由即视为跑偏。
>
> 🚨 **禁忌排序优先级高于默认排序**：只要命中禁忌排序，即使组件与样式都合法，也视为页面模式失配。

#### 自然语言 → 组件规范翻译（定位章节后执行）

收到描述后，在内部完成**「自然语言 → 组件规范」的翻译**，然后再去读规范文件：

| 用户说 | 对应规范 |
|--------|---------|
| 「约 100px 高的列表行」 | `list.md` — `single-line-l`（56pt @2x = 112px）|
| 「左侧图标区 60×60」 | `list.md §4.1` — `biz-icon` prefix |
| 「文字右侧灰色问号」 | `list.md §4.2` — `title-badge` `info-icon` |
| 「右侧小字提示 + 箭头」 | `list.md §5` — suffix `text` + `arrow` 组合 |
| 「右侧黄色胶囊按钮」 | `list.md §5` — suffix `button`（xs），**❌ 同时去掉 arrow，两者互斥**）|
| 「细分割线」 | `list.md §7` — `divider-primary` 0.5pt，从 content 左边界起 |
| 「组间大空白」 | 组间间距区，`bg-page`（`#F5F5F5`）填充 |
| 「底部操作栏」 | 固定在视口底部的 CTA Bar，配色查已加载的 visual-language 对应章节 |
| 「价格数字 / 金额数字」 | `font-price.md` Price Set Token + 价格色规则（默认 `red-default`；到餐 DPT5 用 `dpt5-o5`） |

**翻译完成后**，再按 D2 去读对应规范文件做精确核对，不要在翻译阶段就猜数值。

#### 组件路由总则（唯一路由源 = `references/INDEX.md`）

> **收口原则**：`SKILL.md` 只负责说明**什么时候必须先路由、什么时候必须停止、什么时候必须升级预读/验收**；所有“口语词 -> 合法组件名 -> 相邻候选排错 -> 强关联区域路由”统一以 `references/INDEX.md` 为唯一事实源。
>
> **执行顺序固定**：
> 1. 命中组件词、结构词、高歧义词时，先读 `references/INDEX.md` 的「组件路由注册表」「区域化强关联路由表」「高混淆组件图谱」
> 2. 再用 `references/component/component-quickref.md` 做宿主级收敛，不得拿收敛卡替代正文
> 3. 最后才按 A2/A3 把对应组件文件加入预读集合
>
> **本文件不再重复维护别名字典 / 样例表**：`navbar/header/footer/modal/chip/fab/alert/card/picker` 等口语词、别名与高歧义路由，一律回 `references/INDEX.md` 查，不在 `SKILL.md` 重复抄写第二份。
>
> **阻断规则**：若用户描述里的组件词无法唯一映射到 `INDEX.md` 中某个合法组件名，或命中高混淆组后仍无法写清“为什么是它，不是另一个”，必须立即停止当前生成并告知用户语义仍歧义/缺少规范；❌ 禁止任选一个“最像”的组件，❌ 禁止在 `SKILL.md` 中自造第二套路由口径。
>
> **高风险语义槽位**：当 `INDEX.md` 要求补充解歧时，至少补齐 `position / fixed / trigger / duration / interactivity / primary_task` 中与当前模块有关的证据，再进入 D2 / D3。

#### 受控页面结构词字典（命中先判结构层，再决定组件与布局，不得把结构词当组件名）

> **用法**：结构词描述的是**页面区块关系 / 栅格形态 / 承载方式 / 布局位置**，不是具体组件名。遇到结构词时，必须先确定它对应的是页面结构规则、栅格类型、还是某个组件承载关系；再去决定是否需要加载组件规范。❌ 禁止把「卡片流 / 金刚区 / 横幅 / 吸底区 / 信息分区」直接当组件名。

| 用户常说 | 规范化结构意图 | 唯一允许来源 / 后续动作 |
|---------|---------------|-------------------------|
| 「卡片流 / 推荐卡流 / 商品卡流」 | 页面级**单列或双列卡片栅格**，不是组件名 | `references/templates/grid-layout.md`；再根据区块内容决定是否用 `list.md` 或其他组件承载 |
| 「双列卡片 / 两列瀑布 / 双列推荐」 | **双列卡片栅格** | `references/templates/grid-layout.md §三`；❌ 不是 `card` 组件 |
| 「白卡片承载 / 白色信息卡 / 白底内容块」 | 页面白卡容器（留边圆角卡片） | `references/templates/grid-layout.md` + `references/semantic/radius-semantic.md` + `references/semantic/color-semantic.md` |
| 「通栏 / 全宽区块 / 贴边」 | 通栏栅格例外，而非默认布局 | `references/templates/grid-layout.md §四`；仅限横幅/地图/底部操作栏/系统设置分割线列表 |
| 「横幅 / Banner / 结果横幅」 | 顶部**全屏 Hero 横幅**结构（通栏例外之一） | 先查 `grid-layout.md §四` 判断是否可通栏；若含通知语义，再判定 `notification-banner` / `notice-bar` |
| 「状态横幅 / 订单状态 / 骑手已接单 / 待支付 / 已完成」 | **不是通栏**，属于普通圆角卡片 | 必须用 `border-radius:24px` 圆角卡片，❌ 禁止用 `width:750px; border-radius:0` 做通栏（见 checklist.md §B）|
| 「Hero / 头图 / 顶部大图」 | 顶部 Hero 区域结构 | `references/templates/grid-layout.md §四` + 业务 `visual-language`；不是独立组件名 |
| 「金刚区 / 宫格入口 / 快捷入口宫格」 | Icon Grid 结构区块 | `references/templates/icon-grid.md`；图标本身再查 `icon` 规范 |
| 「吸底区 / 吸底操作区 / 底部固定操作区」 | 固定底部结构区块 | 若承载 CTA 操作 → `references/component/components/bottom-action-bar.md`；同时遵守 `grid-layout.md §四` 通栏例外 |
| 「信息分区 / 分组信息 / 分段卡片」 | 页面区块分组关系 | `references/templates/grid-layout.md §五` + `references/semantic/spacing-semantic.md`；不是组件名 |
| 「列表区 / 信息区 / 表单区」 | 业务区块，不是自动等于某个组件 | 先按内容判断：结构化行信息 → `list.md`；填写项 → `form.md`；否则先走页面结构规则 |
| 「推荐模块 / 推荐区 / 猜你喜欢」 | 业务区块结构词 | 先走 `visual-language` 判断位置与气质，再用 `grid-layout.md` 判单列/双列；内容承载组件另判 |
| 「悬浮信息层 / 浮层操作区」 | 浮层结构，不等于具体组件 | 用户主动触发菜单 → `popover`；系统说明气泡 → `tooltip`；底部半页承载 → `bottom-sheets`；居中模态 → `dialog` |
| 「筛选区 / 筛选模块」 | 结构区块，不等于唯一组件 | 行内筛选条 → `filter`；展开面板/抽屉 → `filter-panel` |
| 「轮播区 / 轮播模块」 | 页面结构区块 | 当前 `INDEX.md` **无 `carousel` 组件**；只能在已有业务结构中用 `page-indicator` 辅助已有承载区，若用户明确要求轮播组件本体则必须停止 |
| 「系统设置列表 / 设置分割线列表」 | 通栏例外结构 | `references/templates/grid-layout.md §四`；若是具体行项承载，再用 `list.md`/`form.md` |
| 「内容容器 / 外层容器 / section」 | 页面区块容器 | `grid-layout.md` + `spacing-semantic.md` + `radius-semantic.md`；❌ 不是独立组件 |

> 🚨 **结构词判定顺序**：先判它是**栅格**（单列/双列/通栏）、还是**区块类型**（金刚区/推荐区/设置区）、还是**浮层结构**（吸底/弹层/悬浮），最后才决定是否需要某个组件文件。
>
> 🚨 **高风险结构词**：`卡片流`、`横幅`、`Hero`、`金刚区`、`吸底区`、`推荐模块`、`信息分区`、`轮播区`、`内容容器`。这些词若未先落到 `grid-layout` / `icon-grid` / `visual-language` / 具体组件之一，禁止继续生成。
>
> 🚫 **阻断规则**：若用户描述中的结构词无法唯一映射到页面栅格规则、区块结构规则或合法组件承载关系，**必须立即停止当前生成并告知用户「该结构描述在当前规范中无唯一对应项，需补充页面结构语义或补规范后再生成」**。❌ 禁止把结构词硬翻成 `card` / `banner` / `hero` / `section` / `carousel` 等伪组件。

#### 自然语言样式词 → 规范来源路由（必须逐条回溯，不得脑补）

当用户描述里出现样式词时，必须先将其路由到**唯一允许的规范来源**，再决定具体 Token / variant / size / state：

| 用户描述的样式词 | 唯一允许的来源 | 禁止事项 |
|----------------|---------------|---------|
| 颜色 / 背景色 / 渐变 / 品牌色 / 业务色 | `color-semantic.md` + `color-business.md`；业务归属由 `visual-language` 判断 | ❌ 禁止直接从 `visual-language` 抄 hex；❌ 禁止凭感觉近似选色 |
| 字号 / 字重 / 行高 / 大标题 / 小字 / 中黑 / 加粗 | `font-semantic.md`；若命中组件内部文字样式，则优先读对应组件 `.md` | ❌ 禁止自行把「regular」升成 `medium/semibold` |
| 价格数字 / 金额数字 | `font-price.md` + 价格色规则（默认 `red-default`；到餐 DPT5 用 `dpt5-o5`） | ❌ 禁止按普通文字 Token 处理价格 |
| 页面留白 / 页面边距 / 卡片间距 / 密度 | `grid-layout.md` + `spacing-semantic.md` | ❌ 禁止凭感觉写 `16px/20px/28px` |
| 组件内 padding / 图文 gap / 按钮图标间距 | `component-spacing.md`；若组件正文已给具体值，以组件 `.md` 为准 | ❌ 禁止页面层直接改组件内部间距 |
| 页面级圆角 / 卡片圆角 / 浮层圆角 | `radius-semantic.md` | ❌ 禁止把组件细圆角写成页面级圆角 |
| 组件内部细圆角 / 标签圆角 / 小气泡圆角 | `component-radius.md`；若组件正文已给具体值，以组件 `.md` 为准 | ❌ 禁止自行发明 `10px/18px/9999px` |
| 描边 / 分割线 / 边框粗细 | `stroke-semantic.md`；若命中组件内部边框，优先读组件 `.md` | ❌ 禁止直接写裸线宽 |
| 阴影 / 浮层感 / 悬浮感 | `shadow-semantic.md`；仅浮层类组件可用 | ❌ 禁止给普通卡片 / 按钮随意加阴影 |
| 图标名称 / 图标粗细 | `icon-quickref.md` → `icon.md §3` → `assets/iconfont.css` | ❌ 禁止凭感觉拼类名；❌ 禁止用 CSS `font-weight` 改粗细 |
| 组件高度 / 结构 / 插槽 / variant / size / state | 对应组件 `.md` | ❌ 禁止先写 CSS 再反推组件 |

#### 受控样式词字典（命中即按此归一，不得自由解释）

> **用法**：先把用户原词归一成「规范化意图」，再按右侧来源查规范。若同一词在当前上下文下**无法唯一归一**，必须停下来补充语义，不得猜测。

| 用户常说 | 规范化意图 | 唯一允许来源 |
|---------|-----------|-------------|
| 「胶囊 / pill / 药丸按钮」 | 先判断是 `button` / `tag` / `list` suffix `button` 三类之一；形状和高度由组件决定 | 对应组件 `.md` |
| 「小圆角」 | 若对象是页面卡片/容器 → 页面级圆角；若对象是标签/气泡/组件内部 → 组件细圆角 | `radius-semantic.md` 或 `component-radius.md`，必须先判断对象 |
| 「大圆角 / 圆润卡片」 | 页面级卡片或浮层圆角 | `radius-semantic.md` |
| 「直角 / 通栏 / 全宽」 | 仅四类通栏例外可用 `border-radius:0` + `width:750px` | `grid-layout.md` |
| 「灰底 / 浅灰底 / 弱底」 | 页面背景通常 `bg-page`；组件内次级背景通常 `bg-surface`；纯白承载面使用 `white` | `color-semantic.md` + 对应组件 `.md` |
| 「白卡片 / 白底卡片」 | `white` 背景 + 页面级卡片圆角 + 栅格 margin | `color-semantic.md` + `radius-semantic.md` + `grid-layout.md` |
| 「品牌黄 / 主按钮黄 / 美团黄」 | 业务主 CTA 色，先判断业务线和组件语义 | `visual-language` + `color-business.md`/`color-semantic.md` + `button.md`/`bottom-action-bar.md` |
| 「业务橙 / 品牌橙 / 强调橙」 | 橙色强调或主色，先判断场景是价格 / 标签 / CTA / Tab | `visual-language` + `color-semantic.md`/`color-business.md` |
| 「红色价格 / 到手价 / 折扣价」 | 价格色规则：默认 `red-default`，到餐 DPT5 用 `dpt5-o5` | `font-price.md` + `color-business.md` |
| 「大标题 / 主标题」 | 标题层级文字样式 | `font-semantic.md`；若在组件内则优先组件 `.md` |
| 「副标题 / 次级文字」 | 次级文字样式 | `font-semantic.md` 或组件 `.md` |
| 「辅助文字 / 弱化文字 / 灰字」 | `text-secondary` / `text-tertiary`，按信息层级判断 | `color-semantic.md` + `font-semantic.md` |
| 「中黑 / 中粗」 | `medium`（500） | `font-semantic.md` 或组件 `.md` |
| 「加粗 / 强调」 | 不可直接等于 `semibold`；需按文本层级或组件规范选择 `medium/semibold/bold` | `font-semantic.md` 或组件 `.md` |
| 「描边 / 细线 / 分割线」 | 描边宽度和颜色 | `stroke-semantic.md` 或对应组件 `.md` |
| 「阴影 / 悬浮感」 | 仅浮层类阴影 token，不等于普通卡片阴影 | `shadow-semantic.md` |
| 「返回箭头 / 返回 icon」 | NavBar 返回图标唯一指定 | `navigation.md` + `icon-quickref.md` |
| 「搜索框」 | `search-bar` 组件，不是手写输入框样式 | `search-bar.md` |
| 「评分星 / 打星」 | `rating` 组件 | `rating.md` |
| 「标签 / 胶囊标签 / 角标 / 徽标」 | 先区分 `tag` / `badge` 两类 | `tag.md` / `badge.md` |
| 「大按钮 / 小按钮」 | 先区分是否在 `bottom-action-bar` 内，再选 `size` | `button.md` / `bottom-action-bar.md` |
| 「紧凑 / 宽松 / 大留白」 | 栅格密度档位与 spacing | `grid-layout.md` + `spacing-semantic.md` |

> 🚫 **感受型词不是合法样式词**：如「高级一点」「更精致」「更轻盈」「更有设计感」「更柔和」等，不能直接翻译成 CSS 或 Token。必须先转译成可落到规范的描述（如字号层级/间距/圆角/背景层次/组件变体），否则停止。

**样式来源优先级（必须遵守）**：
1. **组件内部样式**（高度 / 圆角 / padding / 字号 / 图标规格 / 状态）→ **优先且只能**来自对应组件 `.md`
2. **页面层布局样式**（页边距 / 卡片间距 / 页面级圆角 / 背景层次）→ 来自 `grid-layout.md` + `semantic/`
3. **业务语义判断**（主色归属 / 页面气质 / 区块位置）→ 来自 `visual-language`
4. **`visual-language` 只决定“像谁”，不提供数值**

> 🚨 **阻断规则**：若用户明确提到的样式词无法映射到上表中的某个具体来源，**必须立即停止当前生成并告知用户「该样式描述在当前规范中无唯一对应项，需先补规范或改为现有规范词汇」**。❌ 禁止近似实现；❌ 禁止用“差不多”的 Token/variant 代替。

### D2：规范检索

规范文件分两类，加载时机和作用不同：

**【A0】模块盘点 + 槽位拆解（所有任务强制执行）**

> 🚨 组件检索的触发源不是“用户原话里有没有刚好说出组件名”，而是“页面实际将出现哪些模块、哪些可见槽位、哪些交互控件”。Fast Path 也不得跳过此步。

- **先列模块，不得直接按用户原话开文件**：根据 `page_mode`、默认模块顺序、用户显式需求，以及已有 HTML / 局部修改目标，先列出本页实际模块清单。
- **每个模块先拆槽位**：至少检查 `container / prefix-media / title-meta / inline-status / suffix-info / suffix-control / helper-action` 七类槽位；有就记，没有可留空。
- **系统槽位强制绑定（P0，不可省略）**：所有手机页面在 A0 草稿中必须显式列出 `status-bar` 与 `home-indicator` 两个模块，并在 `component_binding_map + slot_binding_map` 中绑定为 `final_component=system`、`ownership=host-owned(system)`、`source_file_section=references/component/components/system.md §3/§5/§6`；缺任一字段，禁止进入 `W1`。
- **选择态槽位强制归一（P0，不可省略）**：任何模块只要在 `suffix-control / inline-status / helper-action` 中出现单选 / 多选 / 勾选 / `aria-checked` / `role="radio"` / `role="checkbox"` / 圆圈勾选视觉，就必须在 `slot_binding_map` 中绑定为 `final_component=select`，并声明 `data-type="checkbox"` + `size/state`；❌ 禁止把选择态降级为 `icon`、字符、`.radio/.checkbox` 手写 CSS 或 `::after` 画对号。
- **高风险宿主先锁定（P0，先锁宿主再读正文）**：A0 只要命中以下结构，必须先把宿主组件锁成唯一候选，再进入 A2/A3 读取。
  - 顶部区域承担返回 / 标题 / 右操作任一导航语义 → 宿主先锁 `navigation`
  - 顶部区域同时有导航语义 + 搜索入口 → 组合先锁 `navigation + search-bar`，❌ 禁止先把搜索入口误落成 `text-input`
  - 底部固定区承担提交 / 购买 / 确认 / 价格+操作 → 宿主先锁 `bottom-action-bar`
  - 底部固定区承担 2~5 项页面主导航切换 → 宿主先锁 `bottom-navigation`
  - 反馈层需要蒙层或阻断确认 → 先在 `dialog / bottom-sheets` 中二选一；轻量短反馈再判 `toast / snackbar`
- **组件触发看并集，不看单一来源**：`用户原词 + 模块语义 + 槽位语义 + 现有 HTML 中可见控件/装饰痕迹` 四者任一命中，都必须触发对应组件 / icon 规范读取。
- **图标槽位强制绑定（P0，不可省略）**：任何模块只要在 `prefix-media / inline-status / suffix-info / suffix-control / helper-action` 中出现非文字 icon、箭头、放大镜、问号、关闭、加减、勾选、Tab 图标等可见图形，就必须在 `slot_binding_map` 中补一条 `icon-route` 记录，至少写明 `slot_name / semantic_intent / final_icon_class 或 fixed_svg_source / source_file_section / owner_decision`；❌ 禁止把 icon 留成“组件自带”但无出处，❌ 禁止手写 Unicode 字符、CSS 几何图形或猜测类名顶替
- **叶子槽位闭包检查（P0，不可省略）**：凡宿主模块命中 `navigation / list / form / filter-panel / bottom-sheets`，或其 `suffix-info / suffix-control / inline-status / helper-action` 任一槽位非空，A0 都必须逐槽回答“是否存在 `select / tag / badge / button / icon` 叶子”。`slot_binding_map` 不得只写宿主名或“组件自带”；若判定为宿主接管，必须同步写出 `host-owned + source_file_section` 证明宿主正文已接管。只要有一个可见叶子答不清最终来源，禁止进入 `A3/W1`。
- **局部修改时先审旧实现**：已有 HTML 只能当待审对象，不能当合法来源；看到字符箭头、手写圆点、自定义 pill、裸 div 控件时，先回查它应归属哪个组件或 icon 路由，再决定是否替换。
- **A0 的输出必须留痕**：进入 `A1/A2/A3` 前，先形成最小 `component_binding_map` 草稿和 `slot_binding_map` 草稿；没有草稿，禁止继续。
- **高混淆组首轮留痕（P0，不可后移）**：若模块命中 `INDEX.md` 的「高混淆组件图谱」/「区域化强关联路由表」，或命中 `component-quickref.md` 的「高混淆宿主收敛卡」，则 A0 草稿中除 `component_binding_map + slot_binding_map` 外，还必须同步补一条最小收敛记录：至少写明本模块的关键 `route_slots`，以及 `chosen_because / not_component / evidence_slots / owner_decision` 四段；这里只是首轮收敛留痕，不替代 `checklist.md §B` 的最终验收，但缺任一段时，禁止进入 `A3/W1`。

**【A1】Fast Path 最小读取（默认）**

> ⚡ **默认最小读取——普通生成只读以下 4 类，够用即停：**
> 1. `references/component/components/system.md` ← 页面骨架强制规范（Status Bar + Home Indicator）
> 2. `references/templates/grid-layout.md` ← 页面栅格与卡片布局
> 3. `references/semantic/color-semantic.md` + `references/semantic/font-semantic.md` ← 最常用颜色/文字 Token
> 4. `references/templates/visual-language/{业务线对应文件}.md`（只跳到「组件位置规律」与当前页面章节，无需扩大阅读）
>
> **Fast Path 原则**：以上最小集合只负责页面骨架、业务语义和主视觉判断；**不等于可跳过组件正文**。能用以上最小集合唯一确定页面骨架、主色语义、信息层级时，**不得继续预读无关文件**；但只要 `A0` 的模块清单 / 槽位拆解命中组件语义，仍必须补读对应组件 `.md`，不得因“用户没说出组件名”或“Fast Path 要省文件”而跳过。
>
> **升级到 Full Harness 后，再补读：**
> - `references/checklist.md §A`
> - `references/semantic/spacing-semantic.md`
> - `references/semantic/component-spacing.md`
> - `references/semantic/radius-semantic.md`
> - 以及下方 A2/A3/B 中命中的按需文件
>
>    **🗺️ 业务线代码 → 文件名对照表（❌ 禁止猜测，必须按此表查找）**
>
>    | 业务线代码 | 中文关键词（任意一词命中即可） | 文件名 |
>    |-----------|--------------------------|-------|
>    | `platform` | 美团平台、美团首页、搜索结果、推荐、AI助手、小美评审团、评价、消息、账号、个人主页、附近、直播、短视频、拼团、晚8清仓、网约车、打车、地图、POI、通用、架构、商场 | `美团平台设计中心.md` |
>    | `waimai` | 外卖、外卖履约、外卖流量、外卖交易、外卖搜索、外卖售后、拼好饭、神抢手、跑腿、到家、骑手接单、外卖退款 | `外卖履约平台设计中心.md` |
>    | `tuangou` | 团购、到餐、特价团、特团、团购频道、服务零售、门店导购、秒提、核销码、到店、美食团购、门店团购 | `团购软硬件服务设计中心.md` |
>    | `medical` | 医药、健康、问诊、问医生、买药、药品、健保、医美、互医、消费医疗、拍药、药品详情 | `医药健康设计中心.md` |
>    | `hotel` | 酒店、旅行、民宿、度假、大交通、飞机票、火车票、景点、游玩、出行、境外酒店、订酒店、出票成功、购票成功 | `酒店旅行设计中心.md` |
>    | `shangou` | 闪购、即时零售、神券频道、频道营销、基础选购 | `闪购设计中心.md` |
>    | `grocery` | 食杂、小象超市、小象、超市首页、买菜、食杂零售、营销增长（食杂场景） | `食杂零售设计中心.md` |
>    | `finance` | 金融、收银台、支付、钱包、余额、微贷、月付、先用后付、保险、亲情卡、骑行、共享单车、充电宝、投保、续保 | `金融服务设计中心.md` |
>    | `generic` | 通用/不确定（无法匹配以上任一） | 降级使用 `美团平台设计中心.md` |
>
>    ⚠️ **用途锁定**：`visual-language` 仅用于**理解业务场景**，**不是数值来源**。
>    ❌ 禁止从 `visual-language` 中提取任何数值（px/pt/hex/Token 数字段）。
>
> ❌ 禁止串行读取；以上 9 个文件互相独立，并行读取不影响任何设计决策质量。

**【A2】条件并行文件（有对应场景时才加载，否则跳过，共 11 个）**

| 条件 | 加载文件 | 说明 |
|------|---------|------|
| 🚨 **页面含业务专属色 / 渐变色时必须加载**（即业务线为以下任一：小象超市/食杂零售、拼好饭/外卖、医药健康、闪购、酒店旅行、大交通/度假、金融/支付；或设计稿中有 DPT 渐变色） | `references/semantic/color-business.md` | DPT1～DPT14 业务专属色；**声明表①「是否有业务专属色覆盖」一栏必须查此文件填写**，❌ 禁止凭记忆填写；**外卖通用主 CTA 默认仍是 `gradient-yellow`；命中业务覆盖时，再按既有映射切到专属 CTA 色：团购软硬件 `orange-default`、直播特价团 `dpt1-g-m`、拼好饭 `dpt3-g-r`、神枪手 `dpt4-g-b`、到餐 `dpt5-g-or` / `dpt5-g-yo`、医药健康·买药 `dpt7-g-t`、小象超市 `dpt12-g`、美团公益 `dpt13-t`；问诊场景主 CTA 用 `green-default`。`orange-default` 仅用于价格 / 标签 / Tab / 强调信息，不得充当外卖底部主 CTA 背景** |
| 页面有**价格数字**（¥ 符号 / 整数 / 小数，外卖/电商/订单页几乎必中） | `references/semantic/font-price.md` | Price Set Token — 字号/字重/颜色不可自定义；❌ 禁止按普通文字 Token 处理价格 |
| 页面有**描边元素**（输入框/分割线/卡片描边） | `references/semantic/stroke-semantic.md` | border-default / border-bold 等宽度 Token |
| 页面有**按钮**（CTA / 操作按钮） | `references/component/molecules/button.md` | 先读🗺️速查导航，再用 `offset` 跳对应 variant/size 节 |
| 页面有**导航栏**（NavBar / 返回按钮） | `references/component/components/navigation.md` | 先读🗺️速查导航定位 type，再跳对应规格节 |
| 页面有**底部操作栏**（Bottom Action Bar / CTA Bar） | `references/component/components/bottom-action-bar.md` | 先读🗺️速查导航定位 variant，再跳对应规格节 |
| 页面有**底部导航**（Bottom Navigation / Tab Bar / 2~5 项切页） | `references/component/components/bottom-navigation.md` | 固定底部导航切页，和 CTA Bar 二选一，不得混用 |
| 页面有**搜索入口**（独立搜索 / 导航内搜索） | `references/component/components/search-bar.md` | 搜索入口高频串型；导航内搜索必须与 `navigation` 同批读取 |
| 页面有**选择态控件**（Radio / Checkbox / 勾选 / 选择状态） | `references/component/components/select.md` | 选择态视觉统一走 `select`，禁止降级成 `icon` 或手写 CSS |
| 页面有**标签或角标**（Tag / Badge / 胶囊标签 / 红点 / 未读数） | `references/component/molecules/tag.md` + `references/component/components/badge.md` | 行内标签与角标必须前置区分所有权，避免互串 |
| 页面有**筛选入口或展开层**（Filter / Filter Panel） | `references/component/components/filter.md` + `references/component/components/filter-panel.md` | 收起态入口与展开层承载必须成对区分 |

> 💡 上述 A2 文件与 A1 文件完全独立，可与 A1 同批并行发起——有对应场景时直接合并进 A1 的并行读取批次中，不需要等待 A1 完成。
> 🚨 **前置降失败率规则（新增）**：命中新增高风险文件时，属于首轮路由锁定的一部分，❌ 不得等到 `W1` 才想起补读；否则即使 `§B` 能拦住，首轮生成成功率也会持续偏低。

**【A3】基于路由结果的组件预读协议（A3 不负责重新路由）**

> 🚨 A3 的唯一职责，是把已经在 `references/INDEX.md` 与 `references/component/component-quickref.md` 中收敛出的 `route_result`，转换成**本轮必须读取的文件集合**。A3 不再用关键词表重新决定组件家族；“谁是宿主 / 为什么不是另一个”只允许在 `INDEX.md` 完成。
> 🚨 **强关联链（继续保留）**：命中 `references/INDEX.md` 的「区域化强关联路由表」任一行时，必须同步完成四件事：① 按 `INDEX.md` 先锁宿主；② 按 `references/component/component-quickref.md` 完成宿主级收敛；③ 把该行要求的文件加入当前任务的预读集合；④ 在 `checklist.md §B` 的对应白名单项中准备最终验收。四者缺一，视为路由链未闭合。
>
> **进入 A3 前必须已有的最小结果**：`host_component`、`matched_strong_route`（若命中强关联行）、`leaf_slots`、`rejected_candidates`。缺任一关键项，先回 `INDEX.md` 补路由，不得在 A3 内继续猜。
>
> **执行顺序固定**：
> 1. 若命中 `INDEX.md` 的「区域化强关联路由表」，先把该行 `必须联读文件` **整组**加入预读集合；这是 A3 最高优先级
> 2. 若未命中强关联行，则按 `host_component` 去 `INDEX.md` 的「组件路由注册表」读取 `唯一文件`
> 3. 再按 `leaf_slots` 补叶子文件：选择态 → `select.md`；状态/权益标签 → `tag.md`；未读/角标 → `badge.md`；操作按钮 → `button.md`；非文字 icon → `icon-quickref.md`（找不到再读 `icon.md §3`）
> 4. 若 `host_component=form`，再按子控件语义补 `text-input.md` / `select.md` / `time-date-picker.md` 其一；若 `host_component=list`，只补实际出现的叶子文件，不得把整行结构误升格成 `form`
> 5. 若当前结果仍只是结构层结论（白卡容器 / Hero / 金刚区 / 推荐模块等），继续停在结构规则，不得提前补无根据的组件正文

| `route_result` 状态 | 必须加入的预读文件 | 说明 |
|---------------------|------------------|------|
| 命中 `INDEX.md` 强关联行 | 直接使用该行 `必须联读文件` | A3 不得降配，也不再另起一张关键词触发表 |
| `host_component` 已唯一落定，且在 `INDEX.md` 路由注册表中有 `唯一文件` | 读取该 `唯一文件` | 宿主先于子组件 |
| `host_component=navigation` 且导航内有搜索 | `navigation.md + search-bar.md` | `search-bar` 是子槽位，不得误走 `text-input` |
| `host_component=bottom-action-bar` | `bottom-action-bar.md + button.md` | 若出现非文字 icon，再补 `icon-route` |
| `host_component=bottom-navigation` | `bottom-navigation.md`；有未读数再补 `badge.md` | 底导与 CTA Bar 二选一 |
| `host_component=list` / `form` | 宿主文件 + 实际叶子文件（`select/tag/badge/button/icon`） | 不按“长得像”额外补其他宿主 |
| `leaf_slots` 含单选 / 多选 / 勾选 / 圆圈对勾 | `select.md` | 选择态优先级高于普通 icon |
| `leaf_slots` 含非文字 icon | `icon-quickref.md`；找不到再 `icon.md §3` | 普通业务 icon 不得跳到 inline SVG |
| 已直接命中 `INDEX.md` 组件名全集中的精确组件名，且未在路由注册表列出 | `icon -> component/atoms/icon.md`；`button/tag -> component/molecules/*.md`；其余合法组件名 -> `component/components/{name}.md` | 仅在组件名已经是合法最终名时适用 |
| 仍存在 2 个及以上未排除候选 | ❌ 停止，不得进入预读 | 先回 `INDEX.md` 完成路由收敛 |

> 🚨 **现有 HTML 痕迹的使用边界**：只能作为 `route_slots` 证据帮助判断宿主 / 叶子，不得因为现有 DOM “长得像”某组件就跳过路由或直接补读。
>
> 💡 A3 产出的只是“预读集合”，不是新的组件结论。真正的组件结论仍以 `INDEX.md + component-quickref.md + component_binding_map` 为准；若三者与 A3 结果不一致，视为链路断裂。

**【B】硬边界参考（按需查阅，遇到对应场景才读）**

以下文件提供不可违反的约束值，遇到对应场景才读，无强制顺序。【A】中已加载的文件❌ 无需重复读取：

| 场景 | 必须读取的文件 |
|------|-------------|
| 页面含**价格数字** | 已在 A2 并行加载，❌ 无需重复读取 |
| 写**组件内部**细粒度圆角（≤ 4pt，如标签、气泡尖角） | `references/semantic/component-radius.md` ← cr-{N} Token，禁止裸写 pt 数值 |
| 页面含**浮层类组件**（Popover / Toast / Tooltip / FAB / 半页弹窗等需要阴影的元素） | `references/semantic/shadow-semantic.md` ← shadow-* Token；注意绝大多数卡片/筛选器不加阴影 |
| 查阅**组件属性、变体**（每个模块按需查） | `references/component/` 对应文件；button / navigation / bottom-action-bar 已在【A】并行加载，❌ 无需重复读取；图标优先查本 SKILL「🖼️ 图标速查表」，找不到再读 `icon.md §3` |
| 验证**原始色值/字号/圆角原始值** | `references/reference/` 对应文件（仅验证时读，不得直接在输出中使用原始值） |
| **最终合规性兜底** | `references/design-principles/` |

### D3：设计方案生成

**思维顺序：先信息层级 → 再组件选型 → 最后 Token 落地。** 不要从组件出发再填内容，这样生出的页面是零件堆叠，而不是设计。

**① 建立信息层级**

基于已加载的 visual-language，先在内部确定这个页面的三层信息结构：

| 层级 | 问题 | 典型答案示例 |
|------|------|------------|
| **第一优先级**（用户最需要看到的） | 这个页面最核心的一个信息/动作是什么？ | 价格 + 购买按钮 / 订单状态 / 评分总分 |
| **第二优先级**（支撑决策的信息） | 哪些信息帮助用户做判断？ | 商品名、评价摘要、配送时间 |
| **第三优先级**（辅助/次要信息） | 哪些信息弱化处理？ | 时间戳、距离、角标说明 |

确定三层后，决定**强调手段**（来自 visual-language 的业务线主色用在哪里、字号大小差异如何拉开、背景色如何分区）。

> **排版决策口诀**：标题要粗要大、正文要可读、辅助信息要弱化、空白要舍得给。用**字号差异 + 字重对比 + 颜色深浅**三重手段建立层次，不要让全页文字重量相近。具体：第一优先级信息用最大字号 + semibold；第二优先级用中等字号 + regular 深色；第三优先级用最小字号 + regular `text-tertiary(#888888)` 弱化。

**② 组件选型（强制执行，不可跳过）**

信息层级确定后，**必须逐个模块查阅 `references/component/`**，找到对应组件后才能进入第四步。选型原则：
- 优先找**语义最匹配**的组件，而不是形状最像的
- 若规范内有现成变体，直接用，不创造新变体
- 若同一信息有多个可选组件，选**信息密度最贴近 visual-language 规律**的那个
- 若多个组件都不完全匹配，**禁止折中发明新组件**；必须回到 `INDEX.md` 和对应组件正文重新比对，仍无结论则停止并告知用户，不得继续生成

> 📌 **组件完整性约束细则（对应「工作姿态 ⛔ 绝对禁止修改」四类，选型全程执行）**
>
> **① 来源核查**：列出组件清单后，逐条在 `INDEX.md` 组件名全集三张表中验证存在性；不存在的立即删除，不得进入下一步。
>
> **② 数值核查**：每个组件的 `size` / `height` / `padding` / `border-radius` 等数值，必须从对应 `.md` 文件的规范表格中**逐字复制**，❌ 禁止凭印象填写——即使误差只有 2px 也视为违规。
>
> **③ Token 核查**：组件 CSS 中出现的颜色/字号/间距，必须使用 `semantic/` 层 Token 名（通过 `checklist.md` 速查表转为 hex），❌ 禁止直接写原始值。如遇 Token 在 `semantic/` 层找不到，停止并告知用户而非自行补充。
>
> **④ 变体核查**：`data-variant` / `data-size` / `data-state` 的取值，只能是规范文件中**明确列出**的选项，❌ 禁止组合不兼容的 variant（参见 `checklist.md` 组件使用陷阱区块中各组件的数量/类型约束）。

> 🚨 **Step 0：对照组件名全集核验（必须在选型前完成，不可跳过）**
>
> `references/INDEX.md` 中「🗂️ 组件名全集」三张表（atoms / molecules / components）是**组件的唯一权威来源**。
> 在列出页面所需组件清单后，**逐条检查每个组件名是否存在于全集表中**：
> - ✅ 存在 → 读对应 `.md` 文件查变体
> - ❌ 不存在 → 该组件名为幻觉，**必须立即停止当前生成并告知用户「该组件无对应规范，需先补组件规范后再生成」**；❌ 禁止改用已有组件组合兜底；❌ 禁止注释「无对应组件规范」后继续生成
>
> **全集表当前收录 34 个主引用入口**（atoms 1：`icon` / molecules 2：`button`、`tag` / components 31；另有 `component/components/tag.md` 1 个历史兼容文件，见 INDEX.md 完整列表）。常见幻觉组件举例（**以下均不存在，一律禁用**）：
> `card`、`carousel`、`accordion`、`header`、`footer`、`navbar`（正确名：`navigation`）、`modal`（正确名：`dialog` / `bottom-sheets`）、`alert`（需在 `notification-banner` / `notice-bar` / `snackbar` / `toast` / `dialog` 中二次判定）、`chip`（正确名：`tag`）、`fab`（正确名：`floating-action-button`）

> 🚨 **强制阻断规则——禁止自造组件（最高优先级，不可违反）**：
> - ❌ **禁止自写 CSS 类模拟任何有规范的组件**（如自写 `.my-btn`、`.badge`、`.tag-pill` 等）
> - ❌ **禁止把业务图标一律改成 SVG 内联**，常规 icon 必须来自 `icon.md`；不确定名称时先查 `icon.md §3`，找不到不得猜测
> - ✅ **仅两类例外允许且必须直接复用 inline SVG**：`stepper.md §6.5` 的加减号图标；`system.md` 中 Status Bar 的官方 SVG。两者都不得改写为 iconfont 或手绘路径
> - ❌ **禁止在 `INDEX.md` / A3 预读协议中找不到时直接跳过或随机套近似组件**；若组件词经路由后仍无法唯一命中 `references/component/` 的合法文件，必须停止并告知用户缺少规范或语义仍歧义，不得自定义组件、不输出该区域 HTML
> - ✅ **每个模块使用的组件必须能对应到 `references/component/` 中一个具体文件 + 具体变体**，否则视为未完成选型，不得进入第四步

**③ 整理设计方案（内部决策，直接进入第四步）**

整理以下内容作为第四步 HTML 生成的输入，**无需输出给用户、无需等待确认，直接开始第四步**：
- 页面区块划分 + 每个区块的组件列表
- 各组件的 variant / size / state 声明
- 强调色使用位置（来自 visual-language 的主色用在哪些元素）
- 布局约束（栅格密度档位、关键间距来源）
- **布局规则（强制，不可违反）**：🚨 **默认单列卡片栅格**，页面背景 `#F5F5F5`，所有内容区块用白色留边圆角卡片承载；❌ 禁止任何情况下默认通栏。例外场景（须严格限定，不可扩大）：

  | 例外区块类型 | 布局 | CSS 规则 |
  |---------|---------|----------|
  | 顶部全屏 Hero 横幅 / 地图 / 图片 Hero 区域 | 通栏 | `width:750px; border-radius:0;` |
  | 底部操作栏（Bottom Action Bar） | 通栏 | `width:750px; border-radius:0; position:sticky; bottom:0;` |
  | 系统设置分割线列表（设置页类、单纯列表型） | 通栏 | `width:750px; border-radius:0; background:#FFFFFF;` |

  > ⚠️ **订单状态横幅（骑手已接单 / 待支付 / 已完成等）不属于通栏例外**，必须作为普通圆角卡片（`border-radius:24px`），与 checklist.md §B 保持一致。

  > 🚨 **所有其他区块（配送进度、地址行、商品清单、价格明细、推荐卡等）→ 全部用白色卡片**：`border-radius:24px; background:#FFFFFF;`，左右 margin 和卡片间距以**栅格密度档位为准**（默认适中型：margin=**24px** / 卡片间距=**16px**，查 `grid-layout.md`），不用色带隔断。❌ 禁止把整页做成通栏。
- **间距决策（必填，不得留空）**：逐层确定以下间距来源，第四步写 CSS 时必须严格引用，❌ 禁止自行估算任何间距数值：

  | 间距层级 | 来源文件 | 取值方式 |
  |---------|---------|----------|
  | 页面内容区左右 margin | `references/templates/grid-layout.md` 对应密度档位 | 直接用（已是 @2x）|
  | 卡片内部 padding | `references/templates/grid-layout.md` 对应密度档位 | 直接用 |
  | 卡片与卡片的间距（组间距） | `references/semantic/spacing-semantic.md` | 取语义 Token，×2 写 px |
  | 组件内部间距（图文间距、按钮图标+文字间距） | `references/semantic/component-spacing.md`；若组件正文写明具体值，则组件正文优先 | 取语义 Token，×2 写 px |
  | 列表行高 | `references/component/components/list.md` 对应 size | ×2 写 px |
  | 图标与文字 / 图标与容器边缘 | 先看对应组件 `.md` 的固定 icon 约束；无显式值再看 `component-spacing.md` | ❌ 禁止从页面栅格反推 icon 内间距 |

- **间距归属核对（P0，写 CSS 前必须内部回答）**：
  - **页面层**：页面左右 margin、白卡外间距、模块节奏，只能来自 `grid-layout.md` + `spacing-semantic.md`
  - **组件层**：按钮内边距、搜索框内文字与 icon gap、列表行 prefix/content/suffix 内部距离、底栏内部按钮排布，只能来自对应组件 `.md`；组件正文缺省时才允许回 `component-spacing.md`
  - **图标层**：icon 大小、字重、与文字的配对间距优先服从宿主组件；宿主未声明时再查 `icon-quickref.md` 与 `component-spacing.md`
  - **阻断**：若某个间距值只能用“看着差不多”解释，或同时能被页面层/组件层两边解释但没有 owner，必须回 `D3` 重做 binding object，不得继续写 HTML

**检查点**：页面组件清单已逐条通过 `INDEX.md` 组件名全集核验 → 继续下方声明表；有未找到的组件 → 停下来补全选型（查 `references/component/atoms/icon.md`、`references/component/molecules/tag.md`、`references/component/components/list.md` 依次确认）后再继续；布局已确认默认单列卡片、通栏例外已填写完整 → 继续下方声明表。

---

### ⛔ D3 → W1 决策门槛（默认快路径，必要时升级完整声明表）

> **Fast Path（默认）**：只需在内部确认最小决策集：`page_mode / 主组件家族 / CTA 位置 / 主 CTA 色 Token / 顶区背景联动（status-bar/nav） / 栅格档位 / 关键风险点 / 命中混淆组模块的 route_slots + exclusion_reason（chosen_because / not_component / evidence_slots / owner_decision） / component_binding_map / slot_binding_map / component_audit_map`，确认后直接进入 `W1`。
> **Full Harness（升级后）**：若命中高风险条件，再补齐完整声明表；只有此时才需要把声明表完整展开。
>
> **原因**：决策要先于 HTML，但不代表每次都要把完整声明表对外展开。普通任务默认保留最小决策，避免把 token 和时延浪费在低风险显式展开上；真正高风险时再升级完整约束。

**执行方式**：
- **Fast Path**：内部记录最小决策集，不对外输出完整声明表，直接进入第四步。
- **Full Harness**：在开始写任何 HTML/CSS 之前，补齐下方完整声明表；有空白项或「估算」字样，禁止进入第四步。

**组件防幻觉绑定协议（P0，优先级高于“凭感觉像”）**：
- **先列模块，再列候选，不得直接写 HTML**：每个页面模块先写出 `模块名 → 候选组件集合`；候选集合只允许来自 `INDEX.md` 的组件路由结论与页面结构词字典，❌ 禁止脑补第三来源
- **候选数必须收敛**：每个模块进入 `W1` 前，候选集合只能是以下三种状态之一：① `1 个合法组件`；② `结构容器 + 1 个合法承载组件`；③ `无合法组件 → 停止并告知用户补规范`。❌ 只要仍有 `2 个及以上` 未排除候选，禁止进入 `W1`
- **组件名必须先归一**：HTML 中禁止出现用户口语词、伪组件名或中间别名；写入前必须先归一成 `navigation` / `bottom-action-bar` / `filter-panel` 这类 `INDEX.md` 中真实存在的最终组件名
- **组件绑定必须带来源**：每个模块最终都要形成 `模块名 → 合法组件名 → 来源文件 § → variant/size/state` 的绑定链；缺任一环都视为未完成选型
- **叶子槽位必须绑定**：每个模块的 `inline-status / suffix-info / suffix-control / helper-action` 等可见叶子槽位，要么由宿主组件正文明确接管，要么在 `slot_binding_map` 中单独绑定到 `tag / badge / select / button / icon` 等合法来源；❌ 禁止把这些槽位留成“顺手写个 div / 字符 / CSS 圆点”
- **选择态叶子槽位必须直绑 `select`**：只要某个叶子槽位承担“是否被选中”的可见反馈，不论宿主是支付方式行、表单行、筛选项还是列表项，其最终组件固定为 `select`；若仅需单选逻辑，则在业务层用 `role="radio"/radiogroup` 区分，视觉组件仍按 `select.md` 落地。❌ 禁止用 `icon`、手写圆圈或伪元素对号冒充 `select`。
- **结构词与组件词分流**：`card`、`hero`、`banner`、`section`、`金刚区`、`推荐模块` 先落结构层；只有完成结构判定后，才允许继续决定承载组件。❌ 禁止因为视觉像组件就直接落成组件名
- **HTML 只允许消费已绑定结果**：`W1` 写 HTML 时，只能使用已在最小决策集或完整声明表中出现过的宿主组件与叶子槽位绑定；写 HTML 过程中若冒出新的组件候选或新的 icon / control / tag 槽位，必须立刻回退到 `D2/D3`，不得边写边补

**Binding Object（最小绑定对象，Fast Path 必留痕）**：
- 每个页面模块在进入 `W1` 前，内部都必须形成一个最小绑定对象：
  - `module_name`
  - `raw_user_phrase`
  - `structure_intent`
  - `route_slots`（至少含 `position / fixed / trigger / duration / interactivity / primary_task` 中与当前模块有关的字段）
  - `candidate_set`
  - `final_component`
  - `source_file_section`
  - `variant / size / state`
  - `ownership`
  - `slot_binding_map`（写清非文本可见槽位由 `host-owned / child-component / icon-route` 哪一类接管）
  - `exclusion_reason`
- **没有 binding object = 没完成选型**。即使模型“心里已经想清楚”，也视为未绑定，不得进入 `W1`；缺少 `slot_binding_map` 也视为未完成。
- **`slot_binding_map` 中的 icon-route 不得留空**：凡出现 icon 槽位，必须明确是 `iconfont-class` 还是 `fixed-svg-exception`（仅 `stepper` 加减号、`system` 状态栏 SVG 两类），并写出来源；若只写“有个 icon”或只写语义名不写最终来源，视为未完成绑定
- **`slot_binding_map` 必须形成叶子闭包**：凡 `suffix-info / suffix-control / inline-status / helper-action` 任一槽位非空，都必须明确回答该槽位最终由 `host-owned` 还是 `tag / badge / select / button / icon-route` 接管；若写 `host-owned`，必须补 `source_file_section` 证明宿主正文已接管；❌ 禁止只写“宿主组件已覆盖”却不给出处，❌ 禁止留“待实现 / 默认带出 / 组件自带”这类空答案。
- **`exclusion_reason` 必须结构化留痕（新增强制门槛）**：每个命中过高混淆组件图谱或区域化强关联路由表的模块，`exclusion_reason` 不得只写一句自然语言，至少必须包含：`chosen_because`（为什么是它） / `not_component`（为什么不是另一个） / `evidence_slots`（使用了哪些 `route_slots` 证据） / `owner_decision`（宿主与子组件所有权怎么判） 四项；缺任一项，视为未完成绑定。
- **系统组件来源断言（新增强制门槛）**：`component_binding_map + slot_binding_map` 中必须存在 `status-bar` 与 `home-indicator` 两条记录，且 `final_component` 固定为 `system`；若写成自定义容器、空壳占位或其它组件名，直接判定 `back_to_D3`，不得进入 `W1`。
- Fast Path 至少保留 `component_binding_map + slot_binding_map` 的压缩版；若命中混淆组或强关联行，压缩版中也必须保留该模块的 `route_slots + exclusion_reason` 四段模板，不得只剩“最终组件名”。Full Harness 则在下方声明表中完整展开。

**Ownership Protocol（所有权协议，谁能决定什么）**：
- **先判宿主，再判子组件**：只要一个组件被嵌入另一个组件的固定组合场景，必须先确认宿主组件拥有哪些控制权，再判子组件还能改什么。
- **所有权至少拆成三类**：
  1. `layout_owner`：谁决定高度、容器宽度、对齐、占位、安全区
  2. `style_owner`：谁决定背景、描边、主题样式、组合态外观
  3. `behavior_owner`：谁决定触发方式、展开收起、选中切换、反馈时机
- **子组件不得越权改写宿主已锁定字段**：若 `layout_owner/style_owner/behavior_owner` 已被父组件接管，子组件只允许消费剩余合法配置，❌ 禁止反向覆写。
- **间距 owner 必须单点归属**：每个间距位点在进入 `W1` 前都必须能唯一回答“谁拥有这段距离”。页面外边距/卡片间距/区块节奏 → `grid-layout.md` + `spacing-semantic.md`；组件内部 padding/gap → 先看组件 `.md`，未写明才看 `component-spacing.md`；行高/控件高度附带的内部空隙若组件正文已显式给值，一律视为组件 owner。❌ 禁止同一位点同时混用 `gap + 子元素 margin`，❌ 禁止页面层覆写组件内部 spacing
- **高频强制例子**：
  - `navigation` 嵌 `search-bar` 34pt 组合场景：`navigation` 是 `layout_owner + style_owner`，锁定 `size=68` / `style=gray`
  - `form` 嵌 `text-input` / `select`：`form` 是行级 `layout_owner`，子组件只拥有内部输入/选择行为
  - `bottom-action-bar` 嵌 `button`：Bar 拥有底部容器与按钮排布，按钮只消费合法 `size=l`
  - `filter` → `filter-panel`：`filter` 是收起态入口，`filter-panel` 是展开层承载；两者不是互相替代关系
- **若所有权无法唯一判断，视为仍未完成路由收敛**，必须回 `D2/D3`，不得先写 HTML 再靠 `§B` 兜底。

**组件自检轮询协议（Bounded Audit，最多 2 轮）**：
- **先绑定，后自检，再写 HTML**：每个已绑定模块在进入 `W1` 前，都要按同一顺序跑一次组件自检；❌ 禁止“边写 HTML 边顺手检查”
- **固定六项核验**：① 合法组件名是否存在于 `INDEX.md`；② `来源文件 §` 是否唯一可回溯；③ `variant/size/state` 是否是组件正文允许值；④ 结构上下文是否成立（如 `bottom-action-bar` 不能代替主导航、`list` 不能直接冒充白卡容器）；⑤ 相邻候选的排除理由是否足够具体；⑥ 若槽位承担选择态反馈，最终绑定是否为 `select`，且未出现 `.radio/.checkbox`、伪元素对号或纯 icon 替代
- **轮询只修 1 个根因**：任一核验失败时，只允许标记本轮主失败项并回退到 `D2` 或 `D3` 修 1 个根因；修完后必须从第 ① 项重新开始整轮自检，❌ 禁止在失败点后面继续硬跑
- **收敛上限固定**：同一模块最多只允许 **2 轮** 自检；第 2 轮后仍未得到 `通过`，视为规范不足或选型不稳定，必须停止并告知用户补规范，❌ 禁止带着“暂时先这样”进入 `W1`
- **Fast Path / Full Harness 都要留痕**：Fast Path 在内部最小决策集中补 `component_audit_map`（模块 → `pass / back_to_D2 / back_to_D3 / stop`）；Full Harness 在下方补 `②.6 组件自检轮询记录`

**首轮直出绑定（高频错误前移，不等 `§B` 兜底）**：
- **主 CTA 色先绑定再生成**：外卖通用 / 跑腿 / 退款 / 去结算等主操作默认 `gradient-yellow`；命中业务覆盖时，再按既有映射切到专属 CTA 色：团购软硬件 `orange-default`、直播特价团 `dpt1-g-m`、拼好饭 `dpt3-g-r`、神枪手 `dpt4-g-b`、到餐（DPT5）`dpt5-g-or` / `dpt5-g-yo`、医药健康·买药 `dpt7-g-t`、小象超市 `dpt12-g`、美团公益 `dpt13-t`；问诊场景主 CTA 用 `green-default`。`orange-default` 仅用于价格 / 标签 / Tab / 强调信息，❌ 不得作为外卖底部主 CTA 背景。
- **顶部一体化先绑定再生成**：页面存在 NavBar、顶部色块或首屏 Hero 时，先确定 `status-bar` 背景 = NavBar / 顶部区域背景，HTML 中显式写出，不得依赖透明透底后再让验收发现断层。
- **状态栏图标先选资源再生成**：按顶部背景亮度先决定 `Black.svg` / `White.svg`，浅色顶区用 `Black.svg`，深色顶区用 `White.svg`；❌ 禁止先随便放一个再靠修复环回滚。

#### 🔴 Full Harness 必填声明（仅升级后必须完整展开）

**⓪ 页面模式 Schema**

| 项目 | 声明内容 |
|------|---------|
| 页面模式 `page_mode` | {上述 12 个合法值之一}，来源：{用户描述关键词 + `page_stage` + `visual-language` 文件 §} |
| 页面首要目标 `primary_goal` | {只能 1 个} |
| 第一优先级信息 `primary_info` | {只能 1 个} |
| CTA 优先级 `cta_priority` | `{front / middle / back / weak}`，原因：{页面模式} |
| 密度模式 `density_mode` | `{compact / balanced / relaxed}`，映射到栅格：{16px / 24px / 32px} |
| 业务气质来源 `tone_source` | `{visual-language 文件名 §章节}` |
| 禁止偏差 `forbidden_bias` | {本页最不允许出现的偏差 1 条} |
| 默认模块顺序 `module_order` | {按该 `page_mode` 的默认顺序逐项填写，不得漏项} |
| 禁忌排序 `forbidden_order` | {至少写 1 条当前模式禁止出现的排序错误} |

**① 业务线 & 主色**

> 主 CTA 色先由 `visual-language` 判定业务线与场景，再映射到合法 Token：**通用主 CTA** 查 `color-semantic.md` + `button.md` / `bottom-action-bar.md`，**业务专属覆盖**再查 `color-business.md` / 既有业务规则（如团购软硬件 `orange-default`、直播特价团 `dpt1-g-m`、拼好饭 `dpt3-g-r`、神枪手 `dpt4-g-b`、到餐 DPT5、医药健康·买药 `dpt7-g-t`、小象超市 `dpt12-g`、美团公益 `dpt13-t`；问诊场景主 CTA 用 `green-default`）；❌ 禁止把 `orange-default` 当外卖底部主 CTA 背景。

| 项目 | 声明内容 |
|------|---------|
| 业务线 | {业务线名称} |
| 主 CTA 色 Token | {Token名} = {hex值}，来源：{visual-language文件名 §章节} |
| 是否有业务专属色覆盖 | 是 → `{dpt-token}` = `{hex}`，来源：`color-business.md §{章节}`；否 → 无 |
| 价格 / 金额文字色 | 默认 `red-default` = `#FF2D19`；**到餐（DPT5）例外**：`dpt5-o5` = `#FF4B10`（来源：`color-business.md §到餐`）；原价划线色 `text-tertiary` = `#888888`；其他业务禁止用 `orange-default` 冒充价格色 |

**② 关键组件声明**（页面中每个使用的组件逐行列出）

| 组件 | variant / size | 关键尺寸（@2x px） | 来源文件 § |
|------|--------------|-----------------|-----------|
| 按实际页面逐行填写 | {必填} | {必填} | {必填} |

**②.5 组件绑定表（防幻觉必填）**

| 页面模块 | 用户原词 / 结构词 | 路由槽位摘要 | 候选组件集合（归一后） | 最终绑定 | ownership | 排除理由 | 来源文件 § |
|---------|------------------|-------------|----------------------|---------|-----------|---------|-----------|
| 按实际页面逐行填写 | {原词/结构词} | {position / fixed / trigger / duration / interactivity / primary_task 中的关键字段} | {归一后的候选集合} | {最终绑定} | {layout_owner / style_owner / behavior_owner} | `{chosen_because / not_component / evidence_slots / owner_decision}` | {来源文件 §} |

> 🚨 **填写规则**：
> - `候选组件集合` 只能写 `INDEX.md` 中存在的合法组件名，或「白卡容器 / 双列卡片栅格 / Icon Grid」这类合法结构落点；❌ 禁止写 `card` / `navbar` / `header` / `modal` / `footer` 等伪组件名
> - `路由槽位摘要` 至少写清当前模块的**位置 / 固定性 / 触发方式 / 时效 / 交互性 / 主任务**中的关键字段；❌ 禁止直接写“常规组件”之类空话
> - `最终绑定` 必须收敛到 **1 个合法组件**，或 **结构容器 + 1 个合法承载组件**；若仍有多个候选未排除，禁止进入 `W1`
> - `ownership` 必须至少说明谁是 `layout_owner / style_owner / behavior_owner`；若不存在父子关系，可写 `self / self / self`
> - `排除理由` 必须按固定模板填写：
>   - `chosen_because`：最终组件命中的决定性语义
>   - `not_component`：至少写 1 个被排除的相邻候选，以及为什么不是它
>   - `evidence_slots`：引用本模块的 `route_slots` 证据，如 `position=top` / `fixed=true` / `primary_task=search`
>   - `owner_decision`：写清宿主与子组件的所有权判断
> - ❌ 禁止写「看起来更像」「经验判断」「整体更协调」这类无证据描述

**②.6 组件自检轮询记录（高风险模块必填）**

| 页面模块 | 已绑定组件 | 本轮核验项 | 结论 | 失败回退 |
|---------|-----------|-----------|------|---------|
| 按实际页面逐行填写 | {已绑定组件} | {核验项} | {通过/回 D2/回 D3/停止} | {失败回退} |

> 🚨 **填写规则**：
> - `本轮核验项` 只能从「合法名 / 来源 / variant-size-state / 结构上下文 / 排除理由」五类里选，❌ 禁止写“整体看起来没问题”
> - `结论` 只能是 `通过 / 回 D2 / 回 D3 / 停止` 四种；只要存在非 `通过`，禁止进入 `W1`
> - 同一模块若进入第 2 轮后仍不是 `通过`，必须写 `停止` 并告知用户补规范，❌ 禁止继续追加第 3 轮

**③ 图标声明**（页面中每个使用的图标逐行列出）

| 用途 | 完整类名 | 来源验证 |
|------|---------|---------|
| 按实际页面逐行填写 | {完整类名} | {来源验证} |

**④ 布局声明**

| 项目 | 声明内容 |
|------|---------|
| 栅格密度档位 | {紧凑16px / 适中24px / 宽松32px}，原因：{页面类型 + `density_mode`} |
| 页面背景色 | `bg-page` = `#F5F5F5` |
| 卡片布局 | 白色留边圆角卡片，`margin:0 {N}px; border-radius:24px` |
| 页面模式约束是否已落实 | {是/否}；说明：{例如「结果信息已前置，CTA 后置；未使用营销氛围压过结果」} |
| 模块排序是否已落实 | {是/否}；说明：{当前页面自上而下模块顺序与 `module_order` 的一致性} |

**⑤ 样式来源回溯**（用户明确提到的样式词逐条列出，不得省略）

| 用户原始描述 | 解析后的规范项 | 来源文件 § |
|-------------|---------------|-----------|
| 按用户明确提到的样式词逐行填写 | {解析后的规范项} | {来源文件 §} |

**⑥ 歧义词解歧记录**（命中高风险歧义词时必填，不命中可写“无”）

| 用户原始词 | 候选组件 | 最终判定 | 排除理由 | 来源文件 § |
|-----------|---------|---------|---------|-----------|
| 按命中的高风险歧义词逐行填写；未命中可写 `无` | {候选组件} | {最终判定} | {排除理由} | {来源文件 §} |

**⑦ 局部修改影响记录**（仅修改已有 HTML 时必填；新建页面可写“无”）

| 项目 | 声明内容 |
|------|---------|
| 修改目标片段 | {本次只改哪些模块 / 文字 / 间距 / 颜色 / 组件状态} |
| 禁止误伤区域 | {如 `status-bar` / `home-indicator` / NavBar 图标 / 价格字体 / 已有 `data:` 图片 / `{B64:...}`} |
| 允许变更范围 | {只能改文案 / 外层间距 / 已有 `variant/size/state` / 颜色 Token 等} |
| 禁止变更范围 | {不得重写整块 `<style>` / 不得删除 base64 / 不得改组件内部样式 / 不得删除 `data-slot` / `data-variant` / `data-size` / `data-state`} |
| 回归验收重点 | {本次改动后必须重点复验的区域，如“未改 NavBar 图标仍显示、价格字体仍正常、系统栏未变形”} |

---

> 🚨 **强制阻断规则（优先级高于一切）**：
> 1. ❌ **Full Harness 模式下，声明表中任何一行来源填不出来 → 禁止进入第四步**，必须重新读对应规范文件；仍找不到则告知用户「{规范项} 无对应规范，待补充」。
> 2. ❌ **普通 Fast Path 不得伪装成已完成完整声明表**——若未升级 Full Harness，就只允许以“内部最小决策”进入 `W1`。
> 3. ❌ **声明或最小决策通过后，第四步写 HTML 时发现与之不符 → 必须停下来重判，不得用「先写完再说」的方式绕过。**
> 4. ❌ **声明表中任一组件若未写明 `来源文件 § + variant/size/state`，视为未完成选型**；未完成选型的组件不得输出 HTML。
> 5. ❌ **声明表「②.5 组件绑定表」若缺失任一高风险模块，或某模块的 `候选组件集合` 未收敛到唯一合法落点，视为组件仍在幻觉态，禁止进入第四步。**
> 6. ❌ **声明表「②.5 组件绑定表」中若出现 `card / navbar / header / footer / modal / chip / fab / alert` 等伪组件名作为最终绑定，视为违规，必须回退到 D2 / D3 重做。**
> 7. ❌ **Fast Path 的 `component_audit_map` 或 Full Harness 的「②.6 组件自检轮询记录」若缺失任一高风险模块，或存在任一模块未标记为 `通过`，视为组件自检未完成，禁止进入第四步。**
> 8. ❌ **同一模块的组件自检若已到第 2 轮仍未通过，或结论已写成 `停止`，必须停止并告知用户补规范；❌ 禁止带着未收敛组件进入 `W1`。**
> 9. ❌ **声明表中若出现「自定义组件 / 自拟样式 / 近似实现 / 按视觉调整」等字样，视为违规，必须回退到 D3 重做。**
> 10. ❌ **用户明确提到的样式词若未在声明表「⑤ 样式来源回溯」中逐条写明来源文件 §，视为未完成样式解析**；未完成样式解析不得进入第四步。
> 11. ❌ **若某个样式词无法映射到 `semantic/`、`component/`、`grid-layout.md` 或业务 `visual-language` 的合法来源，必须停止并告知用户，不得用相近样式替代。**
> 12. ❌ **声明表 `⓪ 页面模式 Schema` 若缺任一字段，或 `page_mode / primary_goal / primary_info` 出现 2 个及以上候选，视为未完成业务语义解析，不得进入第四步。**
> 13. ❌ **若 `density_mode` 与 `④ 布局声明` 的栅格密度档位不一致，或 `cta_priority` 与实际 CTA 位置不一致，必须回退到 D3 重新声明。**
> 14. ❌ **若页面模式为 `result-feedback` / `fulfillment-status` / `assurance-explanation`，却出现明显营销氛围前置或促销模块压过主信息，视为页面模式失配，必须回退重做。**
> 15. ❌ **若声明表中的 `module_order` 未按 `page_mode` 默认模块顺序填写，或 `模块排序是否已落实` 为否，禁止进入第四步。**
> 16. ❌ **若页面实际顺序命中 `forbidden_order`，即使组件、样式、Token 全部合法，也视为页面骨架错误，必须回退重做。**
> 17. ❌ **若用户描述命中高风险歧义词（如 `footer / alert / card / navbar / tag / picker`），但声明表「⑥ 歧义词解歧记录」未填写，视为未完成组件判定，不得进入第四步。**
> 18. ❌ **若「⑥ 歧义词解歧记录」里未写出“候选组件 + 最终判定 + 排除理由”，或排除理由只是“看起来更像”，视为无效解歧，必须回退到 D2 / D3 重做。**
> 19. ❌ **若本次任务是修改已有 HTML，但声明表「⑦ 局部修改影响记录」未填写，视为未完成修改边界定义，不得进入第四步。**
> 20. ❌ **若局部修改影响记录未明确“禁止误伤区域”与“回归验收重点”，或修改后仍有任一未改区域出现图标失效 / 字体失效 / 系统栏变形 / 标题偏移，视为局部修改回归，必须回退到 `W1` 修正并重注入。**

---

---

## 🌐 PHASE 2 — WEB GENERATE（网页生成阶段）

> **前置条件**：必须持有已通过的设计决策结果（D3 产出）：**Fast Path** 为最小决策集，**Full Harness** 为完整声明表；两者任一未完成都禁止进入本阶段。
>
> **本阶段目标**：将已确认的设计决策结果转化为可运行的 HTML 原型，并在输出前完成内部验收修正。
>
> **阶段输出**：仅输出 `.html` 文件
>
> **Harness Contract（Phase 2）**：
> - **输入**：已通过的设计决策结果（Fast Path 最小决策集 / Full Harness 完整声明表） + 已确认的组件文件来源 + 已确认的 Token / 栅格 / 图标来源
> - **输出**：一个已写入磁盘、已完成内联资源重注入、已通过 `checklist.md §B` 的 `.html` 文件
> - **Gate**：设计决策结果未通过、HTML 未完成内联资源重注入、`§B` 未通过、`§B` 中「第二轮组件调用轮询」任一项未通过、任一区域无法回溯到合法组件或结构规则、`status-bar/home-indicator` 未通过 `system.md` 来源断言（空壳占位 / 手写替代 / 非 system 绑定）、或仍存在已知视觉 bug / 局部修改回归风险时，❌ 禁止交付最终结果
> - **Repair Loop**：本阶段不允许“先交付再修”。**设计决策结果与 HTML 不一致回 `D3`，纯 HTML 落地错 / 内联资源错回 `W1`**：
>   - **回 `D3`**：HTML 使用的组件、`variant/size/state`、模块顺序、CTA 位置、主色/关键 Token 与设计决策结果不一致；或 HTML 证明原设计决策本身写错
>   - **回 `W1`**：Status Bar / Navigation / icon / Home Indicator / 卡片栅格 / body-meta / 组件内部样式覆盖等实现错误；以及 iconfont、价格字体、`data:` 图片、`{B64:...}`、系统栏内联 SVG 丢失
>   - **回退后的强制动作**：回 `D3` 后必须重新声明并重新过 `§A`；回 `W1` 后必须改 HTML、重新注入、重新跑 `checklist.md §B`
> - **Exit Criteria**：HTML 文件存在 + 内联资源重注入完成 + `checklist.md §B` 通过 + 所有界面区域可回溯到合法组件或结构规则 + 无已知视觉 bug / P0 / P1 交付错误

### W1：HTML 原型输出

生成独立 `.html`，保存路径：`~/Desktop/Design Demo/{name}-{YYYYMMDD-HHmm}.html`

> 🚨 **组件调用纪律（进入 W1 后继续生效）**：HTML 中实际出现的每一个宿主组件、叶子控件和非文字 icon 槽位，都必须已经在 `Fast Path 最小决策集` 的 `component_binding_map + slot_binding_map + component_audit_map`，或 Full Harness 的 `② 关键组件声明 + ②.5 组件绑定表 + ②.6 组件自检轮询记录` 中出现，并且自检结论为 `通过`。若写 HTML 时临时冒出新的组件名、伪组件名、未声明的 `variant/size/state`，或未绑定的 `tag / select / button / icon` 槽位，必须立即停止当前写入并回退到 `D2/D3`，不得边写边补。
>
> 🚨 **W1 出口前强制二次对账（新增）**：写完 HTML 且完成注入后，必须按 `checklist.md §B` 中「第二轮组件调用轮询」做一次反向对账：`最终 HTML 实际组件落点` 必须与 `component_binding_map + slot_binding_map + component_audit_map` 一致；若命中 `INDEX.md` 高混淆组件图谱、区域化强关联路由表，或 `component-quickref.md` 的高混淆宿主收敛卡，则必须继续能对上同一套 `chosen_because / not_component / evidence_slots / owner_decision` 四段模板，而不是只写一句“为什么不是另一个”。任一字段答不清、缺失或与最终 HTML 证据对不上，一律按 `R-D3-04` 回退到 `D3` 重做绑定声明，不得直接在 `W1` 打补丁。

> **文件命名与交付路径**：交付文件统一写入 `~/Desktop/Design Demo/{name}-{YYYYMMDD-HHmm}.html`，每次生成独立文件，❌ 禁止覆盖已有文件。若基于已有 HTML 修改，先另存到该目录再做修改、注入、验收；是否同步更新原文件按用户意图决定，但交付预览路径始终是 `Design Demo` 版本。

**关键步骤（按顺序执行）**：

> 🚨 **W1 写入前路由闭环检查（route-driven，降低首轮漏调组件）**：进入写 HTML 前，不再单独维护一张“高风险文件白名单表”，而是检查当前任务的 `route_result + matched_strong_route + preloaded_files` 是否已经闭环。
> - 若命中 `references/INDEX.md` 的「区域化强关联路由表」，必须确认该行 `必须联读文件` 已全部出现在 `preloaded_files`
> - `component-quickref.md` 的收敛结论必须与 `host_component` 一致；若不一致，先回 `INDEX.md` 重做路由，不得写入
> - `leaf_slots` 中出现选择态 / 标签 / 角标 / 操作按钮 / 非文字 icon 时，必须确认对应叶子文件已按 A3 加入预读集合
> - `checklist.md §B` 中与当前 `matched_strong_route` 或 `host_component` 对应的白名单验收项，必须已明确准备好最终核验路径
> - 缺任一项 → 停止写入，回 `A2/A3` 按路由结果补读，不得先写 HTML 再靠 `§B` 抓错。

> 🚨 **进入第四步前的组件完整性检查（按路由结果核对，不得跳过）**：
> | 路由结果 / 全局必查项 | 写入前必须确认的规范来源 |
> |---------------------|-------------------------|
> | **🚨 P0 Status Bar + Home Indicator**（每个手机页面必须，无条件，❌ 不得省略） | 已在 A1 加载的 `system.md`——**直接复用 §3 强制代码结构**，顶部插入 `data-slot="status-bar"`（height:88px，含时间+图标），底部插入 `data-slot="home-indicator"`（height:68px，含胶囊动效）；并在进入写入前完成来源断言：`component_binding_map/slot_binding_map` 中两者 `final_component` 必须为 `system`。❌ 禁止留空白占位；❌ 禁止手写“看起来像”状态栏/胶囊条替代；必须按 `system.md` 的显隐与交互规则实现 |
> | `host_component=navigation` | `navigation.md`；若导航内有搜索，再同时确认 `search-bar.md` |
> | `host_component=bottom-action-bar` | `bottom-action-bar.md`；若含按钮，再确认 `button.md §8` |
> | `host_component=bottom-navigation` | `bottom-navigation.md`；若有未读数，再确认 `badge.md` |
> | `host_component=list` / `form` | 宿主文件 + 实际出现的叶子文件（`select/tag/badge/button/icon`） |
> | `leaf_slots` 含单选/多选/选择态控件 | `select.md`（`data-slot="select"`、`data-type`、`data-size`、`data-state`；❌ 禁止手写 `.radio/.checkbox`、`::after` 对号或纯 icon 替代） |
> | `leaf_slots` 含标签/角标 | `tag.md` / `badge.md` 中实际命中的文件；❌ 禁止自造 pill 标签或绝对定位色块冒充 |
> | 页面内任意非文字 icon | **优先查本 SKILL「🖼️ 图标速查表」**，找不到再读 `icon.md §3`；普通业务 icon 不得凭感觉组合 |
> | 高频组件尺寸 | **先查本 SKILL「📦 高频组件速查卡」快速定位尺寸档，再读对应组件 `.md` 文件核对结构/variant/限制；❌ 速查卡不能替代组件正文** |
> | 页面含价格数字 | `font-price.md`（price-set-* Token，❌ 禁止自定义字号） |
> 
> **凡 `route_result` 已命中的组件/叶子文件，写入前都必须能在 `preloaded_files` 中找到；找不到即视为链路未闭合。**
> **任何已命中组件规范的区域，只允许按组件正文复用其内部样式；页面层若需要调整，只能调整组件外层容器与相邻组件间距，❌ 禁止改组件内部定义好的样式。**


1. **🚨 P0：HTML `<head>` 必须采用「双 style 隔离结构」**：字体资源块与业务 CSS 物理分离，防止任何编辑操作覆盖字体数据。

   > 🚨 **目的**：将 `ds-font-inject` 与业务 `<style>` 物理隔离，避免写回时覆盖字体块；`inject.py` 每次先删旧块再重注入。
   > ❌ **禁止**：预埋空的 `<style id="ds-font-inject">`、在该块写业务 CSS、删除/改名该 id、把字体 CSS 写入业务 `<style>`。
   > 🔗 标准 `<head>` 骨架 → `references/demo-generate/step4-detail.md §A`

2. **栅格 & 间距锁定**：读 `grid-layout.md` 选密度档，将间距值全部写死为 `:root` CSS 变量，❌ 禁止在组件 CSS 中出现未声明的 margin/padding 数值。
   > 🔗 CSS 变量模板 → `references/demo-generate/step4-detail.md §B`
3. **body 字体 fallback**：必须使用完整 fallback 链，❌ 禁止只写 `'PingFang SC',sans-serif`。
   > **美团体**：`special-title` 元素单独声明 `font-family:'美团体','PingFang SC',...`，❌ 禁止写入 body。
   > 🔗 完整 fallback 与原因说明 → `references/demo-generate/step4-detail.md §C`
4. **所有二进制资源（iconfont / 价格字体 / 图片）统一用 Python 脚本注入 HTML**

   > 🚨 **P0 强制规则：所有 base64 编码操作必须通过 Python 脚本完成，❌ 严禁使用 shell 命令。**
   > 每执行一次写回（`write` / `string_replace` / `MultiEdit`），都要立刻重新注入（W1-stabilize）。
   > 🔗 执行命令与完整机制 → `references/demo-generate/inject-fonts-script.md`

   > 🚨 **P0 交付门槛：HTML 写完后必须立即执行注入脚本（图标 + 价格字体才能显示），未注入不得交付**。图标 span 类名正确但字体未注入，页面上图标仍为空白——这是最高频的第一轮交付失败原因。写完 HTML → 立刻跑脚本 → 确认 `<style id="ds-font-inject">` 非空 → 才能告知用户结果。

5. **图标类名**：格式 `font icon-iconfont-{name}-{weight}`，❌ 禁止 SVG、禁止 mtdicon；

   > 🚨 **协议要求：业务 `<style>` 中不得手写 `.font` 基类。** `inject.py` 会自动将 `@font-face` + `.font` 定义写入 `<style id="ds-font-inject">`；唯一正确做法是 HTML 中只写图标元素 `<span class="font icon-iconfont-{name}-{weight}" aria-hidden="true"></span>`，`.font` 基类完全交给脚本管理。最终是否违规由 `checklist.md §B` 阻断。

   > 🚨 **图标核验**：先查本 SKILL 内联「🖼️ 图标速查表」；找不到再读 `icon.md §3` 并核对 `assets/iconfont.css`；仍找不到留空注释，❌ 禁止凭感觉拼接名称。**Toast 图标类名与字重见 `toast.md §3.2`**。
   > 🚨 **图标交付前 3 连闸**：① 绑定阶段已在 `slot_binding_map` 写明 `icon-route`；② 写 HTML 时类名能回溯到 `icon-quickref.md` 或 `assets/iconfont.css` 的真实存在项；③ 注入后通过 `checklist.md §B` 的可见性检查。三者缺一不可；只满足“看起来写了类名”不算完成

   > 🚨 **导航返回按钮**：固定 `icon-iconfont-translate-line-semibold`，❌ 禁止 `leftturn` / `back` / `arrow-left`；NavBar 背景 `#FFFFFF`，secondary 标题 34px/500，默认 `data-title-align="center"`。
   > 🚨 **Bottom Navigation 图标家族规则**：普通 Tab 图标必须整组同家族；若组件正文要求选中/未选中切换，必须在 D3 成对声明 `selectedIcon` / `unselectedIcon`。
   > 🚨 **标题与系统栏协议**：必须按 `navigation.md` 与 `system.md` 正确落地，最终由 `checklist.md §B` 做截图级阻断验收。

   > 🔗 NavBar 模板 → `references/demo-generate/step4-detail.md §D`

   - **图标 span 规则**：除 NavBar 外，图标 span 默认 `display:inline-block` 且 ❌ 禁止 `overflow:hidden`；NavBar 图标不设 `display` / `width` / `height` / `overflow:hidden`。
   > 🔗 场景细则与示例 → `references/demo-generate/step4-detail.md §E`
   > 🚨 **图标不可见根因速查**：优先检查 `overflow:hidden` 与 `display` 是否误设；修正后立即重运行注入脚本。
   - **Stepper 加减图标**：❌ 不使用 iconfont，必须用 inline SVG，尺寸按 `stepper.md §6.4` ×2。
   > 🔗 SVG 模板 → `references/demo-generate/step4-detail.md §F`（仅有 Stepper 时读）
   - **Toast loading 菊花图**：图片路径写占位符 `src="{B64:~/Desktop/loading_white_1_iSpt.webp}"`，由注入脚本统一替换，❌ 禁止 CSS border-spin。
   > 🔗 spinner 模板 → `references/demo-generate/step4-detail.md §G`（仅有 Toast 时读）
6. **尺寸换算规则**：
   - **栅格/间距**：来自 `references/templates/grid-layout.md` → 使用表格中**「@2x px（HTML 实际写入值）」列**的数字直接写入（如 spacing-l = **24px**，spacing-s = **16px**）；❌ 禁止把表格中 pt 列的数字直接当 px 写——那是 @1x 值，750px 画布下会偏小一半
   - **组件规范**（`semantic/*.md` / `component/*.md` / `molecules/*.md` 等所有 @1x 规范文档）：数值为 @1x pt，写 CSS 时 **×2 转 px**（如 14pt → 28px、12pt → 24px、96pt → 192px）
   - **判断依据**：来源是 `references/templates/grid-layout.md` → 直接用表格 @2x px 列；来源是任何其他 `references/` 规范文档 → ×2
   - ⚠️ **常见易漏项**：圆角（`radius-m` 12pt → **24px**）、气泡尺寸（96pt → **192px**）、图标（36pt → **72px**）、字号（14pt → **28px**）
   - ⚠️ **loading 菊花图 spinner**：容器和 img **同样 ×2**（见 `toast.md §3.2` 实测表格）。容器 36pt→72px / 18pt→36px；img 30pt→60px / 15pt→30px，居中于容器内。❌ 禁止写成 36px/18px 容器（那是 @1x 的旧错误写法）
7. **🚨 P0 页面尺寸（直接导致全页崩坏，每次必查）**：
   - **`<meta viewport>` 必须写** `content="width=750, initial-scale=1.0"` ← ❌ **严禁 `width=device-width`**；❌ **严禁 `width=750px`**（带 px 后缀无效）
   - **`body` 必须写** `width:750px; min-height:1624px; margin:0 auto;`
   - ❌ **严禁 `min-height:100vh`**——这是「商品挑选页」崩坏的真实根因：`width=750` 是非标准 viewport，`100vh` 在此环境下计算行为不稳定，会导致 flex 高度失效、内容区被压缩截断
   - ❌ 严禁 `width:100vw / 100% / auto`
   - ⚠️ **`color-scheme: light` 必须写在 `html` 上**，避免 Chrome 在 `width=750` 下强制套用深色主题。
   > 🔗 标准模板 → `references/demo-generate/step4-detail.md §H`
8. **Button CSS**：直接读 `references/component/molecules/button.md §8` 复制，❌ 禁止手动推导。复制后**必须**将其中所有 `"PingFang SC", sans-serif` 替换为完整 fallback 链（见 `references/demo-generate/step4-detail.md §C`）。
   > 🚨 **底部操作栏按钮尺寸（最高频错误，每次必查）**：页面底部固定操作栏（`bottom-action-bar`）内的按钮**必须且只能用 `btn-l`（高度 80px / `size=l`）**。❌ 严禁将 `btn-xl`（高度 96px）放入底部操作栏——`btn-xl` 只能用于页面正文内部的独立全宽 CTA。判断口诀：**栏内 = l（80px），独立 CTA = xl（96px）**。写完底部按钮 HTML 后，逐字检查 class，若见到 `btn-xl` 立即替换为 `btn-l`。
9. **Price Font @2x 覆盖**：见 `button.md §8.3`，`font-family` 和 `font-size` 必须加 `!important`（父级选择器特异性更高会覆盖裸 class）
10. **data-attribute**：每个组件节点带 `data-slot`、`data-variant`、`data-size`、`data-state`
   > 🚨 **组件内部样式禁止覆盖**：若组件正文已定义 `data-variant` / `data-size` / `data-state` 对应样式，页面层只允许挂载这些已定义属性值，❌ 禁止再额外写选择器覆盖其内部高度、圆角、字号、颜色、描边、阴影或图标规格；需要不同样式只能改选已有 variant/size/state，不能 CSS 覆盖
11. **选择态 DOM 强制规则（P0）**：凡页面中出现 `role="radio"` / `role="checkbox"` / `aria-checked` 或圆圈勾选视觉，必须直接渲染 `select` 组件节点，并带 `data-slot="select" data-type="checkbox" data-size="large|small|special" data-state="default|highlighted|checked|disabled|disabled-checked"`；单选与多选的差异只体现在业务行为层，视觉仍按 `select.md` 落地。❌ 禁止写 `.radio` / `.checkbox` 类、❌ 禁止用 `border-radius + border` 手画圆圈、❌ 禁止用 `::after` 画对号。
12. **无障碍**：图标加 `aria-hidden="true"`，icon-only 加 `aria-label`
13. **首页金刚区（Icon Grid）图标规范**：

    > 🚨 **金刚区图标容器使用超椭圆（Squircle）`border-radius: 30%`**，❌ 禁止用 `50%`（正圆）

    > 🔗 **完整 Squircle CSS 模板、颜色变量表、HTML 结构、业务图标色对照** → 读 `references/templates/icon-grid.md`（仅做首页金刚区时读）


14. **容器填充规则**：
    - 块级容器：`width:750px` 或内容区用 `width:100%`，❌ 禁止留默认宽度
    - flex 文字子项：`flex:1; min-width:0`（防溢出截断）
    - Tag/列表行：`display:flex; width:100%; box-sizing:border-box`，❌ 禁止 `inline-flex`
    - 固定尺寸子项（图片/图标）：`flex-shrink:0`
    - 推右对齐（箭头/操作）：`margin-left:auto; flex-shrink:0`
    - 🚨 **默认单列卡片栅格（每次输出前必查，不得跳过）**：
      - ✅ **页面背景必须是 `#F5F5F5`**：❌ 禁止把 `.page` 背景设为 `#FFFFFF` 白色——白底白卡片没有层次感
      - ✅ **所有内容区块默认用白色卡片**：`border-radius:24px; background:#FFFFFF; overflow:hidden;`，左右 margin 和卡片间距以栅格档位为准（默认适中型：margin=**24px** / 卡片间距=**16px**）；❌ 禁止默认通栏
      - ⚠️ **通栏仅限四种例外**（顶部全屏 Hero 横幅 / 地图区 / 底部操作栏 / 系统设置分割线列表）：`width:750px; border-radius:0;`，❌ 禁止扩大例外范围
      - ❌ **禁止把整个页面做成纯白通栏**——把订单信息、商品清单、配送进度等全部设成 `border-radius:0` 是最常见的错误，会让页面失去层次感
    - 🚨 **商品卡加车按钮（add-button）布局强制规则**（P0，命中即阻断）：
      - 主链路只保留阻断条件，不内嵌 CSS 模板；具体实现与验收以 `references/checklist.md §B` 中 `Stepper — add-button 在卡片中的位置与文字对齐` 为准。
      - 进入交付前必须同时满足 5 项：`body position:relative`、按钮 `position:absolute; right:0; bottom:0`、名称/价格左对齐、名称/价格 `padding-right:44px`、`body min-height:80px`。
      - 需要组件结构、图标与尺寸细节时，再读 `references/component/components/stepper.md` 对应章节。
15. **占位图自动填色**：所有「占位图/示意图」区块（商品图、广告位、金刚区矩形图等）**禁止使用浏览器 CSS 默认样式**（灰色描边 `border`、`outline`、`box-shadow` 等），必须用设计 Token 填充背景色或渐变：
   - 若设计稿指定了颜色填充（如 Y3 黄色渐变）→ 直接写对应 `background`
   - 若未指定颜色 → 使用 `bg-page`（`#F5F5F5`）纯色填充
   - ❌ 禁止出现裸 `<img>` 无 `src`、裸 `<div>` 无 `background`、任何灰色描边占位框
   - 🚨 **截图级验收口径**：页面中若出现“系统栏变形 / 标题偏移 / 图标消失 / Home Indicator 消失 / 大面积默认灰框”任一肉眼可见错误，即视为 P0 失败，不得以“其余规则已满足”为由交付

16. **图片区域使用语义化图片源**：凡设计稿中出现「商品图、店铺封面图、广告 Banner 图、用户头像」等图片区域，必须保证**图片内容与旁边文案语义一致**。

    > **主链路只保留 4 个 gate**：
    > - 🟢 **有用户提供的业务图片 / 素材包 / 页面截图真实素材** → 必须优先使用，❌ 禁止降级成通用占位图
    > - 🟢 **已有 HTML / 原始页面里已存在业务图片资源**（含原始 `src`、`data:`、`{B64:...}`）→ 修改时优先保留，❌ 禁止被新占位图覆盖
    > - ⚠️ **无业务图时**：只有在图片不承担精确主体语义时，才允许占位；`picsum.photos` 仅限低风险装饰占位，`images.unsplash.com` 仅限已验证真实 photo ID，头像才允许 `randomuser.me`
    > - 🚨 **图文不一致即 `P0`**：若图片与文案主体不一致，或素材无法唯一归位却仍继续猜，必须回 `W1` 修正，不得交付

    > 🔗 **业务素材映射规则、主体图/装饰图边界、seed 参考速查、头像模板、已验证 Unsplash photo ID 表、降级纯色背景** → `references/demo-generate/image-keywords.md`（遇到图片区域才读）

### W1-edit：已有 HTML 局部修改协议（命中"改一下 / 微调 / 局部调整 / 替换文案 / 改颜色 / 调间距"时强制启用）

> **目标**：已有 HTML 只做局部变更，不把未改区域带崩，不让 iconfont / 价格字体 / 内联 SVG / `data:` 图片在局部修改后失效。
>
> 🚨 **W1-edit 的交付路径与 W1 完全一致**：先另存 `~/Desktop/Design Demo/{name}-{YYYYMMDD-HHmm}.html` 版本文件，再在该文件上修改、稳定化、验收并交付。❌ 禁止在原始路径就地修改后当作最终交付物。
>
> **固定执行链（必须按顺序）**：
> 1. **另存版本文件**：后续所有操作只在 `Design Demo` 版本文件上进行。
> 2. **定边界**：在 D3 声明表填写「⑦ 局部修改影响记录」，明确修改目标片段、禁止误伤区域、允许 / 禁止变更范围。
> 3. **只改目标片段**：优先局部替换；❌ 禁止为了一处小改动重写整块 `<style>`、整页 HTML 或整段内联资源。
> 4. **组件优先**：若改动落在按钮 / 标签 / 列表 / 导航 / 底栏等组件上，继续沿用原组件 `variant/size/state`，❌ 禁止借 CSS 覆盖组件内部样式临时改动。
> 5. **写回后自动进入 `W1-stabilize`**：每次 `write` / `string_replace` / `MultiEdit` 完成后，都必须立刻稳定化，再继续下一次编辑。
> 6. **回归受影响邻域，不只看改动点**：除本次直接改动节点外，必须把它的宿主模块、同一行/同一组叶子槽位、命中同一公共选择器的组件节点视为受影响邻域，一并复验。
>    - 改文案 / 辅助文字：回归同一 `list/form` 宿主行的 `data-slot / data-variant / data-size / data-state`、行尾箭头、选择态、标签、角标
>    - 改选择态 / 行尾控件 / 行内 icon：回归对应 `select / tag / badge / button / icon-route` 绑定，不得只改视觉不改来源
>    - 改顶部 / 底部固定区：连带回归 `system / navigation / bottom-action-bar / bottom-navigation`
>    - 改共享 `<style>` / 公共选择器：回归所有命中该选择器的组件节点，确认未覆盖组件内部样式
>    - 关键未改区仍需保底复验：NavBar 图标、Status Bar、Home Indicator、价格数字、底部栏、`data:` / `{B64:...}` 图片占位等不得被顺带破坏
> 7. **执行 `checklist.md §B`**：发现问题必须先改 HTML、重新注入并复验，直到通过后才能交付；❌ 禁止只记录问题不修。
>
> **W1-stabilize（编辑后稳定化，自动触发）**：
> - **动作 0（新增，最高优先级）：⚡ 立刻执行注入脚本**：HTML 写入磁盘后的第一个动作，立即执行 `references/demo-generate/inject-fonts-script.md` 脚本，将 `@font-face` + `.font` 基类 + iconfont + 价格字体写入 `<style id="ds-font-inject">`；❌ 禁止在注入完成前向用户展示 HTML 或告知"刷新可见图标"
> - **动作 1：立即重注入**：执行 `references/demo-generate/inject-fonts-script.md` 中的脚本命令，更新 `<style id="ds-font-inject">`
> - **动作 2：资源完整性回归**：确认资源块非空，且已有 `data:` / `{B64:...}`、Status Bar / Home Indicator 内联 SVG 未丢失
> - **动作 3：失败即阻断**：若脚本返回非 0 或资源块校验未通过，必须停止交付并继续修复
>
> **升级判定（命中任一条，禁止继续假装"局部小改"）**：
>
> | 触发条件 | 必须升级到 |
> |---|---|
> | 已影响 `page_mode` / `module_order` / `cta_priority` / 主信息顺序 | `D3` |
> | 命中 `footer / alert / card / navbar / tag / picker` 等歧义词，且需要重新解释落点 | `D2` |
> | 组件家族切换（如 `bottom-navigation` ↔ `bottom-action-bar`、`toast` ↔ `dialog`） | `D3`（若语义未定先回 `D2`） |
> | 触碰全局 `<style>`、`body` / `viewport` / 系统栏 / `color-scheme` / 栅格基线 | `W1` 全页重落地；若声明变化则先回 `D3` |
> | 直接触碰 `<style id="ds-font-inject">`、`woff2;base64,`、`font-family:"美团新数字体"`、`data:` / `{B64:...}`、系统栏内联 SVG | `W1` 全页重落地并重注入 |
>
> **收敛铁律**：
> - 同一局部修改在 **2 次 repair loop 内仍未收敛** → 必须升级到 `D3 + W1`
> - 若最终结果改变了组件家族或模块顺序，必须补写 / 重写声明表后才能交付

### W1 后内部验收（不对外输出，不单列报告）

> **触发时机**：HTML 文件写入磁盘并完成 `W1-stabilize` 后，立即执行。
>
> **执行方式**：先执行 `checklist.md §B` 中「第二轮组件调用轮询」→ 再执行“系统组件来源断言”→ 最后跑 `§B` 其余条目。`status-bar/home-indicator` 必须能回溯到 `system.md`，且不得是空壳占位或手写替代；第二轮组件调用轮询失败按 `R-D3-04` 回退，系统来源断言失败按 `R-W1-01` 回退。验收的唯一目标是发现并修正真实问题，直到通过后再输出最终结果。❌ 禁止跳过 `§B`；❌ 禁止只记录问题不修改；✅ 不再输出 W2 QA 报告或“检测全通过”类文字。

### 🔁 显式 Repair Loop 路由矩阵（Phase 3）

> 📌 **内部错误恢复协议**：本节仅在 repair loop 被触发时（即 `checklist.md §B` 发现 P0/P1 问题、自检返回"回 D2/D3"、或局部修改 2 次未收敛）才需要查阅；普通生成任务正常执行 `D1 → D2 → D3 → W1 → §B` 流程，无需主动阅读本矩阵。

> **命中错误时必须按下表回退，不得自由发挥，更不得"顺手一起改"导致层级漂移。**

| failure_code | 失败类别 | 典型症状 | 回退节点 | 必须重做 | 重新放行条件 |
|---|---|---|---|---|---|
| `R-D2-01` | 路由错误 | `page_mode` 判错、业务气质章节判错、组件别名归一错误、组件家族选错、样式词找不到合法来源 | `D2` | 重读 `visual-language` / `INDEX.md` / 对应组件规范，重做 SVCS 路由 | Fast Path 下重新确认最小决策；Full Harness 下重新通过 `checklist.md §A` |
| `R-D3-01` | 声明错误 | 声明表缺字段、来源缺失、`variant/size/state` 缺失、`density_mode` / `cta_priority` / `module_order` 前后冲突 | `D3` | Fast Path 下重做最小决策；Full Harness 下整表重写并重新输出 | Fast Path 下最小决策无冲突；Full Harness 下完整声明表无空项、无估算，并重新通过 `§A` |
| `R-D3-02` | 声明与 HTML 不一致 | HTML 中的组件、顺序、CTA 位置、主色、关键 Token 与声明表不一致 | `D3` | 先修正声明，再回 `W1` 重落地 | 声明表与目标 HTML 一致后，才能继续 `W1` |
| `R-D3-03` | 组件自检失败 | `component_audit_map` / `②.6` 中出现 `回 D2` / `回 D3` / `停止`，或同一模块自检 2 轮仍未收敛 | `D2 / D3` | 按失败类型重做候选归一或绑定声明，并从第 ① 项重新跑组件自检 | 所有高风险模块自检结论 = `通过`，且无超轮次 |
| `R-D3-04` | 第二轮组件调用轮询失败 | `checklist.md §B` 的第二轮组件调用轮询未通过：最终 HTML 实际组件落点与 `component_binding_map/slot_binding_map` 不一致，或命中混淆组但无法给出排除理由，或排除理由未按 `chosen_because / not_component / evidence_slots / owner_decision` 模板写全 | `D3` | 重做组件绑定声明（含宿主 + 叶子槽位 + 排除理由模板），并重新进入 `W1` 落地 | 第二轮组件调用轮询全部通过，且最终 HTML 与绑定声明一一对应，排除理由字段完整且可回溯 |
| `R-W1-01` | HTML 落地错误 | Status Bar 变形、Home Indicator 失真/缺失、`status-bar/home-indicator` 非 `system.md` 来源（空壳占位/手写替代）、标题未居中、图标消失、卡片栅格错、body/meta 错、组件内部样式被页面层覆盖 | `W1` | 改 HTML，并先修复系统组件来源断言后再重跑 `§B` | `checklist.md §B` 全通过，系统组件来源断言通过，且截图级 P0 清零 |
| `R-W1-02` | 内联资源错误 | iconfont、价格字体、`data:` 图片、`{B64:...}`、系统栏内联 SVG、`<style id="ds-font-inject">` 丢失或为空块 | `W1` | 先恢复资源块/资源内容，再重新执行注入脚本并复验 | `§B` 中资源相关检查全部通过 |

> **执行铁律**：
> 1. **D2 / D3 问题禁止在 `W1` 里偷偷修掉**——那会让声明表失效，等于绕过 harness。
> 2. **W1 问题禁止回退时顺手改业务语义**——纯落地错只修实现，不改路由。
> 3. **一旦命中 `R-D3-02`，必须先修声明，再修 HTML**；顺序反过来会导致声明表失去约束力。

## 参考入口（按需读取）

- 图标速查：`references/component/atoms/icon-quickref.md`
- 高频组件尺寸：`references/component/component-quickref.md`
- 检查清单：`references/checklist.md`（Fast Path 读 `§B`；Full Harness 先 `§A` 再 `§B`）

---

## 输出格式

每次 HTML 原型完成后，只输出以下最终交付信息：

### 最终交付信息

```
📄 文件已保存：~/Desktop/Design Demo/{name}-{YYYYMMDD-HHmm}.html

✅ 内联资源重注入完成（iconfont + 价格字体）；已通过 `ds-font-inject` 资源块校验，刷新浏览器即可预览。

🛠️ 本次为已有 HTML 局部修改，未改区域已按回归清单复验。（仅修改已有 HTML 时输出）

⚠️ 已知限制（仅有时输出）：{如"外部图片按规范降级为纯色占位，不影响布局与组件调用"等非阻断限制}
```

> ❌ 禁止只输出 HTML 代码块而不输出上方最终交付信息；❌ 禁止在字体未注入时告知用户"刷新可看到图标"；❌ 禁止把内部验收结果包装成对外 QA 报告；❌ 禁止在 `⚠️ 已知限制` 中夹带任何 `P0/P1` 问题；✅ 若本次是已有 HTML 局部修改，必须补出上方 `🛠️` 行说明回归已完成。

---

## 错误处理

| 错误情况 | 处理方式 |
|---------|---------|
| Token 在 semantic 层找不到 | 停止，告知"[Token名] 不存在，建议先补充规范" |
| 图标在 `icon.md` 找不到 | 停止使用，说明"未找到 [图标名]，请提供准确名称" |
| 业务色无对应 DPT Token | 告知"[业务名] DPT Token 不在规范内，请提供色值或编号" |
| 按钮含价格但未用 Price Font | 停止，改用 `price-set-*` Token |
| 任何涉及价格字段的改写请求（¥ 字号 / 整数档 / 小数档 / 字重） | ❌ 停止改写。`font-price.md` 和 `mt-price-font-tokens.css` 的数值由维护者管理，只做查阅，不得自行修改 |
| 规范文件读取失败 | 告知"无法读取 [路径]，请确认文件存在" |

---

> **更新时间**：2026-04-29　**版本编号**：1.13.9　**架构**：Fast Path（默认） + Full Harness（高风险升级） + PHASE 2 Web Generate (W1 / W1-edit / W1-stabilize + §B) + PHASE 3 Repair Loop
> **创建者**：李开蒙　**维护者**：李开蒙、陆洋
