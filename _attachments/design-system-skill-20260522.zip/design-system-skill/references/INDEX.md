# 规范文档总索引

本文档是设计系统规范的导航中心。所有规范按照**四层架构**组织，旨在支持 AI 模型的按需加载和精准约束。

## 核心概念：四层架构

```
┌────────────────────────────────────────────┐
│         Template 层（页面与最佳案例）        │  ← 最终产出
│  page-type-骨架 / best-case-真实案例       │
│  引用：component 组件
├────────────────────────────────────────────┤
│         Component 层（原子、分子、复合）     │  ← 构建块
│  atoms / components                        │
│  引用：semantic Token
├────────────────────────────────────────────┤
│         Semantic 层（设计意图命名）         │  ← 约束核心
│  color.brand-primary / text.heading-1     │
│  引用：reference 原始值
├────────────────────────────────────────────┤
│         Reference 层（原始规范事实）        │  ← 源头
│  #FF6900 / 16px / Inter-Bold              │
│  + Design Principles                      │
└────────────────────────────────────────────┘
```

**依赖方向**（谁依赖谁）：
- Template → Component → Semantic → Reference
- 所有层都可能引用 Design Principles

---

## 快速导航

### 我想要...

| 需求 | 去哪里 | 场景 |
|-----|--------|------|
| 查看**系统骨架**（Status Bar / Home Indicator） | `component/components/system.md` | 手机页面强制骨架、顶部/底部安全区 |
| 查看**高频组件速查 / 宿主收敛** | `component/component-quickref.md` | 快速定位高频组件尺寸，并对已命中的高混淆候选做宿主级收敛 |
| 查看**栅格 & 间距规则** | `templates/grid-layout.md` | 页面边距 / 卡片间距 / 密度档位 |
| 查看**金刚区图标网格** | `templates/icon-grid.md` | 快捷入口区图标排版 |
| 查看**视觉语言（业务线色彩）** | `templates/visual-language/{设计中心}.md` | 业务线主色 / 渐变 / NavBar 风格 |
| 查看**所有组件**及其属性 | `component/` + 下方「组件名全集」三张表 | 了解全部可用组件（含 `component/molecules/button.md`、`component/molecules/tag.md`） |
| 快速判定**高歧义组件该落谁** | 下方「组件路由注册表」+「区域化强关联路由表」+「高混淆组件图谱」 | 专门解决 `footer / alert / card / navbar / tag / picker` 等高风险词，先路由再读正文 |
| 查看**基础组件**（Icon/Button/Tag） | `component/atoms/` + `component/molecules/` | `component/atoms/icon.md` 在 atoms；`component/molecules/button.md`、`component/molecules/tag.md` 在 molecules |
| 了解**色彩系统** | `semantic/color-semantic.md` | 查看 color.* token |
| 了解**字体规范** | `semantic/font-semantic.md` | 查看 text.* token |
| 了解**间距规范**（页面/模块/卡片级） | `semantic/spacing-semantic.md` | 查看 spacing.* token |
| 了解**组件内部间距**（padding、gap） | `semantic/component-spacing.md` | 查看 cs-{N} token，仅限组件内使用 |
| 看**品牌原则** | `design-principles/brand-principle.md` | 理解设计哲学 |
---

## 逐层详解

### Layer 1️⃣ Reference（参考层）

**位置**：`references/reference/`

**用途**：存储原始规范数据。极少变动，是所有上层的数据源。

**文件清单**：

| 文件 | 内容 | 何时读 |
|-----|------|--------|
| `color-reference.md` | 色板、色阶、RGB/Hex | Semantic 层需要原始值时；做色彩系统映射 |
| `font-reference.md` | 字体名、字号、行高、字重 | Semantic 层需要原始值时 |
| `spacing-reference.md` | 间距梯度：4/8/12/16/24/32... | 理解间距设计系统 |
| `radius-reference.md` | 圆角梯度原始值 | Semantic 圆角 Token 需要原始值时 |
| `shadow-reference.md` | 阴影样式、层级 | 了解阴影系统 |
| `stroke-reference.md` | 描边宽度原始值 | Semantic 描边 Token 需要原始值时 |

**特点**：这些文件通常是表格或结构化列表，机器可读性强。

---

### Layer 2️⃣ Semantic（语义层）

**位置**：`references/semantic/`

**用途**：将 Reference 层的原始值转换成**设计意图名称**。是约束核心，模型生成时必须引用这一层。

**关键原则**：
- ✅ 输出中**只能出现** semantic 名称（`color.brand-primary`）
- ❌ 输出中**不能出现** reference 原始值（`#FF6900`）

**文件清单**：

> 📌 加载策略说明：**【A】= 每次生成页面时必须并行加载**；**【B】= 遇到对应场景才读**。

| 文件 | 内容摘要 | 加载策略 | 何时读 |
|-----|---------|---------|-------|
| `color-semantic.md` | 通用颜色 Token：背景色 / 文字色 / 图标色 / 描边色 / 蒙层色 | 【A】必加载 | 所有页面 |
| `color-business.md` | 业务线专属色 Token：DPT1～DPT14 渐变色 / 纯色 | 【B】按需 | 页面含业务专属色时必读（小象/医药/酒店/金融/闪购/支付等，或含渐变色） |
| `font-semantic.md` | 文字 Token：字号 / 字重 / 行高（Text / Paragraph / Special 字体） | 【A】必加载 | 所有页面 |
| `spacing-semantic.md` | 间距 Token：spacing-3xl ～ spacing-2xs，页面/模块/卡片级，4pt 步进共 11 档 | 【A】必加载 | 所有布局间距 |
| `component-spacing.md` | 组件内部间距 Token：cs-1 ～ cs-60，⚠️ 仅限组件内部 padding/gap | 【A】必加载 | 所有组件内部间距 |
| `radius-semantic.md` | 页面级圆角 Token：radius-xxs（4pt）～ radius-xl（20pt）+ radius-full | 【A】必加载 | 所有卡片/浮层圆角 |
| `stroke-semantic.md` | 描边宽度 Token：border-default（0.5pt）/ border-bold（1pt）等 | 【A】必加载 | 所有分割线/描边 |
| `font-price.md` | 价格字体 Token：Price Set 各档字号/字重/颜色，美团新数字体专用 | 【B】按需 | 页面含价格数字（¥ / 整数 / 小数）时必读 |
| `component-radius.md` | 组件内部细粒度圆角 Token：cr-1（1pt）～ cr-4（4pt），⚠️ 仅限组件内部 | 【B】按需 | 写组件内部细粒度圆角（≤ 4pt）时必读 |
| `shadow-semantic.md` | 阴影 Token：`shadow-subtle`（弱） / `shadow-raised`（中，FAB/侧边栏）/ `shadow-overlay`（强，浮层/气泡）；⚠️ 绝大多数卡片不加阴影 | 【B】按需 | 含浮层类组件（Popover / Toast / Tooltip / FAB / 半页弹窗）时必读 |

**使用例**：
```markdown
✅ 正确：标题使用 text.heading-2，颜色为 color.brand-primary
❌ 错误：标题字号 28px 粗体，颜色 #FF6900
```

---

### Layer 3️⃣ Component（组件层）

**位置**：`references/component/`

**用途**：定义可复用的 UI 构建块。分原子和复合两类。

## 🗂️ 组件名全集（AI 选型必须对照此表，防止幻觉）

> 🚨 **强制规则**：AI 在第三步组件选型时，**所有组件引用必须且只能来自以下三张表**。
> 任何不在此处的组件名均视为幻觉，**必须立即停止使用并回到选型阶段**。❌ 禁止改用近似组件冒充；❌ 禁止输出「自定义组件」；如确实缺规范，必须先补组件规范后再生成。

### Atoms 层（`component/atoms/`）

| 文件名 | 组件中文名 |
|--------|-----------|
| `icon.md` | 图标 |

### Molecules 层（`component/molecules/`）

| 文件名 | 组件中文名 |
|--------|-----------|
| `button.md` | 按钮 |
| `tag.md` | 标签 |

### Components 层（`component/components/`）

| 文件名 | 组件中文名 | 简述 |
|--------|-----------|------|
| `badge.md` | 徽标 | 数字徽标、红点徽标 |
| `bottom-action-bar.md` | 底部操作栏 | 固定在视口底部的 CTA 操作区 |
| `bottom-navigation.md` | 底部导航栏 | 通用型/大促弱样式/大促强样式，2~5个选项，含推荐态/回顶部/未选首Tab |
| `bottom-sheets.md` | 半页弹窗 | 底部弹出多功能层，内容/列表/操作/组合4大类，**必须配蒙层（mask-default）** |
| `dialog.md` | 弹窗 | 模态对话框，含标题/内容/操作按钮 |
| `empty-state.md` | 空状态占位图 | 无数据/搜索无结果/网络错误/权限不足/加载失败，大/中/小3尺寸 |
| `filter-panel.md` | 筛选面板 | 平铺/级联9种子类型，单选/多选/自定义，点击筛选栏后展开 |
| `filter.md` | 筛选条 | 横向筛选标签 / 排序标签 |
| `floating-action-button.md` | 悬浮操作按钮 | FAB，单/多操作悬浮按钮 |
| `form.md` | 表单行 | 输入型/选择型表单条目 |
| `image-selection.md` | 图像选择与上传 | 选图格/预览格/图像上传/视频上传/常规型/证件型，含40个变体 |
| `list.md` | 列表行 | 含图标/头像/操作的结构化列表行 |
| `navigation.md` | 顶部导航栏 | NavBar，支持标题、左右操作区 |
| `notice-bar.md` | 通告栏 | 页面内嵌通告横条 |
| `notification-banner.md` | 通知横幅 | 顶部推送样式通知条 |
| `page-indicator.md` | 分页器 | 点状/横滑/数字/文字/进度条五大类型，附着于轮播图或卡片底部 |
| `popover.md` | 气泡浮层 | 用户主动触发的操作菜单气泡 |
| `rating.md` | 评分评价 | 只读/可交互星级评分，大/中/小/迷你4尺寸，整星/半星精度 |
| `search-bar.md` | 搜索框 | 60/68/72/88px四规格，强/中/弱类型，白底/灰底/描边样式，支持嵌入导航栏 |
| `select.md` | 选择器 | 单选/多选下拉选择 |
| `snackbar.md` | 底部横幅提示 | 底部短暂提示条 |
| `stepper.md` | 步进器 | 数量加减控制组件 |
| `switch.md` | 开关 | Toggle 开关 |
| `system.md` | 系统层组件 | Status Bar / Home Indicator 规范 |
| `tabs.md` | 选项卡 | 单行/双行、居中/居左、模块/分段型4大类变体，支持徽标 |
| `text-edit-menu.md` | 文本复制气泡 | 长按文本弹出，图标文本型/纯文本型，1~5项，支持省略翻页 |
| `text-input.md` | 文本输入框 | 完整版，含标签/辅助文字/状态 |
| `time-date-picker.md` | 时间/日期选择器 | 平铺日历式/平铺列表式/滚轮式，1~5列，底部确认按钮 |
| `toast.md` | 轻提示 | 居中短暂消失的提示 |
| `tooltip.md` | 气泡提示 | 引导说明气泡，系统触发 |
| `user-satisfaction.md` | 用户满意度 | NPS数字型/表情型（3/5项）/标签型（单选/多选），满意度收集组件 |

> ⚠️ `tag.md` 在 `component/molecules/` 和 `component/components/` 均有文件，属于历史遗留。**主引用入口统一使用 `component/molecules/tag.md`**（molecules 版本为完整规范），`component/components/tag.md` 仅作向后兼容保留，不计入上方主引用表。

**上方主引用表共 34 个入口（atoms 1 + molecules 2 + components 31）；另有 `component/components/tag.md` 1 个历史兼容文件，不作为首选引用源。**

### 🧭 组件路由注册表（P0，先路由再读正文）

> 用法：当用户说的是“口语词 / 高歧义词 / 结构词”而不是精确组件名时，**先按下表命中合法组件家族**，再去读对应 `.md` 正文。组件调用失败的根因通常不是“不会写样式”，而是**没有先完成路由收敛**。
>
> **执行顺序固定**：`抽路由槽位 → 命中注册表 → 排除相邻候选 → 形成唯一绑定 → 再读组件正文`。❌ 禁止跳过“排除相邻候选”直接按视觉直觉选组件。

| 组件家族 | 最终组件名 | 必备路由槽位（至少命中这些语义） | 所有权提示 | 一票否决 / 不是它时 | 唯一文件 |
|---|---|---|---|---|---|
| 顶部导航 | `navigation` | `position=top` + 有返回/标题/右操作，承担页面导航或标题承载 | 若嵌 `search-bar`，外层布局与 `size/style` 由 `navigation` 锁定 | 若核心任务是正文输入、底部切换或页面反馈，则不是它 | `component/components/navigation.md` |
| 底部 CTA 区 | `bottom-action-bar` | `position=bottom` + `fixed=true` + 承载提交/购买/确认/价格+操作 | Bar 拥有底部布局、按钮排布、占位高度；内部按钮只消费合法 `button` 规格 | 若核心任务是 2~5 项页面导航切换，则不是它 | `component/components/bottom-action-bar.md` |
| 底部主导航 | `bottom-navigation` | `position=bottom` + `fixed=true` + 2~5 项 tab + 任务是页面主导航切换 | 自己拥有导航语义与占位，不得被 CTA Bar 冒充 | 若核心任务是购买/提交/确认，则不是它 | `component/components/bottom-navigation.md` |
| 搜索入口 | `search-bar` | 核心任务是搜索输入 / 搜索触发 / 搜索结果入口 | 独立使用时可自持 style；嵌入 `navigation` 34pt 组合场景时 `size/style` 由父组件接管 | 若是通用文本录入、表单正文编辑，则不是它 | `component/components/search-bar.md` |
| 文本录入本体 | `text-input` | 用户需要填写文本内容，包含标签/辅助文案/状态 | 自己拥有输入状态与内部结构；若嵌在 `form`，行高/标题区/错误布局由 `form` 接管 | 若只是搜索入口或整行表单承载结构，则不是它 | `component/components/text-input.md` |
| 表单行承载 | `form` | 行级 label + value / error / arrow / selection，承担“表单项结构” | `form` 拥有行高、标题区宽、错误/说明布局；子控件只负责内部输入/选择行为 | 若只需要纯输入本体或纯下拉面板，则不是它 | `component/components/form.md` |
| 行内筛选条 | `filter` | 位于列表/内容上方，负责收起态筛选/排序入口 | `filter` 拥有收起态按钮/文字筛选入口 | 若已展开成抽屉/底部筛选面板，则不是它 | `component/components/filter.md` |
| 展开筛选面板 | `filter-panel` | 展开的右抽屉/底部筛选面板，负责承载筛选选项集合 | `filter-panel` 拥有展开层容器、位置与确认区；触发入口通常来自 `filter` | 若只是顶部筛选按钮条，则不是它 | `component/components/filter-panel.md` |
| 顶部/内容切换 | `tabs` | 顶部栏目切换 / 内容分段切换 | 自己拥有切换语义，可挂 `badge` 但不改主家族 | 若固定底部承担主导航切换，则不是它 | `component/components/tabs.md` |
| 普通选项选择 | `select` | 普通下拉 / 单选 / 多选选项 | 自己拥有选项集合；若在 `form` 中，宿主只接管行级布局 | 若是日期/时间/滚轮列选择，则不是它 | `component/components/select.md` |
| 日期时间选择 | `time-date-picker` | 日期 / 时间 / 滚轮列 / 日历式选择 | 自己拥有列结构与确认行为；若在 `form` 中，宿主只接管行级布局 | 若只是普通选项列表，则不是它 | `component/components/time-date-picker.md` |
| 顶部被动通知 | `notification-banner` | `position=top` + 系统被动出现 + 持续展示 | 自己拥有通知条结构 | 若在页面流内、底部短暂出现或需要强阻断，则不是它 | `component/components/notification-banner.md` |
| 页面流内通知 | `notice-bar` | 页面内容流内 + 持续展示 + 非模态 | 自己拥有内嵌提示条结构 | 若是顶部横幅、底部反馈或模态确认，则不是它 | `component/components/notice-bar.md` |
| 底部可撤销反馈 | `snackbar` | `position=bottom` + 短暂出现 + 可撤销/可操作 | 自己拥有短时反馈语义 | 若无操作且居中短暂消失，则不是它 | `component/components/snackbar.md` |
| 居中轻提示 | `toast` | 居中 + 短暂自动消失 + 轻反馈 | 自己拥有短时提示语义 | 若有撤销/二次确认/复杂操作，则不是它 | `component/components/toast.md` |
| 阻断确认 | `dialog` | 居中模态 + 必须用户处理后继续 | 自己拥有阻断层级与按钮区 | 若从底部滑出承载复杂内容，则不是它 | `component/components/dialog.md` |
| 底部半页承载 | `bottom-sheets` | 从底部滑出 + 半页 / 列表 / 复杂内容承载 | 自己拥有抽屉容器与 mask | 若只是小型确认弹窗或锚点气泡，则不是它 | `component/components/bottom-sheets.md` |
| 点击后菜单 | `popover` | 用户主动触发 + 锚点附近出现 + 承载菜单操作 | 自己拥有锚点关系 | 若是系统说明气泡或模态层，则不是它 | `component/components/popover.md` |
| 系统说明气泡 | `tooltip` | 系统说明 / 教学提示 / 引导语义 | 自己拥有说明型浮层语义 | 若是用户主动点击后的操作菜单，则不是它 | `component/components/tooltip.md` |
| 普通标签 | `tag` | 信息状态 / 权益 / 功能标签 / 激励标签 | 自己拥有标签样式；可附着在其他组件，但不承载未读数语义 | 若承载红点/角标/数字未读，则不是它 | `component/molecules/tag.md` |
| 角标徽标 | `badge` | 红点 / 数字 / 角标 / 未读数 | 自己拥有附着式徽标语义 | 若只是普通状态标签，则不是它 | `component/components/badge.md` |
| 结构化信息行 | `list` | 行级信息结构，存在 prefix / content / suffix 关系 | `list` 只拥有“行”本身，不拥有页面白卡容器 | 若只是白卡承载关系、分区容器或推荐模块结构，则不是它 | `component/components/list.md` |

### 🔗 区域化强关联路由表（P0，路由/预读/验收必须同轨）

> 目的：把 **`INDEX.md` 路由收敛**、**`component-quickref.md` 宿主收敛**、**`SKILL.md A2/A3` 的基于路由结果预读**、**`checklist.md §B` 二轮轮询** 串成一条硬链路。命中以下任一区域时，不只是“知道该选哪个组件”，而是要同步知道：**先锁谁、必须联读谁、最后由谁验收**。
>
> **执行纪律**：先按区域命中本表，再跳到对应组件正文；❌ 禁止只在一个文档里命中、其他文档不对账。凡命中下表任一行，最终都必须能在：
> - `component/component-quickref.md` 找到对应收敛口径
> - `SKILL.md` 的 `A2/A3/W1` 找到对应按路由结果执行的预读 / 写入前闭环要求
> - `checklist.md §B` 的「第二轮组件调用轮询」找到对应白名单验收项
>
>| 页面区域 / 结构位 | 先锁宿主 | 强关联子组件 / 相邻候选 | 必须联读文件 | 验收落点 |
>|---|---|---|---|---|
>| 顶部区：返回 / 标题 / 右操作 | `navigation` | `search-bar` / `icon` / `button` | `component/components/navigation.md` + `component/atoms/icon.md`（必要时） | `checklist.md §B` 的 `Navigation` 白名单项 |
>| 顶部区：导航内搜索 | `navigation` | `search-bar`（不是 `text-input`） | `component/components/navigation.md` + `component/components/search-bar.md` | `checklist.md §B` 的 `Navigation` + `Search Bar` |
>| 底部固定区：提交 / 购买 / 价格+操作 | `bottom-action-bar` | `button` / `icon` | `component/components/bottom-action-bar.md` + `component/molecules/button.md` | `checklist.md §B` 的 `Bottom Action Bar / Bottom Navigation` |
>| 底部固定区：2~5 项主导航切换 | `bottom-navigation` | `badge` / `icon` | `component/components/bottom-navigation.md` + `component/components/badge.md`（有未读数时） | `checklist.md §B` 的 `Bottom Action Bar / Bottom Navigation` |
>| 行内状态区：勾选 / 单选 / 多选 / 圆圈对勾 | `select` | `list` / `form` / `icon` | `component/components/select.md` + `component/components/list.md` / `component/components/form.md`（按宿主择一） | `checklist.md §B` 的 `Select` + `List / Form` |
>| 行内标签区：状态 / 权益 / 激励标签 | `tag` | `badge` | `component/molecules/tag.md` + `component/components/badge.md`（用于排错） | `checklist.md §B` 的 `Tag / Badge` |
>| 宿主角标区：红点 / 未读数 / 数量提醒 | `badge` | `tag` | `component/components/badge.md` + `component/molecules/tag.md`（用于排错） | `checklist.md §B` 的 `Tag / Badge` |
>| 筛选入口区：顶部收起态筛选 / 排序 / 分类入口 | `filter` | `filter-panel` | `component/components/filter.md` + `component/components/filter-panel.md` | `checklist.md §B` 的 `Filter / Filter Panel` |
>| 筛选展开区：右抽屉 / 底部筛选内容承载 | `filter-panel` | `filter` / `select` | `component/components/filter-panel.md` + `component/components/filter.md` + `component/components/select.md`（有选择态时） | `checklist.md §B` 的 `Filter / Filter Panel` + `Select` |
>| 结构化信息行：箭头 / 副标题 / 说明 / 选择承载 | `list` 或 `form` | `select` / `tag` / `badge` / `icon` | `component/components/list.md` / `component/components/form.md` + 对应叶子组件文件 | `checklist.md §B` 的 `List / Form` + 对应叶子项 |
| 任意宿主里的非文字 icon 槽位 | 宿主组件先锁定 | `icon-route` / `fixed-svg-exception` | 对应宿主组件 `.md` + `component/atoms/icon-quickref.md` + `component/atoms/icon.md`（必要时） | `checklist.md §B` 的 `图标来源与渲染合法性` |
| 任意区域的间距位点归属 | 先判页面层还是组件层 | `grid-layout` / `spacing-semantic` / `component-spacing` / 组件正文 | `templates/grid-layout.md` + `semantic/spacing-semantic.md` + `semantic/component-spacing.md` + 对应组件 `.md` | `checklist.md §A` 的 `间距 owner 已唯一判定` + `§B` 的 `间距归属冲突已清零` |
>| 浮层反馈区：阻断确认 | `dialog` | `bottom-sheets` / `toast` | `component/components/dialog.md` + `component/components/bottom-sheets.md`（用于排错） | `checklist.md §B` 的 `Dialog / Bottom Sheets / Toast / Snackbar` |
>| 浮层反馈区：底部半页承载 | `bottom-sheets` | `dialog` / `popover` | `component/components/bottom-sheets.md` + `component/components/dialog.md`（用于排错） | `checklist.md §B` 的 `Dialog / Bottom Sheets / Toast / Snackbar` |
>| 浮层反馈区：短时轻提示 | `toast` 或 `snackbar` | `dialog` / `bottom-sheets` | `component/components/toast.md` + `component/components/snackbar.md` | `checklist.md §B` 的 `Dialog / Bottom Sheets / Toast / Snackbar` |
>
> **强关联铁律**：命中上表任一行后，若 `INDEX.md` 的宿主选择、`component-quickref.md` 的收敛结论、`SKILL.md` 的预读文件集合、`checklist.md §B` 的白名单验收项四者任一对不上，视为**路由链断裂**，不得进入 HTML 写入或交付。

### 🪢 强关联闭环（四份文档必须引用同一结论）

| 环节 | 必须回答的问题 | 对应文档 |
|---|---|---|
| 路由收敛 | 这个区域先锁哪个宿主？为什么不是相邻候选？ | `INDEX.md` |
| 宿主收敛 | 在 `INDEX.md` 已给出候选后，宿主或高风险叶子最终应收敛到哪个合法落点？ | `component/component-quickref.md` |
| 预读执行 | 在路由结果已经收敛后，为了避免首轮漏调，这次必须提前读哪些文件、写入前还要核对哪些闭环条件？ | `SKILL.md A2/A3/W1` |
| 交付验收 | 最终 HTML 要按哪一项白名单逐条核？ | `checklist.md §B` |

> **使用方式**：任何 P0/P1 高风险组件，只要在其中一份文档里被命中，就必须顺着这四步走完整条链，不能只做“路由”不做“预读”，也不能只做“验收”不补“路由”。

### 🔀 高混淆组件图谱（命中这些词时先排错）

> 目的：很多错误不是“没找到组件”，而是**在相邻合法组件之间选错了**。命中下列任一组时，必须先回答“为什么不是另一个”。答不清就停。

| 混淆组 | 先问什么 | 正确落点信号 | 常见误判 | 必停条件 |
|---|---|---|---|---|
| `bottom-action-bar` vs `bottom-navigation` | 底部区域承担的是**提交/购买/确认**，还是**页面主导航切换**？ | CTA / 价格+操作 → `bottom-action-bar`；2~5 tab 主导航 → `bottom-navigation` | 因为都在底部就互相替代 | 同时像 CTA 区又像主导航，且无法确定主任务 |
| `navigation` vs `search-bar` vs `text-input` | 当前是**顶部导航宿主**、**导航内搜索入口**，还是**正文输入本体**？ | 顶部宿主 → `navigation`；导航内搜索 → `navigation + search-bar`；正文输入 → `text-input` | 把导航中的搜索直接落成 `text-input`，或用裸 header 冒充 `navigation` | 顶部区到底承担导航还是正文输入说不清 |
| `notification-banner` vs `notice-bar` vs `snackbar` vs `toast` vs `dialog` | 它出现在哪里？持续多久？是否阻断？是否可撤销？ | 顶部持续 → `notification-banner`；流内持续 → `notice-bar`；底部短暂可撤销 → `snackbar`；居中短暂 → `toast`；强阻断 → `dialog` | 把所有“提示/alert”都落成 `toast` 或 `dialog` | 位置 / 时效 / 阻断性 任一关键槽位不清楚 |
| `search-bar` vs `text-input` vs `form` | 它是**搜索入口**、**纯输入本体**，还是**整行表单项结构**？ | 搜索入口 → `search-bar`；输入本体 → `text-input`；行级表单承载 → `form` | 用普通输入框冒充搜索，或用 `form` 代替输入本体 | 搜索/录入/表单结构三种角色未分清 |
| `filter` vs `filter-panel` | 当前是**收起态入口**还是**展开态选项面板**？ | 顶部筛选条 / 胶囊入口 → `filter`；右抽屉/底部筛选面板 → `filter-panel` | 直接用一个组件兼任触发与展开层 | 未说明是否已展开 |
| `select` vs `time-date-picker` | 选的是**普通选项**还是**日期/时间/滚轮列**？ | 普通选项 → `select`；日期/时间/滚轮 → `time-date-picker` | 所有 picker 都落成 `select` | 没说清是否有时间/日期语义 |
| `tag` vs `badge` | 承担的是**状态/权益标签**还是**未读数/角标/红点**？ | 状态/权益 → `tag`；角标/未读 → `badge` | 胶囊视觉像就误判为 tag | 既像状态标签又像未读角标，语义未定 |
| `dialog` vs `bottom-sheets` vs `popover` vs `tooltip` | 是阻断确认、底部承载、点击菜单，还是系统说明？ | 阻断确认 → `dialog`；底部承载 → `bottom-sheets`；点击菜单 → `popover`；系统说明 → `tooltip` | 把所有浮层都收敛成 `dialog` | 触发方式与位置同时不清楚 |
| `list` vs `form` vs 白卡容器 / 业务区块 | 它描述的是**行级信息结构**、**表单项结构**，还是**页面承载关系**？ | 行级结构 → `list`；表单项结构 → `form`；白卡/推荐区/分组 → 先落结构层 | 把 `card` / 白卡容器误当成组件，或把行级承载误写成裸容器 | 只知道“长得像卡片/像一行”，不知道宿主结构 |

### ⛔ 组件选型强制核查规则

在完成组件列表后，**必须**按以下规则逐条自查：

**禁止规则 1**：组件列表中出现的任何组件名，**必须能在上方三张表中找到对应文件名**。找不到 = 幻觉组件，立即移除。

**禁止规则 2**：❌ **禁止自造组件名**（如 `card.md`、`carousel.md`、`accordion.md`、`header.md` 等上表中不存在的名称）。若需求无法映射到上表任一组件，必须停止生成并回到选型阶段，不得输出近似替代组件。

**禁止规则 3**：❌ **禁止把 `molecules/` 的组件当 `components/` 查询**——`button.md` 和 `tag.md` 在 `molecules/`，路径不同，引用时必须区分。

**禁止规则 4**：`component/components/` 目录下不存在空占位文件，上方列表即为全量。如需新增组件，必须先完成规范内容再创建文件，**不得提前引用不存在的文件**。

---

### Layer 4️⃣ Template（模板层）

**位置**：`references/templates/`

**用途**：页面级的布局规则与视觉语言参考，指导 AI 做布局决策和业务线色彩选择。

**文件清单**（`templates/` 根目录）：

| 文件 | 内容 | 何时读 |
|-----|------|--------|
| `grid-layout.md` | 栅格密度档位（紧凑 16px / 适中 24px / 宽松 32px）+ 页面边距 / 卡片间距 / @2x px 换算表 | **【A】每次生成页面必读** |
| `icon-grid.md` | 金刚区图标网格排版规范，含坑位宽高、角标、文字截断规则 | 页面含快捷入口 / 金刚区时读 |

> 🚨 **图标与间距 owner 总原则**：普通业务 icon 先走组件宿主，再走 `icon-quickref.md` / `icon.md`；只有 `stepper` 加减号与 `system` 状态栏 SVG 可走固定 SVG 例外。页面层 margin 只管页面/卡片/模块节奏，组件内部留白必须优先服从组件 `.md`，缺省时才回 `component-spacing.md`。

**视觉语言**（`templates/visual-language/`）：

各业务线设计中心的颜色语义、布局特征、NavBar 风格参考。**仅用于确认业务场景颜色语义，所有数值（px/pt/hex/Token）须来自 `semantic/` 或 `component/` 规范文件，不得从此处提取数值。**

| 文件 | 业务线 |
|-----|-------|
| `美团平台设计中心.md` | 美团平台 |
| `外卖履约平台设计中心.md` | 外卖履约 |
| `闪购设计中心.md` | 闪购 |
| `食杂零售设计中心.md` | 食杂零售 / 小象超市 |
| `酒店旅行设计中心.md` | 酒店旅行 |
| `医药健康设计中心.md` | 医药健康 |
| `金融服务设计中心.md` | 金融服务 / 美团支付 |
| `团购软硬件服务设计中心.md` | 团购软硬件 |

---

## 横切关注点

### Design Principles（设计原则）

**位置**：`references/design-principles/`

**用途**：定义设计的底层哲学和约束。所有设计决策都应对齐这些原则。

**文件清单**：

| 文件 | 内容 |
|-----|------|
| `brand-principle.md` | 品牌理念、色彩哲学、视觉风格 |

**何时读**：
- 生成设计方案后，对照这些原则做**最终检查**
- 当需要理解"为什么这样设计"时

---

**更新时间**：2026-04-29（补强图标槽位 icon-route 与间距 owner 路由；将 INDEX / SKILL / checklist 的图标与间距裁决口径强关联统一）

**维护人**：Likaimeng
