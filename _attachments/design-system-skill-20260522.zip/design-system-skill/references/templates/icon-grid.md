# 首页金刚区（Icon Grid）规范

> **使用入口**：第四步 HTML 原型输出 → 步骤 12「首页金刚区图标规范」
> **适用场景**：仅在生成含首页金刚区的页面时读取，其他页面无需加载。

12. **首页金刚区（Icon Grid）图标规范**：

    > 🚨 **金刚区图标容器不使用正圆，使用超椭圆（Squircle）**。超椭圆由 `border-radius: 30%` 实现，模拟 iOS/诺基亚 App 图标的连续曲率轮廓，比正圆更柔和，比直角圆角更流畅。

    **① 容器形状：超椭圆（Squircle）**
    ```css
    .icon-grid__icon {
      width: 96px; height: 96px;   /* 48pt × 2 */
      border-radius: 30%;           /* ✅ 超椭圆；❌ 禁止用 50%（正圆）或 border-radius:24px（方形圆角） */
      display: flex; align-items: center; justify-content: center;
    }
    ```

    **② 背景色：低饱和度浅色（色板第1档）**

    > ❌ **禁止使用高饱和渐变**（如 `#FF9233→#FF5500`）——视觉过重、识别疲劳。
    > ✅ **必须使用色板第1档**（最浅、低饱和），图标本体用第4档（中深）形成对比。

    | 业务 | 背景色（第1档） | 图标色（第4档） | Token 来源 |
    |------|--------------|--------------|-----------|
    | 外卖 | `#FFF8F0` | `#FF7700` | Orange-1 / Orange-4 |
    | 美食 | `#FFFADB` | `#CC9900` | Yellow-1 / Yellow-3 暗化 |
    | 买菜 | `#E1FAE8` | `#00B300` | Green-1 / Green-4 |
    | 电影/演出 | `#FFF1F0` | `#FF2D19` | Red-1 / Red-4 |
    | 酒店 | `#F0F7FF` | `#0A77F5` | Blue-1 / Blue-4 |
    | 团购 | `#FFFADB` | `#CC9900` | Yellow-1 / Yellow-3 暗化 |
    | 拼好饭 | `#FFF1F0` | `#FF0B62` | Red-1 / DPT1-m2 |
    | 闪购 | `#FFF1F0` | `#FF2D19` | Red-1 / Red-4 |
    | 医药健康 | `#E1FAE8` | `#02B19A` | Green-1 / Teal 中深（⚠️ 见注①） |
    | 更多 | `#F5F5F5` | `#555555` | `bg-page`（Grey-9）/ `text-secondary`（Grey-2） |

    > ①「医药健康」图标色 `#02B19A` 暂未收录在 Token 库（color-reference.md 无 `.Teal` 系列）；若设计稿明确要 Teal 调性可保留此裸色值，待 Token 补录后替换；若无强制要求可改为 `#00B300`（Green-4 / `green-default`）。

    **③ 完整 CSS + HTML 模板（复制可用）**：

    > 💡 **CSS 变量层说明**：图标色以 CSS 变量声明在 `:root`，后续统一改色只需改变量值，不改具体选择器。Token 来源见表格第三列。

    ```css
    /* ── CSS 变量层（Token 来源）────────────────────────────── */
    :root {
      --ig-waimai-bg:    #FFF8F0; /* orange-bg  / Orange-1 */
      --ig-waimai-fg:    #FF7700; /* orange-default / Orange-4 */
      --ig-meituan-bg:   #FFFADB; /* yellow-bg  / Yellow-1 */
      --ig-meituan-fg:   #CC9900; /* Yellow-3 暗化 */
      --ig-maicai-bg:    #E1FAE8; /* green-bg   / Green-1 */
      --ig-maicai-fg:    #00B300; /* green-default / Green-4 */
      --ig-dianying-bg:  #FFF1F0; /* red-bg     / Red-1 */
      --ig-dianying-fg:  #FF2D19; /* red-default / Red-4 */
      --ig-hotel-bg:     #F0F7FF; /* blue-bg    / Blue-1 */
      --ig-hotel-fg:     #0A77F5; /* blue-default / Blue-4 */
      --ig-tuangou-bg:   #FFFADB; /* yellow-bg  / Yellow-1 */
      --ig-tuangou-fg:   #CC9900; /* Yellow-3 暗化 */
      --ig-pinhaofan-bg: #FFF1F0; /* red-bg     / Red-1 */
      --ig-pinhaofan-fg: #FF0B62; /* DPT1-m2 */
      --ig-flash-bg:     #FFF1F0; /* red-bg     / Red-1 */
      --ig-flash-fg:     #FF2D19; /* red-default / Red-4 */
      --ig-medicine-bg:  #E1FAE8; /* green-bg   / Green-1 */
      --ig-medicine-fg:  #02B19A; /* Teal（暂未入Token，见注①） */
      --ig-more-bg:      #F5F5F5; /* bg-page    / Grey-9 */
      --ig-more-fg:      #555555; /* text-secondary / Grey-2 */
    }
    /* ── 超椭圆容器 ─────────────────────────────────────────── */
    .icon-grid__icon { width:96px; height:96px; border-radius:30%; display:flex; align-items:center; justify-content:center; flex-shrink:0; }
    /* 图标字号（父容器无 overflow:hidden → display:block + overflow:hidden） */
    .icon-grid__icon .font { display:block; height:52px; overflow:hidden; line-height:52px; font-size:52px !important; }
    .icon-grid__icon .font::before { line-height:52px; display:block; }
    /* 🚨 P0：a 标签必须重置，否则文字显示蓝色下划线 */
    .icon-grid__item { text-decoration:none; color:inherit; }
    /* ── 各业务背景 + 图标色（引用变量层）──────────────────── */
    .icon-grid__icon--waimai    { background:var(--ig-waimai-bg); }    .icon-grid__icon--waimai    .font { color:var(--ig-waimai-fg); }
    .icon-grid__icon--meituan   { background:var(--ig-meituan-bg); }   .icon-grid__icon--meituan   .font { color:var(--ig-meituan-fg); }
    .icon-grid__icon--maicai    { background:var(--ig-maicai-bg); }    .icon-grid__icon--maicai    .font { color:var(--ig-maicai-fg); }
    .icon-grid__icon--dianying  { background:var(--ig-dianying-bg); }  .icon-grid__icon--dianying  .font { color:var(--ig-dianying-fg); }
    .icon-grid__icon--hotel     { background:var(--ig-hotel-bg); }     .icon-grid__icon--hotel     .font { color:var(--ig-hotel-fg); }
    .icon-grid__icon--tuangou   { background:var(--ig-tuangou-bg); }   .icon-grid__icon--tuangou   .font { color:var(--ig-tuangou-fg); }
    .icon-grid__icon--pinhaofan { background:var(--ig-pinhaofan-bg); } .icon-grid__icon--pinhaofan .font { color:var(--ig-pinhaofan-fg); }
    .icon-grid__icon--flash     { background:var(--ig-flash-bg); }     .icon-grid__icon--flash     .font { color:var(--ig-flash-fg); }
    .icon-grid__icon--medicine  { background:var(--ig-medicine-bg); }  .icon-grid__icon--medicine  .font { color:var(--ig-medicine-fg); }
    .icon-grid__icon--more      { background:var(--ig-more-bg); }      .icon-grid__icon--more      .font { color:var(--ig-more-fg); }
    ```

    **HTML 结构模板（固定写法，不得改动节点层级）**：
    ```html
    <!-- 金刚区单个入口：必须用 <a> 标签，必须有 text-decoration:none（已在 .icon-grid__item 声明） -->
    <!-- data-slot / data-variant / data-state 为 SVCS Slot+Variant 接入必备，不得省略 -->
    <a class="icon-grid__item" href="#"
       role="button" aria-label="外卖"
       data-slot="icon-grid-item"
       data-variant="waimai"
       data-state="default">
      <div class="icon-grid__icon icon-grid__icon--waimai">
        <span class="font icon-iconfont-{name}-line-semibold" aria-hidden="true"></span>
      </div>
      <span class="icon-grid__label">外卖</span>
    </a>
    <!-- 图标名必须来自「🖼️ 图标速查表」，❌ 禁止凭感觉拼接 -->
    <!-- 医药健康：icon-iconfont-doctor-line-semibold（❌ 禁止用 medicine-line-semibold，不存在） -->
    <!-- data-variant 取值：waimai / meituan / maicai / dianying / hotel / tuangou / pinhaofan / flash / medicine / more -->
    ```
