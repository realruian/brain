# 页面栅格规范（Grid Layout）

>
> ⚠️ **关于单位的核心约定**：
> - 本文件所有数值均为 **@1x 逻辑像素（pt）**，即真实物理尺寸
> - 页面宽度 = **375pt**（@1x），设计稿画布 750px 是 @2x，生成 HTML 时 **1pt × 2 = px**（750px 画布下）
> - 本文件只记录**栅格相关数值**（margin、padding、gap、卡片宽度）；圆角、字号、颜色、描边等请查对应 semantic 文档
> - 间距数值直接引用 `references/semantic/spacing-semantic.md` 中的 Token，Token 对应关系：`spacing-xs`=6pt / `spacing-s`=8pt / `spacing-m`=10pt / `spacing-l`=12pt / `spacing-xl`=16pt
>
> **@2x px 换算速查（750px 画布）**：
>
> | Token | @1x pt | @2x px（HTML 实际写入值）|
> |-------|--------|-------------------------|
> | `spacing-xs` | 6pt | **12px** |
> | `spacing-s` | 8pt | **16px** |
> | `spacing-m` | 10pt | **20px** |
> | `spacing-l` | 12pt | **24px** |
> | `spacing-xl` | 16pt | **32px** |

---

## 一、基础约定

| 属性 | 值 |
|------|---|
| 页面宽度 | `375pt` |
| 最小页面高度 | `812pt` |
| 栅格基础单位 | 2pt |
| 密度档位 | 紧凑型 / 适中型（推荐）/ 宽松型 |

> ⚠️ **每次生成页面 HTML 前，必须先判定栅格密度档位，再查本表确定所有边距值。禁止凭感觉填写。**

---

## 二、单列卡片栅格（默认首选）

> ✅ **AI 生成页面时的默认布局，无特殊说明一律使用此方案。**
> 信息列表、商品卡、店铺卡、内容卡等所有常规内容，全部使用单列卡片排列：有左右 margin、有圆角。
> 🚫 **任何情况下不得默认使用通栏（贴边）布局，通栏仅限第四章列出的特定场景。**
> ❌ **卡片不加描边（border）、不加投影（box-shadow）。**

留边卡片（宽度 < 屏幕宽）。纵向间距与模块内信息层次间距关联，可按 2pt 梯度灵活调整。

> **档位与业务流程深度的对应关系（核心原则）**：
> 页面在业务流程中**越靠前**（曝光量大、用户频繁访问），栅格**越紧凑**；**越靠后**（低频、操作型），栅格**越宽松**。
> - 🔴 **紧凑型**：流程最前端，如各业务线首页（信息密度最高）
> - 🟡 **适中型 ⭐默认**：绝大多数业务页面，如列表页、搜索结果页、商品卡片流等
> - 🟢 **宽松型**：流程末端低频页面，如个人中心、设置页、品牌专题页等，⚠️ 慎用

> ⚠️ **页面边距推荐原则（750px 画布）**
> 卡片与页面边缘的左右 margin，@2x 写入值 **优先选 16px（spacing-s/8pt）或 24px（spacing-l/12pt）**。
> ❌ 尽量避免使用 32px（spacing-xl/16pt 宽松型）——32px 在 750px 宽度下视觉上偏宽，
> 会让卡片显得过于收窄、页面留白失衡，**仅在设置页/个人中心/品牌专题等流程末端低频页时才可使用**；
> ❌ 详情页一律使用适中型（24px），不可用宽松型。

| 档位 | 适用场景（按业务流程深度） | 页面左右 margin | @2x px | 卡片内左右 padding | 卡片间纵向间距 |
|------|----------------------|--------------|--------|------------------|-------------|
| 紧凑型 | 各业务线**首页**（流程最前端，高频高密度） | **`spacing-s` (8pt)** | **16px** | `spacing-xs` (6pt) 或 `spacing-s` (8pt) | `spacing-xs` (6pt) |
| 适中型 ⭐默认 | **绝大多数页面**：列表页、搜索页、商品卡片流等 | **`spacing-l` (12pt)** | **24px** ✅ 首选 | `spacing-s` (8pt) 或 `spacing-m` (10pt) | `spacing-s` (8pt) |
| 宽松型 | 流程末端**低频页**：设置、个人中心、品牌专题 ⚠️ 慎用 | **`spacing-xl` (16pt)** | **32px** | `spacing-m` (10pt) 或 `spacing-l` (12pt) | `spacing-m` (10pt) |

**卡片宽度 = 375 − 左margin × 2**：

| 档位 | 卡片宽度（@1x pt）| 卡片宽度（@2x px）|
|------|-----------------|------------------|
| 紧凑型（margin `spacing-s` 8pt / 16px）| **359pt** | **718px** |
| 适中型（margin `spacing-l` 12pt / 24px）| **351pt** | **702px** |
| 宽松型（margin `spacing-xl` 16pt / 32px）| **343pt** | **686px** |

---

## 三、双列卡片栅格

| 档位 | 页面左右 margin | 列间距 | 卡片内 padding | 适用场景 |
|------|---------------|-------|--------------|---------|
| 紧凑型 | **`spacing-xs` (6pt)** | **`spacing-xs` (6pt)** | `spacing-xs` (6pt) | 内容密度大、屏效要求高的首页推荐卡（如美团首页）|
| 适中型 ⭐推荐 | **`spacing-s` (8pt)** | **`spacing-s` (8pt)** | `spacing-s` (8pt) | 业务频道内首页推荐卡 |
| 宽松型 | **`spacing-l` (12pt)** | **`spacing-l` (12pt)** | `spacing-s` (8pt) | 内容量较少、注重视觉展示的推荐卡 |

**单张卡片宽度 = (375 − 左margin × 2 − 列间距) ÷ 2**：

| 档位 | 单卡宽度 |
|------|---------|
| 紧凑型（margin `spacing-xs` 6pt，列间距 `spacing-xs` 6pt）| (375 − 12 − 6) ÷ 2 = **178.5pt** |
| 适中型（margin `spacing-s` 8pt，列间距 `spacing-s` 8pt）| (375 − 16 − 8) ÷ 2 = **175.5pt** |
| 宽松型（margin `spacing-l` 12pt，列间距 `spacing-l` 12pt）| (375 − 24 − 12) ÷ 2 = **169.5pt** |

---

## 四、通栏卡片栅格

> 🚫 **优先级最低，非必要不得使用。**
> 绝大多数内容列表、信息展示应使用**单列卡片（第二章）**，有左右 margin 和圆角。
> 通栏卡片仅限以下明确需要贴边的场景：**Banner 横幅、地图卡、底部操作栏、系统设置型分割线列表**。
> ❌ 禁止将通栏卡片用于常规商品/店铺/内容列表。

通栏/贴边卡片横向与屏幕等宽（`375pt`），只有上下间距，无左右 margin。

| 档位 | 卡片上下外间距 | 卡片内 padding（上下）| 适用场景 |
|------|-------------|-------------------|---------|
| 紧凑型 | **`spacing-xs` (6pt)** | **`spacing-s` (8pt)** | 内容密度大、屏效要求高的页面 |
| 适中型 | **`spacing-s` (8pt)** | **`spacing-m` (10pt)** | 常规信息展示页面 |
| 宽松型 | **`spacing-m` (10pt)** | **`spacing-l` (12pt) 或 `spacing-xl` (16pt)** | 内容量较少、注重视觉展示的页面 |

---

## 五、模块/内容间距栅格

文字上下间距和卡片内外视觉间距感受保持一致。

| 档位 | 模块间距（区块之间）| 内容间距（卡片内部行间）|
|------|----------------|---------------------|
| 紧凑型 | **`spacing-xs` (6pt)** | **`spacing-xs` (6pt)** |
| 适中型 ⭐推荐 | **`spacing-s` (8pt)** | **`spacing-s` (8pt)** |
| 宽松型 | **`spacing-l` (12pt)** | **`spacing-m` (10pt) 或 `spacing-l` (12pt)** |

---

## 六、HTML 生成强制规则

### Step 0：判定密度档位（生成任何 CSS 前必须完成）

```
【核心判定逻辑：业务流程越靠前 → 越紧凑；越靠后 → 越宽松；绝大多数用适中型】

各业务线首页（外卖/闪购/到餐/酒旅等）    → 紧凑型（margin: spacing-s / 8pt / @2x 16px）
列表页、搜索结果页、商品卡片流、频道页   → 适中型（margin: spacing-l / 12pt / @2x 24px）⭐默认
详情页、订单页、评价页               → 适中型（margin: spacing-l / 12pt / @2x 24px）
设置页、个人中心、品牌专题、低频工具页   → 宽松型（margin: spacing-xl / 16pt / @2x 32px，⚠️ 慎用）
用户未指定                        → 适中型（默认）

⚠️ 卡片类型选择强制提示：
  · 默认使用「单列卡片」（第二章），有左右 margin + 圆角
  · 通栏卡片（第四章）优先级最低，仅限 Banner/地图/底部操作栏/系统设置分割线列表
  · ❌ 不得将通栏卡片用于常规列表，遇到拿不准的场景一律降级为单列卡片

⚠️ 页面边距强制提示：
  · 如判定为宽松型，请二次确认场景是否为详情页/品牌专题页
  · 若不确定，降档至适中型（24px）更安全，❌ 不得将「宽松」理解为默认大边距
```

**判定后必须在注释中声明**，例如：
```css
/* 栅格档位：适中型 | 页面margin:spacing-l(12pt) | 卡片padding:spacing-s(8pt) | 卡片间距:spacing-s(8pt) | 模块间距:spacing-s(8pt) */
```

> ⚠️ **750px 画布下的 CSS 写入规则**：本文件表格中已提供 **「@2x px（HTML 实际写入值）」列**，写 HTML 时**直接使用该列的 px 数值**（如 spacing-l = 24px），❌ 禁止把 pt 列的数字直接当 px 写入——750px 画布需要 ×2，pt 值直接写会导致间距偏小一半。

### Step 1：容器宽度撑满规则

```css
/* ✅ 正确：section 撑满页面（375pt → 375px） */
.section { width: 375px; box-sizing: border-box; }

/* ✅ 正确：带留边的内容区用 padding，不用 margin+width（spacing-l 12pt → @2x 24px，此处为 @1x 示例） */
.card-list { width: 375px; padding: 0 12px; box-sizing: border-box; }  /* @1x 示例，750px 画布请改为 24px */

/* ✅ 正确：flex 文字子项撑满剩余空间 */
.card-content { flex: 1; min-width: 0; overflow: hidden; }

/* ✅ 正确：Tag/行内容器撑满 */
.tag { display: flex; width: 100%; box-sizing: border-box; }

/* ❌ 错误：inline-flex 导致宽度由内容决定，不撑满 */
.tag { display: inline-flex; }

/* ❌ 错误：固定写死内容区宽度 */
.card-content { width: 150px; }
```

### Step 2：固定尺寸子项防压缩

```css
/* ✅ 固定尺寸子项（图片/图标等），必须加 flex-shrink:0 */
.shop-img  { flex-shrink: 0; }
.tag-icon  { flex-shrink: 0; }
.nav-back  { flex-shrink: 0; }

/* ✅ 推右对齐（箭头/操作区） */
.tag-arrow { flex-shrink: 0; margin-left: auto; }
```

### Step 2.5：卡片内图片圆角与贴边规则

> ⚠️ **图片严禁直接贴边（紧贴容器边缘），必须保留 padding 间距；图片四个圆角必须完全一致。**

```css
/* ✅ 正确：图片有 margin，不贴边 */
.shop-img { margin: 8px 0 8px 8px; border-radius: 8px; flex-shrink: 0; }

/* ✅ 头像：纯圆，四角一致 */
.avatar { border-radius: 9999px; flex-shrink: 0; }

/* ❌ 错误：图片贴边，无间距 */
.shop-img { margin: 0; }

/* ❌ 错误：只设置上方两角（与卡片底部"融合"写法） */
.shop-img { border-radius: 8px 8px 0 0; }

/* ❌ 错误：四角不一致 */
.shop-img { border-radius: 8px 4px 8px 4px; }
```

**图片圆角选择规则（与 `references/semantic/radius-semantic.md` 保持一致）：**

| 图片类型 | 圆角 Token | CSS 写法 |
|---------|-----------|---------|
| 头像（描述明确为「头像」） | `radius-full` | `border-radius: 9999px` |
| 非头像图片（显示尺寸 > 50pt） | `radius-xs`（6pt） | `border-radius: 12px` |
| 非头像图片（显示尺寸 <= 50pt） | `radius-xxs`（4pt） | `border-radius: 8px` |

---

### Step 3：单列卡片标准 HTML 骨架（适中型，直接可用）

```html
<!-- 适中型单列卡片（@1x 示例）：margin spacing-l(12pt)，卡片padding spacing-s(8pt)，间距 spacing-s(8pt)；750px 画布输出时对应写入 24px / 16px / 16px -->
<section style="width:375px; padding:0 12px; box-sizing:border-box; display:flex; flex-direction:column; gap:8px;">

  <article style="width:100%; display:flex; overflow:hidden; box-sizing:border-box;">

    <!-- 左侧图片：固定尺寸，flex-shrink:0，margin spacing-s(8pt) -->
    <img src="https://picsum.photos/seed/shop1/94/94"
         style="width:94px; height:94px; flex-shrink:0; margin:8px 0 8px 8px; object-fit:cover; display:block;"
         alt="" aria-hidden="true">

    <!-- 右侧内容区：撑满剩余空间，padding spacing-s(8pt)，左侧图文间距 spacing-xs(6pt) -->
    <div style="flex:1; min-width:0; display:flex; flex-direction:column; padding:8px 8px 8px 6px; justify-content:space-between; overflow:hidden; box-sizing:border-box;">

      <!-- 标题行：撑满，超长截断 -->
      <div style="width:100%; white-space:nowrap; overflow:hidden; text-overflow:ellipsis;">店铺名称</div>

      <!-- 副标题行 -->
      <div style="display:flex; align-items:center; gap:4px;">
        <span>4.9</span>
        <span>1.2km</span>
        <span>约20分钟</span>
      </div>

    </div>
  </article>

</section>
```

---

## 七、快速速查表

### 适中型 ⭐ 默认推荐

| 位置 | Token | pt 值 |
|------|-------|-------|
| 页面左右 padding | `spacing-l` | **12pt** |
| 卡片间纵向 gap | `spacing-s` | **8pt** |
| 卡片内 padding | `spacing-s` | **8pt** |
| 卡片内图文间距 | `spacing-xs` | **6pt** |
| 模块间距 | `spacing-s` | **8pt** |
| 单列卡片宽度 | — | **351pt**（375 − 12×2） |
| 双列单卡宽度 | — | **175.5pt** |

### 紧凑型

| 位置 | Token | pt 值 |
|------|-------|-------|
| 页面左右 padding | `spacing-s` | **8pt** |
| 卡片间纵向 gap | `spacing-xs` | **6pt** |
| 卡片内 padding | `spacing-xs` | **6pt** |
| 模块间距 | `spacing-xs` | **6pt** |
| 单列卡片宽度 | — | **359pt**（375 − 8×2） |
| 双列单卡宽度 | — | **178.5pt** |

### 宽松型

| 位置 | Token | pt 值 |
|------|-------|-------|
| 页面左右 padding | `spacing-xl` | **16pt** |
| 卡片间纵向 gap | `spacing-m` | **10pt** |
| 卡片内 padding | `spacing-m` 或 `spacing-l` | **10pt 或 12pt** |
| 模块间距 | `spacing-l` | **12pt** |
| 单列卡片宽度 | — | **343pt**（375 − 16×2） |
| 双列单卡宽度 | — | **169.5pt** |
