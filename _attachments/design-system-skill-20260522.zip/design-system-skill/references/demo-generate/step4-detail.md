# 第四步 HTML 输出 — 详细说明与模板

> **使用方式**：SKILL.md 第四步各步骤按需跳转到对应节，无需通读全文。
> **仅在遇到对应场景时读取对应节**，其余节跳过。

---

## §A 独立资源块注入机制原理

HTML 骨架中**不要预埋空的字体块**。注入脚本会在 `</head>` 前自动插入 `<style id="ds-font-inject">`，将 iconfont / 价格字体 / `.font` 基类与业务 CSS 物理隔离。标准骨架如下：

```html
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=750, initial-scale=1.0">
  <title>页面标题</title>

  <!-- ① 字体资源隔离块由 inject.py 在 </head> 前自动插入；模板中不要预埋空块 -->

  <!-- ② 业务样式：所有页面 CSS 只写在此块 -->
  <style>
    :root { /* CSS 变量 ... */ }
    body { /* 字体 fallback ... */ }
    /* 其余页面 CSS ... */
  </style>
</head>
```

> 脚本通过完整替换 `<style id="ds-font-inject">...</style>` 的方式管理注入区：每次运行先删旧块，再写新块，❌ 不改写业务 `<style>`。如果 HTML 中没有 `</head>`，脚本会退化为在 `<body>` 前插入资源块，但这只是兜底路径；标准模板仍应保证存在 `</head>`。❌ 不要在模板里手写空的 `<style id="ds-font-inject">`。

---

## §B 栅格 & 间距 CSS 变量模板

读完 `references/templates/grid-layout.md` + `references/semantic/spacing-semantic.md` + `references/semantic/component-spacing.md` 后，将所有间距写死为变量：

```css
:root {
  --page-margin: {grid-layout 对应值}px;      /* 页面左右边距 */
  --card-padding: {grid-layout 对应值}px;     /* 卡片内边距 */
  --gap-section: {spacing-semantic Token×2}px; /* 组间距 */
  --gap-inline: {component-spacing Token×2}px; /* 组件内图文间距 */
}
```

❌ 禁止在任何组件 CSS 中出现未声明来源的 margin/padding 数值（如凭感觉写 `margin: 16px`）。

---

## §C body 字体 fallback 原理

macOS 浏览器默认**亚像素渲染（subpixel）**，会让字体笔画看起来比设计稿偏粗约半个字重。`-webkit-font-smoothing: antialiased` 切换为灰度渲染，还原苹方 Regular 400 的细腻笔画，❌ 不得省略。

**完整 fallback（展开版）：**
```css
body {
  font-family: 'PingFang SC', 'Noto Sans SC', 'Source Han Sans SC',
               'Microsoft YaHei', 'WenQuanYi Micro Hei', sans-serif;
  -webkit-font-smoothing: antialiased;
  -moz-osx-font-smoothing: grayscale;
  text-rendering: optimizeLegibility;
}
```

**美团体（`special-title`）**：仅限 `special-title` 语义对应元素单独声明，❌ 禁止写入 body 全局：
```css
.brand-text {
  font-family: '美团体', 'PingFang SC', 'Noto Sans SC', sans-serif;
}
```
> 美团体在 macOS 系统 Family Name 为 `美团体`（`/Library/Fonts/meituantype-Regular.TTF`）。

---

## §D 导航返回按钮 HTML + CSS 模板

✅ 必须用 `icon-iconfont-translate-line-semibold`（纯箭头，无圆圈）
❌ 禁止用 `leftturn`（带圆圈）、`back`、`arrow-left` 或任何其他箭头类图标
❌ 按钮内图标 span **不加** `width`、`height`、`overflow:hidden`、`display:inline-block`——只设 `font-size` 和 `color`

```html
<button class="navbar__back" aria-label="返回">
  <span class="font icon-iconfont-translate-line-semibold" style="color:var(--text-primary)" aria-hidden="true"></span>
</button>
```
```css
.navbar__back { display:flex; align-items:center; justify-content:center; width:44px; height:44px; background:none; border:none; padding:0; flex-shrink:0; cursor:pointer; }
.navbar__back .font { font-size:44px; color:var(--text-primary); }
```

- ✅ 导航栏背景必须是 `#FFFFFF`（`white`），❌ 禁止用 `bg-page`（`#F5F5F5`）灰色
- ✅ `secondary` 导航标题：34px / font-weight 500（`subtitle-l-34-medium`），❌ 禁止用 40px/600

---

## §E 图标 span 规则（按场景选）

### 场景 A：导航栏图标（NavBar 返回 / 右侧操作）

❌ 图标 span **不加** `display`、`width`、`height`、`overflow:hidden`；只设 `font-size` 和 `color`。返回按钮固定 `icon-iconfont-translate-line-semibold`。

### 场景 B：按钮内 / 圆形容器内图标

必须用 `display:inline-block`；❌ 严禁 `overflow:hidden`。按钮本身若已裁剪圆角，子级图标再加 `overflow:hidden` 会把 `::before` 字形裁掉，导致图标空白。

```css
.btn-icon-left {
  display: inline-block;
  width: {size}px;
  height: {size}px;
  line-height: {size}px;
  font-size: {size}px;
  flex-shrink: 0;
  margin-right: 4px;       /* cs-2，icon-left → label 间距 */
  vertical-align: middle;
  /* ❌ 禁止 overflow:hidden */
}
```

### 场景 C：金刚区 / 搜索框 / 底部导航 / 列表行 / 卡片内图标

图标 span 作为 flex 子项时，默认也用 `display:inline-block`；❌ 禁止在图标 span 自身加 `overflow:hidden`。若需防文字溢出，`overflow:hidden` 只加在**非图标的文字节点**上。

```css
.icon-inline {
  display: inline-block;
  width: {size}px;
  height: {size}px;
  line-height: {size}px;
  font-size: {size}px;
  flex-shrink: 0;
}
```

> 根因：iconfont 图形依赖 `::before` 伪元素输出；图标 span 自身或其直接父容器错误施加 `overflow:hidden` 时，字形会被裁切至不可见。

---

## §F Stepper 加减图标 SVG 模板

❌ 不使用 iconfont，必须用 inline SVG。尺寸按 `stepper.md §6.4` ×2 换算。

```css
.stepper-icon-lg { width:24px; height:24px; display:block; flex-shrink:0; }
.stepper-icon-md { width:20px; height:20px; display:block; flex-shrink:0; }
.stepper-icon-sm { width:16px; height:16px; display:block; flex-shrink:0; }
```

```html
<!-- 加号（十字）-->
<svg class="stepper-icon-md" viewBox="0 0 20 20" fill="none" xmlns="http://www.w3.org/2000/svg" aria-hidden="true" style="display:block;flex-shrink:0;">
  <rect x="4" y="9" width="12" height="2" rx="1" fill="#111111"/>
  <rect x="9" y="4" width="2" height="12" rx="1" fill="#111111"/>
</svg>
<!-- 减号（横线）-->
<svg class="stepper-icon-md" viewBox="0 0 20 20" fill="none" xmlns="http://www.w3.org/2000/svg" aria-hidden="true" style="display:block;flex-shrink:0;">
  <rect x="4" y="9" width="12" height="2" rx="1" fill="#111111"/>
</svg>
<!-- 禁用态：fill 改为 #C2C2C2 -->
```

> viewBox 与尺寸对应：大号 `0 0 24 24` + `stepper-icon-lg`；标准 `0 0 20 20` + `stepper-icon-md`；小号 `0 0 16 16` + `stepper-icon-sm`。

---

## §G Toast loading 菊花图 CSS + HTML 模板

图片路径写占位符，由注入脚本统一替换。❌ 禁止 CSS border-spin 代替。

```css
/* 容器和 img 同样 ×2（@1x pt → @2x px） */
.spinner{display:inline-flex;align-items:center;justify-content:center;flex-shrink:0;overflow:hidden;}
.spinner.lg{width:72px;height:72px;}      /* vertical：36pt×2=72px */
.spinner.sm{width:36px;height:36px;}      /* horizontal：18pt×2=36px */
.spinner.lg img{width:60px;height:60px;display:block;}  /* 30pt×2=60px */
.spinner.sm img{width:30px;height:30px;display:block;}  /* 15pt×2=30px */
```

```html
<span class="spinner lg" role="progressbar" aria-label="加载中">
  <img src="{B64:~/Desktop/loading_white_1_iSpt.webp}" alt="" aria-hidden="true">
</span>
```

> ⚠️ 容器和 img 尺寸均 ×2，❌ 禁止写成 @1x 的 36px/18px 容器。

---

## §H 页面尺寸与浅色模式模板

标准模板如下：

```html
<meta name="color-scheme" content="light">
<meta name="viewport" content="width=750, initial-scale=1.0">
```

```css
html { background: #ffffff; color-scheme: light; }
body { width: 750px; min-height: 1624px; margin: 0 auto; }
```

- ❌ 禁止 `width=device-width`
- ❌ 禁止 `width=750px`（带 `px` 后缀无效）
- ❌ 禁止 `min-height:100vh`
- ❌ 禁止 `width:100vw / 100% / auto`
- ❌ 禁止遗漏 `<meta name="color-scheme" content="light">`

> `width=750` 是非标准 viewport；若缺少 `color-scheme: light`，Chrome 可能强制套用系统深色主题，导致页面背景发灰。`min-height:100vh` 在该环境下也可能导致内容区被压缩截断。