# 字体 & 资源注入脚本

> **使用入口**：第四步 HTML 原型输出 → 步骤 3「所有二进制资源注入」
> 🚨 **P0 规则**：每次用工具编辑已有 HTML 文件后，必须立即重新运行此脚本。

3. **所有二进制资源（iconfont / 价格字体 / 图片）统一用 Python 脚本注入 HTML**

   > 🚨 **P0 强制规则：所有 base64 编码操作必须通过 Python 脚本完成，❌ 严禁使用 `base64 | tr -d '\n'` 或任何 shell 命令获取 base64 后粘贴到 HTML。**
   >
   > **原因**：二进制文件 base64 后体积大（iconfont woff2 ~950KB，价格字体 otf ~10KB，图片不定），超过终端/模型单次输出上限时会被静默截断——截断的 base64 写入 HTML 后字体/图片损坏，浏览器无报错，表现为图标全空白或图片不显示，极难排查。Python 在本地读写文件，完全绕过输出限制。

   **🚀 调用方式（常驻脚本，无需写临时文件，无 `rm`，无确认弹窗）**：

   ```bash
   python3 /Users/kaimeng/.catpaw/skills/skills-market/design-system-skill/assets/inject.py "/path/to/output.html"
   ```

   > 🚨 **P0 规则：每次用工具编辑已有 HTML 文件后，必须立即重新运行此命令。** 编辑工具写回文件可能破坏已注入的字体/图片资源，重新注入才能恢复。❌ 不得跳过、不得等用户提醒。

   > 🔑 **独立资源块注入机制**：脚本会在 `</head>` 前自动插入 `<style id="ds-font-inject">`，将 `@font-face`、`.font` 基类和价格字体数据与业务 `<style>` 物理隔离。Step 0 会先删除旧的 `ds-font-inject` 块，再插入新的资源块；❌ 不会改写业务 CSS。支持**幂等执行**，运行多次结果相同。

   **HTML 骨架要求（模板中不要预埋空块）**：
   ```html
   <head>
     <!-- 业务 style 正常写 -->
     <style>
       :root { /* CSS 变量 */ }
       /* 页面其他 CSS ... */
     </style>
   </head>
   ```
   > ❌ 不要在模板里手写空的 `<style id="ds-font-inject">`；该块只允许由 `inject.py` 自动插入。

   **使用规则**：
   - 生成新 HTML 后：立即运行一次（首次注入）
   - 修改已有 HTML 后：立即再次运行（重新注入）
   - 图片 src 写占位符 `src="{B64:~/Desktop/loading_white_1_iSpt.webp}"`，脚本统一替换
   - 运行后告知用户「已重新注入字体，且 `ds-font-inject` 资源块校验通过，刷新浏览器即可」

   > 📂 **常驻脚本完整代码** → `assets/inject.py`（如需查看或修改逻辑，直接读该文件）

   > ⚠️ **为什么图标随机空白？**——`font-display:block` 是关键。浏览器解析 base64 内联字体有延迟，默认 `auto` 会在字体未就绪时隐藏图标。`block` 强制等字体解析完再渲染，消除竞态。❌ 不得手动移除。

   > ❌ **任何文件缺失时**：跳过该项并打印警告，❌ 不得写入空字符串或损坏的 base64。
