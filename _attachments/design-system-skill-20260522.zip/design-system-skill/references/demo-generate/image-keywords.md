# 🔑 图片关键词速查

> **图片源优先级说明（先判来源，再决定怎么写）**：
> - ✅ **第一优先级：用户提供的业务图片 / 素材包 / 页面截图中的真实素材** — 只要用户给了，就优先使用，不得降级成通用占位图
> - ✅ **第二优先级：已有 HTML / 原始页面中已存在的业务图片资源** — 修改页面时优先保留原图，不得被新占位图覆盖
> - ✅ `randomuser.me/api/portraits/{gender}/{0-99}.jpg` — **头像专用占位**，仅在用户未提供真实头像时可用
> - ⚠️ `images.unsplash.com/photo-{具体ID}?w=&h=&fit=crop` — **高质量备选**，需填入真实存在的 photo ID（见下方品类参考 ID 表），❌ 不得随意猜测 ID
> - ⚠️ `picsum.photos/seed/{关键词}/{w}/{h}` — **通用语义占位**，仅在没有任何业务图可用时使用
> - ❌ `source.unsplash.com/featured/` — **已永久失效（2023 年底 Unsplash 关闭 Source API）**，❌ 禁止使用，生成 HTML 后会显示图片加载失败

---

## 0. 业务图片 / 页面截图优先规则（新增，最高优先级）

> **只要用户提供了业务图片、素材包、页面截图，就先用这些真实素材，不再优先走占位图。**

### 0.1 业务素材映射顺序（生成 HTML 前先做这一步）

1. **先看用户显式说明**：若用户已说明“哪张图对应哪个模块/哪段文案”，直接采用，不要重判
2. **再看文件名语义**：如 `cherry-banner.png`、`store-cover.jpg`、`coupon-popup.png`，文件名本身可作为第一层映射线索
3. **再看模块位置**：若素材和页面截图同时提供，用截图里的位置判断它属于 Banner、商品卡、店铺头图、弹窗插图还是列表配图
4. **最后看相邻文案语义**：只有当 1~3 仍不够时，才用就近文案辅助归位

> 🚫 若以上四步后仍无法唯一确定“这张业务图对应哪个模块/文案”，**必须停止猜测并向用户索要对应关系**。

### 0.2 页面截图怎么用

- **完整页面截图**：可用于恢复页面模块顺序、区块有无、图片位置关系
- **局部截图**：仅可用于对应局部模块，❌ 不得推断整页完整结构
- **只有截图没有单独素材**：可将截图中的图片视为真实素材参考，但不要把低清整页截图硬切成商品图反复复用

### 0.3 交付判定

- 文案是“车厘子”，图片却是汽车 / 街景 / 无关商品 → **`P0` 图片语义错误，禁止交付**
- 用户已给真实业务图，却仍使用 `picsum` / `Unsplash` → **`P1` 素材优先级错误，必须回改**
- 用户只给了部分页面素材，缺失区域暂用语义占位图 → 可继续，但必须保证图文一致

---

## 核心原则：图片内容必须和文案语义一致（最高优先级规则，不可绕过）

> - ✅ 标题是「新鲜樱桃 500g」→ 业务图就用对应樱桃商品图；无业务图时也必须找 **`樱桃/cherry` 本体**，而不是泛化成 `fruit`
> - ✅ 标题是「如家酒店·北京朝阳」→ 业务图就用对应酒店房型/门店图；无业务图时也必须找 **`hotel-room`** 这一层，不要退化成 `building`
> - ✅ 标题是「草莓芝士蛋糕」→ 业务图就用对应蛋糕图；无业务图时也必须找 **`strawberry-cake`**，不是任意甜品
> - ❌ **严禁用通用词兜底**（如把所有菜品图都写 `food`）——文案说「樱桃」就必须是 `cherry`，绝不能出现洋葱、土豆、汽车等无关图片
> - ❌ **严禁所有图片 seed 相同**——同一页面内每张图都必须对应各自的文案内容提取关键词，seed 不同则图片不同
> - ❌ **严禁忽略用户提供的业务图**——只要用户已经给了真实素材，就不能再退回到“语义差不多”的占位图
> - ❌ **严禁把 `picsum` 当成精确找图工具**——它只适合稳定占位，不适合保证“樱桃就一定是樱桃”

---

## `picsum.photos/seed` 的使用边界（稳定，但不保证语义命中）

> ⚠️ `picsum.photos/seed/...` 的 `seed` 只能让结果**相对稳定**，**不能保证返回图片一定符合关键词语义**。
> 因此它只能用于**低风险装饰占位**，不能用于“文案和图片必须精确对应”的主体图片。

### 什么时候不能用 `picsum`

- 文案里有**明确主体词**：如 `樱桃`、`草莓`、`汉堡`、`拉面`、`酒店房间`
- 图片承担**核心信息表达**：如商品主图、店铺头图、Banner 主视觉
- 用户已经明确反馈过“图文不一致”

### 关键词提取规则（仅在允许使用 `picsum` 时逐图执行）

1. **读取该图片区域旁边的文案/标题**（商品名、店名、分类标签等）
2. **提取核心名词翻译为英文**：`樱桃→cherry` / `蛋糕→cake` / `酒店→hotel` / `火锅→hotpot` / `拉面→ramen` / `奶茶→milktea` / `手机→phone` / `护肤品→skincare`
3. **拼接连字符组成 seed**：`cherry-fruit`（樱桃）/ `ramen-japanese`（拉面）/ `hotel-room`（酒店）
4. **同页多图换 seed 保证不重复**：`cherry-fruit-1` / `cherry-fruit-2` / `cherry-red`

### picsum 写法模板

```html
<!-- ✅ 正确：文案「新鲜樱桃」→ seed=cherry-fruit，w/h 对应显示区域 @2x px -->
<img src="https://picsum.photos/seed/cherry-fruit/188/188" style="width:188px;height:188px;object-fit:cover;" alt="" aria-hidden="true">

<!-- ✅ 正确：文案「如家酒店」→ seed=hotel-room，宽度 750px 的 Banner -->
<img src="https://picsum.photos/seed/hotel-room/750/400" style="width:100%;height:400px;object-fit:cover;" alt="" aria-hidden="true">

<!-- ✅ 正确：多图不重复 seed（同页三个商品图） -->
<img src="https://picsum.photos/seed/ramen-1/144/144" ...>
<img src="https://picsum.photos/seed/ramen-2/144/144" ...>
<img src="https://picsum.photos/seed/ramen-3/144/144" ...>
```

### picsum seed 参考速查（按品类）

| 品类 | seed 示例（连字符拼接，不用逗号） |
|------|-------------------------------|
| 水果类 | `cherry-fruit` / `strawberry-fresh` / `mango-tropical` / `grape-purple` / `apple-red` |
| 蔬菜类 | `broccoli-green` / `tomato-fresh` / `carrot-vegetable` |
| 熟食/菜品 | `ramen-japanese` / `hotpot-spicy` / `sushi-japanese` / `burger-beef` / `pizza-italian` |
| 甜品/烘焙 | `cake-dessert` / `croissant-bakery` / `matcha-dessert` / `icecream-sweet` |
| 饮品 | `coffee-latte` / `milktea-bubble` / `juice-fresh` / `beer-cold` |
| 生鲜超市 | `meat-fresh` / `seafood-market` / `egg-farm` / `milk-dairy` |
| 酒店 | `hotel-room` / `hotel-lobby` / `resort-pool` / `bedroom-luxury` |
| 景点/旅行 | `mountain-travel` / `beach-ocean` / `city-landmark` / `temple-asian` |
| 民宿/公寓 | `apartment-cozy` / `interior-modern` / `livingroom-bright` |
| 药品/健康 | `medicine-healthcare` / `vitamin-supplement` / `hospital-clean` |
| 零售商品 | `skincare-cosmetic` / `phone-technology` / `headphone-audio` |
| 促销/Banner | `shopping-sale` / `discount-colorful` / `festival-celebration` |
| 外卖/骑手 | `delivery-food` / `rider-moto` / `takeout-bag` |
| 店铺/门头 | `restaurant-front` / `cafe-shop` / `store-interior` |

---

## 头像专用：randomuser.me（稳定，头像场景必用）

```html
<!-- ✅ 用户头像用 randomuser.me，gender=men/women，数字 0～99 换人 -->
<img src="https://randomuser.me/api/portraits/women/12.jpg" width="80" height="80" style="border-radius:50%;object-fit:cover;flex-shrink:0;" alt="" aria-hidden="true">
<img src="https://randomuser.me/api/portraits/men/34.jpg" width="80" height="80" style="border-radius:50%;object-fit:cover;flex-shrink:0;" alt="" aria-hidden="true">
```

> 规则：同页不同用户换不同数字（0～99），女性用 `women/`，男性用 `men/`，评价区用户统一随机分配，❌ 禁止所有头像用同一个数字。

---

## 高质量备选：images.unsplash.com（需真实 photo ID）

> ⚠️ **使用前提**：必须填入以下已验证存在的 photo ID，❌ 禁止随意拼凑或猜测 ID（猜测的 ID 大概率 404）。

### 已验证可用的 photo ID 参考表

| 场景 | Photo ID | 预览尺寸示例 |
|------|----------|------------|
| 食物综合 | `photo-1546069901-ba9599a7e63c` | `?w=400&h=400&fit=crop` |
| 拉面/面条 | `photo-1569718212165-3a8278d5f624` | `?w=400&h=300&fit=crop` |
| 汉堡 | `photo-1568901346375-23c9450c58cd` | `?w=400&h=300&fit=crop` |
| 寿司 | `photo-1553621042-f6e147245754` | `?w=400&h=300&fit=crop` |
| 蛋糕/甜品 | `photo-1488477181946-6428a0291777` | `?w=400&h=400&fit=crop` |
| 咖啡 | `photo-1495474472287-4d71bcdd2085` | `?w=400&h=300&fit=crop` |
| 酒店房间 | `photo-1631049307264-da0ec9d70304` | `?w=702&h=400&fit=crop` |
| 城市夜景 | `photo-1477959858617-67f85cf4f1df` | `?w=750&h=400&fit=crop` |
| 外卖/骑手 | `photo-1526367790999-0150786686a2` | `?w=400&h=300&fit=crop` |
| 超市/生鲜 | `photo-1542838132-92c53300491e` | `?w=400&h=300&fit=crop` |
| 护肤品/化妆品 | `photo-1598440947619-2c35fc9aa908` | `?w=400&h=400&fit=crop` |
| 手机/电子 | `photo-1511707171634-5f897ff02aa9` | `?w=400&h=400&fit=crop` |

```html
<!-- ✅ 使用已验证 ID，注意尺寸参数和页面 @2x 一致 -->
<img src="https://images.unsplash.com/photo-1546069901-ba9599a7e63c?w=400&h=400&fit=crop&q=80"
     style="width:400px;height:400px;object-fit:cover;" alt="" aria-hidden="true">
```

---

## 网络不可用时：纯色占位背景

> **图片完全无法加载** → 用品牌色系最浅档做纯色占位背景（比灰色更有设计感），❌ 禁止用无 `src` 的裸 `<img>` 或空 `<div>`：

| 场景 | 背景色 | CSS 值 |
|------|--------|--------|
| 美团平台 / 闪购 / 促销营销 | Yellow-1（暖黄） | `background: #FFFADB` |
| 到店团购 / 外卖到餐 / 快消零售 | Orange-1（浅橙） | `background: #FFF8F0` |
| 医药 / 健康 / 正向反馈 | Green-1（浅绿） | `background: #E1FAE8` |
| 酒店 / 旅行 / 信息展示 | Blue-1（浅蓝） | `background: #F0F7FF` |
| 金融 / 支付 / 警示提醒 | Red-1（浅红） | `background: #FFF1F0` |
| 会员 / 权益 / 高端场景 | Purple-1（浅紫） | `background: #F8F2FF` |
| 通用兜底 | Grey-9（页面灰） | `background: #F5F5F5` |

---

## 图片生成完整决策流程

```
每张图片区域：
0. 先判断用户是否提供了业务图片 / 页面截图 / 原始页面图片资源
1. 若有用户显式映射 → 直接使用该真实素材
2. 若无显式映射 → 用 文件名语义 → 模块位置 → 相邻文案语义 依次归位
3. 若仍无法唯一归位 → 停止猜测，向用户索要图片对应关系
4. 若没有任何业务图可用 → 先判断该图片是否属于“必须精确语义命中”的主体图
5. 若是主体图（如商品主图/Banner/店铺头图）→ 优先找可验证真实图；找不到就降级为纯色占位或请求补图
6. 若不是主体图且允许占位 → 才读取旁边文案 → 提取核心名词 → 翻译英文
7. 仅在低风险占位场景下拼接 seed：{英文名词}-{类别修饰词}（如 cherry-fruit）
8. 写入：<img src="https://picsum.photos/seed/{seed}/{w}/{h}">
9. 同页多图检查：每张图 seed 不同 ✅ / 有相同 seed → 加数字后缀区分
10. 头像场景：改用 randomuser.me，数字 0-99 不重复
11. 若有现成高质量 Unsplash ID（见上表）且匹配场景 → 可用 images.unsplash.com 替换
```
