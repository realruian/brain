# 输出检查清单 & 速查表

> 本文件分为**两段**，按运行模式触发：
> - **§A 设计决策核验**：仅 Full Harness / 高风险任务在第三步完成后触发；约束必须在决策发生前生效。
> - **§B HTML 输出验收**：所有任务都在第四步 HTML 写完并注入字体后触发；验证生成结果，不可事前预判。
> **维护者**：李开蒙、陆洋 | **版本**：1.21.0 | **更新**：2026-04-29

---

## §A 设计决策核验

> **触发时机**：**仅 Full Harness / 高风险任务** 在第三步完成后、第四步写任何 HTML 之前触发。默认 Fast Path 不跑本段，避免把低风险任务拖进重核验流程。不得用此段在 HTML 写完后做事后审查。
>
> **命中本段错误时的统一回退口径**：
> - **回 `D2`**：业务语义 → `page_mode` 路由错误、业务气质章节判错、组件别名归一错误、组件家族选错、样式词找不到合法来源
> - **回 `D3`**：声明表缺字段、来源缺失、`variant/size/state` 缺失、`density_mode` / `cta_priority` / `module_order` 前后冲突、声明表与准备输出的页面骨架不一致
> - **禁止**：在 `§A` 发现问题后直接进入 HTML 修修补补；`§A` 的问题只能在 `D2 / D3` 解决

**🚫 反模板核查（首先必须完成，不可跳过）**
- [ ] **渐变色大背景**（紫→蓝、橙→红等）：装饰性过强 → 改用 `bg-page` #F5F5F5 灰底 + 白色卡片
- [ ] **装饰性统计数字**（「98% 满意度」「10万+用户」）：无业务依据 → 只写真实数据，无数据则不写
- [ ] **无意义图标装饰**（在文字旁随意加图标）：增加噪音 → 仅在图标有明确语义时使用
- [ ] **大量彩色渐变角标/标签**：争抢注意力 → 最多 1-2 个强调色标签
- [ ] **「查看更多」「了解详情」占位文字**：无内容的内容 → 写真实操作文案，或不写
- [ ] **纯白大块通栏（整页无层次）**：缺少空间节奏 → 灰底 + 白卡片建立层次
- [ ] **多余的装饰性分割线**：分割线有明确语义（`list.md §7`），随意添加属于噪音 → 用间距和背景色分区
- [ ] **为填满空间添加的图标/数字/色块**：区块感觉空时用布局构图解决 → 调整比例、加大空白、重构信息层级

**视觉语言（首先必须完成，不可跳过）**
- [ ] **页面模式 Schema 已完整声明**：D3 声明表中的 `page_mode / primary_goal / primary_info / cta_priority / density_mode / tone_source / forbidden_bias / module_order / forbidden_order` 已全部填写，且每项只有一个明确值；❌ 禁止多候选并列
- [ ] **业务语义词已先路由到页面模式**：`大促 / 会场 / 结果页 / 履约 / 强转化 / 种草 / 服务保障 / 支付成功 / 收银台` 等词已先归一到合法 `page_mode`，❌ 禁止直接把业务语义词翻成颜色、布局或模块堆叠
- [ ] **业务线确认**：已在第一步确认业务线，已读取对应 `templates/visual-language/{设计中心}.md`
- [ ] **主色来源**：先由该业务线 `visual-language` 判定场景语义，再落到合法 Token；外卖通用主 CTA = `gradient-yellow`，命中业务专属覆盖时再落到对应业务色（团购软硬件 `orange-default`、直播特价团 `dpt1-g-m`、拼好饭 `dpt3-g-r`、神枪手 `dpt4-g-b`、到餐 DPT5、医药健康·买药 `dpt7-g-t`、小象超市 `dpt12-g`、美团公益 `dpt13-t`；问诊场景主 CTA 用 `green-default`）；`orange-default` 不得直接当外卖主 CTA 背景，禁止凭感觉选色或跨业务线混用
- [ ] **NavBar 样式**：背景色、文字色已按 visual-language 确认，禁止默认白底黑字而不查
- [ ] **消息/通知状态**（如有）：查对应 visual-language 通知状态章节，活跃态深色背景 + 失效态灰度化，禁止三态同样式
- [ ] **进度条颜色**（如有）：美团/外卖/闪购用黄 `#FFD100`；特价团/拼团用粉红 `#FF2D7D`；评价激励用橙 `#FF6600`，禁止混用
- [ ] **直播/精选频道**（如有）：查 visual-language 直播章节，品牌黄 + 黑底或渐变背景，禁止用橙色主题
- [ ] **页面模式与流程阶段一致**：`page_mode` 与 `page_stage` 不冲突；如 `payment` 阶段不应路由成 `content-browse`，`fulfillment` 阶段不应路由成 `promo-campaign`，冲突时必须回查用户描述重判
- [ ] **页面模式与业务气质来源一致**：`tone_source` 已明确写到具体 `visual-language` 文件与章节，且该章节确实支持当前页面模式的表达，不得只写文件名不写章节
- [ ] **默认模块顺序已声明**：`module_order` 已按当前 `page_mode` 的默认骨架逐项填写，不得漏写主要模块；若有偏离，必须在声明中写明理由
- [ ] **禁忌排序已声明**：`forbidden_order` 至少写明 1 条当前模式禁止出现的排序错误，不能留空

**SVCS 分层核验（小做版）**
- [ ] **SVCS 顺序未跳步**：当前方案已按 `Scenario → Visual → Component → Semantic` 完成路由；❌ 禁止在 `page_mode` / `module_order` 未确定前先选组件，或在组件未选型前先写 Token/CSS
- [ ] **Visual 未越权**：`visual-language` 仅用于页面层布局、业务氛围、模块关系与位置规律；❌ 禁止用它决定组件内部 `variant/size/state`、内部样式或任何数值来源
- [ ] **Component 可回溯**：所有命中组件的区域都能回溯到具体 `references/component/*.md` 文件及对应 `variant/size/state`；❌ 找不到组件正文时不得继续生成“近似实现”

**色彩 & Token**
- [ ] 颜色名称来自 `references/semantic/color-semantic.md`（HTML 时以下方速查表 A 的 hex 为准）
- [ ] **大面积背景色**：用浅色档位（O1/B1/Y1/G1/P1 等 `-bg` Token），禁止用饱和主色（如 `orange-default`）填充大面积背景
- [ ] **订单/核销/状态区横幅**：背景必须用白色（`#FFFFFF`）或极浅背景（`orange-bg`/`#FFF8F0`），**状态图标用圆形浅色背景（`orange-bg`）+ 橙色图标**，禁止用饱和橙色/渐变橙色填充整块横幅（整屏橙底白字是常见错误，用户看到色块感觉廉价）
- [ ] **业务色**：查 `references/reference/color-reference.md §四 Business Color`，禁止通用色冒充业务色
- [ ] **业务专属色优先**：若业务线在 `references/semantic/color-business.md` 中有专属颜色 Token（如小象超市 `dpt12-g` = `#00CF22`），**必须优先使用业务专属色覆盖通用功能色**（如 `green-default` = `#00B300`）；禁止用通用 Semantic Token 替代业务专属色——两者视觉上接近但并不相同，混用会导致品牌色偏差
- [ ] **跨业务线颜色**：主色已来自已加载的 visual-language 文件，禁止跨业务线混用主色
- [ ] **数值来源核查**：视觉方案中所有 px/hex/Token 数值来自 `semantic/` 或 `component/`；❌ 禁止从 `visual-language` 文件中提取或推断任何数字（visual-language 只描述场景语义，不是数值来源）
- [ ] **样式词来源回溯**：用户明确提到的样式词（如“大标题 / 灰底 / 胶囊按钮 / 小圆角 / 品牌橙 / 间距大一点”）已在声明表中逐条回溯到具体来源文件 §；❌ 禁止只写最终样式、不写来源
- [ ] **样式归属正确**：颜色/字体/间距/圆角/描边/阴影已按归属路由到正确层级（`semantic` / `component` / `grid-layout.md` / `visual-language`），❌ 禁止跨层取值
- [ ] **感受型词已被转译**：用户若使用「高级一点 / 更精致 / 更轻盈 / 更有设计感 / 更柔和」等感受型词，已先转译成合法规范项（字号层级 / 间距 / 圆角 / 背景层次 / 组件变体），❌ 禁止直接把感受型词翻译成 CSS
- [ ] **价格文字颜色**：默认所有业务线用 `red-default`（`#FF2D19`）；**到餐（DPT5）例外**，价格色改用 `dpt5-o5`（`#FF4B10`）；原价划线文字统一 `text-tertiary`（`#888888`）；禁止凭感觉选色
- [ ] **优惠/满减/优惠券金额颜色**：优惠金额文字（满减/立减/优惠券面额）**必须用 `red-default`（`#FF2D19`）**；❌ 严禁用 `green-default`（`#00B300`）——绿色代表"成功/完成"语义，不代表优惠；券标签（`coupon`）/拼接标签（`splice`）的颜色系统均基于 `red-*` Token，没有绿色变体
- [ ] **🚫【无障碍硬性规则】黄色系（Y1–Y5）禁止用于文字色**：黄色色阶 Y1（`#FFFADB`）→ Y5（`#FFDD00`）与白色或浅色背景的对比度均低于 WCAG AA 标准（4.5:1），**严禁将任何黄色 Token 作为文字颜色**（`color:` 属性）使用，包括但不限于 `yellow-bg` / `yellow-default` / `gradient-yellow` 的任意档位；黄色仅允许用于**背景色**（`background`）、**图标填充**（图标本身非文字）或**进度条**等非文字场景。违规示例：`color: #FFDD00`、`color: #FFE74D` → 立即改为 `text-primary`（`#111111`）或 `text-secondary`（`#555555`）

**字体 & 排版**
- [ ] 字体名称与通用字号/行高来自 `references/semantic/font-semantic.md`；HTML 时普通文本一律按该文件或对应组件正文落地，❌ 禁止把 `button.md §8` 当作全局文字 px 来源（`button.md §8` 仅用于按钮组件自身）
- [ ] **字重**：Semibold=600 / Medium=500 / Regular=400，禁止自行降级
- [ ] **列表主标题字重**：默认使用 `regular`（400），Medium 仅在明确需要突出信息层级时可选，未经指定禁止擅自升为 medium / semibold
- [ ] **Price Set Token 决策（含价格展示的页面必查）**：价格展示场景已确认使用 `font-price.md`，已确认展示类型是「相同大小组合 §3.2」（金额/优惠/餐券）还是「不同大小组合 §3.3」（商品价格）；字号档位从表逐行查，禁止「整数降一档」自行推导。HTML 落地样式在 §B 核验

**间距 & 布局**
- [ ] 间距来自 `references/semantic/spacing-semantic.md` / `references/semantic/component-spacing.md`
- [ ] **栅格档位**：已读 `references/templates/grid-layout.md`，按以下逻辑判定密度档位，margin/padding/间距均来自速查表，禁止凭感觉写边距
  - **紧凑型**（margin 16px）：各业务线**首页**（流程最前端，高频高密度）
  - **适中型**（margin 24px）默认：列表页、搜索页、商品卡片流、详情页、订单页等**绝大多数页面**
  - **宽松型**（margin 32px）慎用：设置页、个人中心、品牌专题等**流程末端低频页**
  - 用户未指定 → 一律适中型（24px）
- [ ] **页面背景色**：页面根容器背景必须为 `bg-page`（`#F5F5F5`），无需用户声明，直接应用；卡片背景为 `white`（`#FFFFFF`）；禁止页面背景白色、禁止给卡片加描边或投影
- [ ] **金刚区 → 内容列表过渡渐变**：页面顶部为金刚图标区（白色背景）、下方接 F5 内容列表区时，两区之间必须插入渐变过渡条：`<div style="height:40px; background:linear-gradient(180deg, #FFFFFF 0%, rgba(245,245,245,0) 100%);"></div>`；禁止写 `mix-blend-mode:pass-through`（Figma 私有属性，CSS 无效）
- [ ] **结构词已先落结构层**：`卡片流 / 双列卡片 / 白卡片承载 / 通栏 / 横幅 / Hero / 金刚区 / 吸底区 / 信息分区 / 推荐模块 / 内容容器` 等结构词，已先映射到 `grid-layout.md` / `icon-grid.md` / `visual-language` / 合法组件承载关系；❌ 禁止把结构词直接当组件名
- [ ] **`density_mode` 与栅格档位一致**：`compact → 16px`、`balanced → 24px`、`relaxed → 32px` 的映射已在声明表和布局决策中保持一致；❌ 禁止 schema 写 `balanced`、布局却落成 16px/32px
- [ ] **非通栏卡片页面边距**：750px 画布下左右 margin @2x 写入值优先 16px 或 24px；尽量避免 32px（宽松型），仅设置/个人中心/品牌专题可用，其余场景如不确定一律降档至 24px
- [ ] **通栏例外已核实**：凡使用 `width:750px`、`border-radius:0`、贴边布局时，已确认仅属于 `grid-layout.md §四` 的四类例外（横幅 / 地图 / 底部操作栏 / 系统设置分割线列表）；❌ 禁止把常规内容区做成通栏
- [ ] **单位换算**：来自 `references/templates/grid-layout.md` → **直接用表格「@2x px」列的数字**（如 spacing-l = 24px，spacing-s = 16px），禁止把 pt 列数字直接当 px 写入（750px 画布需 ×2，偏小一半）；来自 `semantic/` / `component/` 等规范文档 → @1x pt **× 2 = px**，禁止直接写 pt 值
- [ ] **间距 owner 已唯一判定**：每个间距位点都已明确归属到 `页面层（grid-layout + spacing-semantic）` / `组件层（组件 .md）` / `组件补充层（component-spacing）` 三者之一；❌ 禁止同一位点同时从页面层和组件层各取一部分；若 owner 说不清，必须回 `D3` 重做绑定
- [ ] **图标与间距未串层**：图标旁 gap / 搜索框内部留白 / 按钮 icon+文案距离 / 列表 suffix icon 距离，已优先按组件正文处理；❌ 禁止从页面 margin 或模块 spacing 反推这些内部距离

**组件 & 图标**
- [ ] 组件来自 `references/component/`，禁止自创变体
- [ ] **组件词已先归一**：`navbar/header/modal/chip/fab/card/alert` 等口语或别名，已先归一为 `navigation/dialog|bottom-sheets/tag/floating-action-button/...` 等 `INDEX.md` 中真实存在的合法组件名；❌ 禁止直接拿别名当组件名查找或输出
- [ ] **`cta_priority` 与实际布局一致**：若声明为 `front`，CTA 不得沉到底部辅助区；若声明为 `back/weak`，CTA 不得抢占页面首屏主信息；不一致时必须回退 D3 重判
- [ ] **模块排序与 `page_mode` 一致**：页面自上而下顺序与 `module_order` 的骨架一致；若偏离，已写明业务理由；❌ 禁止无理由重排主信息
- [ ] **未命中禁忌排序**：页面实际顺序未触发当前 `forbidden_order`；一旦命中，即使组件/样式正确也必须回退重做
- [ ] **结构词与组件词未混淆**：`card/banner/hero/section/carousel` 若出现在描述里，已先判断它们是结构词还是合法组件承载关系；❌ 禁止把 `banner/hero/section/carousel` 直接写进最终组件清单
- [ ] **用户描述的组件外观能在规范中找到唯一落点**：如“胶囊按钮 / 灰底标签 / 返回箭头 / 搜索框 / 评分星级”等，均已映射到具体组件文件 + variant/size/state；❌ 禁止把用户样式词直接翻译成手写 CSS
- [ ] **高风险歧义组件词已解歧**：`通知 / 弹窗 / 标签 / 按钮 / 选择器 / 提示 / 卡片 / footer / navbar / picker` 等词，已按位置 / 触发方式 / 是否固定 / 时效 / 交互性完成二次判定；❌ 未解歧前禁止继续生成
- [ ] **歧义词解歧记录已填写**：若用户命中 `footer / alert / card / navbar / tag / picker` 等高风险词，声明表「⑥ 歧义词解歧记录」已写出**候选组件 + 最终判定 + 排除理由 + 来源文件 §**；❌ 缺任一项都视为未完成 D3
- [ ] **局部修改影响记录已填写**：若本次任务是修改已有 HTML，声明表「⑦ 局部修改影响记录」已明确写出**修改目标片段 / 禁止误伤区域 / 允许变更范围 / 禁止变更范围 / 回归验收重点**；❌ 缺任一项都视为未完成 D3
- [ ] **局部修改未越级**：若本次原本宣称为“局部修改”，需确认它并未实质改变 `page_mode` / `module_order` / `cta_priority` / 组件家族；一旦改变，必须升级回 `D3`（必要时先回 `D2` 做解歧），❌ 禁止继续当作局部补丁处理
- [ ] **组件缺规范即停止**：若当前区域找不到可对应的组件文件，必须停止并回到选型阶段；❌ 禁止输出「近似组件」/「自定义组件」/「视觉上差不多」的替代实现
- [ ] **页面模式失配已排除**：`result-feedback / fulfillment-status / assurance-explanation` 页面未出现明显营销氛围前置；`promo-campaign / conversion-focused` 页面未把主 CTA 和核心转化信息压到次级区域
- [ ] **关键模式的骨架顺序正确**：`result-feedback` 先结果后动作，`fulfillment-status` 先状态后说明，`payment-checkout` 保持支付闭环连续，`content-browse` 不被强 CTA 打断内容主线
- [ ] **列表头像/图片形状**：同一列表内统一圆形或圆角矩形，禁止混用
- [ ] **图片形状判断规则（每次输出含图片的页面必查）**：
  - **头像（Avatar）**：描述中含「头像/avatar/用户图/骑手图/商家图」→ 必须用纯圆形 `border-radius: 50%`
  - **非头像图片**：优先遵循组件规范或业务 `visual-language`；若无特例，则按显示尺寸选择：**`> 50pt → radius-xs → border-radius:12px`**，**`<= 50pt → radius-xxs → border-radius:8px`**
  - 禁止将商品图/缩略图设为圆形（`border-radius:50%`）——小象超市商品图虽有圆形视觉语言，但仅限 `visual-language` 文档明确指定「圆形图片系统」的场景
  - **四个圆角必须一致**：禁止 `border-radius: 8px 8px 0 0` / `12px 12px 0 0` 等非对称写法，必须使用单值圆角
- [ ] **缩略图圆角**：订单商品图/列表缩略图等**小尺寸非头像图片**默认用 `radius-xxs`（**4pt → `border-radius:8px`**）；较大展示图/上传图/证件图等默认用 `radius-xs`（**6pt → `border-radius:12px`**）。禁止不分尺寸统一写 16px/24px，或把所有图片都套成 `radius-s`
- [ ] **卡片圆角规范值（每次含卡片的页面必查）**：
  - **大卡片/推荐卡/内容卡**（`radius-m`）→ 12pt × 2 = **`border-radius:24px`**
  - **内嵌组件/中卡片**（`radius-s`）→ 8pt × 2 = **`border-radius:16px`**（⚠️ 仅用于中卡片/嵌套容器，**不是图片默认圆角**）
  - **缩略图/小卡**（`radius-xs`）→ 6pt × 2 = `border-radius:12px`（展示图片≥50pt 场景）
  - **半页弹窗/浮层**（`radius-xl`）→ 20pt × 2 = `border-radius:40px`
  - **禁止自造任意圆角**（如 `10px / 18px / 20px / 32px`），所有卡片圆角必须来自上方对应档位
- [ ] **卡片内图片不得贴边**：图片不可直接紧贴卡片容器边缘，卡片父级必须设置 `padding`（最小 16px），图片区域配合 `border-radius` 呈现内圆角；禁止 `padding:0` + `overflow:hidden` 让图片撑满整个卡片左侧/顶部（无内边距会导致图片切掉卡片圆角、整体视觉粗糙）
- [ ] **Tag 规范来源**：所有内联标签（功能标签/激励标签）必须按 `references/component/molecules/tag.md §1/§2/§4` 选型，**不得自行定义形状**。订单卡片功能标签（免预约/可用时段）= `type:tag` + `variant:gray-bg` + `size:standard-11`（高32px，内边距0 8px，圆角6px，字色`#555555`）；激励标签（浅橙+橙字）= `variant:light`（背景`#FFF3E8`，字色`#FF6600`）。禁止用 `height:40px` + `border-radius:9999px` 自造 pill 形标签（高度偏大、圆角形状不符规范）
- [ ] **Filter 右侧功能区**：凡按钮筛选栏含右侧功能区，必须按 `references/component/components/filter.md §6.1` 的「AI 生成决策规则」自动选取 style，禁止留空或自定义
**组件使用陷阱（文档里有但 AI 必然踩，每次使用对应组件时必查）**

> 以下规则散落在各组件规范中，但与直觉不符或极易遗漏，统一在此强制提示。按组件名索引，使用某组件前必须逐条核对。

- [ ] **组件内部样式归组件正文所有**：一旦区域命中某个组件规范，页面层只允许调整组件外层容器、区块顺序和组件间距；❌ 禁止覆写组件正文已定义的内部高度/圆角/字号/字重/描边/背景/阴影/图标规格/状态样式。若确需不同视觉，必须改选规范内已有 `variant/size/state`，不能用 CSS 覆盖。
- [ ] **伪组件名零容忍**：`card / header / footer / navbar / modal / chip / fab / accordion / carousel / alert / banner / hero / section` 不得直接出现在最终组件清单中；若出现，必须先改写为 `INDEX.md` 中真实组件名，无法改写则停止。
- [ ] **Button — 价格字体仅限 XL/L/M 尺寸**：`size=s/xs/xxs` 的按钮内价格数字禁止使用 `price-set-*` 美团数字体，改用普通文字 Token。
- [ ] **Tag — 固定宽度违规**：所有标签宽度必须由内容自适应，禁止设置固定宽度。
- [ ] **Tag — 券标签字重固定 Semibold**：一律使用 600，禁止用 regular / medium。
- [ ] **Tag — 外挂角标颜色不可改**：固定 `red-default` 背景 + `white` 文字，不支持 variant 切换。
- [ ] **Badge — 数字上限 "99+"**：超出 maxCount 自动展示 "99+"，不允许出现三位数字。红点型禁止承载数量信息，需显示数字时改用 `type="number"`。
- [ ] **Badge — 白色描边实现方式**：外描边通过绝对定位覆盖层实现（`top/left/right/bottom: -2px`），禁止用 `border` 属性实现（会撑大元素）。
- [ ] **Bottom Sheets / Dialog — 蒙层强制**：半页弹窗和弹窗必须同时渲染全屏蒙层（`mask-default`），不允许无蒙层展示。警示类内容必须加 `maskClosable=false`。
- [ ] **Dialog — 宽度固定**：功能弹窗宽度固定 311pt；营销弹窗仅支持 279pt 或 311pt，不可取中间值。双按钮水平排列时主操作固定在**右侧**。
- [ ] **Dialog — 关闭按钮位置**：功能弹窗关闭 × 在右上角；营销弹窗关闭按钮在弹窗下方 30pt 独立展示，不得将关闭图标放在标题栏内。
- [ ] **Navigation — 返回按钮图标唯一指定**：必须用 `icon-iconfont-translate-line-semibold`（纯箭头），禁止 `leftturn`（带圆圈）/ `back` / `arrow-left` 等任何其他图标。
- [ ] **Navigation — 搜索框插槽规格锁定**：嵌入搜索框时必须使用 `references/component/components/search-bar.md` 组件，`data-size` 固定为 `"68"`，禁止自定义尺寸。
- [ ] **Tabs — 居中型最多 4 项**：`align=center` 时 items 数量 ≤ 4；模块型（`type=module`）固定 2 项，不支持 3 项以上。紧凑模式（`compact=true`）仅在单行居中型时有效。
- [ ] **Stepper — 连体型无小号**：`stepperType=integrated` 不支持 `size=small`。禁用态必须保留视觉（变灰），不得隐藏按钮。数字宽度自适应，禁止固定宽度。步进器在容器内始终**右对齐**。
- [ ] **Stepper — 加减图标必须用 inline SVG，❌ 严禁使用任何 iconfont 类名**：
  - **正确做法**：直接复制 `references/component/components/stepper.md §6.5` 中的加号/减号 `<svg>` 代码块，尺寸用 `.stepper-icon-lg/md/sm` 类控制
  - **❌ 最常见错误（截图级肉眼可见）**：使用 `icon-iconfont-add-line-*`（任意字重）→ 渲染结果为"圆角方框+加号"复合图形，而非纯十字加号；用户看到的是带框的加号，视觉完全错误
  - **❌ 同样禁止**：`icon-iconfont-pluscircle-line-*`（带圆圈）/ `icon-iconfont-add-fill` / 任何 iconfont 减号类名
  - **根本原因**：iconfont 库里没有纯十字加号，`add-line` 是"带圆角方框轮廓"的图标，名字像加号但外形完全不同；唯一正确来源是 stepper.md §6.5 的 inline SVG（两个圆角矩形 `<rect>` 组成十字）
- [ ] **Stepper — add-button 颜色默认黄色，小象超市必须覆盖为品牌绿**：
  - **默认**：`plus` 型添加按钮背景 `yellow-default`（`#FFDD00`）；`cart` 型固定 `bg-page`（`#F5F5F5`）
  - **🚫【P0 阻断】小象超市（`grocery` / `dpt12`）场景**：`plus` 型 add-button 背景必须覆盖为 `dpt12-g`（`#00CF22`），❌ 禁止沿用黄色 `#FFDD00`——小象超市品牌色为绿色，黄色加车按钮与品牌认知严重冲突
  - 其他业务线（外卖/闪购/医药/团购等）保持 `yellow-default`，不随页面主色联动
  - **检查口诀**：小象页面 → 加车绿（`#00CF22`）；其他页面 → 加车黄（`#FFDD00`）；`cart` 型永远灰（`#F5F5F5`）
- [ ] **🚫【P0 阻断】Stepper — add-button 在卡片中的位置与文字对齐（商品列表卡片必查）**：
  - **按钮必须锚定在 info body 容器（名称+价格所在区域）的右下角**：`position:absolute; right:0; bottom:0`；❌ 禁止居中（`justify-content:center` / `align-items:center`）；❌ 禁止作为独立 flex 行单独占位（按钮单独一行居中是最常见错误）
  - **定位父级必须是 info body 容器而非整张卡片**：body 容器设 `position:relative`；❌ 禁止把 `position:relative` 只写在最外层卡片上——图片高度会被算入，按钮会落在图片区而非文字区右下角
  - **名称行与价格行必须左对齐**：`text-align:left` / `justify-content:flex-start`；❌ 禁止居中（`text-align:center` / `justify-content:center`）——秒杀卡、推荐卡等横向滚动卡片的文字居中与按钮右下角锚定同时出现会产生视觉混乱
  - **文字区右侧必须为按钮留位**：名称行和价格行均加 `padding-right:44px; box-sizing:border-box`；❌ 禁止用 `width:calc(100% - 44px)`（在 flex 子项中不可靠）
  - **body 容器必须设 `min-height:80px`**：防止文字极短时容器高度不足，按钮与价格重叠
  - **检查口诀**（逐项过）：① body 有 `position:relative`？ ② 按钮有 `position:absolute; right:0; bottom:0`？ ③ 名称/价格 `text-align:left`？ ④ 名称/价格有 `padding-right:44px`？ ⑤ body 有 `min-height:80px`？——五项全部命中才算通过
- [ ] **Bottom Navigation — 大促型 tab 数约束**：`promo-weak` 和 `promo-strong` 仅支持 `tabCount=3` 或 `tabCount=5`，不支持其他数量。大促强样式上凸圆（55×55pt）溢出导航栏顶部 11pt，上层页面必须预留安全区。
- [ ] **Bottom Navigation — 普通 Tab 图标家族一致性（含底部导航页面必查）**：同一组普通 Tab（非首 Tab）图标必须来自同一视觉家族，优先整组使用 `*-line-medium`；若组件正文明确要求选中态与未选中态使用成对图标，则必须在 D3/图标声明中**成对列出** `selectedIcon` / `unselectedIcon` 并保证一一对应。❌ 禁止出现 `分类=line`、`订单=line`、`我的=fill` 这类同组线/面混搭；❌ 禁止只给个别 Tab 切成 fill 以“强调当前页”；❌ 禁止未声明配对规则就临时混搭。
- [ ] **Search Bar — 嵌入导航栏时 style 规则**：`search-bar.md §10.1` 34pt 组合场景嵌套搜索框默认 `style=gray`；style 由父组件声明，子组件不得擅自改写；`outlined` 仅在父组件主动声明时使用（如旅行业务 36pt 场景）。30pt/34pt 描边用黄色（`stroke-brand`），36pt 描边用旅行蓝（`stroke-blue`），禁止混用。
- [ ] **Popover / Tooltip — 尖角必须切图**：尖角使用图片切图资源实现，禁止用 CSS border 三角形代替。气泡宽度固定 108pt，选项数 1～7 个。
- [ ] **Toast — 禁止添加蒙层**：Toast 是轻量反馈，不阻断用户操作，禁止配合蒙层使用（需阻断时改用 Dialog）。
- [ ] **Rating — 星星颜色不可自定义**：激活色固定 `brand-yellow`，未激活色固定 `stroke-default`，禁止覆盖。评分数值字体必须使用 `price-*` Token，禁止普通文字 Token。星星数量固定 5 颗。
- [ ] **Page Indicator — 点状类型上限 5 项**：超过 5 项必须改用 `numeric` 或 `progress` 类型，禁止点状类型超过 5 项。`dark-bg` 和 `light-bg` 不可跨背景混用。
- [ ] **Floating Action Button — 尺寸与形状固定**：整体固定 48×48pt 正圆形（`radius-full`），不可修改。图标组合型最多 2 个；图标+文字型文字建议 ≤ 2 字，不可换行。禁止加 `box-shadow`。
- [ ] **Empty State — 必须有插画**：禁止纯文字空状态，插画必须展示。操作按钮最多 2 个。
- [ ] **User Satisfaction — 数量约束**：NPS 固定 0～10 共 11 个；Emoji 型仅支持 3 或 5 项；标签型 3～8 个，不可超出范围。
- [ ] **Time/Date Picker — 必须承载于半页弹窗**：不可脱离 Bottom Sheets 独立展示，整体高度不可自定义。

---

## §B HTML 输出验收

> **触发时机**：**第四步 HTML 文件写入磁盘、字体注入完毕后**。仅作内部验收使用：逐条核查生成结果，**发现问题必须先改 HTML、重新注入并复验，直到通过后才能交付**；不得只记录问题而不修正；❌ 不再要求对外输出单独 QA 报告。
>
> **命中本段错误时的统一回退口径**：
> - **回 `D3`**：若最终 HTML 证明设计决策结果本身写错，或 HTML 使用的组件 / 顺序 / CTA / 主色 / 关键 Token 与设计决策结果不一致
> - **回 `W1`**：若错误属于实现落地或资源保全，包括 Status Bar / Navigation / 标题 / icon / Home Indicator / 栅格 / meta / body / 组件内部样式覆盖 / 字体与图片内联资源丢失
> - **禁止**：在 `§B` 命中“设计决策结果与 HTML 不一致”后只改 HTML 不改设计决策；必须先回 `D3`
>
> **严重级别与交付阻断口径**：
> - **`P0`**：任何用户可见 / 截图级问题（标题偏移、图标空白、系统栏异常、资源失效、组件串型、未改区域回归、大面积灰框）→ **禁止交付**
> - **`P1`**：任何破坏设计决策约束或结果可信度的问题（设计决策结果与 HTML 不一致、歧义词未解歧、组件不可回溯、局部修改越级）→ **禁止交付**
> - **`P2`**：仅允许极少数不影响视觉与结构的非阻断限制（如外部图片按规范降级为纯色占位）→ 可交付，但必须写入最终 `已知限制`
> - **铁律**：`已知限制` 只允许承载 `P2`；❌ 禁止把任何 `P0/P1` 问题伪装成“已知限制”

- [ ] **交付文件路径正确**：最终对外交付的 HTML 文件路径**必须**位于 `~/Desktop/Design Demo/`；若本次基于已有 HTML 修改，原始文件可保留或同步更新，但**用于预览和交付的版本文件**仍必须是 `Design Demo` 下的新文件。❌ 禁止把 `~/Desktop/xiaoxiang-homepage/index.html` 或任何非 `Design Demo` 目录下的原始工作文件当作最终交付物。

> **硬验收补充口径**：
> - 若命中样例级 `must_fail_if`，却仍准备交付 → 记为 `block-missed`
> - 若未命中任何 `P0/P1` 阻断条件，却被误判为不可交付 → 记为 `false-block`
> - 若 `severity` 与样例预期不一致 → 记为 `severity-miss`
> - 若 `已知限制` 中混入阻断项 → 记为 `known-limit-polluted`

**第二轮组件调用轮询（P0/P1 高风险组件，交付前强制再跑一遍）**

> 目的：`A0 / component_binding_map / slot_binding_map / 首轮组件自检` 主要解决“写之前选错组件”；本轮专门拦截“最终 HTML 看起来像对了，但实际上没有真正调用到合法组件”的情况，尤其是宿主组件被手写近似结构替代、叶子槽位偷写 `div`/字符、固定层组件串型。
>
> 🚨 **职责边界**：`§B` 只负责**最终 HTML 验收**，不承担前置路由、预读决策或 `W1` 写入前闭环；这些职责分别属于 `INDEX.md` 与 `SKILL.md A2/A3/W1`。若本轮发现组件结论本身有误，必须回前链路重做，不得在 `§B` 现场重新路由。
>
> **执行顺序固定**：① 从最终 HTML 反推实际出现的宿主模块与可见叶子槽位；② 对照 `component_binding_map + slot_binding_map + component_audit_map`；③ 命中 `INDEX.md` 中「区域化强关联路由表 / 组件路由注册表 / 高混淆组件图谱」的项，必须写清“为什么是它、为什么不是另一个”；④ 按下方验收白名单逐项轮询所有命中的高风险组件；⑤ 全部通过后，才能进入下方通用视觉/资源验收。❌ 任一项失败，直接阻断交付，不得继续靠“样式差不多”放行。
>
> **白名单执行口径（新增）**：本轮白名单是**交付验收白名单**，不是前置路由表或预读清单；它的职责是把最终 HTML 中**实际命中的 P0/P1 组件家族逐项勾过**。凡页面出现下列任一组件家族，就必须逐条核验其宿主、子组件、叶子槽位、所有权和禁用替代实现；❌ 禁止只写一句“组件调用正常”笼统放行。
> **排除理由模板（新增，命中混淆组时强制填写）**：所有“为什么是它 / 为什么不是另一个”的判断，必须至少按四段写全：`chosen_because={最终组件命中的决定性语义}` / `not_component={被排除候选 + 排除原因}` / `evidence_slots={position/fixed/trigger/duration/interactivity/primary_task 中的证据}` / `owner_decision={layout_owner/style_owner/behavior_owner 的判断}`。缺任一段，视为本轮未通过。

- [ ] **总对账通过**：最终 HTML 中实际出现的宿主组件、叶子控件、非文字 icon 槽位，与最小决策集/声明表中的 `component_binding_map + slot_binding_map + component_audit_map` 一一对应；❌ 禁止 HTML 新冒出未绑定组件、未绑定 icon、未绑定 `tag/select/button` 槽位
- [ ] **🚫【P0 阻断】System 来源唯一**：`status-bar` / `home-indicator` 在最终 HTML 中都能反查到 `system.md`，且绑定结果 `final_component=system`；❌ 禁止空白占位、手写“像状态栏/胶囊条”的自定义结构
- [ ] **🚫【P0 阻断】Navigation / Search Bar 组合路由正确**：顶部区域只要承担返回/标题/右操作任一导航语义，宿主必须是 `navigation`；导航内嵌搜索时，子组件必须是 `search-bar`，`data-size="68"`，并由父组件接管 `style/布局`；❌ 禁止把导航搜索写成 `text-input`、裸 input、或独立搜索框反客为主
- [ ] **🚫【P0 阻断】底部固定区家族无串型**：`position=fixed bottom` 的主区域若承担提交/购买/确认/价格+操作 → 必须是 `bottom-action-bar`；若承担 2~5 项页面主导航切换 → 必须是 `bottom-navigation`；❌ 禁止同一底部区同时扮演两者，❌ 禁止声明与落地不一致
- [ ] **🚫【P0 阻断】可见控件槽位未手写**：`suffix-control / suffix-info / helper-action / inline-status` 中出现箭头、单选/多选、勾选、加减、标签、角标、状态 icon 时，必须能回溯到 `icon / select / stepper / tag / badge / button` 等合法来源；❌ 禁止 Unicode 字符、CSS 圆点、手写 pill、裸 div 控件充当组件
- [ ] **【P1 阻断】Filter / Filter Panel / Select 路由正确**：收起态顶部筛选入口 = `filter`；展开层筛选容器 = `filter-panel`；普通单选/多选选择语义 = `select`；❌ 禁止把展开层写成普通筛选条，或把单选/多选状态手写在列表行里却不绑定 `select`
- [ ] **【P1 阻断】Tag / Badge / List / Form 叶子归属正确**：行内标签必须落 `tag`，数字/红点角标必须落 `badge`，带箭头/选择/说明的结构化行需回溯到 `list` 或 `form` 作为宿主；❌ 禁止把标签和角标都当普通文字块/绝对定位色块处理
- [ ] **【P1 阻断】浮层反馈家族无误**：阻断式反馈 / 需蒙层 = `dialog` 或 `bottom-sheets`；轻量短反馈 / 不阻断 = `toast` 或 `snackbar`；❌ 禁止把阻断弹层写成 `toast`，或给 `toast` 私加蒙层冒充 `dialog`
- [ ] **命中混淆组必须留排除理由**：凡命中 `INDEX.md` 高混淆组件图谱（如 `bottom-action-bar vs bottom-navigation`、`filter vs filter-panel`、`navigation vs search-bar`、`tag vs badge`、`dialog vs bottom-sheets vs toast`），都必须按模板写出 `chosen_because / not_component / evidence_slots / owner_decision` 四段；答不清或任一字段缺失，视为 `P1`

**P0/P1 组件白名单逐项轮询（命中哪个查哪个，不得跳项）**

- [ ] **System**：检查 `status-bar + home-indicator` 是否都实际渲染、都来自 `system.md`、都与顶区/底区亮度和安全区联动；❌ 任一缺失或被业务结构代替，直接 `P0`
- [ ] **Navigation**：检查顶部承担导航语义的宿主是否唯一为 `navigation`，返回按钮/icon/标题/右操作是否都落在合法槽位；❌ 用 `div header`、自造返回区、搜索框反客为主都算失败
- [ ] **Search Bar**：若处于导航内，检查是否由 `navigation` 作为宿主管理、尺寸是否锁 `68`、style 是否由父层声明；若独立出现，再检查是否符合对应 size/type；❌ 导航搜索误落 `text-input` 直接 `P0`
- [ ] **Bottom Action Bar / Bottom Navigation**：检查固定底部区是否只承担一种职责；`CTA/价格+操作` 只能是 `bottom-action-bar`，`2~5 项主导航切换` 只能是 `bottom-navigation`；❌ 宿主职责混用或一块区域双重声明直接 `P0`
- [ ] **Select**：检查所有勾选/单选/多选/选择态视觉是否都绑定 `select`，并带 `data-type + size/state`；❌ 裸 `icon`、字符勾、CSS 圆圈、列表行假装选中态一律 `P0/P1`
- [ ] **Tag / Badge**：检查行内标签是否落 `tag`、数字/红点角标是否落 `badge`，并说明宿主是谁；❌ 用彩色文字块、绝对定位小红块、手写 pill 冒充都视为失败
- [ ] **Filter / Filter Panel**：检查收起态入口与展开层是否拆成两个组件；❌ 一个组件同时承担“筛选入口 + 展开内容”双职责视为路由失败
- [ ] **List / Form**：检查承载箭头、说明、副标题、选择态的结构化行是否由 `list` / `form` 作为宿主，而不是散落多个裸容器拼出“像列表”；❌ 宿主缺失视为 `P1`
- [ ] **Dialog / Bottom Sheets / Toast / Snackbar**：检查是否按阻断性、蒙层、位置、停留时长正确路由；❌ 阻断反馈却无蒙层、轻提示却做成弹层、`toast` 私加蒙层都视为失败
- [ ] **Stepper / Button / Icon**：检查高频叶子控件是否真实来自组件正文或 icon 规范；❌ Stepper 加减号若不是 `stepper.md §6.5` inline SVG、按钮若非 `button.md §8` 结构、icon 若靠 Unicode/手画几何代替，视为失败

> **放行门槛（新增）**：只有当“总对账 + 命中混淆组排除理由模板完整 + 白名单逐项轮询”三者同时通过时，`第二轮组件调用轮询` 才算通过；缺任一项，都不得进入后续视觉验收，更不得交付。

- [ ] **`color-scheme` 强制声明（防深色模式污染）**：在 `<head>` 中必须写 `<meta name="color-scheme" content="light">`，同时在 `html` CSS 中显式写 `color-scheme: light; background:#FFFFFF;`；系统深色模式会自动反转背景色和边框颜色，缺少此声明会导致白色卡片变成深灰、灰色描边变为亮色，直接破坏视觉稿忠实度；**这是 HTML 原型文件的强制要求，不是可选项**
- [ ] **`<meta viewport>`**：必须写 `content="width=750, initial-scale=1.0"`，严禁 `width=device-width`；严禁 `width=750px`（带 px 后缀无效）
- [ ] **`body` 尺寸（最高频崩坏根因）**：必须 `width:750px; min-height:1624px; margin:0 auto;`
  - **严禁 `min-height:100vh`**——在 `width=750` 非标准 viewport 下，`100vh` 计算行为不稳定，会导致 flex 高度计算失效、内容区被压缩截断，这是「商品挑选页」崩坏的真实根因
  - 严禁 `width:100vw / 100% / auto`
  - 正确写法：`body { width: 750px; min-height: 1624px; margin: 0 auto; }`
- [ ] **`body` 字体链**：`body` 的 `font-family` 必须使用完整 fallback 链 `'PingFang SC','Noto Sans SC','Source Han Sans SC','Microsoft YaHei','WenQuanYi Micro Hei',sans-serif`，同时加 `-webkit-font-smoothing: antialiased`；禁止只写 `'PingFang SC',sans-serif`——无苹方环境会 fallback 到 Helvetica/Arial，Regular 400 字形明显偏粗
- [ ] **价格 HTML 落地核验（含价格展示的页面，§B 必查，不可跳过）**：
  - **字号档位**：¥ 符号 / 整数 / 小数的 `font-size` 和 `font-weight` 必须逐一与 `font-price.md §3.2/§3.3` 的选定档位一致；禁止「整数降一档」自行推导（常见错误：`price-set-18+12` 选了整数 18pt，却把小数写成 10pt）
  - **基线对齐**：¥ 符号、整数、小数**必须包裹在 `display:flex; align-items:baseline` 的容器内**；❌ 禁止顶对齐（`align-items:center` 或无声明默认）—— 常见错误：¥ 符号字号偏小，与大字号整数顶对齐后视觉上浮，像是没有对齐
  - **原价划线**：若有原价，其容器也必须 `align-items:baseline`；划线用 `text-decoration:line-through`，颜色用 `text-tertiary`（`#888888`）
  - **HTML 模板**：`<div style="display:flex;align-items:baseline;gap:4px"><span class="price-symbol">¥</span><span class="price-integer">18</span><span class="price-decimal">.9</span></div>`
- [ ] **Status Bar / Home Indicator（必须渲染，不得省略）**：顶部 `data-slot="status-bar"`（height:88px）必须渲染完整样式——左侧时间「9:41」+ 右侧信号格/WiFi/电池 SVG 图标；底部 `data-slot="home-indicator"`（height:68px）必须按 `system.md` 渲染胶囊条与动效；禁止只留空白占位、禁止手写 SVG 图标路径（必须内联 `assets/Black.svg` 或 `assets/White.svg` 完整内容）
  - **Status Bar 必须首轮与顶部联动**：白底页面 NavBar 用 `#FFFFFF`，则 `data-slot="status-bar"` 的 div 必须显式写 `background:#FFFFFF`，并使用 `Black.svg`；深色 NavBar / 顶部色块则同步写对应深色背景，并使用 `White.svg`。禁止不写背景色、禁止图标资源与顶区亮度不匹配——这类问题必须在首次生成时命中，不能靠后验修正
  - **🚫【P0 阻断】Status Bar 右侧 SVG 渲染尺寸必须与 viewBox 坐标空间一致**：`Black.svg` / `White.svg` 的 `viewBox="0 0 220 88"` 是 @2x 坐标系，内联时 SVG 元素的 `width` / `height` 属性必须写 **`width="220" height="88"`**；❌ 禁止写成 `width="110" height="44"`（@1x 尺寸）——坐标系是 @2x 而渲染尺寸按 @1x 会导致图标缩小一半，截图中明显偏小
- [ ] **`ds-font-inject` 资源块存在且非空**：最终 HTML 中必须存在 `<style id="ds-font-inject">`，且块内包含真实字体数据（至少能找到 `woff2;base64,` 与 `font-family:"美团新数字体"`）；❌ 只存在空块/注释占位视为未通过
- [ ] **🚫【P0 阻断】禁止手写 `.font` 基类**：HTML `<style>` 中**不得出现任何** `.font { font-family: ... }`、`.font::before` 或其他试图手动接管 iconfont 基类的规则；`.font` 的 `font-family:"font" !important` 及相关定义只能由 `inject.py` 注入。❌ 只要发现手写 `.font` 基类，即使类名看起来“差不多正确”，也必须删除后重新注入，否则极易出现图标空白 / 灰框 / 重注入后被覆盖的问题。最终 HTML 中图标节点只允许写 `<span class="font icon-iconfont-{name}-{weight}" aria-hidden="true"></span>`，不得额外自定义字体 family。
- [ ] **🚨 内联资源注入结果与资源保全通过**：
  > **根本原因**：`string_replace` / `MultiEdit` / `write` 写回 HTML 时可能破坏已注入的字体/图片资源；若修改范围不受控，还会误删 `<style id="ds-font-inject">`、已有 `data:` 图片、`{B64:...}` 占位符或系统栏内联 SVG——这就是「修了问题却导致图标/字体/内联资源丢失」的直接根因。
  - **结果 1 / 图标字体**：最终 HTML 中必须已注入 iconfont，`grep -c "woff2;base64," {HTML文件路径}` 结果必须 ≥ 1
  - **结果 2 / 价格字体**：HTML 中必须仍能找到 `font-family:"美团新数字体"`，缺失则视为未通过
  - **结果 3 / 资源块**：最终 HTML 中必须存在 `<style id="ds-font-inject">`，且不能是空块/注释占位
  - **结果 4 / 图片占位**：本次页面若使用 `data:` 图片或 `{B64:...}` 占位符，修改后不得被清空、改名或整段删除
  - **结果 5 / 系统栏图标**：若页面含 `data-slot="status-bar"` / `data-slot="home-indicator"`，其中必需的内联 SVG 仍需存在，不得退化为空白占位
  - **结果 6 / `.font` 基类**：HTML `<style>` 中不得存在手写 `.font { font-family: ... }` / `.font::before` 规则；若存在，视为未通过，必须删除后重新注入
  - **结果 7 / 最终图标可见性**：完成注入后，必须额外核查**首屏**与**本次修改区域**中的 icon 是否真实可见，不能只确认类名存在或 `woff2;base64` 已注入；若出现“有占位但无图形 / 空白 icon / 灰框 icon / 图标被裁切 / NavBar icon 消失 / Stepper 加号呈现带框复合图形”任一情况，视为 `P0`，必须回 `W1` 修正并重新注入
  - **交付口径**：对外回复时必须说明「已重新注入字体，且 `ds-font-inject` 资源块校验通过，刷新浏览器即可预览」
- [ ] **Button 结果与规范一致**：最终按钮结构与样式必须与 `references/component/molecules/button.md §8` 保持一致，不得出现手动推导导致的高度、圆角、内边距、字重或状态样式偏差
- [ ] **线性按钮按压态与阴影正确**：线性按钮按压态必须是 `opacity: 0.5` + 描边色降至 50% 透明度；❌ 禁止只改描边颜色而忽略文字/图标透明度变化；❌ 禁止任何按钮使用 `box-shadow`
- [ ] **🚫【P0 阻断】按钮点击缩小动效**：最终 HTML/CSS 中不得出现任何按钮点击/按压缩小动效，包括但不限于：`transform: scale(...)` / `:active { transform: scale(0.9) }` / `transition: transform` / `@keyframes` 缩放动画。按压态只能使用白色半透明遮罩或 `opacity` 降低实现；❌ 禁止任何形式的尺寸/位移变化
- [ ] **卡片内行内按钮比例正确**：与价格并排的行内按钮高度必须跟随 `size` 档位（s=60px / m=68px），禁止将宽高设为相等的正方形
- [ ] **并列按钮关系正确**：并列按钮（≥2 个按钮横排）必须符合 `references/component/components/bottom-action-bar.md` 的尺寸、间距与比例约束，禁止自行设定横排按钮宽度和间距
- [ ] **底部主 CTA 颜色首轮命中业务线**：外卖通用 / 跑腿 / 退款 / 去结算等底部主操作背景必须 `gradient-yellow`；命中业务覆盖时，再按业务切到专属 CTA 色（团购软硬件 `orange-default`、直播特价团 `dpt1-g-m`、拼好饭 `dpt3-g-r`、神枪手 `dpt4-g-b`、到餐 DPT5、医药健康·买药 `dpt7-g-t`、小象超市 `dpt12-g`、美团公益 `dpt13-t`；问诊场景主 CTA 用 `green-default`）；`orange-default` 仅用于价格 / 标签 / Tab / 强调信息，❌ 不得作为外卖底部主 CTA 背景
- [ ] **默认单列卡片栅格（最常见错误，每次必查）**：
  - **默认规则**：所有内容区块一律使用白色留边圆角卡片，页面背景 `#F5F5F5`，禁止默认通栏
  - 全部内容区块（配送进度 / 地址行 / 商品清单 / 价格明细 / 订单信息 / 推荐卡 等）→ `border-radius:24px; background:#FFFFFF`（**白色卡片**）
  - 左右 margin 和卡片间距以**栅格档位为准**（默认适中型：margin = **24px** / 卡片间距 = **16px**），禁止用色带隔断、禁止凭感觉写 16px
  - **通栏仅限四种例外**：顶部全屏 Hero 横幅 / 地图区 / 底部操作栏（Bottom Action Bar）/ 系统设置分割线列表 → `width:750px; border-radius:0`，禁止扩大例外范围
  - **订单状态横幅不属于通栏例外**：「骑手已接单 / 待支付 / 已完成」等订单状态区块必须作为普通圆角卡片（`border-radius:24px`），其宽度由 `page-scroll` 的左右 padding 自然约束，严禁设置 `width:750px; border-radius:0`——否则卡片展现为全屏直角贴边，与其他圆角卡片视觉不一致
  - **禁止把整页做成通栏**——把订单信息、商品清单、配送进度等全部设为 `border-radius:0` 是最高频错误
  - **🚫【P0 阻断】推荐卡（商品卡 / 信息流卡片）全业务线高度必须自适应，❌ 严禁固定高度**：所有推荐卡、商品卡、信息流卡片的高度必须由内容撑开（不设 `height` / `min-height` 固定值）；双列网格（grid）场景下同行两列卡片由 grid 对齐等高，但高度本身由内容量决定，❌ 禁止写 `height: Xpx`。卡片 body 区需使用 `display:flex; flex-direction:column; flex:1`，价格行使用 `margin-top:auto` 保证始终贴底——这样无论商品名是 1 行还是 2 行，价格行都对齐底部，不出现中间空白。此规则适用于所有业务线（外卖 / 电商 / 小象超市 / 闪购 / 医药等）
- [ ] **金刚区（icon-grid）居中（含金刚区的页面必查）**：金刚区 grid 容器**禁止用 `grid-template-columns: repeat(N, 1fr)` + 固定 `padding`** 的组合——`1fr` 会让列撑满容器，但图标本身是固定宽度，视觉上整体靠左；正确做法二选一：
  - **方案 A（推荐）**：`grid-template-columns: repeat(N, 1fr)` + `justify-items: center`，让每列内图标居中，外层容器 `width: 100%` 自动撑满；
  - **方案 B**：`grid-template-columns: repeat(N, {固定列宽}px)` + `justify-content: center`，整个 grid 在父容器内水平居中；
  - **严禁双重缩进**：外层黄色/彩色背景容器若已有 `padding: 0 {page-margin}`，内部卡片不可再叠加 `width: calc(750px - margin*2)` + `margin: 0 margin`——两层缩进会让实际可用宽度严重压缩，导致 grid 溢出或强制靠左
- [ ] **sticky / fixed 层叠 z-index（含悬浮元素的页面必查）**：
  - 页面层级约定：`底部操作栏(Bottom Action Bar)` / `底部导航(Bottom Navigation)` = `z-index:100`；`悬浮按钮(FAB)` = `z-index:200`；`Toast` / `Snackbar` = `z-index:300`；`Dialog` / `Bottom Sheets` = `z-index:400`；蒙层(`mask`) = `z-index:399`
  - 禁止将 `position:sticky` 的导航栏或 Tab 设置过低（如 `z-index:1`），会被同级 flex 子元素遮盖
  - `position:fixed` 元素必须声明 `z-index`，禁止不写（默认 `auto` 在某些 stacking context 下会消失于内容层之下）
- [ ] **文字溢出截断（单行截断场景必查）**：
  - 所有需要限制行数的文字容器必须同时写 `overflow:hidden; text-overflow:ellipsis; white-space:nowrap`（三条缺一不可，缺少任一条均不生效）
  - 多行截断（如 2 行摘要）必须用 `-webkit-line-clamp: 2; display:-webkit-box; -webkit-box-orient:vertical; overflow:hidden`
  - 价格 / 标签 / 按钮文字属于**固定内容，禁止加截断**——加了会在较短文字场景下产生不必要省略号
  - flex 容器内文字子项截断前提：父项必须有 `min-width:0`（否则 flex 子项不会收缩，截断无效）
- [ ] **图片 `object-fit:cover`（含图片的页面必查）**：
  - 所有 `<img>` 标签在有明确宽高约束时，必须同时加 `object-fit:cover`；否则图片按原始比例缩放，出现变形或留白
  - 正确写法：`<img style="width:200px;height:200px;object-fit:cover;border-radius:16px" src="...">`
  - 背景图（`background-image`）对应写 `background-size:cover; background-position:center`
  - **禁止裸 `<img>` 无任何尺寸约束**——无宽高时图片按原始大小渲染，撑破容器
- [ ] **Bottom Navigation 底部安全区（含底部导航的页面必查）**：
  - 底部导航栏 `position:fixed; bottom:0` 时，内容区域底部必须留出足够 padding 避免被导航栏遮挡
  - 底部导航组件高度规范：标准型总占位 = **78pt × 2 = 156px**（44pt 导航区 + 34pt Home Indicator 安全区）；纯导航区域 = **44pt × 2 = 88px**
  - 主内容 `.page-scroll` 容器必须加 `padding-bottom: 156px`（或与导航总占位高度一致），禁止内容滚动到底部被导航栏完全遮挡
  - **如果页面同时有 Bottom Navigation + Bottom Action Bar**：两者不可叠加，只能二选一；若确实需要共存，Bottom Action Bar 必须放在 Bottom Navigation 之上，`z-index` 差值 ≥ 100
- [ ] **间距不叠加**：组件内的子元素间距**只用父容器 `gap` 实现**，禁止同时在子元素上加 `margin-top/bottom`（gap + margin 会叠加，导致实际间距翻倍）
- [ ] **🚫【P0 阻断】间距归属冲突已清零**：若某个距离同时命中组件正文与页面栅格，必须以组件正文为准；若页面层试图覆盖搜索框/按钮/列表/底栏等组件内部 padding/gap，立即阻断并回 `R-W1-01`；若同一位点既写 `gap` 又写子元素 margin，或既拿 `component-spacing` 又拿 `grid-layout` 解释同一内部距离，视为 owner 冲突，不得交付
- [ ] **Navigation 标题居中真实落地**：普通二级页导航（`secondary`）必须显式落地 `data-title-align="center"` 或等价居中实现；❌ 禁止标题因左侧返回按钮占位而视觉偏左，除非用户明确要求左对齐
- [ ] **图标来源与渲染合法性（结果核验）**：
  - 最终 HTML 中所有图标必须使用合法 iconfont 类名 `font icon-iconfont-{name}-{weight}`；❌ 禁止 SVG 内联、禁止 mtdicon、禁止凭感觉拼接不存在的类名
  - 非白名单图标必须能在 `assets/iconfont.css` 中找到对应 `::before { content }` 定义；找不到即视为非法图标，不得交付
  - **严禁在图标节点上写 `font-weight`**；图标粗细唯一正确控制方式是 class 名后缀（`-line-medium` / `-line-semibold` / `-line-bold` / `-fill`）
  - **图标槽位必须可回溯**：命中 `prefix-media / inline-status / suffix-info / suffix-control / helper-action` 的 icon，必须都能回溯到 `slot_binding_map` 中的 `icon-route`；❌ 禁止最终 HTML 出现“有 icon span 但绑定表里无来源”的悬空图标
  - **固定 SVG 例外只能有两类**：`stepper` 加减号、`system` 状态栏 SVG；除此之外一律回 iconfont 路由，❌ 禁止把普通业务 icon 偷换成 inline SVG
- [ ] **🚫【P0 阻断】图标 span CSS 属性逐字核验（含图标的页面，HTML 写完后必须逐一扫描）**：
  - **按钮内图标 / 圆形容器内图标**（`<button>` / 父有 `overflow:hidden`）：必须含 `display:inline-block`；❌ 一旦发现 `overflow:hidden` 立即阻断 → iconfont 依赖 `::before` 伪元素渲染字形，图标 span 加 `overflow:hidden` 会将 `::before` 完整裁掉，图标消失
  - **导航栏图标 span**（NavBar 返回 / 右侧操作区）：不得含 `display` / `width` / `height` / `overflow` 任何属性；❌ 误加 `inline-block` 会产生空灰框，误加 `overflow:hidden` 会截断字符
  - **金刚区 icon-grid / 搜索框 / 底部导航 TabBar / 列表行 / 卡片内图标 span**（图标 span 是 flex 子项，或外层容器已做 overflow 控制）：必须用 `display:inline-block`；❌ 禁止在**图标 span 自身**加 `overflow:hidden`——`::before` 字形依赖 `inline-block` 渲染，加 `overflow:hidden` 会裁切字形至不可见；若需防文字溢出，`overflow:hidden` 只加在**非图标的文字节点**上，图标 span 自身禁止加
  - **⚠️ 容器层可以有 `overflow:hidden`，图标 span 自身不可以**：`overflow:hidden` 用于容器圆角裁剪或防内容溢出是合法的；但图标 `<span>` 元素自身（或其直接父容器对其设置时）加 `overflow:hidden`，则会把 `::before` 的字符裁掉——这是图标消失最常见根因
  - **根本原因备忘**：iconfont 图标的字形由 CSS `::before { content }` 伪元素输出，伪元素渲染依赖 `inline-block` 且不受外层容器的 `overflow:hidden` 保护；图标 span 自身或其直接父容器对图标施加 `overflow:hidden` 时，`::before` 被裁切至不可见，图标消失但外层占位不消失，极难排查；命中任一项，回 `W1` 修正后重注入
- [ ] **系统栏 / 标题 / 图标 / 灰框截图级核验**：最终首屏不得出现以下任一问题：Status Bar 图标变形、标题未居中、导航/操作 icon 空白消失、大面积浏览器默认灰色描边框；命中任一项即退回修改
- [ ] **🚫【P0 阻断】最终图标可见性检查（收尾必查，不能只看注入成功）**：在完成字体注入后，必须对**首屏**和**本次修改区域**做一次真实图标检查——确认 icon 不是仅有类名和占位，而是确实渲染出正确图形；以下任一情况直接阻断交付：`icon` 为空白、只剩占位宽高、出现灰色空框、Stepper 加号是“带框加号”、NavBar / 按钮 / 列表图标被裁切、图标字重错误导致形态异常
- [ ] **🚫【P0 阻断】NavBar 图标字重分区核验（含导航栏的页面，HTML 写完后必须逐项核查）**：
  - **左侧返回按钮**：`translate-line-semibold`（中粗体）—— ❌ 一旦发现 `line-medium` 或 `line-bold` 即阻断
  - **右侧操作区所有图标**：**强制** `line-medium`（中黑体），**无论一级页首页型、二级页还是全屏页，此规则不区分页面层级** —— ❌ 一旦发现 `line-semibold` 或 `line-bold` 即阻断（常见错误：把返回字重复制到右侧图标）
  - **根本原因备忘**：返回图标和右侧图标是两套不同字重规范，来源分别为 `navigation.md §4`（semibold）和 `§5.2`（medium）；生成时极容易统一写成同一字重，写完 HTML 必须逐项核查
- [ ] **🚫【P0 阻断】底部操作栏按钮尺寸核验（含 bottom-action-bar 的页面，HTML 写完后必须核查）**：
  - `bottom-action-bar` 内所有按钮**必须用 `size=l`（`btn-l`，高度 80px）**；❌ 发现 `size=xl` / `btn-xl` 立即阻断
  - `xl` 仅用于页面正文内部的独立全宽 CTA，禁止放入底部操作栏
- [ ] **🚫【P0 阻断】底部操作栏描边数值核验（含 bottom-action-bar 的页面，HTML 写完后必须核查）**：
  - **副按钮（线性按钮）描边**：必须 `border: 1px solid #CCCCCC`（@2x）；❌ 发现 `2px` 立即阻断（最常见错误，@2x 下应写 1px 而非 2px）；❌ 发现 `0.5px` 立即阻断（0.5px 是顶部分割线宽度，不是按钮描边）
  - **容器顶部分割线**：必须 `border-top: 1px solid rgba(0,0,0,0.06)`（@2x）；颜色与按钮描边颜色不同，禁止混用
  - **根本原因备忘**：副按钮描边 1pt = @2x 1px，顶部分割线 0.5pt = @2x 1px，两者 @2x 数值相同但颜色完全不同；最常见错误是把副按钮描边写成 2px
- [ ] **🚫【P0 阻断】底部操作栏图标入口字重核验（含 icon-entry 的页面，HTML 写完后必须核查）**：
  - 左侧图标入口区（`icon-action` / `icon-capsule-combo` 等变体）的图标默认字重必须为 **`line-medium`**；❌ 禁止写成 `line-regular`、`line-semibold` 或其他字重
  - **同一业务线所有页面必须保持一致**，❌ 禁止在商品详情用 `medium`、订单页用 `regular` 等混用
  - **根本原因备忘**：底部操作栏入口图标与顶部 NavBar 返回按钮不是一套字重规则；返回按钮才使用 `semibold`，入口图标应保持 `medium`
- [ ] **🚫【P0 阻断】CSS 覆盖扫描通过**：检查业务 `<style>` 中是否存在命中组件节点、`[data-slot]`、`[data-variant]`、`[data-size]`、`[data-state]` 的选择器；若这些规则改写组件内部关键属性（`height / min-height / width / padding / gap / border-radius / font-size / font-weight / line-height / color / border / background / box-shadow`），一律视为页面层覆写组件内部样式，必须删除并回到组件正文或改选合法 `variant/size/state`；仅允许在组件外层容器调整 `margin / position / z-index / flex/grid placement`
- [ ] **局部修改属性保全扫描通过**：若本次为已有 HTML 局部修改，则改动点及其受影响邻域内的组件节点，`data-slot / data-variant / data-size / data-state / data-type / role / aria-checked / aria-selected / aria-expanded` 不得无故删除、降级、改名或回退成裸结构；若声明未变却属性减少，视为 `R-W1-01`
- [ ] **用户原始样式描述已体现在合法规范项中**：**Full Harness** 逐条核对声明表「⑤ 样式来源回溯」中的样式词；**Fast Path** 则核对最小决策集中的样式词路由，确认最终 HTML 使用的是对应 Token / variant / size / state，而不是“看起来差不多”的近似值；若设计决策结果与 HTML 不一致，统一记为 `R-D3-02`
- [ ] **高歧义词最终落点与声明一致**：若声明表「⑥ 歧义词解歧记录」存在内容，最终 HTML / 组件清单中的实际落点必须与其一致；❌ 禁止声明里判成 `bottom-action-bar`、落地时又写成 `bottom-navigation`
- [ ] **所有区域都能回溯到合法组件或结构规则**：页面中的按钮、导航、列表、标签、底栏、通知、卡片承载区、金刚区、横幅、表单等区域，均能回溯到 `references/component/` 或 `grid-layout.md` / `icon-grid.md` / 对应业务 `visual-language`；❌ 禁止出现“长得像组件”的手写伪实现
- [ ] **局部修改受影响邻域与未改关键区已回归**：除本次直接改动节点外，还必须回归其宿主模块、同一行/同一组叶子槽位、命中同一公共选择器的组件节点，以及 NavBar 图标、Status Bar、Home Indicator、价格字体、底栏、`data:` 图片等关键未改区域；任一处回归失败都不得交付
- [ ] **局部修改升级条件已复核**：若本次修改已触碰全局 `<style>` / `body` / `viewport` / `color-scheme` / 系统栏 / 栅格基线 / 内联资源锚点，或已引起组件家族切换，则不得按“局部修改通过”交付，必须升级执行 `W1` 全页重落地（声明变化时先回 `D3`）
- [ ] **两轮内必须收敛**：同一局部修改若在 2 次 repair loop 后仍反复出现图标丢失、标题偏移、字体失效、底栏串型等问题，视为局部补丁策略失败，必须升级为 `D3 + W1`，❌ 禁止继续小修小补
- [ ] **视觉 bug 零容忍**：交付前不得存在任何已知肉眼可见问题，包括但不限于标题偏移、图标空白、系统栏变形、Home Indicator 缺失、组件错位、裁切异常、大面积灰框、通栏误用、底栏遮挡内容；命中任一项即不得交付
- [ ] **P0/P1 不得进入交付**：若当前问题属于用户可见异常、资源缺失、声明失配、组件不可回溯、歧义未解、局部修改越级，或命中上方「第二轮组件调用轮询」中的任一 `P0/P1` 条目，则必须继续 repair loop；❌ 禁止靠“说明一下已知问题”直接交付
- [ ] **仅 P2 可进入已知限制**：若要输出 `⚠️ 已知限制`，必须先确认该问题不影响视觉、资源、组件调用、声明一致性与未改区域稳定性；不满足则不得写入“已知限制”
- [ ] **图片来源合规**：
  - **主力**：`picsum.photos/seed/{语义seed}/{w}/{h}`，seed 必须对应文案含义（`cherry-fruit` / `hotel-room` / `ramen-japanese` 等），禁止所有图片用同一 seed
  - **头像**：`randomuser.me/api/portraits/{men|women}/{0-99}.jpg`，同页不同用户换不同数字
  - **Unsplash**：仅允许使用 `images.unsplash.com/photo-{已验证ID}?w=&h=&fit=crop`，禁止随意猜测 photo ID
  - **严禁使用** `source.unsplash.com/featured/`（已于 2023 年永久失效，必然 404）
  - 禁止裸 `<div>` 无背景 / 无 `src` 的 `<img>`；占位图/示意图无外部图片时必须用 `background` Token 色（见 `references/demo-generate/image-keywords.md` 降级方案）
- [ ] **图片与文案语义匹配**：逐图核查图片 seed / photo ID 是否对应旁边的文案内容，禁止用通用词兜底（如所有商品图都写 `food`）；同页多图 seed 各不相同
- [ ] **`<html>` 标签 `color-scheme` 同步**：`<html>` 标签建议加 `style="color-scheme:light"`，与 `<meta>` 声明双重保险；部分浏览器以 `<html>` 内联样式为准而非 meta 标签
- [ ] **局部修改交付口径一致**：若本次为已有 HTML 局部修改，对外最终交付信息中必须明确说明"未改区域已按回归清单复验"；❌ 禁止只说"已修改完成"而不说明回归已做

---

## §C 评测协议核验（仅进入 Eval Set v2 时触发，普通交付任务跳过）

> 📌 以下条款属于**评测流程管理**范畴，与 §B HTML 输出验收相互独立。普通新页面生成和局部修改任务**无需执行本节**；仅当本轮涉及规则新增/修订、repair loop 调整、局部修改协议加固或需要验证"有没有提升"时才激活。

- [ ] **failure sample 记录完整**：若本轮出现失败并进入修复/复盘，至少需补齐 `failure_layer / severity / rollback_node / delivery_block / fix_action`；❌ 缺字段样本不得用于后续统计与评测
- [ ] **样例级阻断判定正确**：若当前任务对应 Eval Set v2 中的硬验收样例，必须核对 `must_fail_if / severity / 交付预期` 三项是否一致；若出现应拦未拦、误拦或判级错误，视为 gate 失效
- [ ] **评测记录字段完整**：若当前任务进入样例评测，至少补齐 `eval_id / must_fail_hit / actual_severity / actual_delivery / final_outcome / rollback_node / fix_action`；缺字段则本轮评测结果无效
- [ ] **评测触发条件正确**：仅当本轮涉及规则新增/修订、repair loop 调整、局部修改协议加固，或需要验证"有没有提升"时，才进入 `Eval Set v2`；普通交付任务不强制升级为整套 10 样例评测，但一旦进入评测，单样例仍必须先完成 `§B`
- [ ] **评测执行顺序正确**：必须先完成 `D1 / D2 / D3 → W1（或 W1-edit）→ 注入 → §B`，再判 `must_fail_hit / actual_severity / actual_delivery / final_outcome`；若首轮失败，先补 failure sample，再写 `Eval Record`
- [ ] **逐样例主指标与修复路径明确**：若当前任务进入 `Eval Set v2`，每个样例都必须能明确指出 `primary_metric / expected_repair_path`；若说不清"这条样例在拉哪项指标、首轮失败该回哪一层"，则样例定义仍过粗，不得拿来下提升结论
- [ ] **样例预期与实际可对照**：评测时必须能说清 `expected_pass_signal / expected_fail_signal / expected_regression_scope / expected_delivery` 与实际是否一致；若说不清，则样例定义不合格，需先补模板再继续跑
- [ ] **整轮评测放行条件满足**：若要对外声称"这轮更稳了 / 成功率提升"，至少满足：样例数与配比达标、`fail-block-missed = 0`、`known-limit-polluted = 0`、`blocking_recall = 100%`；若本轮主攻局部修改，还需 `partial_edit_integrity_rate = 100%`
- [ ] **评测汇总可回答三问**：每轮评测后至少能回答"有没有提升 / 有没有误拦 / 有没有漏拦"；若不能回答，说明记录格式不足，不得直接下结论

---

## 速查表（HTML 生成时直接查，禁止推导）

### A. Color Token → CSS hex

**文字 & 背景 & 描边**

| Token | CSS 值 | 说明 |
|---|---|---|
| `text-primary` | `#111111` | 主要文字 |
| `text-secondary` | `#555555` | 次要文字 |
| `text-tertiary` | `#888888` | 辅助文字 |
| `text-disabled` | `#C2C2C2` | 禁用文字 |
| `white` | `#FFFFFF` | 白色 |
| `bg-page` | `#F5F5F5` | 页面背景 |
| `bg-surface` | `#F7F7F7` | 组件内次级背景（非卡片白！**卡片白色背景统一用 `white` = `#FFFFFF`**，`bg-surface` 仅用于组件内层次区分）|
| `bg-disabled` | `#F0F0F0` | 禁用背景 |
| `stroke-default` | `#E5E5E5` | 默认描边（输入框/卡片边框等） |
| `stroke-strong` | `#CCCCCC` | 强描边（副按钮 / 线性按钮边框；⚠️ 不是禁用！）|
| `stroke-disabled` | `#CCCCCC` | 禁用描边（与 `stroke-strong` 同色值，但语义不同：此处用于禁用态）|

**功能主色**

| Token | CSS 值 | 说明 |
|---|---|---|
| `orange-default` | `#FF7700` | 橙色主色（美团橙） |
| `yellow-default` | `#FFDD00` | 黄色主色（品牌黄） |
| `green-default` | `#00B300` | 绿色主色 |
| `blue-default` | `#0A77F5` | 蓝色主色 |
| `red-default` | `#FF2D19` | 红色主色 |

**浅色背景（大面积用）**

| Token | CSS 值 | 说明 |
|---|---|---|
| `orange-bg`（O1） | `#FFF8F0` | 浅橙背景（色板第1档，金刚区外卖/到店背景色） |
| `yellow-bg`（Y1） | `#FFFADB` | 浅黄背景 |
| `green-bg`（G1） | `#E1FAE8` | 浅绿背景（色板第1档，金刚区买菜/医药健康背景色）|
| `blue-bg`（B1） | `#F0F7FF` | 浅蓝背景 |
| `red-bg`（R1） | `#FFF1F0` | 浅红背景 |

**渐变色**

| Token | CSS 值 |
|---|---|
| `gradient-yellow` | `linear-gradient(to bottom right, #FFE74D, #FFDD00)` |
| `gradient-orange` | `linear-gradient(to bottom right, #FF9233, #FF5500)` |
| `gradient-red` | `linear-gradient(to bottom right, #FF6619, #FF2D19)` |
| `gradient-green` | `linear-gradient(to bottom right, #38D12A, #00B300)` |
| DPT5 到餐渐变 | `linear-gradient(to bottom right, #FF7700, #FF4B10)` |

### B. Button CSS → 详见 `references/component/molecules/button.md 八（§8）`

> 完整 CSS（全尺寸 / Variant / 双行模板 / Price Font @2x 覆盖）均在 `references/component/molecules/button.md 八（§8）`，直接复制，禁止手动推导。
