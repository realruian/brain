# stroke-reference.md

> **规范类型：** Reference 层规范
> **Token 类型：** Reference Stroke Token
> **使用说明：** 本文件为原始描边数据源，供 Semantic 层引用映射使用。所有名称以 `.` 开头，表示不可直接用于业务需求，请通过 `semantic/stroke-semantic.md` 中的语义 Token 调取描边。描边值格式为 `top, right, bottom, left`。
> **单位说明：** 本文件所有描边值均为 **@1x 逻辑像素（pt）**，直接对应 CSS 输出值，无需换算。
> **维护人：** Likaimeng
> **最新版本：** 2026-4-9

---

## 一、Stroke

> 数值格式：top, right, bottom, left
> 单位：pt

| 名称 | 数值 |
|-----|------|
| .0.5pt | 0.5, 0.5, 0.5, 0.5 |
| .1pt | 1, 1, 1, 1 |
