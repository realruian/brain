# spacing-reference.md

> **规范类型：** Reference 层规范
> **Token 类型：** Reference Spacing Token
> **使用说明：** 本文件为原始间距数据源，供 Semantic 层引用映射使用。所有名称以 `.` 开头，表示不可直接用于业务需求，请通过 `semantic/spacing-semantic.md` 中的语义 Token 调取间距。
> **单位说明：** 本文件所有间距均为 **@1x 逻辑像素（pt）**，直接对应 CSS/开发输出值，无需换算。
> **维护人：** Likaimeng
> **最新版本：** 2026-4-9

---

## 一、Grid Spacing

> 单位：pt

| 名称 | 数值 |
|-----|----------|
| .32pt | 32 |
| .28pt | 28 |
| .24pt | 24 |
| .18pt | 18 |
| .16pt | 16 |
| .12pt | 12 |
| .10pt | 10 |
| .8pt | 8 |
| .6pt | 6 |
| .4pt | 4 |
| .2pt | 2 |
