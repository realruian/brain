# font-reference.md

> **规范类型：** Reference 层规范
> **Token 类型：** Reference Font Token
> **使用说明：** 本文件为原始字体数据源，供 Semantic 层引用映射使用。所有名称以 `.` 开头，表示不可直接用于业务需求，请通过 `semantic/font-semantic.md` 中的语义 Token 调取字体样式。
> **单位说明：** 本文件所有字号、行高均为 **@1x 逻辑像素（pt）**，直接对应 CSS/开发输出值，无需换算。
> **维护人：** Likaimeng
> **最新版本：** 2026-4-9

> ⚠️ **平台字重约定（全局生效）**：所有基于本设计系统生成的界面效果，**统一以 iOS 字重体系为基准**。即 Token 名中的 `Semibold` 对应苹方简 Semibold 600，`Medium` 对应 Medium 500，`Regular` 对应 Regular 400。安卓平台字重（如 Bold 700）仅供工程师参考，**不用于设计方案输出和 AI 生成**。

---

## 一、Text Font

> 字体：苹果系统 苹方 简（iOS）/ 安卓系统字体（Android）
> **CSS font-family**：`'PingFang SC', 'Noto Sans SC', 'Source Han Sans SC', 'Microsoft YaHei', 'WenQuanYi Micro Hei', sans-serif`
> **渲染优化**：`-webkit-font-smoothing: antialiased; -moz-osx-font-smoothing: grayscale;`
> 路径前缀：`Font/Text Font/`

| 名称 | 字号 | 行高 | 字重（苹果） | 字重（安卓） |
|-----|------|------|------------|------------|
| `.42-Semibold` | 42pt | 60pt | 中粗体 Semibold 600 | 粗体 Bold 700 |
| `.42-Medium` | 42pt | 60pt | 中黑体 Medium 500 | 中黑体 Medium 500 |
| `.42-Regular` | 42pt | 60pt | 常规 Regular 400 | 常规 Regular 400 |
| `.38-Semibold` | 38pt | 54pt | 中粗体 Semibold 600 | 粗体 Bold 700 |
| `.38-Medium` | 38pt | 54pt | 中黑体 Medium 500 | 中黑体 Medium 500 |
| `.38-Regular` | 38pt | 54pt | 常规 Regular 400 | 常规 Regular 400 |
| `.32-Semibold` | 32pt | 46pt | 中粗体 Semibold 600 | 粗体 Bold 700 |
| `.32-Medium` | 32pt | 46pt | 中黑体 Medium 500 | 中黑体 Medium 500 |
| `.32-Regular` | 32pt | 46pt | 常规 Regular 400 | 常规 Regular 400 |
| `.28-Semibold` | 28pt | 40pt | 中粗体 Semibold 600 | 粗体 Bold 700 |
| `.28-Medium` | 28pt | 40pt | 中黑体 Medium 500 | 中黑体 Medium 500 |
| `.28-Regular` | 28pt | 40pt | 常规 Regular 400 | 常规 Regular 400 |
| `.24-Semibold` | 24pt | 34pt | 中粗体 Semibold 600 | 粗体 Bold 700 |
| `.24-Medium` | 24pt | 34pt | 中黑体 Medium 500 | 中黑体 Medium 500 |
| `.24-Regular` | 24pt | 34pt | 常规 Regular 400 | 常规 Regular 400 |
| `.22-Semibold` | 22pt | 32pt | 中粗体 Semibold 600 | 粗体 Bold 700 |
| `.22-Medium` | 22pt | 32pt | 中黑体 Medium 500 | 中黑体 Medium 500 |
| `.22-Regular` | 22pt | 32pt | 常规 Regular 400 | 常规 Regular 400 |
| `.20-Semibold` | 20pt | 28pt | 中粗体 Semibold 600 | 粗体 Bold 700 |
| `.20-Medium` | 20pt | 28pt | 中黑体 Medium 500 | 中黑体 Medium 500 |
| `.20-Regular` | 20pt | 28pt | 常规 Regular 400 | 常规 Regular 400 |
| `.18-Semibold` | 18pt | 26pt | 中粗体 Semibold 600 | 粗体 Bold 700 |
| `.18-Medium` | 18pt | 26pt | 中黑体 Medium 500 | 中黑体 Medium 500 |
| `.18-Regular` | 18pt | 26pt | 常规 Regular 400 | 常规 Regular 400 |
| `.17-Semibold` | 17pt | 24pt | 中粗体 Semibold 600 | 粗体 Bold 700 |
| `.17-Medium` | 17pt | 24pt | 中黑体 Medium 500 | 中黑体 Medium 500 |
| `.17-Regular` | 17pt | 24pt | 常规 Regular 400 | 常规 Regular 400 |
| `.16-Semibold` | 16pt | 22pt | 中粗体 Semibold 600 | 粗体 Bold 700 |
| `.16-Medium` | 16pt | 22pt | 中黑体 Medium 500 | 中黑体 Medium 500 |
| `.16-Regular` | 16pt | 22pt | 常规 Regular 400 | 常规 Regular 400 |
| `.15-Semibold` | 15pt | 22pt | 中粗体 Semibold 600 | 粗体 Bold 700 |
| `.15-Medium` | 15pt | 22pt | 中黑体 Medium 500 | 中黑体 Medium 500 |
| `.15-Regular` | 15pt | 22pt | 常规 Regular 400 | 常规 Regular 400 |
| `.14-Semibold` | 14pt | 20pt | 中粗体 Semibold 600 | 粗体 Bold 700 |
| `.14-Medium` | 14pt | 20pt | 中黑体 Medium 500 | 中黑体 Medium 500 |
| `.14-Regular` | 14pt | 20pt | 常规 Regular 400 | 常规 Regular 400 |
| `.13-Semibold` | 13pt | 18pt | 中粗体 Semibold 600 | 粗体 Bold 700 |
| `.13-Medium` | 13pt | 18pt | 中黑体 Medium 500 | 中黑体 Medium 500 |
| `.13-Regular` | 13pt | 18pt | 常规 Regular 400 | 常规 Regular 400 |
| `.12-Semibold` | 12pt | 16pt | 中粗体 Semibold 600 | 粗体 Bold 700 |
| `.12-Medium` | 12pt | 16pt | 中黑体 Medium 500 | 中黑体 Medium 500 |
| `.12-Regular` | 12pt | 16pt | 常规 Regular 400 | 常规 Regular 400 |
| `.11-Semibold` | 11pt | 16pt | 中粗体 Semibold 600 | 粗体 Bold 700 |
| `.11-Medium` | 11pt | 16pt | 中黑体 Medium 500 | 中黑体 Medium 500 |
| `.11-Regular` | 11pt | 16pt | 常规 Regular 400 | 常规 Regular 400 |
| `.10-Semibold` | 10pt | 14pt | 中粗体 Semibold 600 | 粗体 Bold 700 |
| `.10-Medium` | 10pt | 14pt | 中黑体 Medium 500 | 中黑体 Medium 500 |
| `.10-Regular` | 10pt | 14pt | 常规 Regular 400 | 常规 Regular 400 |

---

## 二、Paragraph Font

> 字体：苹果系统 苹方 简（iOS）/ 安卓系统字体（Android）
> **CSS font-family**：`'PingFang SC', 'Noto Sans SC', 'Source Han Sans SC', 'Microsoft YaHei', 'WenQuanYi Micro Hei', sans-serif`
> **渲染优化**：`-webkit-font-smoothing: antialiased; -moz-osx-font-smoothing: grayscale;`
> 与 Text Font 的区别：行高更大，适用于段落正文阅读场景
> 路径前缀：`Font/Paragraph Font/`

| 名称 | 字号 | 行高 | 字重（苹果） | 字重（安卓） |
|-----|------|------|------------|------------|
| `.16-Semibold` | 16pt | 26pt | 中粗体 Semibold 600 | 粗体 Bold 700 |
| `.16-Medium` | 16pt | 26pt | 中黑体 Medium 500 | 中黑体 Medium 500 |
| `.16-Regular` | 16pt | 26pt | 常规 Regular 400 | 常规 Regular 400 |
| `.15-Semibold` | 15pt | 24pt | 中粗体 Semibold 600 | 粗体 Bold 700 |
| `.15-Medium` | 15pt | 24pt | 中黑体 Medium 500 | 中黑体 Medium 500 |
| `.15-Regular` | 15pt | 24pt | 常规 Regular 400 | 常规 Regular 400 |
| `.14-Semibold` | 14pt | 22pt | 中粗体 Semibold 600 | 粗体 Bold 700 |
| `.14-Medium` | 14pt | 22pt | 中黑体 Medium 500 | 中黑体 Medium 500 |
| `.14-Regular` | 14pt | 22pt | 常规 Regular 400 | 常规 Regular 400 |
| `.13-Semibold` | 13pt | 20pt | 中粗体 Semibold 600 | 粗体 Bold 700 |
| `.13-Medium` | 13pt | 20pt | 中黑体 Medium 500 | 中黑体 Medium 500 |
| `.13-Regular` | 13pt | 20pt | 常规 Regular 400 | 常规 Regular 400 |
| `.12-Semibold` | 12pt | 20pt | 中粗体 Semibold 600 | 粗体 Bold 700 |
| `.12-Medium` | 12pt | 20pt | 中黑体 Medium 500 | 中黑体 Medium 500 |
| `.12-Regular` | 12pt | 20pt | 常规 Regular 400 | 常规 Regular 400 |
| `.11-Semibold` | 11pt | 18pt | 中粗体 Semibold 600 | 粗体 Bold 700 |
| `.11-Medium` | 11pt | 18pt | 中黑体 Medium 500 | 中黑体 Medium 500 |
| `.11-Regular` | 11pt | 18pt | 常规 Regular 400 | 常规 Regular 400 |
| `.10-Semibold` | 10pt | 16pt | 中粗体 Semibold 600 | 粗体 Bold 700 |
| `.10-Medium` | 10pt | 16pt | 中黑体 Medium 500 | 中黑体 Medium 500 |
| `.10-Regular` | 10pt | 16pt | 常规 Regular 400 | 常规 Regular 400 |

---

## 三、Price Font

> 字体：美团新数字体（iOS / Android 一致）
> 路径前缀：`Font/Price Font/`
> **CSS font-family**：`'美团新数字体', 'MTNewDigitalDisplay', sans-serif`
> **字重映射**：Bold → `font-weight: 700`；Medium → `font-weight: 500`；Regular → `font-weight: 400`
> **本机使用说明**：字体文件位于 `~/Library/Fonts/MTNewDigitalDisplay-{Bold|Medium|Regular}.otf`，macOS 已全局安装，HTML 预览时**无需 `@font-face`**，直接写 `font-family` 即可在本机浏览器生效。

| 名称 | 字号 | 行高 | 字重 |
|-----|------|------|------|
| `.30-Bold` | 30pt | 42pt | Bold 700 |
| `.30-Medium` | 30pt | 42pt | Medium 500 |
| `.30-Regular` | 30pt | 42pt | Regular 400 |
| `.26-Bold` | 26pt | 36pt | Bold 700 |
| `.26-Medium` | 26pt | 36pt | Medium 500 |
| `.26-Regular` | 26pt | 36pt | Regular 400 |
| `.24-Bold` | 24pt | 34pt | Bold 700 |
| `.24-Medium` | 24pt | 34pt | Medium 500 |
| `.24-Regular` | 24pt | 34pt | Regular 400 |
| `.22-Bold` | 22pt | 32pt | Bold 700 |
| `.22-Medium` | 22pt | 32pt | Medium 500 |
| `.22-Regular` | 22pt | 32pt | Regular 400 |
| `.20-Bold` | 20pt | 28pt | Bold 700 |
| `.20-Medium` | 20pt | 28pt | Medium 500 |
| `.20-Regular` | 20pt | 28pt | Regular 400 |
| `.18-Bold` | 18pt | 26pt | Bold 700 |
| `.18-Medium` | 18pt | 26pt | Medium 500 |
| `.18-Regular` | 18pt | 26pt | Regular 400 |
| `.16-Bold` | 16pt | 22pt | Bold 700 |
| `.16-Medium` | 16pt | 22pt | Medium 500 |
| `.16-Regular` | 16pt | 22pt | Regular 400 |
| `.15-Bold` | 15pt | 22pt | Bold 700 |
| `.15-Medium` | 15pt | 22pt | Medium 500 |
| `.15-Regular` | 15pt | 22pt | Regular 400 |
| `.14-Bold` | 14pt | 20pt | Bold 700 |
| `.14-Medium` | 14pt | 20pt | Medium 500 |
| `.14-Regular` | 14pt | 20pt | Regular 400 |
| `.13-Bold` | 13pt | 18pt | Bold 700 |
| `.13-Medium` | 13pt | 18pt | Medium 500 |
| `.13-Regular` | 13pt | 18pt | Regular 400 |
| `.12-Bold` | 12pt | 16pt | Bold 700 |
| `.12-Medium` | 12pt | 16pt | Medium 500 |
| `.12-Regular` | 12pt | 16pt | Regular 400 |
| `.11-Bold` | 11pt | 16pt | Bold 700 |
| `.11-Medium` | 11pt | 16pt | Medium 500 |
| `.11-Regular` | 11pt | 16pt | Regular 400 |
| `.10-Bold` | 10pt | 14pt | Bold 700 |
| `.10-Medium` | 10pt | 14pt | Medium 500 |
| `.10-Regular` | 10pt | 14pt | Regular 400 |

---

## 四、Special Font

> 字体：美团体（iOS / Android 一致）
> 行高为 Auto，由系统自动计算
> 路径前缀：`Font/Special Font/`

| 名称 | 字号 | 行高 | 字重 |
|-----|------|------|------|
| `.20-Regular-美团体` | 20pt | Auto | Regular 400 |
