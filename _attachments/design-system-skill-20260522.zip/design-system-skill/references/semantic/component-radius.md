# component-radius.md

> **规范类型：** Semantic 层规范
> **Token 类型：** Component Radius Token
> **适用范围：** ⚠️ **仅用于组件内部圆角**（border-radius）。页面级卡片、浮层等大圆角请使用 `radius-semantic.md`（`radius-xxs` 起，最小 4pt）。
> **使用说明：** 本文件为组件内部圆角的补充档位层。`radius-semantic.md` 最小档位为 `radius-xxs`（4pt），无法覆盖组件内部的细粒度圆角需求（如标签 3pt、气泡尖角 1pt 等）。组件规范中出现的精确圆角约束值，统一从本文件引用，不再使用裸 pt 数值。
> **维护人：** likaimeng
> **最新版本：** 2026-04-09

---

## 使用边界说明

| 场景 | 使用的文件 |
|------|----------|
| 页面卡片、浮层、弹窗等大圆角（≥ 4pt） | `radius-semantic.md`（`radius-xxs` ~ `radius-xl`，`radius-full`） |
| 组件内部细粒度圆角（≤ 4pt） | **本文件** `component-radius.md` |
| 全圆角（胶囊形） | `radius-semantic.md` 的 `radius-full`（`border-radius: 9999px`） |

> ❌ **禁止**在页面级布局中引用本文件的 Token。
> ❌ **禁止**在组件内部圆角中直接写裸 pt 数值，统一引用本文件或 `radius-semantic.md`。

---

## 一、Component Radius（组件内圆角档位）

> 档位命名规则：`cr-{N}`，N 为对应的 pt 值（@1x 逻辑像素）。

| Token 名称 | 值 | 备注 |
|-----------|-----|------|
| `cr-1`   | 1pt  | Tag 气泡角标尖角（左下角） |
| `cr-2`   | 2pt  | — |
| `cr-3`   | 3pt  | Tag compact / standard-10 / standard-11 圆角 |
| `cr-4`   | 4pt  | Tag loose-11 / loose-12 / large 圆角（同 `radius-xxs`，组件层统一引用此 Token） |
| `cr-5`   | 5pt  | — |
| `cr-6`   | 6pt  | Search Bar 44pt 内嵌搜索框圆角（address-search / double-input 布局）；Tag corner 标签圆角（容器圆角 = 6pt 时，A / C 角） |
| `cr-7`   | 7pt  | Tag 气泡角标 compact 大圆角（三角非尖角侧） |
| `cr-8`   | 8pt  | Tag 气泡角标 standard-11 大圆角；Tag corner 标签圆角（容器圆角 = 8pt 时 A / C 角；容器圆角 = 12pt 时 C 角） |
| `cr-9`   | 9pt  | Tag 气泡角标 loose-11 / loose-12 大圆角 |
| `cr-10`  | 10pt | Tag 气泡角标 large 大圆角 |
| `cr-11`  | 11pt | — |
| `cr-12`  | 12pt | Tag corner 标签圆角（容器圆角 = 12pt 时，A 角 = 12pt） |
| `radius-full` | `border-radius: 9999px` | 全圆角（胶囊形），用于按钮、搜索框、标签、头像等需要完全圆角的场景；不映射固定 pt 档位 |

> **说明**：「备注」列仅标注当前已在组件规范中实际使用的值，其余档位预留备用。
> **`cr-4` 与 `radius-xxs` 的关系**：两者数值相同（均为 4pt），但组件层统一从本文件引用 `cr-4`，保持圆角来源的一致性，不跨层混用 `radius-semantic.md`。
> **`radius-full` 说明**：实现值为 `border-radius: 9999px`，W3C 规范会将其 clamp 到元素自身半径，任意高度下均呈胶囊形。这是行业标准写法，不是"极大值临时方案"。

---

## 引用规则

- **Component 层**（`references/component/`）通过 `cr-{N}` 或 `radius-full` 名称引用本层 Token
- **不得**在 Template 层、页面描述中引用本文件 Token
- 气泡角标的非对称圆角（如 `cr-8 cr-8 cr-8 cr-1`）各角分别引用对应档位 Token，不再使用裸 pt 精确值
