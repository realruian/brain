# stroke-semantic.md

> **规范类型：** Semantic 层规范
> **Token 类型：** Semantic Border Token（描边宽度）
> **使用说明：** 本文件为描边**宽度**语义映射层，专管线条粗细。颜色请查阅 `color-semantic.md` 中的 `stroke-*` 颜色 Token。所有业务需求应直接引用本文件中的语义名称，禁止跨层直接使用 Reference 层的原始 Token（如 `.0.5pt`）。通过分割线使页面同类信息中不同容器内容间的关系更清晰，优化视觉排版节奏。
> **维护人：** Likaimeng
> **最新版本：** 2026-4-9

---

## ⚠️ 命名区分说明

| Token 前缀 | 所在文件 | 描述 |
|-----------|---------|------|
| `stroke-*` | `color-semantic.md` | 描边**颜色**（如 `stroke-default`、`stroke-strong`） |
| `border-*` | `stroke-semantic.md`（本文件） | 描边**宽度**（如 `border-default`、`border-bold`） |

Component 层使用时，颜色和宽度需分别从两个文件取值，组合使用。

---

## 路径解析说明

**读取规则：** 表格中"映射值"列格式为 `Stroke/.[Token名]`。Agent 使用时，在 `reference/stroke-reference.md` 的 `## 一、Stroke` 章节中按名称完全匹配（含 `.` 前缀）找到原始值。

| 映射值前缀 | 对应文件 | 对应章节 |
|-----------|---------|---------|
| `Stroke/` | `reference/stroke-reference.md` | 一、Stroke |

**⚠️ Token 名称必须与 Reference 文件中完全一致（含 `.` 前缀），否则引用无效。**

---

## 一、Border（描边宽度）

| 语义名称 | 映射值 | 使用场景描述 |
|--------|--------|------------|
| `border-default` | Stroke/.0.5pt | 标准线宽（0.5pt）。常用于常规信息的分组 |
| `·` | Stroke/.1pt | 加粗线宽（1pt）。常用于各类容器之间的分割，如白底商卡等 |

---

## 引用规则

- **Component 层** 通过语义名称（如 `border-default`）引用本层 Token
- **向下追踪**：映射值中的 Token 名须与 `stroke-reference.md → ## 一、Stroke` 完全匹配（含 `.` 前缀）
- **命名原则**：采用 `border-[语义描述]` 的 kebab-case 格式，以视觉权重区分用途，与颜色层的 `stroke-*` 前缀区分
