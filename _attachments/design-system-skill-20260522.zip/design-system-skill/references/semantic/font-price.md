# font-price.md

> **规范类型：** Semantic 层规范
> **Token 类型：** Semantic Font Token（价格数字字体子集）
> **使用说明：** 本文件是 `font-semantic.md` 中 Price Font 部分的独立专项规范，包含完整字号档位定义、字重选用规则和场景指引。组件层应通过本文件或 `font-semantic.md` 的语义名称引用 Price Font Token，禁止跨层直接使用 `font-reference.md` 的原始值。
> **单位说明：** 本文件所有数值均为 **@1x 逻辑像素（pt）**，直接对应 CSS 输出值，无需换算。
> **维护人：** Likaimeng
> **最新版本：** 2026-4-9

---

## 一、字体说明

**字体名称**：美团新数字体（MT New Digital Display）
**适用平台**：iOS / Android 一致（双端同一字体）
**适用内容**：价格数字、货币符号（¥）、小数点（.）
**禁止场景**：普通文字、标题、正文内容——必须使用苹方（Text Font / Paragraph Font）

**CSS 声明**：
```css
font-family: '美团新数字体', 'MT New Digital Display', sans-serif;
font-weight: 400; /* Regular */
font-weight: 500; /* Medium  */
font-weight: 700; /* Bold    */
```

> **字体资产**：字体文件（Regular / Medium / Bold）安装在系统字体册（`~/Library/Fonts/MTNewDigitalDisplay-*.otf`）。生成 HTML 时**必须 Base64 内联**（`file://` 协议会被浏览器安全策略拦截导致字体不加载），通过 `fs.readFileSync(fontPath).toString('base64')` 内嵌至 `@font-face src`。详见 SKILL.md 第四步 HTML 原型输出第 2 条。

**默认颜色**：价格数字（¥ 符号 + 整数 + 小数点 + 小数位）统一使用 `red-default`（`#FF2D19`）。**到餐（DPT5）业务例外**：使用 `dpt5-o5`（`#FF4B10`），见 `references/semantic/color-business.md §到餐`。除该业务例外或用户明确指定外，不得使用其他色值。

---

## 二、字号档位与行高

| 语义名称 | font-size | line-height | font-weight | 分组 |
|---------|-----------|-------------|-------------|------|
| `price-30-bold` | 30pt | 42pt | 700 | 超大 |
| `price-30-medium` | 30pt | 42pt | 500 | 超大 |
| `price-30-regular` | 30pt | 42pt | 400 | 超大 |
| `price-26-bold` | 26pt | 36pt | 700 | 超大 |
| `price-26-medium` | 26pt | 36pt | 500 | 超大 |
| `price-26-regular` | 26pt | 36pt | 400 | 超大 |
| `price-24-bold` | 24pt | 34pt | 700 | 超大 |
| `price-24-medium` | 24pt | 34pt | 500 | 超大 |
| `price-24-regular` | 24pt | 34pt | 400 | 超大 |
| `price-22-bold` | 22pt | 32pt | 700 | 超大 |
| `price-22-medium` | 22pt | 32pt | 500 | 超大 |
| `price-22-regular` | 22pt | 32pt | 400 | 超大 |
| `price-20-bold` | 20pt | 28pt | 700 | 大 |
| `price-20-medium` | 20pt | 28pt | 500 | 大 |
| `price-20-regular` | 20pt | 28pt | 400 | 大 |
| `price-18-bold` | 18pt | 26pt | 700 | 大 |
| `price-18-medium` | 18pt | 26pt | 500 | 大 |
| `price-18-regular` | 18pt | 26pt | 400 | 大 |
| `price-16-bold` | 16pt | 22pt | 700 | 大 |
| `price-16-medium` | 16pt | 22pt | 500 | 大 |
| `price-16-regular` | 16pt | 22pt | 400 | 大 |
| `price-15-bold` | 15pt | 22pt | 700 | 中 |
| `price-15-medium` | 15pt | 22pt | 500 | 中 |
| `price-15-regular` | 15pt | 22pt | 400 | 中 |
| `price-14-bold` | 14pt | 20pt | 700 | 中 |
| `price-14-medium` | 14pt | 20pt | 500 | 中 |
| `price-14-regular` | 14pt | 20pt | 400 | 中 |
| `price-13-bold` | 13pt | 18pt | 700 | 中 |
| `price-13-medium` | 13pt | 18pt | 500 | 中 |
| `price-13-regular` | 13pt | 18pt | 400 | 中 |
| `price-12-bold` | 12pt | 16pt | 700 | 小 |
| `price-12-medium` | 12pt | 16pt | 500 | 小 |
| `price-12-regular` | 12pt | 16pt | 400 | 小 |
| `price-11-bold` | 11pt | 16pt | 700 | 小 |
| `price-11-medium` | 11pt | 16pt | 500 | 小 |
| `price-11-regular` | 11pt | 16pt | 400 | 小 |
| `price-10-bold` | 10pt | 14pt | 700 | 小 |
| `price-10-medium` | 10pt | 14pt | 500 | 小 |
| `price-10-regular` | 10pt | 14pt | 400 | 小 |

---

## 三、价格组合 Token（Price Set Token）

### 3.1 货币符号（¥）、数字间距规则

价格部分（¥ 符号 + 整数 + 小数点 + 小数位）建议全部使用美团新数字体，不与苹方混用。

**间距规则**：
- ¥ 符号与整数之间：固定间距 **1pt**
- 整数十位与各位之间：固定间距 **0**（字体自带等宽字距，无需额外设置）
- 小数点字号须与小数位**严格保持一致**

**¥ 符号字号规则**：字重与数字部分保持一致。

---

### 3.2 相同大小组合

> 整数、小数点、小数位使用**相同字号**，所有元素引用同一档位 Token。
>
> **适用场景**：用户获得的金额数字，如红包、优惠券、余额等。场景重心在金额本身，价格数字是页面主角。

#### 超大（30 / 26 / 24 / 22）

| 字号档 | ¥ 符号 Token | 整数 Token | 小数点 + 小数位 Token | 场景 |
|--------|------------|------------|---------------------|------|
| `price-set-30` | `price-16-bold` | `price-30-bold` | `price-30-bold` | 重点金额大号展示 |
| `price-set-26` | `price-16-bold` | `price-26-bold` | `price-26-bold` | 首选。常用于评价小分项，也可用于空间小，推荐卡价格 |
| `price-set-24` | `price-15-bold` | `price-24-bold` | `price-24-bold` | 订单金额、结算金额 |
| `price-set-22` | `price-14-bold` | `price-22-bold` | `price-22-bold` | 页面头部金额 |

#### 大（20 / 18 / 16）— Bold 700 首选；非主要价格可降级为 Medium 500

| 字号档 | ¥ 符号 Token | 整数 Token | 小数点 + 小数位 Token | 场景 |
|--------|------------|------------|---------------------|------|
| `price-set-20` | `price-13-bold` | `price-20-bold` | `price-20-bold` | 余额、红包金额 |
| `price-set-18` | `price-12-bold` | `price-18-bold` | `price-18-bold` | 优惠券面额 |
| `price-set-16` | `price-11-bold` | `price-16-bold` | `price-16-bold` | 小金额展示 |

#### 中（15 / 14 / 13）— Bold 700 首选；非主角价格可用 Medium 500

| 字号档 | ¥ 符号 Token | 整数 Token | 小数点 + 小数位 Token | 场景 |
|--------|------------|------------|---------------------|------|
| `price-set-15` | `price-11-bold` | `price-15-bold` | `price-15-bold` | 次级金额 |
| `price-set-14` | `price-10-medium` | `price-14-medium` | `price-14-bold` | 紧凑空间金额 |
| `price-set-13` | `price-13-bold` | `price-13-bold` | `price-13-bold` | 辅助金额 |

#### 小（12 / 11 / 10）— Regular 400 首选；需突出时用 Medium 500，不推荐 Bold

| 字号档 | ¥ 符号 Token | 整数 Token | 小数点 + 小数位 Token | 场景 |
|--------|------------|------------|---------------------|------|
| `price-set-12` | `price-11-regular` | `price-12-regular` | `price-12-regular` | 小号金额 |
| `price-set-11` | `price-10-regular` | `price-11-regular` | `price-11-regular` | 小号金额 |
| `price-set-10` | `price-10-regular` | `price-10-regular` | `price-10-regular` | 极小金额（¥ 与整数同档） |

---

### 3.3 不同大小组合

> 整数字号**大于**小数点 + 小数位字号，建议差 1～2 个档位，通过字号差建立视觉层级。
>
> **适用场景**：商品金额展示，如商品列表页、商品详情页、购物车页、结算页等。场景重心在商品，价格数字是核心信息之一。

#### 超大（30 / 26 / 24 / 22）— Bold 700 首选，一般不降级

| 整数 + 小数档 | ¥ 符号 Token | 整数 Token | 小数点 + 小数位 Token | 场景 |
|-------------|------------|------------|---------------------|------|
| `price-set-30+22` | `price-16-bold` | `price-30-bold` | `price-22-bold` | POI 页面主价格、商详头部价格 |
| `price-set-26+18` | `price-16-bold` | `price-26-bold` | `price-18-bold` | 商详页主价格 |
| `price-set-24+16` | `price-15-bold` | `price-24-bold` | `price-16-bold` | 购物车、结算页底部价格 |
| `price-set-22+16` | `price-14-bold` | `price-22-bold` | `price-14-bold` | 外卖选规格页价格 |

#### 大（20 / 18 / 16）— Bold 700 首选；辅助价格可用 Medium 500

| 整数 + 小数档 | ¥ 符号 Token | 整数 Token | 小数点 + 小数位 Token | 场景 |
|-------------|------------|------------|---------------------|------|
| `price-set-20+13` | `price-13-bold` | `price-20-bold` | `price-13-bold` | 首页标准双列推荐卡价格 |
| `price-set-18+12` | `price-12-bold` | `price-18-bold` | `price-12-bold` | 商品列表、商品卡片价格 |
| `price-set-16+11` | `price-11-bold` | `price-16-bold` | `price-11-bold` | 评价小分项、空间小推荐卡 |

#### 中（15 / 14 / 13）— Bold 700 首选；辅助价格可用 Medium 500

| 整数 + 小数档 | ¥ 符号 Token | 整数 Token | 小数点 + 小数位 Token | 场景 |
|-------------|------------|------------|---------------------|------|
| `price-set-15+11` | `price-11-bold` | `price-15-bold` | `price-11-bold` | 商品小卡片价格 |
| `price-set-14+10` | `price-10-bold` | `price-14-bold` | `price-10-bold` | 紧凑型推荐卡价格 |

---

## 五、引用规则

- **Component 层**通过 `font-semantic.md` 中的语义名称（如 `price-20-bold`）引用，不直接引用本文件原始值
- **向下追踪**：`font-semantic.md` 中的映射值格式为 `Font/Price Font/.{N}-{Weight}`，对应 `font-reference.md` 三、Price Font 章节
- **禁止跨层**：Component 层不得直接写 `font-family: 'MT New Digital Display'; font-size: 20pt`，必须通过语义 Token 引用

### 如何将 Token 转成 CSS

以 `price-20-bold` 为例，在第二章档位表中查到对应的值后，直接写成：

```css
/* price-20-bold */
font-family: '美团新数字体', 'MT New Digital Display', sans-serif;
font-size: 20pt;
line-height: 28pt;
font-weight: 700;
```

**完整价格组（相同大小组合，整数 20 + 小数 20，¥ 降档 18）**：

```css
/* ¥ 符号 — price-18-bold */
.price-symbol {
  font-family: '美团新数字体', 'MT New Digital Display', sans-serif;
  font-size: 18pt;
  line-height: 26pt;
  font-weight: 700;
  margin-right: 1pt; /* ¥ 与整数固定间距 */
}

/* 整数 — price-20-bold */
.price-integer {
  font-family: '美团新数字体', 'MT New Digital Display', sans-serif;
  font-size: 20pt;
  line-height: 28pt;
  font-weight: 700;
  letter-spacing: 0; /* 十位与各位固定 0 间距 */
}

/* 小数点 + 小数位 — price-20-bold（与整数同档） */
.price-decimal {
  font-family: '美团新数字体', 'MT New Digital Display', sans-serif;
  font-size: 20pt;
  line-height: 28pt;
  font-weight: 700;
}
```
