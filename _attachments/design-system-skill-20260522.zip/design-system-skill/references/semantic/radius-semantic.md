# radius-semantic.md

> **规范类型：** Semantic 层规范
> **Token 类型：** Semantic Radius Token
> **使用说明：** 本文件为圆角语义映射层，所有业务需求应直接引用本文件中的语义名称，禁止跨层直接使用 Reference 层的原始 Token（如 `.20pt`）。
> **维护人：** Likaimeng
> **最新版本：** 2026-4-9

---

## 路径解析说明

**读取规则：** 表格中"映射值"列格式为 `Radius/.[Token名]`。Agent 使用时，在 `reference/radius-reference.md` 的 `## 一、Radius` 章节中按名称完全匹配（含 `.` 前缀）找到原始值。

| 映射值前缀 | 对应文件 | 对应章节 |
|-----------|---------|---------|
| `Radius/` | `reference/radius-reference.md` | 一、Radius |

**⚠️ Token 名称必须与 Reference 文件中完全一致（含 `.` 前缀），否则引用无效。**

---

## 一、Radius（圆角）

| 语义名称 | 映射值 | pt 值 | 使用场景描述 |
|--------|--------|-------|------------|
| `radius-xl` | Radius/.20pt | 20pt | 常用于浮层/半页弹窗卡片圆角 |
| `radius-l` | Radius/.18pt | 18pt | 常用于通栏卡片圆角，用于页面通栏分割 |
| `radius-m` | Radius/.12pt | 12pt | 常用于大卡片/推荐卡片的圆角，用于页面卡片分割 |
| `radius-s` | Radius/.8pt | 8pt | 常用于中卡片圆角，用于卡片嵌套组件；**不是通用图片圆角默认值** |
| `radius-xs` | Radius/.6pt | 6pt | 常用于小卡片圆角、展示图片（大于 50pt）、上传图片、输入框的圆角 |
| `radius-xxs` | Radius/.4pt | 4pt | 常用于最小卡片圆角、图片（小于等于 50pt）、标签 |
| `radius-full` | `border-radius: 9999px` | — | 全圆角（胶囊形），用于按钮、搜索框、标签、**头像**等需要完全圆角的场景；不映射固定 pt 档位 |

---

## 图片圆角强制规则

> ⚠️ **图片四个圆角必须完全一致，严禁只设置部分圆角（如 `8px 8px 0 0`）。**

| 图片类型 | 圆角规则 | 示例 CSS |
|---------|---------|--------|
| **头像**（描述中明确为「头像」） | `radius-full`（纯圆形） | `border-radius: 9999px` |
| **非头像图片（显示尺寸 > 50pt）**（商品图、上传图、证件图、较大宫格图等） | `radius-xs`（6pt），**四角一致** | `border-radius: 12px` |
| **非头像图片（显示尺寸 <= 50pt）**（小缩略图、小图标位、小封面等） | `radius-xxs`（4pt），**四角一致** | `border-radius: 8px` |

**禁止写法示例（❌）：**
```css
/* ❌ 只设置上方两角，与卡片底部融合 */
border-radius: 8px 8px 0 0;

/* ❌ 四角不一致 */
border-radius: 8px 4px 8px 4px;
```

**正确写法示例（✅）：**
```css
/* ✅ 大尺寸非头像图片（>50pt）：四角统一 radius-xs */
border-radius: 12px;

/* ✅ 小尺寸非头像图片（<=50pt）：四角统一 radius-xxs */
border-radius: 8px;

/* ✅ 头像：纯圆 */
border-radius: 9999px;
```

---

## 引用规则

- **Component 层** 通过语义名称（如 `radius-m`）引用本层 Token
- **图片默认规则**：非头像图片不得一律套用 `radius-s`；优先遵循组件规范或业务 visual-language，若无特例则按显示尺寸选择：`> 50pt → radius-xs`，`<= 50pt → radius-xxs`
- **向下追踪**：映射值中的 Token 名须与 `radius-reference.md → ## 一、Radius` 完全匹配（含 `.` 前缀）
- **命名原则**：采用 `radius-[尺寸级别]` 的 kebab-case 格式，从 `xxs` 到 `xl` 共 6 档；胶囊全圆角统一用 `radius-full`
- **`radius-full` 特殊说明**：实现值为 `border-radius: 9999px`，确保任意高度下均呈现胶囊形，不使用具体 pt 值
