# color-business.md

> **规范类型：** Semantic 层规范（业务色）
> **Token 类型：** Business Color Token
> **使用说明：** 本文件为业务线专属色彩语义层。所有业务定制色均在此声明，Component 层禁止跨层直接使用原始 Hex 值。渐变色使用 `↘︎`（左上→右下）表示方向，支付业务使用 `↙`（右上→左下）。
> **维护人：** Likaimeng
> **最新版本：** 2026-4-1

---

## 路径解析说明

**读取规则：** 表格中"映射值"列格式为 `Color/Business Color/[业务域]/.[Token名]`。Agent 使用时，根据下方对照表定位业务域，再在 `reference/color-reference.md` 的 `## 四、Business Color` 对应子章节中按名称完全匹配（含 `.` 前缀）找到原始值。

| 业务域 | DPT 前缀 | Reference 子章节 |
|------|---------|----------------|
| 直播特价团 | DPT1 | `### 直播特价团（DPT1）` |
| 商场 | DPT2 | `### 商场（DPT2）` |
| 拼好饭 | DPT3 | `### 拼好饭（DPT3）` |
| 神枪手 | DPT4 | `### 神枪手（DPT4）` |
| 到餐 | DPT5 | `### 到餐（DPT5）` |
| 服务零售 | DPT6 | `### 服务零售（DPT6）` |
| 医药 | DPT7 | `### 医药（DPT7）` |
| 闪购 | DPT8 | `### 闪购（DPT8）` |
| 酒店 | DPT9 | `### 酒店（DPT9）` |
| 交通 | DPT10 | `### 交通（DPT10）` |
| 度假 | DPT11 | `### 度假（DPT11）` |
| 小象超市 | DPT12 | `### 小象超市（DPT12）` |
| 美团公益 | DPT13 | `### 美团公益（DPT13）` |
| 支付 | DPT14 | `### 支付（DPT14）` |

**⚠️ Token 名称必须与 `color-reference.md` 中完全一致（含 `.` 前缀），否则引用无效。**

---

## 一、直播特价团（DPT1）

| 语义名称 | 映射值 | 使用场景描述 |
|--------|--------|------------|
| `dpt1-m1` | Color/Business Color/直播特价团/.dpt1-m1 | 直播业务标签文字色 |
| `dpt1-m2` | Color/Business Color/直播特价团/.dpt1-m2 | 特价团业务标签字色/底色/价格字色/边框/按钮底色等 |
| `dpt1-g-m` | Color/Business Color/直播特价团/.dpt1-g-m | 直播/特价团通用渐变。主 CTA 按钮底色，文字色 `white`；也用于强化用户认知的促销产品、秒杀背景等 |

---

## 二、商场（DPT2）

| 语义名称 | 映射值 | 使用场景描述 |
|--------|--------|------------|
| `dpt2-g-rm` | Color/Business Color/商场/.dpt2-g-rm | 商场优惠权益，用于券包背景色 |

---

## 三、拼好饭（DPT3）

| 语义名称 | 映射值 | 使用场景描述 |
|--------|--------|------------|
| `dpt3-r` | Color/Business Color/拼好饭/.dpt3-r | 常用于常规文字、标签文字、筛选项文字、描边及底 Tab 图标等 |
| `dpt3-g1` | Color/Business Color/拼好饭/.dpt3-g1 | 拼好饭"亮厨商家"业务，常用于文字、标签文字、筛选项文字、描边等 |
| `dpt3-g2` | Color/Business Color/拼好饭/.dpt3-g2 | 拼好饭"美团拼拼鲜厨"业务，常用于文字、标签文字、筛选项文字、描边等 |
| `dpt3-g-r` | Color/Business Color/拼好饭/.dpt3-g-r | 拼好饭主 CTA 按钮底色，文字色 `white`；也用于标签、腰封等背景填充色 |
| `dpt3-g-g1` | Color/Business Color/拼好饭/.dpt3-g-g1 | 拼好饭"亮厨商家"业务，常用于按钮、标签、腰封等背景填充色 |
| `dpt3-g-g2` | Color/Business Color/拼好饭/.dpt3-g-g2 | 拼好饭"美团拼拼鲜厨"业务，常用于按钮、标签、腰封等背景填充色 |

---

## 四、神枪手（DPT4）

| 语义名称 | 映射值 | 使用场景描述 |
|--------|--------|------------|
| `dpt4-b` | Color/Business Color/神枪手/.dpt4-b | 常用于神枪手场域内重要信息强化、点缀等 |
| `dpt4-g-b` | Color/Business Color/神枪手/.dpt4-g-b | 神枪手主 CTA 面性按钮底色，文字色 `white` |

---

## 五、到餐（DPT5）

| 语义名称 | 映射值 | 使用场景描述 |
|--------|--------|------------|
| `dpt5-o1` | Color/Business Color/到餐/.dpt5-o1 | 用户关系标签背景、特殊时/空场景标签背景 |
| `dpt5-o2` | Color/Business Color/到餐/.dpt5-o2 | 用于旗舰店引导约标签背景色 |
| `dpt5-o3` | Color/Business Color/到餐/.dpt5-o3 | 浅标签、大约浅色卡面背景 |
| `dpt5-o4` | Color/Business Color/到餐/.dpt5-o4 | 用于旗舰店深色背景下文字颜色 |
| `dpt5-o5` | Color/Business Color/到餐/.dpt5-o5 | 到餐业务**价格文字色**（`#FF4B10`），用于全局价格、折扣金额等字段；覆盖通用 `red-default`（`#FF2D19`） |
| `dpt5-o6` | Color/Business Color/到餐/.dpt5-o6 | 文字、标签文字、按钮文字 |
| `dpt5-g-yo` | Color/Business Color/到餐/.dpt5-g-yo | 到餐胶囊组合按钮（`capsule-combo`）**左半**底色（次操作，如「加入购物车」），文字色 `white`；见 `component/molecules/bottom-action-bar.md §capsule-combo` |
| `dpt5-g-or` | Color/Business Color/到餐/.dpt5-g-or | 到餐主 CTA 按钮底色，文字色 `white`：独立单按钮场景直接用此色；胶囊组合（`capsule-combo`）时用于**右半**（主操作，如「立即购买」）；也用于强引导促销标签背景、美食首页头部背景；见 `component/molecules/bottom-action-bar.md §capsule-combo` |
| `dpt5-g-p` | Color/Business Color/到餐/.dpt5-g-p | 大约深色卡片背景、深按钮、深标签、复选框 |
| `dpt5-g-o5` | Color/Business Color/到餐/.dpt5-g-o5 | 深标签、浅按钮、复选框 |
| `dpt5-g-o4` | Color/Business Color/到餐/.dpt5-g-o4 | 大约浅色卡片背景 |
| `dpt5-g-o3` | Color/Business Color/到餐/.dpt5-g-o3 | 深标签、浅按钮、复选框 |
| `dpt5-g-o2` | Color/Business Color/到餐/.dpt5-g-o2 | 大约浅色卡片背景 |
| `dpt5-g-o9` | Color/Business Color/到餐/.dpt5-g-o9 | 大约深色卡片背景、深按钮、深标签、复选框 |
| `dpt5-g-o8` | Color/Business Color/到餐/.dpt5-g-o8 | 臻享订的按钮、大面积渲染氛围图头图背景 |
| `dpt5-g-o1` | Color/Business Color/到餐/.dpt5-g-o1 | 用于榜单标签背景（强）|
| `dpt5-g-o6` | Color/Business Color/到餐/.dpt5-g-o6 | 用于旗舰店按钮背景、标签背景 |
| `dpt5-g-o7` | Color/Business Color/到餐/.dpt5-g-o7 | 用于旗舰店按钮、标签的文字颜色 |

---

## 六、服务零售（DPT6）

| 语义名称 | 映射值 | 使用场景描述 |
|--------|--------|------------|
| `dpt6-g1` | Color/Business Color/服务零售/.dpt6-g1 | M 潮标签背景色 |
| `dpt6-g2` | Color/Business Color/服务零售/.dpt6-g2 | M 潮主题色 |
| `dpt6-p1` | Color/Business Color/服务零售/.dpt6-p1 | 酒吧指南标签背景色 |
| `dpt6-p2` | Color/Business Color/服务零售/.dpt6-p2 | 酒吧指南标签文字 |
| `dpt6-o1` | Color/Business Color/服务零售/.dpt6-o1 | 洗浴指南标签文字色 |
| `dpt6-g-y` | Color/Business Color/服务零售/.dpt6-g-y | 安心学标签背景色 |
| `dpt6-g-o` | Color/Business Color/服务零售/.dpt6-g-o | 洗浴指南标签背景色 |
| `dpt6-g-g` | Color/Business Color/服务零售/.dpt6-g-g | M 潮标签背景色 |

---

## 七、医药（DPT7）

| 语义名称 | 映射值 | 使用场景描述 |
|--------|--------|------------|
| `dpt7-t1` | Color/Business Color/医药/.dpt7-t1 | 医疗场景筛选背景色，通知栏、提示条、标签等背景色 |
| `dpt7-t2` | Color/Business Color/医药/.dpt7-t2 | 小面积控件或边框，如筛选边框（描边）或筛选按钮的icon |
| `dpt7-t3` | Color/Business Color/医药/.dpt7-t3 | 医疗场景中文字链接或具有医疗性质的标签，或强调文案等 |
| `dpt7-g-t` | Color/Business Color/医药/.dpt7-g-t | 医药业务主 CTA 面性按钮底色，文字色 `white`（含买药、医疗模块等所有医药场景 |

---

## 八、闪购（DPT8）

| 语义名称 | 映射值 | 使用场景描述 |
|--------|--------|------------|
| `dpt8-r` | Color/Business Color/闪购/.dpt8-r | 神价频道标签文字，Tab 文字，价格文字等 |
| `dpt8-g-r` | Color/Business Color/闪购/.dpt8-g-r | 神价频道的按钮背景色 |
| `dpt8-g-b1` | Color/Business Color/闪购/.dpt8-g-b1 | 冰镇、冷藏等 0 度以上冰品标签背景色 |
| `dpt8-g-b2` | Color/Business Color/闪购/.dpt8-g-b2 | 冷冻等 0 度以下冻货标签背景色 |

---

## 九、酒店（DPT9）

| 语义名称 | 映射值 | 使用场景描述 |
|--------|--------|------------|
| `dpt9-y` | Color/Business Color/酒店/.dpt9-y | 民宿评分标签颜色 |
| `dpt9-b1` | Color/Business Color/酒店/.dpt9-b1 | 浅色卡片底色 |
| `dpt9-b1-a` | Color/Business Color/酒店/.dpt9-b1-a | 浅色卡片底色（50% 透明度） |
| `dpt9-b2` | Color/Business Color/酒店/.dpt9-b2 | 按钮背景色、标签背景色等 |
| `dpt9-b2-a` | Color/Business Color/酒店/.dpt9-b2-a | 按钮背景色、标签背景色等（10% 透明度） |
| `dpt9-b3` | Color/Business Color/酒店/.dpt9-b3 | 常规通知背景色、服务类标签描边色 |
| `dpt9-b3-a` | Color/Business Color/酒店/.dpt9-b3-a | 常规通知背景色、服务类标签描边色（20% 透明度） |
| `dpt9-b4` | Color/Business Color/酒店/.dpt9-b4 | 酒店业务整体主色 |
| `dpt9-g-y` | Color/Business Color/酒店/.dpt9-g-y | 领券订、民宿业务按钮色 |
| `dpt9-g-o` | Color/Business Color/酒店/.dpt9-g-o | 必住榜标签色 |
| `dpt9-g-r` | Color/Business Color/酒店/.dpt9-g-r | 真便宜页面标签、按钮主色 |
| `dpt9-g-b` | Color/Business Color/酒店/.dpt9-g-b | AI 一致性规范用色 |

---

## 十、交通（DPT10）

| 语义名称 | 映射值 | 使用场景描述 |
|--------|--------|------------|
| `dpt10-g` | Color/Business Color/交通/.dpt10-g | 用于浅绿色背景上的文字色，例如交通青年卡 |
| `dpt10-b` | Color/Business Color/交通/.dpt10-b | 用于浅蓝色背景上的文字色，例如商旅出行卡 |
| `dpt10-g-g` | Color/Business Color/交通/.dpt10-g-g | 用于按钮背景色 |

---

## 十一、度假（DPT11）

| 语义名称 | 映射值 | 使用场景描述 |
|--------|--------|------------|
| `dpt11-g1` | Color/Business Color/度假/.dpt11-g1 | 用于标签、卡片浅色背景 |
| `dpt11-g2` | Color/Business Color/度假/.dpt11-g2 | 用于标签、快筛文字色 |
| `dpt11-g-yg` | Color/Business Color/度假/.dpt11-g-yg | 用于卡片背景 |

---

## 十二、小象超市（DPT12）

| 语义名称 | 映射值 | 使用场景描述 |
|--------|--------|------------|
| `dpt12-g` | Color/Business Color/小象超市/.dpt12-g | 小象业务图标及按钮颜色 |

---

## 十三、美团公益（DPT13）

| 语义名称 | 映射值 | 使用场景描述 |
|--------|--------|------------|
| `dpt13-t` | Color/Business Color/美团公益/.dpt13-t | 面性 CTA 按钮底色（青山计划等主按钮），文字色用 `white` 白色 |

---

## 十四、支付（DPT14）

| 语义名称 | 映射值 | 使用场景描述 |
|--------|--------|------------|
| `dpt14-g` | Color/Business Color/支付/.dpt14-g | 标签及描边色，卡片底色 |
| `dpt14-g-g` | Color/Business Color/支付/.dpt14-g-g | 标签颜色（↙ 渐变方向） |

---

## 主 CTA 按钮色速查

> 各业务线主操作按钮（CTA）颜色汇总，生成页面前对照确认，禁止凭感觉选色。

| 业务线 | 主 CTA Token | 按钮文字色 | 常见陷阱 |
|--------|------------|----------|---------|
| 美团平台（DPT0/通用） | `gradient-yellow` | `text-primary`（黑色） | ❌ 不是 `orange-default` |
| 外卖（DPT5） | `gradient-yellow` | `text-primary`（黑色） | ❌ 不是 `orange-default` |
| 闪购（DPT8） | `gradient-yellow` | `text-primary`（黑色） | ❌ 不是 `yellow-default`；Tab 指示线/Logo 背景用 `yellow-default` |
| 金融·支付（DPT14） | `gradient-yellow` | `text-primary`（黑色） | 单选框用 `yellow-default`，与 CTA 渐变黄视觉相近但 token 不同 |
| 酒店旅行（DPT9） | `gradient-yellow` | `text-primary`（黑色） | Tab 选中/评分用蓝色 `blue-default`，CTA 用黄渐变 |
| 团购软硬件（DPT6） | `orange-default` | `white` | 骑行卡次级 CTA 才用 `yellow-default` |
| 直播特价团（DPT1） | `dpt1-g-m` | `white` | 秒杀/促销背景也用此渐变 |
| 拼好饭（DPT3） | `dpt3-g-r` | `white` | ❌ 不用平台通用 `gradient-yellow` |
| 神枪手（DPT4） | `dpt4-g-b` | `white` | — |
| 到餐（DPT5独立场景） | `dpt5-g-or` | `white` | 胶囊组合左半用 `dpt5-g-yo`；❌ 到餐不用 `gradient-yellow` |
| 医药健康·买药（DPT7） | `dpt7-g-t` | `white` | 问诊场景 CTA 用 `green-default`，两者严格隔离 |
| 食杂零售·小象超市（DPT12） | `dpt12-g`（`#00CF22`） | `white` | ❌ 禁止用通用 `green-default`（`#00B300`），两色不同 |
| 美团公益（DPT13） | `dpt13-t`（`#00BABE`） | `white` | — |


---

## 引用规则

- **Component 层** 通过语义名称（如 `dpt9-b4`）引用本层 Token
- **向下追踪**：映射值中的 Token 名（如 `.dpt9-b4`）须与 `color-reference.md → ## 四、Business Color` 对应子章节完全匹配
- **命名原则**：Semantic 层用无 `.` 的小写 kebab-case；Reference 层用带 `.` 前缀的小写 kebab-case，两层通过 `.` 天然区分
- **渐变方向**：`↘︎` 为左上至右下；`↙` 为右上至左下（仅 DPT14 支付使用）
