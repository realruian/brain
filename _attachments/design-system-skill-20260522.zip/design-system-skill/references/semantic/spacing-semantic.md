# spacing-semantic.md

> **规范类型：** Semantic 层规范
> **Token 类型：** Semantic Spacing Token
> **使用说明：** 本文件为间距语义映射层，所有业务需求应直接引用本文件中的语义名称，禁止跨层直接使用 Reference 层的原始 Token（如 `.32pt`）。Token 可应用于 CSS 的 `padding`、`margin`、`gap` 等所有间距属性，命名与具体 CSS 属性解耦。
> **维护人：** Likaimeng
> **最新版本：** 2026-4-9

---

## 间距术语约定

- **外间距**：元素 / 卡片 / 模块之间的距离，对应 CSS `margin`、`gap`
- **内间距**：容器内部内容与边界的距离，对应 CSS `padding`
- **本规范 spacing Token 不区分内/外间距**，Token 按尺度命名，由 Component 层按实际场景自行选择对应的 CSS 属性

---

## 路径解析说明

**读取规则：** 表格中"映射值"列格式为 `Grid Spacing/.[Token名]`。Agent 使用时，在 `reference/spacing-reference.md` 的 `## 一、Grid Spacing` 章节中按名称完全匹配（含 `.` 前缀）找到原始值。

| 映射值前缀 | 对应文件 | 对应章节 |
|-----------|---------|---------|
| `Grid Spacing/` | `reference/spacing-reference.md` | 一、Grid Spacing |

**⚠️ Token 名称必须与 Reference 文件中完全一致（含 `.` 前缀），否则引用无效。**

---

## 一、Spacing（间距）

| 语义名称 | 映射值 | pt 值 | 使用场景描述 |
|--------|--------|-------|------------|
| `spacing-5xl` | Grid Spacing/.32pt | 32pt | 模块超大间距。常用于页面模块和内容较少的布局 |
| `spacing-4xl` | Grid Spacing/.28pt | 28pt | 模块大间距。常用于模块的宽松纵向间距（内容较少的页面），无卡片/通栏内容的纵向间距 |
| `spacing-3xl` | Grid Spacing/.24pt | 24pt | 模块中间距。常用于模块内容的常规纵向间距 |
| `spacing-2xl` | Grid Spacing/.18pt | 18pt | 模块小间距。常用于内容密度大、对屏效要求高的模块间距 |
| `spacing-xl` | Grid Spacing/.16pt | 16pt | 宽松卡片大间距。卡片之间的纵向间距 |
| `spacing-l` | Grid Spacing/.12pt | 12pt | 常规卡片中间距。卡片距离页面边缘的横/纵向间距 |
| `spacing-m` | Grid Spacing/.10pt | 10pt | 常规卡片小间距。卡片之间的纵向间距 |
| `spacing-s` | Grid Spacing/.8pt | 8pt | 紧凑卡片大间距。卡片距离页面边缘的横向间距、卡片之间的横/纵向间距；紧凑通栏大间距：距离页面边缘的横向间距 |
| `spacing-xs` | Grid Spacing/.6pt | 6pt | 紧凑卡片小间距。卡片之间的横/纵向间距；紧凑通栏小间距：卡片中内容之间的横/纵向间距 |
| `spacing-2xs` | Grid Spacing/.4pt | 4pt | 组件内元素大间距。相关但需要一定视觉区分的元素 |
| `spacing-3xs` | Grid Spacing/.2pt | 2pt | 组件内元素小间距。紧密相关的元素，需要视觉上保持一体性 |

---

## 引用规则

- **Component 层** 通过语义名称（如 `spacing-l`）引用本层 Token
- **向下追踪**：映射值中的 Token 名须与 `spacing-reference.md → ## 一、Grid Spacing` 完全匹配（含 `.` 前缀）
- **命名原则**：采用 `spacing-[尺度级别]` 的 kebab-case 格式，从 `3xs`（2pt）到 `5xl`（32pt）共 11 档，按尺度递增排列，不限定使用者
