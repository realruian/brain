# shadow-semantic.md

> **规范类型：** Semantic 层规范
> **Token 类型：** Semantic Shadow Token
> **使用说明：** 本文件为阴影语义映射层，所有业务需求应直接引用本文件中的语义名称，禁止跨层直接使用 Reference 层的原始 Token（如 `.Light`）。阴影用于表达元素的层级关系，层级越高阴影越强。
> **维护人：** Likaimeng
> **最新版本：** 2026-4-1

---

## 路径解析说明

**读取规则：** 表格中"映射值"列格式为 `Shadow/.[Token名]`。Agent 使用时，在 `reference/shadow-reference.md` 的 `## 一、Shadow` 章节中按名称完全匹配（含 `.` 前缀）找到原始值。

| 映射值前缀 | 对应文件 | 对应章节 |
|-----------|---------|---------|
| `Shadow/` | `reference/shadow-reference.md` | 一、Shadow |

**⚠️ Token 名称必须与 Reference 文件中完全一致（含 `.` 前缀），否则引用无效。**

---

## 一、Shadow（阴影）

> ⚠️ **全局约束：一般情况下，不要给筛选器、容器、卡片加任何投影。**
> 投影应仅用于需要明确表达层级关系的浮层类组件（如悬浮入口、Popover、气泡提示等）。
> 筛选器（Filter）、内容容器（Container）、卡片（Card）使用边框或背景色区分层级，不加投影。

| 语义名称 | 映射值 | 使用场景描述 |
|--------|--------|------------|
| `shadow-subtle` | Shadow/.Light | 弱阴影。常用于提升组件元素的识别性和可操作感知，常在扁平风格的页面使用，常用在分段器、开关等组件 |
| `shadow-raised` | Shadow/.Medium | 中阴影。常用于提升组件元素的识别性和可操作感知，也用于提升组件元素的层级，常在扁平风格的页面中使用，常用在悬浮入口、侧边栏等组件上 |
| `shadow-overlay` | Shadow/.Large | 强阴影。常用于提升组件元素的层级，常在已有阴影的页面中使用，常用在容器卡片、气泡 Popover 等组件上 |

---

## 引用规则

- **Component 层** 通过语义名称（如 `shadow-raised`）引用本层 Token
- **向下追踪**：映射值中的 Token 名须与 `shadow-reference.md → ## 一、Shadow` 完全匹配（含 `.` 前缀）
- **命名原则**：采用 `shadow-[层级语义]` 的 kebab-case 格式，以视觉层级由低到高排列：`subtle`（轻感知）→ `raised`（层级提升）→ `overlay`（浮层覆盖）
