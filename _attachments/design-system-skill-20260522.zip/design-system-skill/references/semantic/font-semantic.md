# font-semantic.md

> **规范类型：** Semantic 层规范
> **Token 类型：** Semantic Font Token
> **使用说明：** 本文件为字体语义映射层，所有业务需求应直接引用本文件中的语义名称，禁止跨层直接使用 Reference 层的原始 Token（如 `.42-Semibold`）。
> **维护人：** Likaimeng
> **最新版本：** 2026-4-9

---

## 路径解析说明

**读取规则：** 表格中"映射值"列格式为 `Font/[字族]/.[Token名]`。Agent 使用时，先根据下方对照表定位到对应字族，再在 `reference/font-reference.md` 对应章节中按名称完全匹配（含 `.` 前缀）找到原始值。

| 映射值前缀 | 对应文件 | 对应章节 |
|-----------|---------|---------|
| `Font/Text Font/` | `reference/font-reference.md` | 一、Text Font |
| `Font/Paragraph Font/` | `reference/font-reference.md` | 二、Paragraph Font |
| `Font/Price Font/` | `reference/font-reference.md` | 三、Price Font |
| `Font/Special Font/` | `reference/font-reference.md` | 四、Special Font |

**⚠️ Token 名称必须与 Reference 文件中完全一致（含 `.` 前缀），否则引用无效。**

---

## 一、Text Font（文本字体）

> 字体：苹方 简（iOS）/ 安卓系统字体（Android）
> 适用于界面中所有单行/短文本场景

### Display 展示标题

| 语义名称 | 映射值 | 使用场景描述 |
|--------|--------|------------|
| `display-l-42-semibold` | Font/Text Font/.42-Semibold | 展示标题大号（特殊场景首选） |
| `display-l-42-medium` | Font/Text Font/.42-Medium | 展示标题大号 |
| `display-l-42-regular` | Font/Text Font/.42-Regular | 不常用 |
| `display-m-38-semibold` | Font/Text Font/.38-Semibold | 展示标题中号（特殊场景首选） |
| `display-m-38-medium` | Font/Text Font/.38-Medium | 展示标题中号 |
| `display-m-38-regular` | Font/Text Font/.38-Regular | 不常用 |
| `display-s-32-semibold` | Font/Text Font/.32-Semibold | 展示标题小号（特殊场景首选） |
| `display-s-32-medium` | Font/Text Font/.32-Medium | 展示标题小号 |
| `display-s-32-regular` | Font/Text Font/.32-Regular | 不常用 |

### Headline 大标题

| 语义名称 | 映射值 | 使用场景描述 |
|--------|--------|------------|
| `headline-l-28-semibold` | Font/Text Font/.28-Semibold | 大标题大号（特殊场景首选） |
| `headline-l-28-medium` | Font/Text Font/.28-Medium | 大标题大号 |
| `headline-l-28-regular` | Font/Text Font/.28-Regular | 不常用 |
| `headline-s-24-semibold` | Font/Text Font/.24-Semibold | 大标题小号（特殊场景首选） |
| `headline-s-24-medium` | Font/Text Font/.24-Medium | 大标题小号 |
| `headline-s-24-regular` | Font/Text Font/.24-Regular | 不常用 |

### Title 页面标题

| 语义名称 | 映射值 | 使用场景描述 |
|--------|--------|------------|
| `title-l-22-semibold` | Font/Text Font/.22-Semibold | 页面标题大号（特殊场景首选） |
| `title-l-22-medium` | Font/Text Font/.22-Medium | 页面标题大号 |
| `title-l-22-regular` | Font/Text Font/.22-Regular | 不常用 |
| `title-m-20-semibold` | Font/Text Font/.20-Semibold | 页面标题中号（首选，常用于 POI/Deal 页标题） |
| `title-m-20-medium` | Font/Text Font/.20-Medium | 页面标题中号 |
| `title-m-20-regular` | Font/Text Font/.20-Regular | 不常用 |
| `title-s-18-semibold` | Font/Text Font/.18-Semibold | 页面标题小号（首选，常用于模块/类目/浮层标题） |
| `title-s-18-medium` | Font/Text Font/.18-Medium | 页面标题小号（备选） |
| `title-s-18-regular` | Font/Text Font/.18-Regular | 不常用 |

### Subtitle 卡片标题

| 语义名称 | 映射值 | 使用场景描述 |
|--------|--------|------------|
| `subtitle-l-17-semibold` | Font/Text Font/.17-Semibold | 卡片标题大号（常用于卡片/商品列表标题） |
| `subtitle-l-17-medium` | Font/Text Font/.17-Medium | 卡片标题大号（备选） |
| `subtitle-l-17-regular` | Font/Text Font/.17-Regular | 不常用 |
| `subtitle-m-16-semibold` | Font/Text Font/.16-Semibold | 卡片标题中号（备选） |
| `subtitle-m-16-medium` | Font/Text Font/.16-Medium | 卡片标题中号（首选，常用于卡片/模块/商品详情标题） |
| `subtitle-m-16-regular` | Font/Text Font/.16-Regular | 卡片标题中号（也可常用于消息对话文字） |
| `subtitle-s-15-semibold` | Font/Text Font/.15-Semibold | 卡片标题小号（仅在用户明确要求有屏效要求的卡片/模块，或不需要突出标题的场景） |
| `subtitle-s-15-medium` | Font/Text Font/.15-Medium | 卡片标题小号（备选） |
| `subtitle-s-15-regular` | Font/Text Font/.15-Regular | 卡片标题小号（常用于评价内容、聊天对话文字大小） |

### Body 正文

| 语义名称 | 映射值 | 使用场景描述 |
|--------|--------|------------|
| `body-l-14-semibold` | Font/Text Font/.14-Semibold | 正文大号（常用于双列 Feed 标题） |
| `body-l-14-medium` | Font/Text Font/.14-Medium | 正文大号（首选，常用于不需要突出标题的场景） |
| `body-l-14-regular` | Font/Text Font/.14-Regular | 正文大号（首选，常用于页面/卡片的正文信息） |
| `body-m-13-semibold` | Font/Text Font/.13-Semibold | 不常用 |
| `body-m-13-medium` | Font/Text Font/.13-Medium | 不常用 |
| `body-m-13-regular` | Font/Text Font/.13-Regular | 正文中号（常用于商品详情页描述信息） |
| `body-s-12-semibold` | Font/Text Font/.12-Semibold | 正文小号（可用于图文组合标题，列表辅助信息） |
| `body-s-12-medium` | Font/Text Font/.12-Medium | 正文小号（可用于辅助标题、加粗正文） |
| `body-s-12-regular` | Font/Text Font/.12-Regular | 正文小号（首选，常用于页面辅助/说明信息，也可用于图文宫格图标下的文字） |

### Caption 描述信息

| 语义名称 | 映射值 | 使用场景描述 |
|--------|--------|------------|
| `caption-l-11-semibold` | Font/Text Font/.11-Semibold | 不常用 |
| `caption-l-11-medium` | Font/Text Font/.11-Medium | 描述信息大号（备选） |
| `caption-l-11-regular` | Font/Text Font/.11-Regular | 描述信息大号（常用于辅助信息，也可用于金刚区文字） |
| `caption-s-10-semibold` | Font/Text Font/.10-Semibold | 不常用 |
| `caption-s-10-medium` | Font/Text Font/.10-Medium | 不常用 |
| `caption-s-10-regular` | Font/Text Font/.10-Regular | 描述信息小号（首选，常用于特殊场景辅助信息，也可展示是移动端最小字号） |

---

## 二、Paragraph Font（段落字体）

> 字体：苹方 简（iOS）/ 安卓系统字体（Android）
> 适用于多行正文/段落阅读场景，行高比 Text Font 更大

| 语义名称 | 映射值 | 使用场景描述 |
|--------|--------|------------|
| `para-subtitle-m-16-semibold` | Font/Paragraph Font/.16-Semibold | 不常用 |
| `para-subtitle-m-16-medium` | Font/Paragraph Font/.16-Medium | 不常用 |
| `para-subtitle-m-16-regular` | Font/Paragraph Font/.16-Regular | 不常用 |
| `para-subtitle-s-15-semibold` | Font/Paragraph Font/.15-Semibold | 不常用 |
| `para-subtitle-s-15-medium` | Font/Paragraph Font/.15-Medium | 卡片标题小号（常用于商家/商品多行评价文字段落的加粗样式） |
| `para-subtitle-s-15-regular` | Font/Paragraph Font/.15-Regular | 卡片标题小号（常用于商家/商品多行评价文字段落、输入框文字段落） |
| `para-body-l-14-semibold` | Font/Paragraph Font/.14-Semibold | 不常用 |
| `para-body-l-14-medium` | Font/Paragraph Font/.14-Medium | 正文大号（常用于商家/商品多行评价文字段落的加粗样式） |
| `para-body-l-14-regular` | Font/Paragraph Font/.14-Regular | 正文大号（常用于商家/商品多行评价文字段落，AI 生成搜索卡片） |
| `para-body-m-13-semibold` | Font/Paragraph Font/.13-Semibold | 不常用 |
| `para-body-m-13-medium` | Font/Paragraph Font/.13-Medium | 不常用 |
| `para-body-m-13-regular` | Font/Paragraph Font/.13-Regular | 正文中号（常用于多行评价文字段落） |
| `para-body-s-12-semibold` | Font/Paragraph Font/.12-Semibold | 不常用 |
| `para-body-s-12-medium` | Font/Paragraph Font/.12-Medium | 不常用 |
| `para-body-s-12-regular` | Font/Paragraph Font/.12-Regular | 正文小号（常用于更小字号的多行评价文字段落，也可用于多行副标题） |
| `para-caption-l-11-semibold` | Font/Paragraph Font/.11-Semibold | 不常用 |
| `para-caption-l-11-medium` | Font/Paragraph Font/.11-Medium | 不常用 |
| `para-caption-l-11-regular` | Font/Paragraph Font/.11-Regular | 描述信息大号（常用于多行条件描述） |
| `para-caption-s-10-semibold` | Font/Paragraph Font/.10-Semibold | 不常用 |
| `para-caption-s-10-medium` | Font/Paragraph Font/.10-Medium | 不常用 |
| `para-caption-s-10-regular` | Font/Paragraph Font/.10-Regular | 不常用 |

---

## 三、Price Font（价格字体）

> 字体：美团新数字体（iOS / Android 一致）
> 专用于价格/数字场景，禁止用于普通文字

| 语义名称 | 映射值 | 使用场景描述 |
|--------|--------|------------|
| `price-30-bold` | Font/Price Font/.30-Bold | 首选，常用于履约配送时间、评价总体评分 |
| `price-30-medium` | Font/Price Font/.30-Medium | 不常用 |
| `price-30-regular` | Font/Price Font/.30-Regular | 不常用 |
| `price-26-bold` | Font/Price Font/.26-Bold | 首选，常用于商详页主价格信息 |
| `price-26-medium` | Font/Price Font/.26-Medium | 不常用 |
| `price-26-regular` | Font/Price Font/.26-Regular | 不常用 |
| `price-24-bold` | Font/Price Font/.24-Bold | 首选，可用于商品列表、商品卡片中的价格信息 |
| `price-24-medium` | Font/Price Font/.24-Medium | 不常用 |
| `price-24-regular` | Font/Price Font/.24-Regular | 不常用 |
| `price-22-bold` | Font/Price Font/.22-Bold | 备选，可用于商品列表、商品卡片中的价格信息 |
| `price-22-medium` | Font/Price Font/.22-Medium | 不常用 |
| `price-22-regular` | Font/Price Font/.22-Regular | 不常用 |
| `price-20-bold` | Font/Price Font/.20-Bold | 首选，常用于首页标准双列推荐卡价格 |
| `price-20-medium` | Font/Price Font/.20-Medium | 不常用 |
| `price-20-regular` | Font/Price Font/.20-Regular | 不常用 |
| `price-18-bold` | Font/Price Font/.18-Bold | 首选，常用于商品列表、商品卡片中的价格信息，也可用于双列推荐卡价格 |
| `price-18-medium` | Font/Price Font/.18-Medium | 不常用 |
| `price-18-regular` | Font/Price Font/.18-Regular | 不常用 |
| `price-16-bold` | Font/Price Font/.16-Bold | 首选，常用于评价小分项，也可用于空间小、推荐卡价格 |
| `price-16-medium` | Font/Price Font/.16-Medium | 备选 |
| `price-16-regular` | Font/Price Font/.16-Regular | 不常用 |
| `price-15-bold` | Font/Price Font/.15-Bold | 首选，可用于商品列表、商品小卡片中的价格信息 |
| `price-15-medium` | Font/Price Font/.15-Medium | 备选 |
| `price-15-regular` | Font/Price Font/.15-Regular | 不常用 |
| `price-14-bold` | Font/Price Font/.14-Bold | 首选，可用于紧凑型推荐卡价格 |
| `price-14-medium` | Font/Price Font/.14-Medium | 备选 |
| `price-14-regular` | Font/Price Font/.14-Regular | 不常用 |
| `price-13-bold` | Font/Price Font/.13-Bold | 首选，常用于当价格信息为非当前页面中主要内容时 |
| `price-13-medium` | Font/Price Font/.13-Medium | 备选 |
| `price-13-regular` | Font/Price Font/.13-Regular | 不常用 |
| `price-12-bold` | Font/Price Font/.12-Bold | 不常用 |
| `price-12-medium` | Font/Price Font/.12-Medium | 首选，常用于当价格信息为非当前页面中主要内容时 |
| `price-12-regular` | Font/Price Font/.12-Regular | 不常用 |
| `price-11-bold` | Font/Price Font/.11-Bold | 不常用 |
| `price-11-medium` | Font/Price Font/.11-Medium | 首选，常用于空间小，当价格信息为非当前页面中主要内容时 |
| `price-11-regular` | Font/Price Font/.11-Regular | 备选 |
| `price-10-bold` | Font/Price Font/.10-Bold | 不常用 |
| `price-10-medium` | Font/Price Font/.10-Medium | 首选，常用于空间很紧凑，当价格信息为非当前页面中主要内容时 |
| `price-10-regular` | Font/Price Font/.10-Regular | 备选 |

---

## 四、Special Font（特殊字体）

> 字体：美团体（iOS / Android 一致）
> 仅用于品牌特殊展示场景，不可滥用

| 语义名称 | 映射值 | 使用场景描述 |
|--------|--------|------------|
| `special-title` | Font/Special Font/.20-Regular-美团体 | 品牌特殊标题。仅用于美团体特殊展示场景，如品牌活动主标题 |

---

## 引用规则

- **Component 层** 通过语义名称（如 `title-m-20-semibold`）引用本层 Token
- **向下追踪**：映射值中的 Token 名须与 `font-reference.md` 对应章节完全匹配（含 `.` 前缀）
- **命名原则**：Semantic 层用无 `.` 的小写 kebab-case；Reference 层用带 `.` 前缀的原始名称
- **禁止跨层**：Component 层不得直接引用 `Font/Text Font/.16-Semibold` 等原始路径
