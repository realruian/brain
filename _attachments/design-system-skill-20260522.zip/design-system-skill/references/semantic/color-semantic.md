# color-semantic.md

> **规范类型：** Semantic 层规范
> **Token 类型：** Semantic Color Token
> **使用说明：** 本文件为语义色彩映射层，所有业务需求应直接引用本文件中的语义名称，禁止跨层直接使用 Reference 层的原始值（如 #111111）。
> **维护人：** Likaimeng
> **最新版本：** 2026-4-1

---

## 路径解析说明

**读取规则：** 表格中"映射值"列格式为 `大类/子类/.Token名`。Agent 使用时，必须先根据下方对照表定位到对应的 Reference 文件，再在该文件中按名称完全匹配（含 `.` 前缀）找到原始值。Reference 文件路径和分类的对应关系只在此处声明一次，表格中不重复标注。

| 映射值前缀 | 对应文件 | 对应章节 |
|-----------|---------|---------|
| `Color/Neutral/` | `reference/color-reference.md` | 一、Neutral Color |
| `Color/Functional Color/` | `reference/color-reference.md` | 二、Functional Color |
| `Color/Gradient Color/` | `reference/color-reference.md` | 三、Gradient Color |

**⚠️ Token 名称必须与 Reference 文件中完全一致（含 `.` 前缀），否则引用无效。**

---

## 一、Neutral Color

| 语义名称 | 映射值 | 使用场景描述 |
|--------|--------|------------|
| `white` | Color/Neutral/.White | 纯白色，用于白色背景、白色文字、白色图标等 |

---

## 二、Text Color

| 语义名称 | 映射值 | 使用场景描述 |
|--------|--------|------------|
| `text-primary` | Color/Neutral/.Grey-1 | 一级文字色。常用于标题、主要文案、主按钮文字等（默认首选，所有场景优先使用） |
| `text-secondary` | Color/Neutral/.Grey-2 | 二级文字色。常用于副标题、次要文案等 |
| `text-tertiary` | Color/Neutral/.Grey-3 | 三级文字色。常用于主要辅助信息和说明文字等 |
| `text-quaternary` | Color/Neutral/.Grey-4 | 四级文字色。常用于次要辅助信息和说明文字等 |
| `text-disabled` | Color/Neutral/.Grey-5 | 置灰文字色，用于禁用态文字 |
| `text-primary-alpha` | Color/Neutral/.Black-Opacity-93 | 一级文字色（仅在用户明确要求透明度时使用） |
| `text-secondary-alpha` | Color/Neutral/.Black-Opacity-67 | 二级文字色（仅在用户明确要求透明度时使用） |
| `text-tertiary-alpha` | Color/Neutral/.Black-Opacity-47 | 三级文字色（仅在用户明确要求透明度时使用） |
| `text-quaternary-alpha` | Color/Neutral/.Black-Opacity-40 | 四级文字色（仅在用户明确要求透明度时使用） |
| `text-disabled-alpha` | Color/Neutral/.Black-Opacity-24 | 置灰文字色（仅在用户明确要求透明度时使用） |

---

## 三、Background Color

> ✅ **页面默认背景色**：生成手机页面时，页面根容器背景色**必须**使用 `bg-page`（`#F5F5F5`），无需用户声明，直接应用。
> 卡片、导航等纯白承载面统一使用 `white`（`#FFFFFF`）；`bg-surface` 仅用于组件内部次级背景和轻层次区分。
>
> **金刚区 → 内容列表过渡渐变规则**：
> 当页面顶部为金刚图标区（白色背景 `#FFFFFF`），下方接内容列表区（`bg-page` `#F5F5F5`）时，两区之间需插入一个渐变过渡条，实现自然衔接：
> ```html
> <!-- 白色→F5 渐变过渡条，置于金刚区底部/内容区顶部之间 -->
> <!-- ⚠️ mix-blend-mode:pass-through 为 Figma 私有属性，HTML 中必须删除，不写该属性 -->
> <div style="height:40px; background:linear-gradient(180deg, #FFFFFF 0%, rgba(245,245,245,0) 100%);"></div>
> ```
> 高度可根据视觉效果在 32px～48px 之间调整。金刚区本身背景色为 `white`（`#FFFFFF`），内容区为 `bg-page`（`#F5F5F5`）。

| 语义名称 | 映射值 | 使用场景描述 |
|--------|--------|------------|
| `bg-page` | Color/Neutral/.Grey-9 | 页面级背景色（**默认页面背景，#F5F5F5**） |
| `bg-fill-tertiary` | Color/Neutral/.Grey-9 | `bg-page` 的别名，等同于 `#F5F5F5`；用于组件内部灰色填充背景（如分段型 Tabs 容器背景、模块型 Tabs 背景）；与 `bg-page` 映射值完全相同，引用哪个均可 |
| `bg-surface` | Color/Neutral/.Grey-10 | 组件内次级背景色（**#F7F7F7**），用于轻层次区分、内嵌容器、弱底色区域；❌ 不再作为默认白卡片/导航背景，纯白承载面统一使用 `white`；注意：`unselected-white` 场景下的筛选按钮背景亦引用此 Token |
| `bg-subtle` | Color/Neutral/.Grey-11 | 最轻量背景，用于极细微的层次区分（`#FAFAFA`） |
| `bg-overlay-light` | Color/Neutral/.Black-Opacity-4 | 轻叠加背景（透明），用于悬停、选中等状态 |
| `bg-overlay-lighter` | Color/Neutral/.Black-Opacity-3 | 更轻叠加背景（透明） |
| `bg-overlay-lightest` | Color/Neutral/.Black-Opacity-2 | 最轻叠加背景（透明） |
| `bg-overlay-dark` | Color/Neutral/.Black-Opacity-40 | 深色半透明叠加背景（`rgba(0,0,0,0.4)`），用于分段型 Tabs 深色模式容器背景（叠加在图片/沉浸式背景上） |
| `bg-disabled` | Color/Neutral/.Grey-8 | 禁用态填充背景色，用于面性按钮禁用态 |
| `bg-fill-brand-light` | Color/Functional Color/.Yellow-1 | 品牌色浅填充背景（`#FFFADB`），用于筛选按钮弱/中/多选中态背景 |

---

## 四、Stroke Color

| 语义名称 | 映射值 | 使用场景描述 |
|--------|--------|------------|
| `stroke-disabled` | Color/Neutral/.Grey-6 | 禁用态描边色，用于线性按钮禁用态边框 |
| `stroke-strong` | Color/Neutral/.Grey-6 | 强描边，用于输入框、强调边框等 |
| `stroke-default` | Color/Neutral/.Grey-7 | 默认描边，用于卡片、列表等常规边框 |
| `stroke-strong-alpha` | Color/Neutral/.Black-Opacity-20 | 强描边透明版（仅在用户明确要求透明度时使用） |
| `stroke-default-alpha` | Color/Neutral/.Black-Opacity-10 | 默认描边透明版（仅在用户明确要求透明度时使用） |
| `stroke-brand` | Color/Functional Color/.Yellow-3 | 品牌色描边（`#FFDD00`），用于筛选按钮中/多选中态 0.5pt 边框 |

---

## 五、Divider Color

| 语义名称 | 映射值 | 使用场景描述 |
|--------|--------|------------|
| `divider-primary` | Color/Neutral/.Black-Opacity-10 | 主分割线（透明），适用于浅色背景 |
| `divider-primary-dark` | Color/Neutral/.White-Opacity-30 | 主分割线，适用于深色背景 |
| `divider-secondary` | Color/Neutral/.Black-Opacity-6 | **默认**分割线（透明），适用于浅色背景；组件内分割线默认使用此色 |
| `divider-secondary-dark` | Color/Neutral/.White-Opacity-15 | **默认**分割线，适用于深色背景 |
| `divider-primary-solid` | Color/Neutral/.Grey-7 | 主分割线（实色），适用于浅色背景 |
| `divider-primary-solid-dark` | Color/Neutral/.Grey-7-Dark | 主分割线实色，适用于深色背景 |
| `divider-secondary-solid` | Color/Neutral/.Grey-8 | 次分割线（实色），适用于浅色背景 |
| `divider-secondary-solid-dark` | Color/Neutral/.Grey-8-Dark | 次分割线实色，适用于深色背景 |

---

## 六、Mask Color

| 语义名称 | 映射值 | 使用场景描述 |
|--------|--------|------------|
| `mask-thin` | Color/Neutral/.Black-Opacity-4 | 极薄遮罩，用于悬停态、轻交互反馈 |
| `mask-thinner` | Color/Neutral/.Black-Opacity-3 | 更薄遮罩 |
| `mask-thinnest` | Color/Neutral/.Black-Opacity-2 | 最薄遮罩 |
| `mask-light` | Color/Neutral/.Black-Opacity-40 | 轻遮罩，用于侧边栏、抽屉等半遮挡场景 |
| `mask-default` | Color/Neutral/.Black-Opacity-60 | 默认遮罩，用于底部弹窗、对话框 |
| `mask-heavy` | Color/Neutral/.Black-Opacity-80 | 重遮罩，用于全屏弹窗、强引导场景 |

---

## 七、Functional Color

| 语义名称 | 映射值 | 使用场景描述 |
|--------|--------|------------|
| `yellow-bg` | Color/Functional Color/.Yellow-1 | 黄色浅背景，用于标签、提示背景 |
| `yellow-bg-secondary` | Color/Functional Color/.Yellow-2 | 黄色深背景，也用于描边色 |
| `yellow-default` | Color/Functional Color/.Yellow-3 | 黄色主色，用于警告、强调 |
| `yellow-text` | Color/Functional Color/.Yellow-4 | 黄色场景专用文字色 |
| `red-bg` | Color/Functional Color/.Red-1 | 红色浅背景，用于错误提示背景 |
| `red-bg-secondary` | Color/Functional Color/.Red-2 | 红色深背景，也用于描边色 |
| `red-default` | Color/Functional Color/.Red-4 | 红色主色，用于错误、删除、危险操作 |
| `red-text` | Color/Functional Color/.Red-5 | 红色场景专用文字色 |
| `orange-bg` | Color/Functional Color/.Orange-1 | 橙色浅背景 |
| `orange-bg-secondary` | Color/Functional Color/.Orange-2 | 橙色深背景，也用于描边色 |
| `orange-default` | Color/Functional Color/.Orange-4 | 橙色主色，用于警告、促销标签 |
| `orange-text` | Color/Functional Color/.Orange-5 | 橙色场景专用文字色 |
| `green-bg` | Color/Functional Color/.Green-1 | 绿色浅背景，用于成功提示背景 |
| `green-bg-secondary` | Color/Functional Color/.Green-2 | 绿色深背景，也用于描边色 |
| `green-default` | Color/Functional Color/.Green-4 | 绿色主色，用于成功、完成、通过等正向状态 |
| `green-text` | Color/Functional Color/.Green-5 | 绿色场景专用文字色 |
| `blue-bg` | Color/Functional Color/.Blue-1 | 蓝色浅背景，用于信息提示背景 |
| `blue-bg-secondary` | Color/Functional Color/.Blue-2 | 蓝色深背景，也用于描边色 |
| `blue-default` | Color/Functional Color/.Blue-4 | 蓝色主色，用于信息、链接、操作引导 |
| `blue-text` | Color/Functional Color/.Blue-5 | 蓝色场景专用文字色 |
| `purple-bg` | Color/Functional Color/.Purple-1 | 紫色浅背景 |
| `purple-bg-secondary` | Color/Functional Color/.Purple-2 | 紫色深背景，也用于描边色 |
| `purple-default` | Color/Functional Color/.Purple-4 | 紫色主色 |
| `purple-text` | Color/Functional Color/.Purple-5 | 紫色场景专用文字色 |
| `red-backup` | Color/Functional Color/.Red-3 | 红色备用色 |
| `orange-backup` | Color/Functional Color/.Orange-3 | 橙色备用色 |
| `green-backup` | Color/Functional Color/.Green-3 | 绿色备用色 |
| `blue-backup` | Color/Functional Color/.Blue-3 | 蓝色备用色 |
| `purple-backup` | Color/Functional Color/.Purple-3 | 紫色备用色 |

---

## 七、Brand Color

> 品牌色 Token，供需要明确区分「美团黄」和「强调橙」的组件使用。这两个 Token 也常被组件文档以 `color-brand` / `color-brand-emphasis` 形式引用，与本章节含义完全一致。

| 语义名称 | 映射值 | 使用场景描述 |
|--------|--------|------------|
| `color-brand` | Color/Functional Color/.Yellow-3 | 美团品牌黄（`#FFDD00`），用于 Tabs 指示器、选中状态高亮等品牌色场景 |
| `color-brand-emphasis` | Color/Functional Color/.Orange-4 | 品牌强调橙（`#FF7700`），用于筛选器选中文字、文字筛选选中态等强调品牌色场景 |
| `text-on-brand` | Color/Neutral/.White | 品牌色背景上的文字（`#FFFFFF`），用于深色/彩色背景上的文字 |

---

## 八、Gradient Color

> **渐变方向规则**（所有渐变均适用）：
> - 默认方向：从元素**左上角 → 右下角**（CSS 写法：`to bottom right`），浅色在左上、深色在右下。
> - ⚠️ **禁止固定为 45°（或 135°）角度值**——固定角度会导致长按钮与短按钮的渐变视觉效果不一致；必须使用方向关键字 `to bottom right`，确保渐变始终贴合元素自身尺寸自动适配。
> - **例外：支付（DPT14）** 方向相反，从元素**右上角 → 左下角**（CSS 写法：`to bottom left`），浅色在右上、深色在左下。
> - 详细规则见 `reference/color-reference.md` §三 Gradient Color。

| 语义名称 | 映射值 | CSS 方向 | 使用场景描述 |
|--------|--------|---------|------------|
| `gradient-yellow` | Color/Gradient Color/.Gradient-Yellow | `to bottom right` | 黄色渐变，用于美团平台、外卖（DPT5）、闪购（DPT8）、金融（DPT14）主 CTA 按钮底色；也用于黄色系促销、活动背景。按钮完整 CSS 见 `component/molecules/button.md §8` |
| `gradient-red` | Color/Gradient Color/.Gradient-Red | `to bottom right` | 红色渐变，用于红色系促销、活动背景 |
| `gradient-orange` | Color/Gradient Color/.Gradient-Orange | `to bottom right` | 橙色渐变，用于橙色系促销、活动背景 |
| `gradient-green` | Color/Gradient Color/.Gradient-Green | `to bottom right` | 绿色渐变，用于绿色系活动背景 |
| `gradient-blue` | Color/Gradient Color/.Gradient-Blue | `to bottom right` | 蓝色渐变，用于蓝色系活动背景 |
| `gradient-purple` | Color/Gradient Color/.Gradient-Purple | `to bottom right` | 紫色渐变，用于紫色系活动背景 |
