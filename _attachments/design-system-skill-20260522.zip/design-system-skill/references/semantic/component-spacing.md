# component-spacing.md

> **规范类型：** Semantic 层规范
> **Token 类型：** Component Spacing Token
> **适用范围：** ⚠️ **仅用于组件内部间距**（padding、gap、icon 间距等）。页面级、模块级、卡片级间距请使用 `spacing-semantic.md`。
> **使用说明：** 本文件为组件内部间距的补充档位层。`spacing-semantic.md` 基于 Grid 步进，无法覆盖组件内部的细粒度间距需求（如按钮 padding、标签内边距等）。组件规范中出现的精确约束值，统一从本文件引用，不再使用裸 pt 数值。
> **维护人：** likaimeng
> **最新版本：** 2026-04-09

---

## 使用边界说明

| 场景 | 使用的文件 |
|------|----------|
| 页面模块间距、卡片间距、内容区 padding | `spacing-semantic.md` |
| 组件内部 padding、icon 与文字 gap、组件内行高辅助间距 | **本文件** `component-spacing.md` |

> ❌ **禁止**在页面级布局中引用本文件的 Token。
> ❌ **禁止**在组件内部间距中直接写裸 pt 数值，统一引用本文件或 `spacing-semantic.md`。

---

## 一、Component Spacing（组件内间距档位）

> 档位命名规则：`cs-{N}`，N 为对应的 pt 值（@1x 逻辑像素）。
> 覆盖范围：0.5pt 至 30pt，按需引用，不强制全部使用。

| Token 名称 | 值 | 备注 |
|-----------|-----|------|
| `cs-0.5`  | 0.5pt | 极细分隔、描边偏移 |
| `cs-1`    | 1pt   | 最小视觉单元 |
| `cs-1.5`  | 1.5pt | — |
| `cs-2`    | 2pt   | — |
| `cs-2.5`  | 2.5pt | Popover 多行文字行间距 |
| `cs-3`    | 3pt   | Tag compact/standard 圆角；Bottom Navigation 推荐态胶囊上内边距 |
| `cs-3.5`  | 3.5pt | — |
| `cs-4`    | 4pt   | 常用小 gap（同 spacing-2xs） |
| `cs-4.5`  | 4.5pt | — |
| `cs-5`    | 5pt   | Tag 内边距；Time-Date Picker 选项上下内边距；Bottom Navigation 推荐态胶囊下内边距 |
| `cs-5.5`  | 5.5pt | — |
| `cs-6`    | 6pt   | Tag 内边距（有箭头） |
| `cs-6.5`  | 6.5pt | — |
| `cs-7`    | 7pt   | Button m 上下内边距；Filter Panel 选项上下内边距（宽松/标准）；Bottom Navigation 回顶部胶囊下内边距 |
| `cs-7.5`  | 7.5pt | — |
| `cs-8`    | 8pt   | 常用中 gap（同 spacing-s） |
| `cs-8.5`  | 8.5pt | — |
| `cs-9`    | 9pt   | Button l 上下内边距；Bottom Navigation 胶囊左右内边距（推荐态/回顶部）；Filter Panel 底部操作按钮上下内边距 |
| `cs-9.5`  | 9.5pt | — |
| `cs-10`   | 10pt  | Tag 内边距；Button xxs 水平内边距 |
| `cs-10.5` | 10.5pt | — |
| `cs-11`   | 11pt  | — |
| `cs-11.5` | 11.5pt | — |
| `cs-12`   | 12pt  | Button xs 水平内边距 |
| `cs-12.5` | 12.5pt | — |
| `cs-13`   | 13pt  | Button xl 上下内边距 |
| `cs-13.5` | 13.5pt | — |
| `cs-14`   | 14pt  | Text Edit Menu 操作区左右内边距；文本型项间距 |
| `cs-14.5` | 14.5pt | — |
| `cs-15`   | 15pt  | Button m/s 水平内边距；Time-Date Picker 标题区上下内边距 |
| `cs-15.5` | 15.5pt | — |
| `cs-16`   | 16pt  | — |
| `cs-17`   | 17pt  | — |
| `cs-18`   | 18pt  | Floating Button 组合型按钮间距 |
| `cs-19`   | 19pt  | — |
| `cs-20`   | 20pt  | Button l 水平内边距（同 spacing-m）；Filter Panel 选项间距 / 模块间距（实际引用时优先用 `spacing-m`） |
| `cs-21`   | 21pt  | — |
| `cs-22`   | 22pt  | — |
| `cs-23`   | 23pt  | Filter Panel 面板内容底部内边距（无底部按钮） |
| `cs-24`   | 24pt  | Button xl 水平内边距；Filter Panel 底部操作按钮左右内边距 |
| `cs-25`   | 25pt  | — |
| `cs-26`   | 26pt  | — |
| `cs-27`   | 27pt  | — |
| `cs-28`   | 28pt  | Text Edit Menu 图标文本型项间距 |
| `cs-29`   | 29pt  | — |
| `cs-30`   | 30pt  | — |

> **说明**：「备注」列仅标注当前已在组件规范中实际使用的值，其余档位预留备用。待所有组件规范完成后统一清理未使用的档位。

---

## 引用规则

- **Component 层**（`references/component/`）通过 `cs-{N}` 名称引用本层 Token
- **不得**在 Template 层、页面描述中引用本文件 Token
- 若组件间距恰好与 `spacing-semantic.md` 中某档位数值相同（如 `cs-24` = `spacing-3xl` = 24pt），**优先引用 `spacing-semantic.md`**，本文件仅用于覆盖 spacing-semantic 未涉及的值
