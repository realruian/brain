# list.md — List 列表 - 组件规范

> **组件分类**：Molecule（分子级组件）
> **定义**：列表行（List）是列表页面的基础信息单元，由可选前缀区（图标/图片/序号）、内容区（主标题 + 可选标题徽标 + 可选副标题）和可选后缀区（操作/元信息/箭头）四段式组合构成。多个列表行垂直堆叠形成列表容器。
> **Style 依赖**：`color-semantic.md` · `font-semantic.md` · `spacing-semantic.md` · `component-spacing.md` · `radius-semantic.md` · `stroke-semantic.md`

---

## 0. 图标 / 间距 / Ownership 约束

- **icon-route（默认）**：List 内功能图标默认回 `component/atoms/icon.md`，并沿用正文规定的 iconfont class / weight。
- **fixed-asset 例外**：若正文位点要求官方 SVG、PNG/CDN 切图或 `assets/*.svg`，该位点必须走固定资产并记录 `icon-route=fixed-asset`。
- **spacing-owner（List 自持）**：行高、行内 padding、`prefix / content / title-badge / suffix` 四段式布局及槽位间距归 List。
- **宿主裁决（优先级）**：`suffix` / `title-badge` 内嵌 `badge` / `tag` / `switch` 时，子组件只拥有内部样式，锚点位置与槽位间距归 List。
- **不可跳步**：先回 `references/INDEX.md` 完成区域路由与宿主锁定，再用 `component-quickref.md` 做宿主级收敛；本文件仅承接组件内 ownership 细则，不承担前置路由改判；不得凭语义猜测。


## 1. 组件类型（type）

type 只描述**内容层级和行高**，与前缀/后缀 slot 内容正交，可自由组合。

| type | 名称 | 高度 | 适用场景 |
|------|------|------|----------|
| `single-line-s` | 单行小号 | 50pt | 仅有主标题，内容单一紧凑（如设置项、菜单项） |
| `single-line-l` | 单行大号 | 56pt | 主标题 + 右侧元信息或描述，内容稍丰富 |
| `double-line-s` | 双行小号 | 66pt | 主标题 + 副标题，无图或带小图标 |
| `double-line-l` | 双行大号 | 76pt | 主标题 + 副标题，带图片/头像等较大前缀 |
| `message` | 消息列表型 | 72pt | 主标题 + 消息预览 + 右侧时间/徽标，用于 IM/通知场景 |

> **不可自定义高度**：列表行高度由内容层级决定，不可任意调整，必须从上表选取。

### 大号（l）与小号（s）选择规则

> **优先用大号**：页面空间宽松、信息密度低、需要呼吸感时（如「我的」主页、品牌频道、内容详情入口），默认选 `l`。
>
> **改用小号**：页面空间紧凑、条目数量多、需要一屏展示更多内容时（如设置项列表、选择器弹窗、筛选面板、多级菜单），改用 `s`。
>
> **同一列表内不混用大小号**：同一个列表容器内所有行必须使用同一 `type`，不可大小号混排。

---

## 2. 四段式结构（slot）

列表行采用四段式横向布局：

```
[ prefix-slot ] [ content-slot [ title-badge-slot ] ] [ suffix-slot ]
```

> `title-badge` 是 `content` 内部的内嵌 slot，紧跟主标题文字右侧，不独立占据一列。

| slot | 名称 | 是否必须 | 说明 |
|------|------|----------|------|
| `prefix` | 前缀区 | 否 | 见下方§4，位于行最左侧，可填入图标、图片、头像、序号等；与 type 正交组合 |
| `content` | 内容区 | 是 | 主标题 + 可选 title-badge + 可选副标题；flex:1 撑满剩余宽度 |
| `title-badge` | 标题徽标区 | 否 | 内嵌于 content 内、紧跟主标题右侧，用于标签、红点、New 标记等；见下方§4.2 |
| `suffix` | 后缀区 | 否 | 位于行最右侧，默认为向右箭头；可替换为开关、徽标、辅助文字、操作按钮等；右对齐 |

---

## 3. 内容区层级（content）

### 主标题

| type | 字体 Token（**默认**） | 字体 Token（可选 medium，仅在需要突出层级时） | 字体 Token（强化，需强调时） | 颜色 Token |
|------|-----------------|--------------------------------|---------------------------|-----------|
| `single-line-l` / `double-line-l` | `subtitle-m-16-regular` ✅ 默认 | `subtitle-m-16-medium` | `subtitle-m-16-semibold` | `text-primary`（`#111111`） |
| `single-line-s` / `double-line-s` | `body-l-14-regular` ✅ 默认 | `body-l-14-medium` | `body-l-14-semibold` | `text-primary`（`#111111`） |

> ⚠️ **主标题默认字重为 Regular**；Medium 仅在设计需要突出信息层级时可选；未经用户/设计师明确指定时，❌ 禁止擅自升级为 Medium 或 Semibold。

**主标题截断规则**：

| 场景 | 处理方式 | 行高变化 |
|------|---------|--------|
| 标题 ≤15字，单行可容纳 | 单行显示，`…` 截断超出部分 | 不变 |
| 标题 >15字，超出单行 | 折行，最多 **2 行**；第 2 行超出部分用 `…` 截断 | 行高按实际内容撑高 |

> 主标题为必填项；❌ 禁止超过 2 行，第 2 行末尾必须截断。

### 副标题（双行类型专有）

| type | 字体 Token | 颜色 Token | 与主标题间距 | 对齐 |
|------|-----------|-----------|------------|------|
| `double-line-l` | `body-l-14-regular` | `text-tertiary`（`#888888`）；需进一步弱化时可用 `text-quaternary`（`#999999`） | `spacing-2xs`（4pt） | 左对齐 |
| `double-line-s` | `body-s-12-regular` | `text-tertiary`（`#888888`）；需进一步弱化时可用 `text-quaternary`（`#999999`） | `spacing-2xs`（4pt） | 左对齐 |

> 副标题默认 1 行，超出用 `…` 截断；当业务需要时可配置最多 **2 行**，第 2 行末尾截断。折行时行高随内容自然撑高，不可超过 2 行。

### 右侧信息（suffix 默认内容）

默认展示「向右」箭头图标，`l` 和 `s` 规格一致：

| 内容 | 字体 Token | 颜色 Token | 说明 |
|-----|-----------|-----------|------|
| 向右箭头图标 `icon-iconfont-right-medium` | `body-s-12-medium`（12pt，图标 font-size 同步取此值） | `text-tertiary`（`#888888`） | 默认右侧信息，可替换为其他 suffix 类型（见§5） |

> 若箭头左侧有辅助文字（如"已开启"、"中国大陆"等），文字与箭头图标之间间距为 **0pt**（紧贴）；文字颜色同箭头，使用 `text-tertiary`（`#888888`）。

---

## 4. 前缀区规格（prefix）

### 4.1 prefix 内容选项

prefix 位于行最左侧，与 type 正交，按需填入。

| prefix 类型 | 适用 type | 尺寸 | 圆角 Token | 与内容区间距 | 备注 |
|------------|----------|------|-----------|------------|------|
| `icon`（业务图标） | `single-line-s` / `single-line-l` | 32×32pt | — | `spacing-s`（8pt） | 业务场景图标容器；若填入功能图标（线性/面性系统图标），图标大小 18pt 居中显示，颜色默认 `text-primary`（`#111111`），间距改为 0 |
| `image`（图片） | `double-line-s` / `double-line-l` | 46×46pt | `radius-full` | `spacing-s`（8pt） | 全圆角，用于商品图、场景图等；默认白色背景 `#FFFFFF` |

### 4.2 标题徽标区规格（title-badge）

`title-badge` 内嵌于 content 内、紧跟主标题文字右侧，与主标题水平对齐，用于标签、红点、New 标记等轻量附加信息。

| title-badge 类型 | 说明 | 与主标题间距 |
|----------------|------|------------|
| `tag`   | 文字标签（如「新」「荐」「会员」），使用 `tag.md` 中 `size=standard`（高 16pt，字体 `caption-l-11-regular`，圆角 `cr-3` 3pt） | `cs-6`（6pt） |
| `dot`   | 待补充 | `cs-6`（6pt） |
| `badge` | 文字徽标、数字徽标，待补充，详见 `badge.md` | `cs-6`（6pt） |
| `info-icon` | 疑问图标，使用 `icon-iconfont-question-line-regular`，16pt，颜色 `text-quaternary`（`#999999`） | `cs-4`（4pt） |

> ⚠️ `title-badge` 不可与 suffix 中的 `badge` 同时出现；两者语义冲突，只能选其一。

---

## 5. 后缀区规格（suffix）

| suffix 类型 | 说明 | 字体 Token | 颜色 Token |
|------------|------|-----------|-----------|
| `arrow` | 向右箭头，导航跳转，使用 `icon-iconfont-right-line-medium` | — | `text-tertiary`（`#888888`） |
| `switch` | 开关组件，详见 `select-and-switch.md` | — | — |
| `badge` | 数字/红点徽标，详见 `badge.md` | — | — |
| `text` | 辅助说明文字 | `body-s-12-regular` | `text-tertiary`（`#888888`） |
| `button` | 小型操作按钮（`xs` size），详见 `button.md` | — | — |
| `meta-time` | 消息时间戳 | `caption-l-11-regular` | `text-tertiary`（`#888888`） |
| `price` | 右侧价格，字体方案见下表；详见 `font-price.md` | — | `red-default`（`#FF2D19`，默认）；可按业务色替换 |

**price 字体方案选择**：

| 方案 | 字体 | 适用 type | 使用场景 |
|-----|------|----------|---------|
| 新数字字体等大 | `price-set-16`（¥ 符 + 整数 + 小数同档） | 全部 type | 红包、优惠券、余额等用户**已得到或已有**的金额数字展示 |
| 新数字字体非等大 | `price-set-16+11`（¥ 符 + 整数 16pt / 小数 11pt） | 全部 type | 商品列表、购物车、商品详情、结算页等**突出的商品价格**信息 |
| 普通字体 | `single-line-l` / `double-line-l` → 16pt 中黑苹方；`single-line-s` / `double-line-s` → 14pt 中黑苹方 | 全部 type | 常规价格信息，无需特别突出时使用 |

---

## 6. 间距 Token

**水平内边距**（左右 padding，组件内固定值，不可自定义）：

| 应用场景 | Token 名称 | 值 |
|---------|-----------|-----|
| 列表行左右 padding | `spacing-xl`（×2） | 各 16pt |

**内容区竖向间距**：

| 间距 | Token 名称 | 值 |
|-----|-----------|-----|
| 主标题 → 副标题 | `cs-4` | 4pt |

**prefix 与 content 间距**：各 prefix 类型间距不同，以 §4.1 prefix 规格表中「与内容区间距」列为准。

---

## 7. 分割线（divider）

列表行之间默认使用分割线区分，分割线位于每行**底部**。

**分割线长度范围**：从 `content` 区左边界 → `content` 区右边界，即：
- **左侧**：不含左 padding（16pt）、不含 prefix 区及其间距
- **右侧**：不含右 padding（16pt）、不含 suffix 区

```
|←16pt→| prefix | gap | [===== divider =====] | suffix |←16pt→|
                        ↑ content 左边界        ↑ content 右边界
```

| 属性 | Token | 值 |
|-----|-------|-----|
| 颜色 | `divider-secondary` | `Color/Neutral/.Black-Opacity-6`（`rgba(0,0,0,0.06)`） |
| 粗细 | `border-default` | 0.5pt |
| 左起点 | content 区左边界 | 随 prefix 存在与否变化 |
| 右终点 | content 区右边界 | 固定，不延伸到 suffix 区 |

> **最后一行不加分割线**：列表容器最后一个 List Item 的 divider 不显示。

---

## 8. 背景色

默认背景：`white`（`#FFFFFF`），与页面背景 `bg-page`（`#F5F5F5`）形成层次。按压态等状态背景见 §9。

| Token | 色值 |
|-------|------|
| `white` | `#FFFFFF` |
| `bg-page` | `#F5F5F5` |

---

## 9. 状态（state）

| state | `data-state` 值 | 视觉表现 |
|-------|----------------|----------|
| 默认 | `default` | 正常展示 |
| 按压态 | `pressed` | 背景叠加 `bg-overlay-light`（`rgba(0,0,0,0.04)`）；**禁止使用 `transform: scale()`** |
| 禁用态 | `disabled` | 文字颜色降级为 `text-disabled`（`#C2C2C2`）；`aria-disabled="true"` |

---

## 10. 消息列表型（message 变体）补充规范

消息列表型为独立变体，结构固定为：

```
[ avatar 40pt ] [ content（主标题 + 消息预览） ] [ time + badge ]
```

| 区域 | 内容 | 字体 Token | 颜色 Token |
|-----|------|-----------|-----------|
| 主标题 | 联系人/群组名称 | `subtitle-m-16-regular`（默认）；需突出时可用 `subtitle-m-16-medium` | `text-primary`（`#111111`） |
| 消息预览 | 最近一条消息（截断至 1 行） | `body-l-14-regular` | `text-tertiary`（`#888888`） |
| 时间戳 | 右上方时间 | `caption-l-11-regular` | `text-tertiary`（`#888888`） |
| 徽标 | 右下方数字/红点 | 详见 `badge.md` | — |

> **布局对齐规则**：主标题与时间戳水平对齐（同在第一行，垂直居中对齐）；消息预览与徽标水平对齐（同在第二行，垂直居中对齐）。

> **内边距与分割线**：左右水平内边距同通用规则，均为 `spacing-xl`（16pt）；分割线规则与其他列表类型一致，左侧从 content 区起始（不含 padding、不含 avatar 区），右侧到 time+badge 区结束（不含右侧 padding）。

> **免打扰模式**：开启后数字徽标变为红点，Badge 类型只能搭配红点，不可与数字徽标混用。

---

## 11. data-attribute 规范

| 属性 | 值 | 说明 |
|-----|-----|------|
| `data-slot` | `"list-item"` | 全局稳定标识，供父组件 CSS 定向选中 |
| `data-type` | `"single-line-s"` / `"single-line-l"` / `"double-line-s"` / `"double-line-l"` / `"message"` | 当前变体类型 |
| `data-prefix` | `"none"` / `"icon"` / `"image"` | 前缀区内容类型 |
| `data-state` | `"default"` / `"pressed"` / `"disabled"` | 当前交互状态 |
| `data-has-divider` | `"true"` / `"false"` | 是否显示底部分割线 |

---

## 12. 无障碍（a11y）

- 列表行整体应为可聚焦元素（`role="listitem"`，父容器 `role="list"`）
- 可交互的列表行（含箭头/开关）应有 `role="button"` 或包裹在 `<a>` / `<button>` 内
- suffix 中的操作按钮必须有独立 `aria-label`，描述操作内容
- 禁用态使用 `aria-disabled="true"`，不使用 HTML `disabled` 属性（保留 focus）
- icon-only 的 prefix 图标加 `aria-hidden="true"`

---

## 13. 使用约束

- **宽度**：默认 100% 填满容器（375pt 全宽），不可自定义宽度
- **不加投影**：列表行不使用任何 shadow Token，层次通过分割线和背景色区分
- **分割线颜色**：必须使用 `divider-secondary`（`rgba(0,0,0,0.06)`），❌ 禁止使用 `divider-primary`（10%黑）或硬编码色值
- **内容行数**：描述行最多 2 行，超出必须截断，不可撑高行高
- **suffix 组合**：`arrow` 与 `button` 不可同时出现；`switch` 与 `arrow` 不可同时出现
- **prefix 图片**：必须保持正方形比例，不可裁切为非正方形
- **与表单混排时字体统一**：同一页面中列表行与表单行同时出现时，主标题字体必须统一使用 `body-l-14-medium`，❌ 禁止列表用 `regular` 而表单用 `medium`（或反之）
