# Dialog 弹窗

> **组件分类**：Component（组件级）
> **定义**：弹窗出现在页面最上层，从中间弹出，**强中断**用户当前进程的反馈窗口，用于提供重要提示或要求决策。

> ⚠️ **蒙层强制规则（最高优先级）**：只要使用 Dialog 组件，**必须**同时展示全屏蒙层覆盖下层页面。功能弹窗使用 `mask-default`（60% 黑），营销弹窗使用 `mask-heavy`（80% 黑）。任何场景**均不允许**无蒙层展示弹窗。

---

## 0. 图标 / 间距 / Ownership 约束

- **icon-route（默认）**：本组件内功能图标默认回 `component/atoms/icon.md`，并沿用本文件已声明的 iconfont class / weight。
- **fixed-asset 例外**：若正文已指定 `assets/*.svg`、官方 SVG、PNG/CDN 切图、URL 尖角资源或固定插画，该位点必须走固定资产，不得强行回 iconfont；输出时可标注 `icon-route=fixed-asset`。
- **spacing-owner（归属）**：组件内部 slot、行内/容器内 gap、padding、对齐归本组件；页面边距、吸顶/吸底占位、列表外层留白归宿主。
- **宿主裁决（优先级）**：冲突遵循 `宿主 > 组合场景 > 本组件通用规则`，子组件仅拥有自身内部样式，不反向改宿主排布。
- **不可跳步**：先回 `references/INDEX.md` 完成区域路由与宿主锁定，再用 `component-quickref.md` 做宿主级收敛；本文件仅承接组件内 ownership 细则，不承担前置路由改判；不得凭语义猜测。

## 1. 组件大类（category）

弹窗按使用场景分为两类，两类在蒙层色、布局结构、关闭按钮位置等方面均有差异：

| category | 名称 | 定义 | 布局特点 | 蒙层 |
|----------|------|------|---------|------|
| `functional` | 功能弹窗 | 基于系统弹窗，应用美团元素与规范，用于提示、引导、判断、选择、输入等 | 布局固定，结构化 | `mask-default`（60% 黑） |
| `marketing` | 营销弹窗 | 强化营销氛围，用于大促入口、奖励发放、活动推荐、分享引导、结果反馈、用户挽留等 | 布局灵活，仅约束关闭按钮组件 | `mask-heavy`（80% 黑） |

---

## 2. 功能弹窗（category=functional）

### 2.1 内容类型（contentType）

功能弹窗内容区按形态分为五类，决定弹窗整体结构：

| contentType | 名称 | 内容特征 | 典型场景 |
|-------------|------|---------|---------|
| `text` | 文本类 | 内容仅由标题、副标题、正文文字构成 | 删除确认、权限获取提示、操作确认 |
| `icon` | 图标类 | 标题/正文区包含图标，用于可视化传达 | 版本升级、开启消息通知 |
| `image` | 图片类 | 弹窗顶部包含图片区域（可有标题正文，也可无） | 版本升级大图、商品推荐 |
| `other` | 其他操作类 | 内容区为自定义交互组件，如输入框、选择列表、券码、自定义内容 | 输入备注、选择评价、可选项组合 |
| `scroll` | 滑动展示类 | 内容较多，支持内部上下滚动查看；标题和按钮区固定不滚动 | 用户协议、条款说明 |

---

### 2.2 标题区结构（titleType）

标题区根据行数和是否含副标题划分，所有文本类/图标类/其他操作类弹窗均须指定：

| titleType | 名称 | 主标题行数 | 副标题 | 字号(1x) | 对齐 | 字体 Token |
|-----------|------|-----------|--------|---------|------|-----------|
| `single-center` | 单行居中标题 | 1行 | 无 | 17pt | 居中 | `subtitle-l-17-medium` |
| `multi-center` | 多行居中标题（≤2行） | ≤2行 | 无 | 14pt | 居中 | `body-l-14-medium` |
| `multi-left` | 多行居左标题（>2行） | >2行 | 无 | 14pt | 居左 | `body-l-14-medium` |
| `single-center-sub` | 单行居中主标题＋副标题 | 1行 | 有 | 主17pt；副14pt | 居中 | 主标题：`subtitle-l-17-medium`；副标题：`body-l-14-regular` |

**字色规则：**

| 元素 | Token | 来源 |
|------|-------|------|
| 主标题 | `text-primary` | `color-semantic.md` §二 Text Color |
| 副标题 | `text-quaternary` | `color-semantic.md` §二 Text Color |

> 标题建议不超过 3 行；行数超过时须确保弹窗整体高度 ≤ 460pt。
> 单行大标题（`subtitle-l-17-medium`，34px/2x）用于内容精简场景；多行标题（`body-l-14-medium`，28px/2x）用于内容较多场景，超过 2 行自动切换为居左对齐。

---

### 2.3 正文区结构（bodyType）

| bodyType | 名称 | 行数 | 对齐 | 字体 Token | 字体来源 | 字色 Token | 字色来源 |
|----------|------|------|------|-----------|---------|-----------|--------|
| `none` | 无正文 | — | — | — | — | — | — |
| `single` | 单段正文 | 1~2行居中，3行居左 | 视行数 | `body-l-14-regular` | `font-semantic.md` §一 Body | `text-secondary` | `color-semantic.md` §二 Text Color |
| `multi-para` | 多段正文 | 每段独立折行，段间距 10pt（20px/2x，`cs-10`） | 居左 | `body-l-14-regular` | `font-semantic.md` §一 Body | `text-secondary` | `color-semantic.md` §二 Text Color |

> 正文内容建议不超过 3 行。多段正文为自定义区域（非组件），段间距 20px（2x，`cs-10`），各段居左对齐，参见 §5.3.3。

---

### 2.4 底部按钮区结构（buttonLayout）

| buttonLayout | 名称 | 说明 | 行动按钮位置 |
|--------------|------|------|------------|
| `single` | 单按钮 | 唯一主操作，宽度充满弹窗 | — |
| `single-text` | 单按钮＋文字选项 | 主按钮下方附次要文字操作 | — |
| `dual-horizontal` | 双按钮水平 | 左次右主，等宽平分 | **右侧**（主操作） |
| `dual-horizontal-text` | 双按钮水平＋文字选项 | 双按钮下方附文字操作 | **右侧** |
| `dual-vertical` | 双按钮纵向 | 按钮文案 >6 个字时改纵向，主按钮在上 | 上方 |
| `dual-vertical-text` | 双按钮纵向＋文字选项 | 纵向基础上附文字操作 | 上方 |

**按钮样式规范（弹窗内按钮为 Button 三级按钮）：**

| 属性 | 值 | 来源 | 说明 |
|------|---|------|------|
| 字体 | `subtitle-s-15-medium` | `font-semantic.md` §一 Subtitle | — |
| 字号 | 15pt | — | 含于字体 Token |
| 按钮高度 | **40pt** | — | 对应 Button `size=l` |
| 主按钮样式 | `variant=primary`，背景 `gradient-yellow` | `button.md` §2 | — |
| 次要按钮样式 | `variant=secondary`，边框 `stroke-default` | `button.md` §2 | — |
| 文字选项颜色 | `text-tertiary` | `color-semantic.md` §二 Text Color | — |

> **行动按钮位置强制规则**：双按钮水平排列时，行动（主操作）按钮固定在**右侧**，取消/次操作在左侧。严禁颠倒。

---

### 2.5 关闭图标规则（closeIcon）

| closeIcon | 说明 |
|-----------|------|
| `false`（无 ×） | 按钮文案已具备明确关闭语义（"知道了"、"再想想"、"取消"、"关闭"），右上角无需展示 × |
| `true`（有 ×） | 按钮文案无关闭语义（如主按钮为"确认"、"订阅"），**必须**展示右上角 × 关闭按钮 |

> **法规要求**（工信部 2023 年通知）：弹窗必须提供清晰有效的关闭按钮，保证用户可便捷关闭。

---

### 2.6 功能弹窗尺寸规格

| 属性 | 值(1x) | 值(2x) | Token / 说明 |
|------|--------|--------|-------------|
| 弹窗宽度（固定） | **311pt** | 622px | 不可自定义 |
| 弹窗最大高度 | **460pt** | 920px | 超出内容时内容区支持滚动 |
| 定位 | 屏幕水平垂直居中 | — | — |
| 背景色（默认） | `white` | — | `color-semantic.md` §一 Neutral Color |
| 背景色（可选） | 自定义氛围色/渐变 | — | 灰色建议用 `bg-surface` |
| 圆角 | `cr-18`（18pt） | 36px | `component-radius.md` |
| overflow | `hidden` | — | 内容不超出圆角边界 |
| 布局方向 | `flex-direction: column` | — | 模块从上到下堆叠 |
| 弹窗高度 | 自适应 | — | 由各模块高度之和决定，无需固定 |
| **全屏蒙层（必须）** | `mask-default`（60% 黑） | — | `color-semantic.md` §六 Mask Color |

---

### 2.7 功能弹窗内部间距

> 各模块通过自身 padding 直接控制间距，模块间无额外 gap。以下为从 2x 源数据换算后的精确值：

| 区域 | 属性 | 精确值(1x) | 精确值(2x) | Token |
|------|------|-----------|-----------|-------|
| 标题区左右内边距 | padding-left / padding-right | **18pt** | 36px | `cs-18` |
| 标题区上内边距（仅一段内容，单行） | padding-top | **28.5pt** | 57px | — |
| 标题区上内边距（组合正文 / 组合滚动） | padding-top | **20pt** | 40px | `cs-20` |
| 标题区上内边距（上下等距） | padding-top | **20.5pt** | 41px | — |
| 标题区下内边距（仅一段内容） | padding-bottom | **21pt** | 42px | `cs-21` |
| 标题区下内边距（组合正文） | padding-bottom | **10pt** | 20px | `cs-10` |
| 标题区下内边距（上下等距） | padding-bottom | **20.5pt** | 41px | — |
| 标题区下内边距（组合滚动） | padding-bottom | **13pt** | 26px | `cs-13` |
| 正文区左右内边距 | padding-left / padding-right | **18pt** | 36px | `cs-18` |
| 正文区上内边距 | padding-top | **0pt** | 0px | — |
| 正文区下内边距 | padding-bottom | **21pt** | 42px | `cs-21` |
| 多段正文段间距 | row-gap | **10pt** | 20px | `cs-10` |
| 按钮区下内边距 | padding-bottom | **16pt** | 32px | `cs-16` |
| 双按钮间距（水平 / 纵向） | gap | **8pt** | 16px | `cs-8` |
| 关闭 × 距弹窗顶边 | top | **10pt** | 20px | `cs-10` |
| 关闭 × 距弹窗右边（仅一段内容 / 图标类） | right | **10pt** | 20px | `cs-10` |
| 关闭 × 距弹窗右边（组合正文 / 上下等距 / 组合滚动） | right | **26pt** | 52px | `cs-26` |

---

### 2.8 图片类补充规则（contentType=image）

图片区使用 `flex-grow:1` 自适应高度，顶部圆角与弹窗对齐（36px 36px 0 0，2x，即 `cr-18` 仅应用于顶部两角），关闭按钮绝对定位于图片区内（top:20（`cs-10`）, right:20（`cs-10`），2x）：

| 场景 | 规则 |
|------|------|
| 关闭按钮（图片较暗） | 使用**浅色关闭按钮**（`divider-secondary-dark` 背景，参见 §4.5） |
| 关闭按钮（图片较浅） | 使用**深色关闭按钮**（`bg-overlay-light` 背景，参见 §4.5） |

**关闭按钮深/浅色判断方法（基于对比度）：**

> 根据图片**右上方**（圆形关闭按钮所在位置）的颜色，通过与纯白的对比度来决定使用哪种关闭按钮样式。

判断步骤：

1. **吸取颜色**：在图片右上方、圆形关闭按钮所在位置处，吸取该区域的图片颜色色值
2. **查询对比度**：使用 [WebAIM Contrast Checker](https://webaim.org/resources/contrastchecker/)，将吸取的颜色填入 Foreground，纯白 `#FFFFFF` 填入 Background，读取 Contrast Ratio 值
3. **选择按钮样式**：
   - **Contrast Ratio > 3**（图片该区域偏深）→ 使用**浅色（偏白）圆形关闭按钮**（`divider-secondary-dark` 背景）
   - **Contrast Ratio ≤ 3**（图片该区域偏浅）→ 使用**深色圆形关闭按钮**（`bg-overlay-light` 背景）

| 示例图片颜色 | 与纯白对比度 | 判断结果 | 关闭按钮样式 |
|---|---|---|---|
| 深色（如 `#1B4074`，对比度 10.33:1） | > 3 | 图片深 | 浅色（偏白）关闭按钮 |
| 浅色（如 `#FFE9E7`，对比度 1.16:1） | ≤ 3 | 图片浅 | 深色关闭按钮 |
| 无标题/正文（`titleType=none`） | 图片区 + 按钮容器（上padding 32px/2x）组合，参见 §5.3.5 第1种 |
| 有标题/正文 | 图片区 + 标题模块「组合正文无关闭」+ 正文模块 + 按钮模块，参见 §5.3.5 第2种 |
| 渐变过渡（gradientFade） | 可选，绝对定位于图片区底部，高80px（2x），`rgba(white, 0) → white` |

---

### 2.9 滑动展示类补充规则（contentType=scroll）

| 属性 | 规范 |
|------|------|
| 弹窗高度 | 自适应（由标题 + 滚动内容区 + 按钮高度决定），最大 **460pt** |
| 标题区 | 固定不滚动，使用标题模块「组合滚动」（下padding 26px/2x，`cs-13`） |
| 内容区 | 自定义滚动区域，`flex-grow:1`，`overflow:hidden`，宽622px |
| 按钮区 | 固定不滚动，按钮容器上padding 32px（2x，`cs-16`） |
| 底部渐变遮罩 | 绝对定位于滚动区底部，高48px（2x），`rgba(white, 0) → white`；默认展示，内容滚动到底后可隐藏 |
| 拼接结构 | 参见 §5.3.7 |

---

## 3. 营销弹窗（category=marketing）

### 3.1 营销弹窗基础规格

| 属性 | 值 | 说明 |
|------|----|----|
| 弹窗主体宽度（窄） | **279pt** | 常规营销内容 |
| 弹窗主体宽度（宽） | **311pt** | 含券码、横向商卡等较宽内容 |
| 弹窗最大高度 | **460pt** | 排除光效等装饰性元素的主体尺寸 |
| 定位 | 弹窗整体（含关闭按钮）在屏幕居中 | — |
| 关闭按钮距弹窗主体 | **30pt** | 关闭按钮在弹窗下方，与主体间距 30pt |
| 背景色 | 自定义（氛围色/渐变） | 不做限制 |
| 圆角 | 不做限制，推荐使用 `component-radius.md` 中的圆角 Token | — |
| 文字 | 不做限制，推荐使用 `font-semantic.md` 中的字体 Token | — |
| 按钮 | 不做限制，推荐使用 `button.md` 中的按钮样式 | — |
| **全屏蒙层（必须）** | `mask-heavy`（80% 黑） | `color-semantic.md` §六 Mask Color |

---

### 3.2 营销弹窗关闭按钮规格

| 属性 | 规范 |
|------|------|
| 位置 | 弹窗**下方**居中（不在弹窗内部右上角） |
| 按钮容器 | 面性圆形，**32pt × 32pt** |
| 关闭图标 | **18pt** 关闭 icon，居中叠加于容器内 |
| 距弹窗主体间距 | **30pt**（含光效等装饰元素时，距主体可视边缘） |
| 位置原因 | 营销弹窗顶部样式多变，不易定位；放在下方更符合用户浏览顺序，且不遮挡主视觉 |

---

## 4. 模块样式规格（2倍图源数据）

> 本章节记录各拼接模块在 2 倍图下的精确样式数据，供还原与生码参考。所有数值均为 **2x 像素值**，换算为 pt 时除以 2。

---

### 4.1 标题模块（Title Module）

标题模块共 5 种类型，根据下方拼接的内容区域不同，底部 padding 有所差异。

#### 4.1.1 仅一段内容（title-only）

> 标题下方直接接按钮区，无正文，上下 padding 对称或接近对称。

| 变体 | 字号/行高/字重(2x) | 文本对齐 | 文本最大高度(2x) | 上padding(2x) | 下padding(2x) | 左右padding(2x) | 有关闭按钮 |
|------|-----------------|---------|---------------|--------------|--------------|----------------|-----------|
| 单行居中（无关闭） | `subtitle-l-17-medium`（34px/500） | center | 48px（1行） | 57px（无 Token，28.5pt 非整数） | 57px（无 Token） | 36px（`cs-18`） | ✗ |
| 单行居中（有关闭） | `subtitle-l-17-medium`（34px/500） | center | 48px（1行） | 57px（无 Token，28.5pt 非整数） | 57px（无 Token） | 36px（`cs-18`） | ✓ |
| 双行居中（无关闭） | `body-l-14-medium`（28px/500） | center | 80px（2行） | 42px（`cs-21`） | 42px（`cs-21`） | 36px（`cs-18`） | ✗ |
| 双行居中（有关闭） | `body-l-14-medium`（28px/500） | center | 80px（2行） | 58px（`cs-29`） | 42px（`cs-21`） | 36px（`cs-18`） | ✓ |
| 三行居左（无关闭） | `body-l-14-medium`（28px/500） | left | 120px（3行） | 42px（`cs-21`） | 42px（`cs-21`） | 36px（`cs-18`） | ✗ |
| 三行居左（有关闭） | `body-l-14-medium`（28px/500） | left | 120px（3行） | 58px（`cs-29`） | 42px（`cs-21`） | 36px（`cs-18`） | ✓ |

#### 4.1.2 组合正文（title-with-body）

> 标题下方接正文区，下 padding 收窄为 20px（`cs-10`），关闭按钮 right 偏移至 52px（`cs-26`）。

| 变体 | 字号/行高/字重(2x) | 文本最大高度(2x) | 上padding(2x) | 下padding(2x) | 左右padding(2x) | 有关闭按钮 | 关闭按钮位置(2x) |
|------|-----------------|---------------|--------------|--------------|----------------|-----------|----------------|
| 单行主标题 | `subtitle-l-17-medium`（34px/500） | 48px（1行） | 40px（`cs-20`） | 20px（`cs-10`） | 36px（`cs-18`） | ✓ | top:20（`cs-10`）, right:52（`cs-26`） |
| 单行主标题 + 副标题 | 主`subtitle-l-17-medium`；副`body-l-14-regular` | 主48px；副40px；gap:4px（`cs-2`） | 40px（`cs-20`） | 20px（`cs-10`） | 36px（`cs-18`） | ✓ | top:20（`cs-10`）, right:52（`cs-26`） |
| 双行主标题 | `subtitle-l-17-medium`（34px/500） | 96px（2行） | 40px（`cs-20`） | 20px（`cs-10`） | 36px（`cs-18`） | ✓ | top:20（`cs-10`）, right:52（`cs-26`） |

#### 4.1.3 组合正文无关闭（title-with-body-no-close）

> 与「组合正文」结构完全一致，仅无关闭按钮。

| 变体 | 字号/行高/字重(2x) | 文本最大高度(2x) | 上padding(2x) | 下padding(2x) | 左右padding(2x) | 有关闭按钮 |
|------|-----------------|---------------|--------------|--------------|----------------|-----------|
| 单行主标题 | `subtitle-l-17-medium`（34px/500） | 48px（1行） | 40px（`cs-20`） | 20px（`cs-10`） | 36px（`cs-18`） | ✗ |
| 单行主标题 + 副标题 | 主`subtitle-l-17-medium`；副`body-l-14-regular` | 主48px；副40px；gap:4px（`cs-2`） | 40px（`cs-20`） | 20px（`cs-10`） | 36px（`cs-18`） | ✗ |
| 双行主标题 | `subtitle-l-17-medium`（34px/500） | 96px（2行） | 40px（`cs-20`） | 20px（`cs-10`） | 36px（`cs-18`） | ✗ |

#### 4.1.4 上下等距（title-centered）

> 上下 padding 完全对称（41px），视觉居中，标题下方直接接按钮区，字号固定 34px。

| 变体 | 字号/行高/字重(2x) | 文本最大高度(2x) | 上padding(2x) | 下padding(2x) | 左右padding(2x) | 有关闭按钮 | 关闭按钮位置(2x) |
|------|-----------------|---------------|--------------|--------------|----------------|-----------|----------------|
| 单行居中 | `subtitle-l-17-medium`（34px/500） | 48px（1行） | 41px（无 Token，20.5pt 非整数） | 41px（无 Token） | 36px（`cs-18`） | ✓ | top:20（`cs-10`）, right:52（`cs-26`） |
| 双行居中 | `subtitle-l-17-medium`（34px/500） | 96px（2行） | 41px（无 Token，20.5pt 非整数） | 41px（无 Token） | 36px（`cs-18`） | ✓ | top:20（`cs-10`）, right:52（`cs-26`） |

#### 4.1.5 组合滚动（title-with-scroll）

> 标题下方接滚动内容区，下 padding 为 26px（`cs-13`，介于「组合正文」20px（`cs-10`）与「上下等距」41px 之间）。

| 变体 | 字号/行高/字重(2x) | 文本最大高度(2x) | 上padding(2x) | 下padding(2x) | 左右padding(2x) | 有关闭按钮 | 关闭按钮位置(2x) |
|------|-----------------|---------------|--------------|--------------|----------------|-----------|----------------|
| 单行主标题 | `subtitle-l-17-medium`（34px/500） | 48px（1行） | 40px（`cs-20`） | 26px（`cs-13`） | 36px（`cs-18`） | ✓ | top:20（`cs-10`）, right:52（`cs-26`） |
| 单行主标题 + 副标题 | 主`subtitle-l-17-medium`；副`body-l-14-regular` | 主48px；副40px；gap:4px（`cs-2`） | 40px（`cs-20`） | 26px（`cs-13`） | 36px（`cs-18`） | ✓ | top:20（`cs-10`）, right:52（`cs-26`） |
| 双行主标题 | `subtitle-l-17-medium`（34px/500） | 96px（2行） | 40px（`cs-20`） | 26px（`cs-13`） | 36px（`cs-18`） | ✓ | top:20（`cs-10`）, right:52（`cs-26`） |

#### 4.1.6 标题模块下 padding 汇总

| 标题变体 | 下padding(2x) | 下方衔接区域 |
|---------|--------------|------------|
| 仅一段内容 | 42px（`cs-21`）~ 57px | 直接接按钮区（无正文） |
| 上下等距 | 41px（无对应 Token，20.5pt 非整数） | 直接接按钮区（视觉居中） |
| 组合滚动 | 26px（`cs-13`） | 滚动内容区 |
| 组合正文 / 组合正文无关闭 | 20px（`cs-10`） | 正文区 |

#### 4.1.7 标题文字颜色

| 元素 | Token | 来源 |
|------|-------|------|
| 主标题 | `text-primary` | `color-semantic.md` §二 Text Color |
| 副标题 | `text-quaternary` | `color-semantic.md` §二 Text Color |

---

### 4.2 正文模块（Body Module）

> 上 padding 为 0（顶部紧接标题区底部），下 padding 固定 42px（`cs-21`，底部接按钮区）。

| 变体 | 文本高度(2x) | 行数 | 字号/行高/字重(2x) | 字体来源 | 文本对齐 | 字色 | 字色来源 | 上padding(2x) | 下padding(2x) | 左右padding(2x) |
|------|------------|------|-----------------|---------|---------|------|---------|--------------|--------------|----------------|
| 单行正文 | 40px（1行） | 1行 | `body-l-14-regular`（28px/400） | `font-semantic.md` §一 Body | center | `text-secondary` | `color-semantic.md` §二 Text Color | 0px | 42px（`cs-21`） | 36px（`cs-18`） |
| 双行正文 | 80px（2行） | 2行 | `body-l-14-regular`（28px/400） | `font-semantic.md` §一 Body | center | `text-secondary` | `color-semantic.md` §二 Text Color | 0px | 42px（`cs-21`） | 36px（`cs-18`） |
| 三行正文 | 120px（3行） | 3行 | `body-l-14-regular`（28px/400） | `font-semantic.md` §一 Body | left | `text-secondary` | `color-semantic.md` §二 Text Color | 0px | 42px（`cs-21`） | 36px（`cs-18`） |

> **对齐规则**：1~2 行居中对齐，3 行及以上居左对齐。

---

### 4.3 图标模块（Icon Module）

> 图标区位于弹窗顶部，下方接标题区。插槽为自定义内容区域。

| 变体 | 插槽尺寸(2x) | 插槽背景 | 背景来源 | 上padding(2x) | 下padding(2x) | 水平padding(2x) | 有关闭按钮 | 关闭按钮位置(2x) |
|------|------------|---------|---------|--------------|--------------|----------------|-----------|----------------|
| 无关闭 | 120×120px | `bg-surface`（占位色，实际自定义） | `color-semantic.md` §三 Background Color | 48px（`cs-24`） | 0px | 251px | ✗ | — |
| 有关闭 | 120×120px | `bg-surface`（占位色，实际自定义） | `color-semantic.md` §三 Background Color | 48px（`cs-24`） | 0px | 251px | ✓ | top:20（`cs-10`）, right:20（`cs-10`） |

> 水平 padding 251px × 2 + 插槽 120px = 622px（弹窗内容宽度），即图标在弹窗内**水平居中**。下 padding 为 0，图标区底部紧接标题区顶部（间距由标题区上 padding 控制）。

---

### 4.4 按钮模块（Button Module）

#### 4.4.1 按钮通用属性

| 属性 | 值(2x) | 换算1x | Token / 说明 | 来源 |
|------|--------|--------|-------------|------|
| 按钮高度 | 80px | 40pt | `size=l` | — |
| 圆角 | 40px | — | `radius-full`（全圆角胶囊形） | `component-radius.md` |
| 上下内边距 | 19px | — | `cs-9.5` | `component-spacing.md` |
| 左右内边距 | 48px | — | `cs-24` | `component-spacing.md` |
| 最小宽度 | 188px | 94pt | — | — |
| 字号 / 行高 / 字重 | 30px / 44px / 500 | 15pt | `subtitle-s-15-medium` | `font-semantic.md` §一 Subtitle |
| 字色 | — | — | `text-primary` | `color-semantic.md` §二 Text Color |

#### 4.4.2 主按钮（Primary）

| 属性 | 值 | 来源 |
|------|---|------|
| 背景 | `gradient-yellow` | `color-semantic.md` §八 Gradient Color |

#### 4.4.3 次要按钮（Secondary）

| 属性 | 值 | 来源 |
|------|---|------|
| 边框 | `stroke-default`（1px solid） | `color-semantic.md` §四 Stroke Color |
| 背景 | 透明 | — |

#### 4.4.4 六种 buttonLayout 规格

| buttonLayout | 排列方向 | 主按钮宽(2x) | 次按钮宽(2x) | 按钮间距(2x) | 含文字选项 | 外框下padding(2x) |
|-------------|---------|------------|------------|------------|---------|----------------|
| `single` | — | 558px（全宽） | — | — | ✗ | 32px（`cs-16`） |
| `single-text` | 纵向 | 558px（全宽） | — | — | ✓ | — |
| `dual-horizontal` | 横向 | 271px | 271px | 16px（`cs-8`） | ✗ | 32px（`cs-16`） |
| `dual-horizontal-text` | 横向 | 271px | 271px | 16px（`cs-8`） | ✓ | — |
| `dual-vertical` | 纵向 | 558px | 558px | 16px（`cs-8`） | ✗ | 32px（`cs-16`） |
| `dual-vertical-text` | 纵向 | 558px | 558px | 16px（`cs-8`） | ✓ | — |

> **双按钮水平排列**：左侧为次要按钮（border），右侧为主按钮（gradient）。

#### 4.4.5 文字选项（Text Option）

| 属性 | 值(2x) | Token | 来源 |
|------|--------|-------|------|
| 容器高度 | 92px | — | — |
| 上下内边距 | 26px | `cs-13` | `component-spacing.md` |
| 左右内边距 | 10px | `cs-5` | `component-spacing.md` |
| 字号 / 行高 / 字重 | 28px / 40px / 400 | `body-l-14-regular` | `font-semantic.md` §一 Body |
| 字色 | — | `text-tertiary` | `color-semantic.md` §二 Text Color |

---

### 4.5 关闭按钮模块（Close Button Module）

> ⚠️ **圆形关闭按钮（带背景容器）仅限 `contentType=image` 图片类弹窗使用。其余所有弹窗类型（文本类、图标类、其他操作类、滑动展示类等）均不得使用圆形关闭按钮。**

圆形关闭按钮提供深色背景和浅色背景两种变体，根据图片明暗选择：

| 变体 | 容器尺寸(2x) | 圆角(2x) | 背景色 | 背景色来源 | 图标尺寸(2x) | 内边距(2x) | 使用场景 |
|------|------------|---------|--------|----------|------------|---------|---------|
| 深色背景版 | 44×44px | `radius-full`（全圆） | `bg-overlay-light` | `color-semantic.md` §三 Background Color | 24×24px | 10px（`cs-5`） | 图片较浅时（浅色图片背景） |
| 浅色背景版 | 44×44px | `radius-full`（全圆） | `divider-secondary-dark` | `color-semantic.md` §五 Divider Color | 24×24px | 10px（`cs-5`） | 图片较暗时（深色图片背景） |

#### 4.5.1 图标规格（非图片类弹窗统一，不可更改）

> ⚠️ 以下图标规格适用于**非图片类弹窗**的关闭按钮（即标题「仅一段内容」「组合正文」「上下等距」「组合滚动」及图标类弹窗），这些场景使用**纯图标形式**（无圆形背景容器）。以下规格为**强制锁定项**，**尺寸、图标样式、粗细、颜色、位置均不允许更改**。

| 属性 | 值 | 来源 | 说明 |
|------|---|------|------|
| 图标库 | iconfont | — | 字体图标 |
| 图标名 | `cancel-line-semibold` | — | semibold 粗细，不可替换为其他变体 |
| 图标尺寸 | **16pt**（32px @2x） | — | 固定，不可缩放 |
| 图标颜色 | `text-quaternary` | `color-semantic.md` §二 Text Color | 使用 Token，不可硬编码或更换色值 |

#### 4.5.2 各模块定位规则（绝对定位，强制不可更改）

> ⚠️ 关闭按钮相对**所在模块**绝对定位，所有模块统一：**`top: 10pt`，`right: 10pt`**（20px @2x）。位置强制锁定，不允许任何场景下调整。

| 使用模块 | 定位参照 | top | right |
|---------|---------|-----|-------|
| 标题「仅一段内容」 | 标题区内 | **10pt**（20px @2x） | **10pt**（20px @2x） |
| 标题「组合正文」 | 标题区内 | **10pt**（20px @2x） | **10pt**（20px @2x） |
| 标题「上下等距」 | 标题区内 | **10pt**（20px @2x） | **10pt**（20px @2x） |
| 标题「组合滚动」 | 标题区内 | **10pt**（20px @2x） | **10pt**（20px @2x） |
| 图标类弹窗 | 图标区内 | **10pt**（20px @2x） | **10pt**（20px @2x） |

#### 4.5.3 显隐控制

关闭按钮在以下模块中为**可选项**，由使用方通过 `showClose`（布尔值 prop）显式指定是否展示，默认值为 `true`：

| 模块 | 是否支持显隐控制 | 默认值 |
|------|--------------|-------|
| 标题「仅一段内容」 | ✅ 支持 | `true`（默认展示） |
| 标题「组合正文」 | ✅ 支持 | `true`（默认展示） |
| 标题「上下等距」 | ✅ 支持 | `true`（默认展示） |
| 标题「组合滚动」 | ✅ 支持 | `true`（默认展示） |
| 图标类弹窗 | ✅ 支持 | `true`（默认展示） |

> 当 `showClose=false` 时，关闭按钮整体不渲染（不占位）；图标样式、颜色、位置等规格仅在展示时生效，不因显隐状态发生任何变化。

---

## 5. 模块拼接规则

> 本章节说明如何将 §4 中定义的各模块按弹窗类型组合拼接，形成完整弹窗。

### 5.1 弹窗容器规格（2倍图）

所有功能弹窗共享同一容器规格，模块在容器内纵向堆叠：

| 属性 | 值(2x) | 换算1x | Token / 说明 | 来源 |
|------|--------|--------|-------------|------|
| 宽度 | 622px | 311pt | 固定不可变 | — |
| 最大高度 | 920px | 460pt | 超出需内部滚动 | — |
| 圆角 | 36px | 18pt | `cr-18` | `component-radius.md` |
| 背景色 | — | — | `white` | `color-semantic.md` §一 Neutral Color |
| 布局方向 | `flex-direction: column` | — | 模块从上到下堆叠 | — |
| 溢出处理 | `overflow: hidden` | — | 内容不超出圆角边界 | — |

---

### 5.2 通用拼接规则

- **按钮模块**：所有弹窗均包含按钮模块，固定位于弹窗**最底部**
- **模块顺序**：从上到下依次堆叠，各模块的 padding 直接控制间距，模块间无额外 gap
- **模块独立引用**：每个模块（标题、正文、图标、按钮等）均独立引用各自的组件集（ComponentSet）。用户可在对应组件集内切换变体（如标题行数、按钮布局等），弹窗整体样式随之改变，无需手动调整尺寸
- **弹窗高度自适应**：弹窗容器高度由各模块实际高度之和决定，随模块变体自动撑开，不需要固定高度（上限为 460pt / 920px 2x）

---

### 5.3 各类型弹窗拼接结构

> ⚠️ **强制规则：弹窗类型锁定，共 7 种，不可自由拼接。**
>
> 所有功能弹窗必须且只能从以下 7 种类型中选择，**不允许在此之外随意组合模块或创造新结构**。可根据弹窗名称或各类型下定义的触发词来选择对应类型：
>
> | 编号 | 类型名称 | 适用场景关键词 |
> |------|---------|--------------|
> | §5.3.1 | 仅一段内容（text，无正文） | 仅一段内容、没有正文、不区分标题和正文 |
> | §5.3.2 | 标题 + 正文（text，有正文） | 有标题有正文、标题和正文分开 |
> | §5.3.3 | 标题 + 多段正文（text，多段自定义正文） | 多段正文、多条说明、自定义正文 |
> | §5.3.4 | 图标类（icon） | 有图标、图标弹窗 |
> | §5.3.5 | 图片类（image） | 有图片、图片弹窗 |
> | §5.3.6 | 其他操作类（other） | 输入框、选择列表、自定义内容 |
> | §5.3.7 | 滑动展示类（scroll） | 长文本、可滚动、用户协议、条款说明 |

#### 5.3.1 仅一段内容（text，无正文）

> **触发词**：用户提到「仅一段内容」、「没有正文」、或「有文字但不区分标题和正文」时，使用此类型弹窗。

拼接顺序（从上到下）：

```
┌─────────────────────────────┐
│   标题模块「仅一段内容」       │  ← 单行居中34px，上下padding各57px（无 Token，28.5pt 非整数）
│   按钮模块                   │  ← 底部 padding 32px（`cs-16`）
└─────────────────────────────┘
```

| 层级 | 使用模块 | 变体选择 |
|------|---------|---------|
| ① 标题 | 标题模块「仅一段内容」| 根据标题行数选：单行→`34px/57px`；双行→`28px/42px`；三行→`28px/42px 居左` |
| ② 按钮 | 按钮模块 | 根据操作数量选 `single` / `dual-horizontal` / `dual-vertical` 等 |

**参考尺寸（2x，单行标题 + 单按钮）**：

| 元素 | 高度(2x) |
|------|---------|
| 标题区（单行） | 162px |
| 按钮区（single） | 112px |
| **弹窗总高** | **274px** |

---

#### 5.3.2 标题 + 正文（text，有正文）

拼接顺序（从上到下）：

```
┌─────────────────────────────┐
│   标题模块「组合正文」         │  ← 上padding 40px（`cs-20`），下padding 20px（`cs-10`）
│   正文模块                   │  ← 上padding 0px，下padding 42px（`cs-21`）
│   按钮模块                   │  ← 底部 padding 32px（`cs-16`）
└─────────────────────────────┘
```

| 层级 | 使用模块 | 变体选择 |
|------|---------|---------|
| ① 标题 | 标题模块「组合正文」或「组合正文无关闭」 | 有关闭按钮→「组合正文」；无关闭按钮→「组合正文无关闭」；含副标题→选带副标题变体 |
| ② 正文 | 正文模块 | 根据正文行数选：1行→居中；2行→居中；3行→居左 |
| ③ 按钮 | 按钮模块 | 根据操作数量选 `single` / `dual-horizontal` / `dual-vertical` 等 |

**参考尺寸（2x，单行标题 + 单行正文 + 单按钮）**：

| 元素 | 高度(2x) |
|------|---------|
| 标题区（单行，组合正文） | 108px |
| 正文区（单行） | 82px |
| 按钮区（single） | 112px |
| **弹窗总高** | **302px** |

---

#### 5.3.3 标题 + 多段正文（text，多段自定义正文）

拼接顺序（从上到下）：

```
┌─────────────────────────────┐
│ ┌─────────────────────────┐ │
│ │  标题模块「组合正文」      │ │  ← 上padding 40px（`cs-20`），下padding 20px（`cs-10`）
│ │  多段正文区域（自定义）    │ │  ← 自定义内容，非组件，参见样式建议
│ └─────────────────────────┘ │  ← 外层容器统一管理底部 padding 42px（`cs-21`）
│   按钮模块                   │  ← 底部 padding 32px（`cs-16`）
└─────────────────────────────┘
```

> **注意**：标题模块与多段正文区域被包裹在同一外层容器（`flex-direction: column`）中，由外层容器统一管理 `padding-bottom: 42px`（2x），而非各模块独立控制底部间距。

| 层级 | 使用模块 | 说明 |
|------|---------|------|
| ① 外层容器 | — | `flex-direction: column`，`row-gap: 16px`（2x，`cs-8`），`padding-bottom: 42px`（2x，`cs-21`） |
| ② 标题 | 标题模块「组合正文」或「组合正文无关闭」 | 嵌套于外层容器内 |
| ③ 多段正文 | **自定义区域（非组件）** | 嵌套于外层容器内，样式参见下方建议 |
| ④ 按钮 | 按钮模块 | 外层容器外，固定底部 |

**多段正文区域样式建议（2x）**：

| 属性 | 值(2x) | Token | 来源 |
|------|--------|-------|------|
| 宽度 | 550px | — | — |
| 每段文字高度 | 40px | — | — |
| 字号 / 行高 / 字重 | 28px / 40px / 400 | `body-l-14-regular` | `font-semantic.md` §一 Body |
| 字色 | — | `text-secondary` | `color-semantic.md` §二 Text Color |
| 段间距（row-gap） | 20px | `cs-10` | `component-spacing.md` |
| 对齐 | `align-items: start`（居左） | — | — |

**参考尺寸（2x，单行标题 + 3段正文 + 单按钮）**：

| 元素 | 高度(2x) |
|------|---------|
| 外层容器（标题108px + gap16px + 多段正文160px + bottom-padding42px） | 326px |
| 按钮区（single） | 112px |
| **弹窗总高** | **438px** |

---

#### 5.3.4 图标类（icon）

拼接顺序（从上到下）：

```
┌─────────────────────────────┐
│   图标模块（无关闭按钮）       │  ← 上padding 48px（`cs-24`），下padding 0px
│   标题模块「组合正文无关闭」   │  ← 上padding 40px（`cs-20`），下padding 20px（`cs-10`）
│   正文模块                   │  ← 上padding 0px，下padding 42px（`cs-21`）
│   按钮模块                   │  ← 底部 padding 32px（`cs-16`）
└─────────────────────────────┘
```

| 层级 | 使用模块 | 变体选择 |
|------|---------|---------|
| ① 图标 | 图标模块「无关闭按钮」 | 插槽内容自定义，120×120px（2x） |
| ② 标题 | 标题模块「组合正文无关闭」 | 根据标题行数选：单行 / 带副标题 / 双行 |
| ③ 正文 | 正文模块 | 根据正文行数选：1行→居中；2行→居中；3行→居左 |
| ④ 按钮 | 按钮模块 | 根据操作数量选 `single` / `dual-horizontal` 等 |

> 图标类弹窗中，关闭按钮（若需要）位于**图标模块**内，绝对定位 top:20（`cs-10`）, right:20（`cs-10`）（2x）。若按钮文案已具备关闭语义，则使用无关闭版图标模块，整体无 × 按钮。

**参考尺寸（2x，图标 + 单行标题 + 单行正文 + 单按钮）**：

| 元素 | 高度(2x) |
|------|---------|
| 图标区 | 168px |
| 标题区（单行，组合正文无关闭） | 108px |
| 正文区（单行） | 82px |
| 按钮区（single） | 112px |
| **弹窗总高** | **470px** |

---

#### 5.3.5 图片类（image）

图片类弹窗分为两种子类型，共同特征：图片区右上角**必须**使用关闭按钮模块（绝对定位）。

---

**第1种：无标题正文（image，titleType=none）**

拼接顺序（从上到下）：

```
┌─────────────────────────────┐
│   自定义图片区（flex-grow:1） │  ← 高度用户指定，顶部圆角 36px 36px 0 0（`cr-18` 仅顶部两角）
│     └─ 关闭按钮模块（绝对定位 top:20（`cs-10`）, right:20（`cs-10`））
│     └─ 渐变遮罩（可选，绝对定位底部，高80px）
├─────────────────────────────┤  ← 按钮容器上padding 32px（`cs-16`）
│   按钮模块                   │  ← 底部 padding 32px（`cs-16`）
└─────────────────────────────┘
```

| 层级 | 使用模块 | 变体选择 |
|------|---------|---------|
| ① 图片区 | **自定义区域（非组件）** | `flex-grow:1`，高度由用户指定，顶部圆角 `36px 36px 0 0`（2x，即 `cr-18` 仅顶部两角） |
| ② 关闭按钮 | 关闭按钮模块（绝对定位于图片区内） | 根据图片色调选深色/浅色版；top:20（`cs-10`）, right:20（`cs-10`）（2x） |
| ③ 渐变遮罩 | **可选**，绝对定位于图片区底部 | 高80px（2x），图片底部渐变过渡到弹窗背景色 |
| ④ 按钮 | 按钮模块 | 外层容器上padding 32px（2x，`cs-16`）；按钮根据需求选变体 |

---

**第2种：有标题正文（image，有标题和正文）**

拼接顺序（从上到下）：

```
┌─────────────────────────────┐
│   自定义图片区（flex-grow:1） │  ← 高度用户指定，顶部圆角 36px 36px 0 0（`cr-18` 仅顶部两角）
│     └─ 关闭按钮模块（绝对定位 top:20（`cs-10`）, right:20（`cs-10`））
│     └─ 渐变遮罩（可选，绝对定位底部，高80px）
│   标题模块「组合正文无关闭」   │  ← 上padding 40px（`cs-20`），下padding 20px（`cs-10`）
│   正文模块                   │  ← 上padding 0px，下padding 42px（`cs-21`）
│   按钮模块                   │  ← 底部 padding 32px（`cs-16`）
└─────────────────────────────┘
```

| 层级 | 使用模块 | 变体选择 |
|------|---------|---------|
| ① 图片区 | **自定义区域（非组件）** | `flex-grow:1`，高度由用户指定，顶部圆角 `36px 36px 0 0`（2x，即 `cr-18` 仅顶部两角） |
| ② 关闭按钮 | 关闭按钮模块（绝对定位于图片区内） | 根据图片色调选深色/浅色版；top:20（`cs-10`）, right:20（`cs-10`）（2x） |
| ③ 渐变遮罩 | **可选**，绝对定位于图片区底部 | 高80px（2x） |
| ④ 标题 | 标题模块「组合正文无关闭」 | 无关闭按钮（× 已在图片区内），根据行数选变体 |
| ⑤ 正文 | 正文模块 | 根据正文行数选变体 |
| ⑥ 按钮 | 按钮模块 | 根据操作数量选变体 |

**自定义图片区规格（2x）**：

| 属性 | 值(2x) | 说明 |
|------|--------|------|
| 宽度 | 622px | 与弹窗等宽 |
| 高度 | 用户自定义 | `flex-grow:1`，根据内容需要设定 |
| 圆角 | `36px 36px 0px 0px`（`cr-18` 仅应用于顶部两角） | 仅顶部圆角，与弹窗容器圆角对齐 |
| overflow | `hidden` | 图片内容不超出圆角边界 |
| 关闭按钮定位 | `position:absolute`，top:20（`cs-10`）, right:20（`cs-10`） | 叠加于图片区右上角 |
| 渐变遮罩定位 | `position:absolute`，left:0, right:0, bottom:0 | 叠加于图片区底部（可选） |

**参考尺寸（2x）**：

| 变体 | 图片区高 | 其他模块高 | 弹窗总高 |
|------|---------|----------|---------|
| 第1种（无标题正文，图片622px） | 622px | 按钮容器144px | **766px** |
| 第2种（有标题正文，图片622px） | 622px | 标题108px + 正文82px + 按钮112px | **924px** |

---

#### 5.3.6 其他操作类（other）

其他操作类弹窗分为两种子类型，自定义区域宽度固定 550px（2x），高度由用户指定。标题/正文/自定义区域均被包裹在外层容器中，由外层统一管理底部与按钮区的间距（`padding-bottom: 48px`，2x，`cs-24`）。

---

**第1种：无正文（other，bodyType=none）**

拼接顺序（从上到下）：

```
┌─────────────────────────────┐
│ ┌─────────────────────────┐ │
│ │  标题模块「上下等距」      │ │  ← 上下padding各41px（无 Token，20.5pt 非整数）
│ │  自定义区域（flex-grow:1）│ │  ← 宽550px，高度用户指定，圆角 `cr-10`（20px/2x）
│ └─────────────────────────┘ │  ← 外层容器 padding-bottom 48px（`cs-24`）
│   按钮模块                   │  ← 底部 padding 32px（`cs-16`）
└─────────────────────────────┘
```

| 层级 | 使用模块 | 变体选择 |
|------|---------|---------|
| ① 外层容器 | — | `flex-grow:1`，`flex-direction:column`，`padding-bottom:48px`（2x，`cs-24`） |
| ② 标题 | 标题模块「上下等距」 | 上下padding各41px；根据标题行数选单行/双行；可选带/不带关闭按钮（right:52，`cs-26`） |
| ③ 自定义区域 | **自定义区域（非组件）** | `flex-grow:1`，宽550px，圆角 `cr-10`（20px/2x），高度自适应内容 |
| ④ 按钮 | 按钮模块 | 外层容器外，根据操作数量选变体 |

---

**第2种：有正文（other，bodyType=single）**

拼接顺序（从上到下）：

```
┌─────────────────────────────┐
│ ┌─────────────────────────┐ │
│ │  标题模块「组合正文」      │ │  ← 上padding 40px（`cs-20`），下padding 20px（`cs-10`）
│ │  正文模块                │ │  ← 上padding 0px，下padding 42px（`cs-21`）
│ │  自定义区域（flex-grow:1）│ │  ← 宽550px，高度用户指定，圆角 `cr-10`（20px/2x）
│ └─────────────────────────┘ │  ← 外层容器 padding-bottom 48px（`cs-24`）
│   按钮模块                   │  ← 底部 padding 32px（`cs-16`）
└─────────────────────────────┘
```

| 层级 | 使用模块 | 变体选择 |
|------|---------|---------|
| ① 外层容器 | — | `flex-grow:1`，`flex-direction:column`，`padding-bottom:48px`（2x，`cs-24`） |
| ② 标题 | 标题模块「组合正文」 | 上padding 40px（`cs-20`），下padding 20px（`cs-10`）；带关闭按钮（right:52，`cs-26`） |
| ③ 正文 | 正文模块 | 上padding 0px，下padding 42px（`cs-21`）；根据行数选变体 |
| ④ 自定义区域 | **自定义区域（非组件）** | `flex-grow:1`，宽550px，圆角 `cr-10`（20px/2x），高度自适应内容 |
| ⑤ 按钮 | 按钮模块 | 外层容器外，根据操作数量选变体 |

**自定义区域规格（2x）**：

| 属性 | 值(2x) | 说明 |
|------|--------|------|
| 宽度 | 550px | 与标题/正文文本区等宽 |
| 高度 | 用户自定义 | `flex-grow:1`，根据内容需要设定 |
| 圆角 | `cr-10`（20px/2x） | 四角均有圆角 |
| overflow | `hidden` | 内容不超出圆角边界 |

**参考尺寸（2x）**：

| 变体 | 标题 | 正文 | 自定义区域 | 外层bottom-padding | 按钮区 | 弹窗总高 |
|------|------|------|----------|-------------------|--------|---------|
| 第1种（无正文，自定义224px） | 130px | — | 224px | 48px | 112px | **514px** |
| 第2种（有正文，自定义224px） | 108px | 82px | 224px | 48px | 112px | **574px** |

---

#### 5.3.7 滑动展示类（scroll）

拼接顺序（从上到下）：

```
┌─────────────────────────────┐
│ ┌─────────────────────────┐ │
│ │  标题模块「组合滚动」      │ │  ← 上padding 40px（`cs-20`），下padding 26px（`cs-13`）
│ │  自定义滚动区域            │ │  ← flex-grow:1，overflow:hidden
│ │    └─ 渐变遮罩（绝对定位） │ │  ← 叠加于底部，高48px（固定视觉高度）
│ └─────────────────────────┘ │  ← 外层容器 flex-grow:1
├─────────────────────────────┤  ← 按钮容器上padding 32px（`cs-16`）
│   按钮模块                   │  ← 底部 padding 32px（`cs-16`）
└─────────────────────────────┘
```

| 层级 | 使用模块 | 变体选择 |
|------|---------|---------|
| ① 外层容器 | — | `flex-grow:1`，`flex-direction:column`，无额外 padding（由内部模块自行控制） |
| ② 标题 | 标题模块「组合滚动」 | 上padding 40px（`cs-20`），下padding 26px（`cs-13`）；带关闭按钮（right:52，`cs-26`）；根据内容选单行/带副标题/双行 |
| ③ 自定义滚动区域 | **自定义区域（非组件）** | `flex-grow:1`，宽622px，`overflow:hidden`，高度由用户指定 |
| ④ 渐变遮罩 | **固定叠加于滚动区域底部** | 绝对定位，left:0, bottom:0，622×48px（2x），`rgba(white, 0) → white` |
| ⑤ 按钮 | 按钮模块 | 外层容器外，按钮容器上padding 32px（2x，`cs-16`）；根据操作数量选变体 |

**渐变遮罩规格（2x）**：

| 属性 | 值(2x) | 说明 |
|------|--------|------|
| 宽度 | 622px | 与弹窗等宽 |
| 高度 | 48px | 固定 |
| 定位 | `position:absolute`，left:0, bottom:0 | 叠加于自定义滚动区域底部 |
| 渐变方向 | `180deg`（从上到下） | — |
| 渐变色 | `rgba(white, 0) 0%` → `white 100%` | 顶部透明（`white` token 透明度为 0），底部使用 `white` token |
| 展示条件 | 默认展示；内容未滚动到底时展示，滚动到底后可隐藏 | — |

**参考尺寸（2x，单行标题 + 自定义区域622px + 单按钮）**：

| 元素 | 高度(2x) |
|------|---------|
| 外层容器（标题114px + 滚动区622px） | 736px |
| 按钮容器（上padding32px + 按钮112px） | 144px |
| **弹窗总高** | **880px** |

---

## 6. Token 引用

### 6.1 颜色 Token

| 用途 | Token 名称 | 语义层来源 |
|------|-----------|-----------|
| 功能弹窗背景（默认） | `white` | `color-semantic.md` §一 Neutral Color |
| 备选灰色背景 | `bg-surface` | `color-semantic.md` §三 Background Color |
| 功能弹窗全屏蒙层 | `mask-default` | `color-semantic.md` §六 Mask Color |
| 营销弹窗全屏蒙层 | `mask-heavy` | `color-semantic.md` §六 Mask Color |
| 主标题文字 | `text-primary` | `color-semantic.md` §二 Text Color |
| 副标题文字 | `text-quaternary` | `color-semantic.md` §二 Text Color |
| 正文文字 | `text-secondary` | `color-semantic.md` §二 Text Color |
| 文字选项文字 | `text-tertiary` | `color-semantic.md` §二 Text Color |
| 关闭按钮图标色 | `text-quaternary` | `color-semantic.md` §二 Text Color |
| 主按钮背景渐变 | `gradient-yellow` | `color-semantic.md` §八 Gradient Color |
| 次要按钮边框 | `stroke-default` | `color-semantic.md` §四 Stroke Color |
| 滚动条 | `divider-primary` | `color-semantic.md` §五 Divider Color |
| 图片类关闭按钮背景（深色版） | `bg-overlay-light` | `color-semantic.md` §三 Background Color |
| 图片类关闭按钮背景（浅色版） | `divider-secondary-dark` | `color-semantic.md` §五 Divider Color |

### 6.2 字体 Token

| 用途 | Token 名称 | 语义层来源 |
|------|-----------|-----------|
| 单行居中主标题（17pt） | `subtitle-l-17-medium` | `font-semantic.md` §一 Subtitle |
| 多行/副标题场景主标题（14pt 加粗） | `body-l-14-medium` | `font-semantic.md` §一 Body |
| 副标题（灰色辅助信息） | `body-l-14-regular` | `font-semantic.md` §一 Body |
| 正文（14pt） | `body-l-14-regular` | `font-semantic.md` §一 Body |
| 按钮文字（15pt） | `subtitle-s-15-medium` | `font-semantic.md` §一 Subtitle |

### 6.3 圆角 Token

| 用途 | Token 名称 | 来源 |
|------|-----------|------|
| 功能弹窗整体圆角 | `cr-18`（18pt） | `component-radius.md` |
| 图片区顶部圆角 | `cr-18`（仅顶部两角） | `component-radius.md` |
| 按钮圆角（胶囊形） | `radius-full` | `component-radius.md` |
| 圆形关闭按钮容器圆角 | `radius-full` | `component-radius.md` |
| 其他操作类自定义区域圆角 | `cr-10`（10pt） | `component-radius.md` |

### 6.4 间距 Token

> 弹窗内各模块的间距均来自模块自身 padding，模块间无额外 gap。以下为文档中使用的间距 token 汇总，精确数值参见 §2.7 功能弹窗内部间距。

| Token 名称 | pt 值(1x) | 2x 像素值 | 使用场景 | 来源 |
|-----------|----------|---------|---------|------|
| `cs-18` | 18pt | 36px | 标题区/正文区左右内边距 | `component-spacing.md` |
| `cs-24` | 24pt | 48px | 图标模块上内边距、按钮左右内边距、other 类外层容器底部内边距 | `component-spacing.md` |
| `cs-16` | 16pt | 32px | 按钮区下内边距、按钮容器上内边距 | `component-spacing.md` |
| `cs-8` | 8pt | 16px | 双按钮间距（gap）、外层容器 row-gap | `component-spacing.md` |
| `cs-10` | 10pt | 20px | 标题区下内边距（组合正文）、段间距、关闭按钮 top/right 定位（仅一段内容/图标类） | `component-spacing.md` |
| `cs-2` | 2pt | 4px | 主标题与副标题间距（gap） | `component-spacing.md` |
| `cs-20` | 20pt | 40px | 标题区上内边距（组合正文/滚动） | `component-spacing.md` |
| `cs-29` | 29pt | 58px | 标题区上内边距（有关闭，双/三行） | `component-spacing.md` |
| `cs-26` | 26pt | 52px | 关闭 × 距弹窗右边（组合正文/上下等距/组合滚动） | `component-spacing.md` |
| `cs-21` | 21pt | 42px | 标题区/正文区下内边距 | `component-spacing.md` |
| `cs-13` | 13pt | 26px | 标题区下内边距（组合滚动）、文字选项上下内边距 | `component-spacing.md` |
| `cs-9.5` | 9.5pt | 19px | 按钮上下内边距 | `component-spacing.md` |
| `cs-5` | 5pt | 10px | 圆形关闭按钮内边距、文字选项左右内边距 | `component-spacing.md` |

> **无对应 token 的裸值（保留）**：
> - `57px`（28.5pt）— 仅一段内容标题上内边距（非整数 pt，无档位）
> - `41px`（20.5pt）— 上下等距标题上/下内边距（非整数 pt，无档位）

---

## 7. Props API（供 AI 生码参考）

```typescript
export type DialogProps = {
  /**
   * 弹窗大类
   * @default "functional"
   */
  category?: "functional" | "marketing";

  /**
   * 功能弹窗——内容类型（仅 functional 有效）
   * @default "text"
   */
  contentType?: "text" | "icon" | "image" | "other" | "scroll";

  /**
   * 标题区结构
   * @default "single-center"
   */
  titleType?:
    | "none"
    | "single-center"
    | "multi-center"
    | "multi-left"
    | "single-center-sub";

  /**
   * 正文区结构
   * @default "single"
   */
  bodyType?: "none" | "single" | "multi-para";

  /**
   * 底部按钮区布局（仅 functional 有效）
   * @default "dual-horizontal"
   */
  buttonLayout?:
    | "single"
    | "single-text"
    | "dual-horizontal"
    | "dual-horizontal-text"
    | "dual-vertical"
    | "dual-vertical-text";

  /**
   * 是否显示右上角关闭图标（× 按钮）
   * 功能弹窗：有明确关闭语义按钮时为 false；否则必须为 true
   * 营销弹窗：此属性无效，关闭按钮固定在弹窗下方
   * @default false
   */
  closeIcon?: boolean;

  /**
   * 图片类：是否开启底部渐变过渡（仅 contentType=image 有效）
   * @default false
   */
  gradientFade?: boolean;

  /**
   * 营销弹窗宽度（仅 marketing 有效）
   * @default "narrow"
   */
  marketingWidth?: "narrow" | "wide"; // narrow=279pt, wide=311pt

  /**
   * 弹窗标题
   */
  title?: React.ReactNode;

  /**
   * 弹窗副标题（仅 titleType=single-center-sub 有效）
   */
  subTitle?: React.ReactNode;

  /**
   * 弹窗正文内容
   */
  body?: React.ReactNode;

  /**
   * 主按钮文案
   */
  primaryLabel?: string;

  /**
   * 次要按钮文案（双按钮时必填）
   */
  secondaryLabel?: string;

  /**
   * 文字选项文案（buttonLayout 含 text 时使用）
   */
  textOptionLabel?: string;

  /**
   * 主按钮点击回调
   */
  onPrimary?: () => void;

  /**
   * 次要按钮点击回调
   */
  onSecondary?: () => void;

  /**
   * 文字选项点击回调
   */
  onTextOption?: () => void;

  /**
   * 关闭回调（点击蒙层或关闭按钮触发）
   */
  onClose?: () => void;

  /**
   * 图标插槽（contentType=icon 时使用）
   */
  icon?: React.ReactNode;

  /**
   * 自定义内容区（contentType=other 时使用）
   */
  children?: React.ReactNode;
};
```

---

## 8. data-attribute 规范

| 属性 | 值 | 说明 |
|------|----|------|
| `data-slot` | `"dialog"` | 弹窗根容器标识 |
| `data-slot` | `"dialog-overlay"` | 全屏蒙层标识 |
| `data-slot` | `"dialog-content"` | 弹窗主体容器标识 |
| `data-slot` | `"dialog-title"` | 标题区标识 |
| `data-slot` | `"dialog-body"` | 正文区标识 |
| `data-slot` | `"dialog-footer"` | 按钮区标识 |
| `data-slot` | `"dialog-close"` | 关闭按钮标识 |
| `data-category` | `"functional"` / `"marketing"` | 弹窗大类 |
| `data-content-type` | `"text"` / `"icon"` / `"image"` / `"other"` / `"scroll"` | 内容类型（仅 functional） |

---

## 9. 无障碍（Accessibility）

- 弹窗根容器使用 `role="dialog"`，`aria-modal="true"`
- 必须设置 `aria-labelledby` 指向标题元素 ID
- 如有正文描述，设置 `aria-describedby` 指向正文元素 ID
- 打开弹窗时焦点移入弹窗内（首个可聚焦元素）
- 关闭弹窗时焦点返回触发元素
- 键盘 `Esc` 键关闭弹窗
- Tab 键焦点限制在弹窗内部（Focus Trap）
- 全屏蒙层 `aria-hidden="true"`，不可聚焦

---

## 10. 使用约束（AI 生成时的硬性规则）

1. **蒙层不可省略**：任何场景下使用 Dialog，均必须同时渲染全屏蒙层（`mask-default` 或 `mask-heavy`），禁止无蒙层展示弹窗
2. **功能弹窗宽度固定**：功能弹窗宽度固定 311pt，不可自定义
3. **营销弹窗宽度二选一**：279pt（默认）或 311pt（宽内容），不可中间值
4. **按钮行动方向固定**：双按钮水平排列时，主操作（行动按钮）固定在右侧
5. **关闭按钮位置不同**：功能弹窗关闭 × 在右上角；营销弹窗关闭按钮在弹窗下方 30pt
6. **按钮文字选关闭语义时无需 ×**：有"知道了"、"再想想"、"取消"等文案时，`closeIcon=false`
7. **禁止写 hex 颜色**：颜色必须使用 §6.1 中的语义 Token
8. **营销弹窗内容不约束**：营销弹窗除关闭按钮外，内容、字体、颜色、按钮均不做规范约束
9. **弹窗高度上限**：功能弹窗和营销弹窗的最大高度均为 460pt，超出需内部滚动
10. **谨慎使用**：弹窗为强中断组件，使用频次应较低，设计需谨慎

---

## 11. 常见组合示例

### 11.1 操作确认弹窗（文本类，双按钮，有关闭语义）

```
Dialog
  category: functional
  contentType: text
  titleType: single-center        // "确定要删除这 7 件商品吗？"
  bodyType: none
  buttonLayout: dual-horizontal   // 左"再想想" 右"删除"
  closeIcon: false                // "再想想" 已有关闭语义
  蒙层: mask-default（60% 黑）
```

### 11.2 订阅确认弹窗（文本类，双按钮，需关闭图标）

```
Dialog
  category: functional
  contentType: text
  titleType: single-center        // "确定要订阅景区吗？"
  bodyType: single                // "订阅后，你将收到抢票信息和价格变动的推送通知。"
  buttonLayout: dual-horizontal   // 左"再想想" 右"订阅"
  closeIcon: false                // "再想想" 具有关闭语义
  蒙层: mask-default（60% 黑）
```

### 11.3 版本更新弹窗（图标类，单按钮）

```
Dialog
  category: functional
  contentType: icon
  titleType: single-center        // "发现新版本"
  bodyType: single                // 更新说明文案
  buttonLayout: single            // "立即更新"
  closeIcon: true                 // 主按钮无关闭语义，需展示 ×
  蒙层: mask-default（60% 黑）
```

### 11.4 协议阅读弹窗（滑动展示类）

```
Dialog
  category: functional
  contentType: scroll
  titleType: single-center        // 协议标题
  bodyType: single                // 长文本，内部滚动
  buttonLayout: dual-horizontal   // "不同意" / "同意"
  closeIcon: false                // 有"不同意"关闭语义
  蒙层: mask-default（60% 黑）
```

### 11.5 输入备注弹窗（其他操作类）

```
Dialog
  category: functional
  contentType: other
  titleType: single-center        // "填写备注"
  bodyType: none
  children: <InputField />        // 自定义输入区
  buttonLayout: dual-horizontal   // "取消" / "确认"
  closeIcon: false                // "取消" 具有关闭语义
  蒙层: mask-default（60% 黑）
```

### 11.6 营销活动弹窗

```
Dialog
  category: marketing
  marketingWidth: narrow          // 279pt
  children: <MarketingBanner />   // 自定义营销内容
  // 关闭按钮自动置于弹窗下方 30pt，32pt 圆形面性容器，18pt 图标
  蒙层: mask-heavy（80% 黑）
```

---

## 12. 变体矩阵（功能弹窗）

功能弹窗的变体由 **contentType × titleType × bodyType × buttonLayout × closeIcon** 组合决定，以下为主要使用场景矩阵：

| contentType | titleType | bodyType | buttonLayout | closeIcon | 典型场景 |
|-------------|-----------|----------|--------------|-----------|---------|
| `text` | `single-center` | `none` | `dual-horizontal` | `false` | 删除/退出确认 |
| `text` | `single-center` | `single` | `dual-horizontal` | `false` | 权限申请、订阅确认 |
| `text` | `single-center` | `single` | `single` | `true` | 单一操作提示 |
| `text` | `multi-center` | `single` | `dual-horizontal` | `false` | 标题较长的确认 |
| `text` | `single-center-sub` | `single` | `dual-horizontal` | `false` | 有辅助信息的确认 |
| `text` | `single-center` | `multi-para` | `dual-horizontal` | `false` | 多条提示 |
| `icon` | `single-center` | `single` | `single` | `true` | 版本升级、消息通知 |
| `icon` | `single-center` | `single` | `dual-horizontal` | `false` | 图标+双操作 |
| `image` | `none` | `none` | `single` | `true` | 纯图营销/版本引导 |
| `image` | `single-center` | `single` | `dual-horizontal` | `false` | 图片+操作确认 |
| `other` | `single-center` | `none` | `dual-horizontal` | `false` | 输入框、选择列表 |
| `other` | `multi-center` | `none` | `dual-horizontal` | `false` | 双标题+自定义内容 |
| `scroll` | `single-center` | `single` | `dual-horizontal` | `false` | 协议/条款阅读 |

---

## 13. 与其他组件的关系

| 关联组件 | 关系说明 |
|----------|----------|
| `button` | 弹窗底部按钮区使用 `button.md` 中的 `size=l`（高度 40pt）按钮；主操作用 `primary`，次要操作用 `secondary` |
| `half-screen-dialog` | 半页弹窗从底部弹出，不强中断；使用场景比 Dialog 更轻；蒙层使用 `mask-light`（40% 黑） |
| `toast` | Toast 不使用蒙层，不中断操作，用于轻量反馈；与 Dialog 互斥不同时使用 |
| `list` | `contentType=other` 时内容区可嵌套 List 组件实现选项选择 |
| `select` | `contentType=other` 时内容区可嵌套 Select 组件实现单选/多选 |
