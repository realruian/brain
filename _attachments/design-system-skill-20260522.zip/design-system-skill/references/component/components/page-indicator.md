# Page Indicator 分页器

> **组件分类**：Component（组件级）
> **定义**：分页器通常附着在轮播图、一组卡片或者页面的底部，用来表示页面总数量并指示当前停留的页面位置。

> ⚠️ **核心约束**：
> - 分页器分为 **点状、横滑、数字、文字、进度条** 五大类型，各类型语义明确，不可混用
> - 点状/横滑/进度条分页器建议项数 **不超过 5**，数字/文字分页器不受此限
> - 颜色分为**常规**（浅色背景）、**浅色背景描边**、**深色背景描边**三种方案；深色背景上叠加时需配合蒙层
> - 宽度类组件（横滑、进度条）随页面宽度自适应，默认左右 **12pt**（`spacing-l`）边距

---

## 0. 图标 / 间距 / Ownership 约束

- **icon-route（默认）**：本组件内功能图标默认回 `component/atoms/icon.md`，并沿用本文件已声明的 iconfont class / weight。
- **fixed-asset 例外**：若正文已指定 `assets/*.svg`、官方 SVG、PNG/CDN 切图、URL 尖角资源或固定插画，该位点必须走固定资产，不得强行回 iconfont；输出时可标注 `icon-route=fixed-asset`。
- **spacing-owner（归属）**：组件内部 slot、行内/容器内 gap、padding、对齐归本组件；页面边距、吸顶/吸底占位、列表外层留白归宿主。
- **宿主裁决（优先级）**：冲突遵循 `宿主 > 组合场景 > 本组件通用规则`，子组件仅拥有自身内部样式，不反向改宿主排布。
- **不可跳步**：先回 `references/INDEX.md` 完成区域路由与宿主锁定，再用 `component-quickref.md` 做宿主级收敛；本文件仅承接组件内 ownership 细则，不承担前置路由改判；不得凭语义猜测。

## 1. 类型总览（indicatorType）

| indicatorType | 中文名 | 适用场景 | 特点 |
|---------------|--------|---------|------|
| `dot` | 点状分页器 | 整屏切换的轮播，内容相互独立 | 当前页为胶囊条，其余为圆点 |
| `swipe` | 横滑分页器 | 连续内容滑动，引导用户缓慢查看 | 滑动横条在滑轨中移动 |
| `numeric` | 数字分页器 | 多图/多视频切换，强调个数 | 显示「当前页 / 总页数」 |
| `text` | 文字分页器 | 多内容切换，需显示每部分名称 | 文字胶囊选项卡 |
| `progress` | 进度条分页器 | 多图/多视频切换，强调进度 | 线段式进度条 |

> **选型原则**：
> - 整屏独立页面切换（Banner、卡片组）→ `dot`（点状）
> - 内容连续、引导缓慢查看 → `swipe`（横滑）
> - 强调总数量、图片/视频较多 → `numeric`（数字）
> - 各部分有名称标签 → `text`（文字）
> - 强调进度感、顺序感 → `progress`（进度条）

---

## 2. 点状分页器（indicatorType=dot）

### 2.1 尺寸（size）

| size | 中文名 | 选中条宽 | 选中条高 | 圆点宽 | 圆点高 | 圆角 | 间距 |
|------|--------|---------|---------|-------|-------|------|------|
| `compact` | 紧凑 | **10pt** | **3pt** | **3pt** | **3pt** | **1.5pt**（`radius-full`） | **4pt**（`spacing-2xs`） |
| `standard` | 标准 | **12pt** | **4pt** | **4pt** | **4pt** | **2pt**（`radius-full`） | **4pt**（`spacing-2xs`） |

> ✅ **推荐**：标准尺寸适用于大部分场景；紧凑尺寸用于空间有限时（如叠加在图片底部）。

### 2.2 颜色方案（colorScheme）

| colorScheme | 选中条（胶囊）颜色 | 未选圆点颜色 | 适用背景 |
|-------------|----------------|------------|---------|
| `default` | `yellow-default`（`#FFDD00`） | `bg-overlay-ultra-light`（`#00000019`，黑色 10%） | 浅色/白色背景 |
| `light-bg` | `yellow-default`（`#FFDD00`） | `bg-overlay-ultra-light`（`#00000019`）+ 描边 | 浅色图片背景（增加描边保证可见） |
| `dark-bg` | `white-80`（`#FFFFFFCC`，白色 80%） | `white-20`（`#FFFFFF33`，白色 20%） | 深色/彩色图片背景 |

> **颜色使用建议**：
> - 多张**浅色图片**场景 → 使用 `light-bg`（带描边，保证滑动至深色图片时可见）
> - 多张**深色/彩色图片**场景 → 使用 `dark-bg`（白色反色，保证滑动至浅色图片时可见）
> - 纯白/灰色背景、需要体现品牌感 → 使用 `default`（品牌黄 + 黑色10%透明圆点）

### 2.3 项数（count）

| count | 选中条 | 未选圆点 | 总组件宽度（标准） | 总组件宽度（紧凑） |
|-------|-------|---------|----------------|----------------|
| `2` | 1 条 | 1 点 | 20pt | 17pt |
| `3` | 1 条 | 2 点 | 28pt | 24pt |
| `4` | 1 条 | 3 点 | 36pt | 31pt |
| `5` | 1 条 | 4 点 | 44pt | 38pt |

> ⚠️ **不建议超过 5 项**；项数超过 5 时优先改用 `numeric` 或 `progress` 类型。

### 2.4 布局规则

- 当前选中项：**胶囊条**（选中条），宽度为圆点宽度的 `3.33x`（标准）或 `3.33x`（紧凑）
- 未选项：**圆点**，宽高相等
- 排列方向：横向水平居中排列，gap 固定 **4pt**（`spacing-2xs`）
- 圆角：全部元素均为 `radius-full`（胶囊形）

### 2.5 Slot 规范

| Slot | 说明 | 默认值 | 用户可指定 |
|------|------|-------|-----------|
| `count` | 总页数（圆点总数量） | `2` | ✅ 可指定为 2-5 任意整数 |
| `activeIndex` | 当前选中项（0-indexed） | `0`（第 1 页） | ✅ 可指定为 0 ~ count-1 |

> **默认状态**：共 2 个内容，当前处于第 1 个（`count=2`，`activeIndex=0`）。

**示例指令映射**：
- 「总共 4 个页面，当前在第 3 页」→ `count=4`，`activeIndex=2`
- 「5 张图片，展示第 1 张」→ `count=5`，`activeIndex=0`

---

## 3. 横滑分页器（indicatorType=swipe）

> 适用于可滑动的模块或页面的切换，通常内容连续且可随时定位，引导用户缓慢查看。
> 常与**大尺寸模块**组合使用，例如金刚区卡片、横滑模块等。
> 纵向位置应结合实际场景而定；横向位置通常居于**屏幕中央**。

### 3.1 核心规格

| 属性 | 值 | Token | 可否修改 |
|------|-----|-------|--------|
| 组件整体高度 | **4pt** | — | ❌ 固定不变 |
| 圆角 | `radius-full`（9999px，完全胶囊） | `radius-full` | ❌ 固定不变 |
| 滑轨宽度 | **24pt**（@2x `48px`） | — | ❌ 固定不变（不可手动指定） |
| 滑轨背景色 | `bg-overlay-ultra-light-06`（`#0000000F`，黑色 6%） | `bg-overlay-ultra-light-06` | ❌ 固定不变 |
| 横条宽度 | **12pt**（@2x `24px`） | — | ❌ 固定不变（由页数决定） |
| 横条圆角 | `radius-full`（9999px） | `radius-full` | ❌ 固定不变 |
| 横条段间距 | **5pt** | — | ❌ 固定不变 |
| 左右边距 | **12pt**（`spacing-l`）或 **16pt**（`spacing-xl`） | `spacing-l` / `spacing-xl` | ❌ 固定不变 |

### 3.2 横条颜色方案（colorScheme）

| colorScheme | 横条颜色 | 滑轨颜色 | 适用场景 | 可调整颜色 |
|-------------|---------|---------|---------|----------|
| `brand` | `yellow-default`（`#FFDD00`） | `bg-overlay-ultra-light-06`（`#0000000F`） | 纯白/灰色背景，体现品牌感 | ✅ 横条可用品牌色 |
| `light-bg` | `white-80`（`#FFFFFF`）+ 描边 | `white-20`（`#FFFFFF33`） | 浅色图片/背景上 | ❌ 不建议调整 |
| `dark-bg` | `white-80`（`#FFFFFF`）+ 描边 | `white-20`（`#FFFFFF33`） | 深色图片/背景上 | ❌ 不建议调整 |

> **横条颜色建议**：
> - 仅 `brand` 方案下可将横条调整为品牌色，其他方案不建议修改颜色
> - 横条与滑轨建议使用**固定长度**，不严格体现页数物理比例
> - 同一页面多个模块均使用横滑分页器时，**横条与滑轨宽度应保持一致**

> **可调整项 vs 固定项**：
> - ✅ **仅横条颜色可根据业务色调整**（限 `brand` 方案）
> - ❌ **横条宽度、滑轨宽度、组件高度、横条圆角、横条间距、左右边距均不可改变**
> - ⚠️ 任何修改上述尺寸的诉求，均应拒绝执行，保持设计稿原值

### 3.3 尺寸规格

| 属性 | 值 | 说明 |
|------|-----|------|
| 组件高度 | **4pt** | ❌ 不可修改 |
| 滑轨宽度 | **24pt**（@2x `48px`） | ❌ 不可修改、不可手动指定 |
| 横条宽度 | **12pt**（@2x `24px`） | ❌ 不可修改、不可手动指定 |
| 横条间距 | **5pt** | ❌ 不可修改 |
| 左右边距 | `spacing-l`（12pt）或 `spacing-xl`（16pt） | ❌ 不可修改 |

> 横条宽度计算公式：`(组件总宽 - 2×边距) / 总页数`，最短 **不小于 2 倍高度**（≥ 8pt）。
> ⚠️ **所有尺寸均为固定值，不接受任何手动覆盖。**

### 3.4 间距规格（分页器与其他元素的距离）

| 场景 | 建议间距 |
|------|---------|
| 在元素内（如 Banner 以容器作为参考） | 距下边缘 **8pt**（`spacing-s`；Banner 较小时可用 `spacing-xs` **6pt**） |
| 在元素外（如金刚卡片，以上方元素作为参考） | 距上方元素 **12pt**（`spacing-l`） |
| 调整步长 | 以 **2pt**（`spacing-3xs`）为梯度增减 |

### 3.5 Slot 规范

> 无 Slot。横滑分页器不支持用户通过指令调整内容数量或位置。

### 3.6 横条位置规范

横条在滑轨中的水平位置（`left` 值）可根据用户描述动态指定，用于表达当前滑动进度：

**① 根据进度比例推算（大体效果，非精准值）**

用户描述当前进度比例时（如「滑动到 2/5」），横条 `left` 值按以下公式估算：

```
left = round((当前页 - 1) / 总页数 × 滑轨可用宽度)
```

> 此时仅展示大体位置效果，`left` 数值**不要求精准**。

**② 用户直接指定 `left` 数值**

用户可给出具体数值（如「黄色横条距离左侧 8px」），此时直接使用该值作为横条的 `left`。

> ⚠️ **约束**：无论如何调整横条位置，**横条宽度、滑轨宽度、组件高度、横条圆角、横条间距均不可改变**，仅 `left` 值变化。❌ 禁止通过任何方式修改上述尺寸。

> 📐 **`left` 取整规则**：无论通过公式推算还是用户直接指定，`left` 值**必须为整数**（单位 px/@2x 或 pt，均需取整）。计算结果若含小数，一律使用 `Math.round()` 四舍五入取整。❌ 禁止出现小数点的 `left` 值。

---

## 4. 数字分页器（indicatorType=numeric）

### 4.1 核心规格

| 属性 | 值 | 说明 |
|------|-----|------|
| 组件尺寸 | 高度固定 **24pt**，宽度**自适应**（由内容决定） | 左右 padding 固定，宽度随数字位数伸展 |
| 圆角 | `radius-full`（9999px，胶囊形） | `radius-full` |
| 内容格式 | `当前页 / 总页数`，如 `2 / 4` | 数字间隔 `/` 分隔 |
| 数字字号 | **12pt** | `body-s-12-medium` |
| 数字字重 | **500**（Medium） | `body-s-12-medium` |
| 数字行高 | **16pt** | `body-s-12-medium` |
| 内边距 | 左右 **10pt**（`spacing-m`），上下 **4pt**（`spacing-2xs`） | 宽度 = 左右 padding × 2 + 文字内容宽 |
| 数字间距（column-gap） | **1pt** | 数字与斜杠之间的间距 |

### 4.2 主题（theme）

| theme | 容器背景色 | 文字颜色 | 适用场景 |
|-------|----------|---------|---------|
| `dark` | `bg-overlay-dark-40`（`#00000066`，黑色 40%） | `white`（`#FFFFFF`） | 深色或图片背景上（推荐） |
| `light` | `white-80`（`#FFFFFFCC`，白色 80%） | `text-primary`（`#111111`） | 浅色背景上，与深色内容配合 |

### 4.3 字体 Token

| 用途 | Token 名称 | 字号 | 字重 | 行高 |
|------|-----------|------|------|------|
| 数字与分隔符 | `body-s-12-medium` | 12pt | 500 | 16pt |

### 4.4 Slot 规范

| Slot | 位置 | 说明 | 默认值 | 用户可指定 |
|------|------|------|-------|-----------|
| `current` | 左侧数字 | 当前页数（1-indexed） | `1` | ✅ 可指定为 1 ~ count |
| `count` | 右侧数字 | 总页数 | `2` | ✅ 可指定任意正整数 |
| `/`（分隔符） | 中间符号 | 固定为 `/`，不可修改 | `/` | ❌ 写死，不可更改 |

> **默认状态**：显示 `1 / 2`（当前第 1 页，共 2 页）。

**示例指令映射**：
- 「总共 4 个页面，当前在第 3 页」→ `current=3`，`count=4`，显示 `3 / 4`
- 「共 12 张图，当前第 7 张」→ `current=7`，`count=12`，显示 `7 / 12`

---

## 5. 文字分页器（indicatorType=text）

### 5.1 核心规格

| 属性 | 值 | 说明 |
|------|-----|------|
| 容器圆角 | `radius-m`（**12pt**） | `radius-m` |
| 容器高度 | **24pt** | 固定 |
| 容器内边距 | **1pt**（上下） | 内部选项有 1pt 缓冲 |
| 选项宽度 | **随文字内容自适应**，左右 padding 各 **10pt**（`spacing-m`）固定（❌ 禁止固定宽度） | 文字不同时各选项宽度可不一致 |
| 选项高度 | **22pt** | |
| 选项圆角（选中） | `radius-full`（**20pt**，完全胶囊） | `radius-full` |
| 选项内边距 | 上下 **3pt**，左右 **10pt**（`spacing-m`） | — |
| 文字字号 | **11pt** | `caption-l-11-medium` / `caption-l-11-regular` |
| 文字字重（选中） | **500**（Medium） | `caption-l-11-medium` |
| 文字字重（未选） | **400**（Regular） | `caption-l-11-regular` |
| 文字行高 | **16pt** | `caption-l-11-medium` / `caption-l-11-regular` |

### 5.2 主题（theme）

| theme | 容器背景色 | 选中项背景 | 选中项文字 | 未选项文字 | 适用背景 |
|-------|----------|----------|-----------|-----------|---------|
| `dark` | `bg-overlay-dark-40`（`#00000066`，黑色 40%） | `white`（`#FFFFFF`） | `text-primary`（`#111111`） | `white`（`#FFFFFF`） | 深色/图片背景 |
| `light` | `bg-page-75`（`#F5F5F5BF`，浅灰 75%，无精确 token）+ `divider-secondary`（`#0000000F`）描边 | `white`（`#FFFFFF`） | `text-primary`（`#111111`） | `text-secondary`（`#555555`） | 浅色/白色背景 |

### 5.3 选项数（count）

| count | 容器总宽 | 说明 |
|-------|---------|------|
| `2` | 86pt | 以「A」「B」各 2 字为例的示例值 |
| `3` | 128pt | 示例值 |
| `4` | 170pt | 示例值 |
| `5` | 212pt | 示例值 |

> ⚠️ 上表为规范设计稿中 **2字选项** 时的示例宽度，**非固定值**。
> 容器宽度 = 所有选项宽度之和（各选项随文字自适应）+ 容器上下各 **1pt** padding（左右无额外 padding，选项紧贴容器内壁）。
> 容器整体宽度跟随选项内容自动撑开，❌ 禁止按枚举值硬编码容器宽度。

### 5.4 跳转项（jumpable）

| jumpable | 描述 | 跳转区宽度 | 额外元素 |
|----------|------|----------|---------|
| `false` | 无跳转 | — | — |
| `true` | 有跳转按钮 | **随 `jumpLabel` 文字内容自适应**（❌ 禁止固定宽度） | 分割线（0.5pt，opacity 60%）+ 「跳转」文字 + 箭头图标 |

> 跳转项容器内边距：上下 **3pt**，左 **8pt**（`spacing-s`），右 **7pt**（固定不变）。
> 跳转区整体宽度 = 左padding **8pt**（`spacing-s`） + 文字宽（自适应）+ 右padding **7pt** + 图标 **9pt**。
> 规范设计稿中展示的 **46pt** 为「跳转」2字时的示例值，非固定值；`jumpLabel` 字数变化时容器随文字撑开。

> **箭头图标规格（jumpable=true 时必须遵守）**：
> - **图标类名**：`icon-iconfont-right-line-semibold`（❌ 禁止使用其他字重或 SVG）
> - **图标尺寸**：**9pt**（→ HTML 时写 `font-size:18px`）
> - **图标与左侧文字的 gap**：**0**（两者紧贴，❌ 禁止添加任何间距）
> - **图标颜色**：与跳转文字同色（dark 主题 `white`（`#FFFFFF`），light 主题 `text-secondary`（`#555555`））

### 5.5 Slot 规范

#### 无跳转按钮（jumpable=false）

| Slot | 说明 | 默认值 | 用户可指定 |
|------|------|-------|-----------|
| `options` | 选项文字列表（2-5 项） | `["A", "B"]` | ✅ 可指定各项文字内容及数量 |
| `activeIndex` | 当前选中项（0-indexed） | `0`（第 1 项） | ✅ 可指定为 0 ~ options.length-1 |

**示例指令映射**：
- 「有 A、B、C、D 四个内容，当前选中 C」→ `options=["A","B","C","D"]`，`activeIndex=2`

#### 有跳转按钮（jumpable=true）

| Slot | 说明 | 默认值 | 用户可指定 |
|------|------|-------|-----------|
| `options` | 选项文字列表（2-5 项） | `["A", "B"]` | ✅ 可指定各项文字内容及数量 |
| `activeIndex` | 当前选中项（0-indexed） | `0`（第 1 项） | ✅ 可指定为 0 ~ options.length-1 |
| `jumpLabel` | 右侧跳转按钮的文字 | `"跳转"` | ✅ 可指定任意文字 |

**示例指令映射**：
- 「有 A、B、C、D 四个内容，当前选中 B，右侧按钮文字为 E」→ `options=["A","B","C","D"]`，`activeIndex=1`，`jumpLabel="E"`

---

## 6. 进度条分页器（indicatorType=progress）

### 6.1 核心规格

| 属性 | 值 | 说明 |
|------|-----|------|
| 组件高度 | **2pt** | 固定 |
| 圆角 | `radius-xxs`（**1pt**） | `radius-xxs` |
| 默认总宽度 | **375pt**（撑满页面） | 可自定义 |
| 左右边距 | **12pt**（`spacing-l`）；局部使用时可设置为 0 | `spacing-l` |
| 段间距 | **4pt**（`spacing-2xs`） | `spacing-2xs` |

### 6.2 单段状态（segmentState）

| segmentState | 背景色 | 说明 |
|--------------|-------|------|
| `active` | `white-80`（`#FFFFFFCC`，白色 80%） | 当前选中段 |
| `partial` | `white-40`（`#FFFFFF66`，白色 40%）+ 子进度条覆盖 | 进行中（有当前进度子条） |
| `inactive` | `white-40`（`#FFFFFF66`，白色 40%） | 未到达段 |

> **子进度条**（`partial` 状态内）：圆角 `radius-full`（9999px），背景色 `white-80`（`#FFFFFFCC`），宽度等于 `段宽 × 进度比例`（50% 进度时为段宽的一半）。

### 6.3 段数（count）支持范围

| count | 每段宽度（750px 宽时） | 说明 |
|-------|-------------------|------|
| `2` | 173.5pt | |
| `3` | 114pt | |
| `4` | 84.5pt | |
| `5` | 67pt | |
| `6` | 55pt | |
| `7` | 46.5pt | |
| `8` | 40pt | |
| `9` | 35pt | |
| `10` | 31.5pt | |
| `11` | 28pt | |
| `12` | 25.5pt | |

> 每段宽度公式：`(totalWidth - 2×padding - (count-1)×gap) / count`，其中 padding=`spacing-l`（12pt），gap=`spacing-2xs`（4pt）。

### 6.4 宽度拉伸规则

进度条分页器整体宽度可根据实际需求**水平拉伸**，拉伸时遵循以下约束：

| 固定不变 | 自适应变化 |
|---------|----------|
| 左右边距（`padding`，默认 `spacing-l` 12pt） | 组件整体宽度（随容器/页面宽度变化） |
| 段与段之间的间距（`gap`，固定 `spacing-2xs` 4pt） | **每段宽度**（均分剩余空间，各段等宽） |

> **每段宽度计算公式**：
> ```
> 段宽 = (组件总宽 - 左右边距×2 - 段间距×(count-1)) / count
> ```
> 例：组件宽 375pt，count=4，padding=`spacing-l`（12pt），gap=`spacing-2xs`（4pt）：
> `(375 - 12×2 - 4×3) / 4 = (375 - 24 - 12) / 4 = 84.75pt`

> ⚠️ **约束**：拉伸时仅调整组件整体宽度，**左右边距与段间距始终保持不变**，不可随宽度等比缩放。

### 6.5 边距（padding）规格

| 边距选项 | 值 | 适用场景 |
|---------|-----|---------|
| 标准 | 左右各 **12pt**（`spacing-l`） | 撑满页面宽度，符合正常页面栅格 |
| 宽松 | 左右各 **16pt**（`spacing-xl`） | 特殊栅格或设计需要 |
| 无边距 | **0pt** | 局部使用（未撑满页面时） |

### 6.6 Slot 规范

| Slot | 说明 | 默认值 | 用户可指定 |
|------|------|-------|-----------|
| `count` | 总段数（2-12） | `2` | ✅ 可指定为 2-12 任意整数 |
| `activeIndex` | 当前正在播放的段（0-indexed） | `1`（第 2 段） | ✅ 可指定为 0 ~ count-1 |

> **段状态推导规则**（由 `activeIndex` 自动推算，无需单独指定）：
> - `activeIndex` 之前的所有段 → `active`（已播完）
> - `activeIndex` 当前段 → `partial`（播放中）
> - `activeIndex` 之后的段 → `inactive`（未到达）

> **默认状态**：共 2 段，当前播放第 2 段（`count=2`，`activeIndex=1`），第 1 段已播完。

**示例指令映射**：
- 「共 4 段，正在播放第 3 段」→ `count=4`，`activeIndex=2`（第 1、2 段已播完，第 4 段未到达）
- 「共 6 段，正在播放第 1 段」→ `count=6`，`activeIndex=0`（无已播完段，第 2-6 段未到达）
- 「正在播放第 5 段」（未指定总数时默认推断）→ `activeIndex=4`，前 4 段自动标记为已播完

---

## 7. Token 引用

### 7.1 颜色 Token

| 用途 | Token 名称 | 值 | 语义层来源 |
|------|-----------|-----|-----------|
| 点状选中条（品牌色） | `yellow-default` | #FFDD00 | `color-semantic.md` §七 |
| 点状未选圆点（常规） | `bg-overlay-ultra-light` | #00000019（10%黑） | `color-semantic.md` §三 |
| 点状未选圆点（深色背景） | `white-40` | #FFFFFF66（40%白） | — |
| 数字/文字容器（深色） | `bg-overlay-dark-40` | #00000066（40%黑） | `color-semantic.md` §六 |
| 数字/文字容器（浅色） | `white-80` | #FFFFFFCC（80%白） | — |
| 文字分页器选中文字 | `text-primary` | #111111 | `color-semantic.md` §二 |
| 文字分页器未选文字（浅色主题） | `text-secondary` | #555555 | `color-semantic.md` §二 |
| 文字分页器浅色容器描边 | `stroke-ultra-light` | #0000000F（6%黑） | `color-semantic.md` §四 |
| 横滑/进度条滑轨 | `bg-overlay-ultra-light-06` | #0000000F（6%黑） | `color-semantic.md` §三 |
| 进度条激活段/横条（深色背景） | `white-80` | #FFFFFFCC（80%白） | — |
| 进度条未激活段 | `white-40` | #FFFFFF66（40%白） | — |
| 纯白色（选中项背景、dark主题文字） | `white` | #FFFFFF | `color-semantic.md` §一 |
| 描边（黑色10%） | `stroke-default-alpha` | #0000001A（10%黑） | `color-semantic.md` §四 |

### 7.2 字体 Token

| 用途 | Token 名称 | 字号 | 字重 | 行高 |
|------|-----------|------|------|------|
| 数字分页器文字 | `body-s-12-medium` | 12pt | 500 | 16pt |
| 文字分页器选中文字 | `caption-l-11-medium` | 11pt | 500 | 16pt |
| 文字分页器未选文字 | `caption-l-11-regular` | 11pt | 400 | 16pt |

### 7.3 间距 Token

| 用途 | Token 名称 | 值（@2x） | @1x | 来源 |
|------|-----------|---------|-----|------|
| 分页器左右边距（标准） | `spacing-l` | 24px | 12pt | `component-spacing.md` |
| 分页器左右边距（宽松） | `spacing-xl` | 32px | 16pt | `component-spacing.md` |
| 点状/进度条各项间距 | `spacing-2xs` | 8px | 4pt | `component-spacing.md` |
| 分页器距容器下边缘 | `spacing-s` | 16px（或 `spacing-xs` 12px） | 8pt | `component-spacing.md` |
| 分页器距上方元素 | `spacing-l` | 24px | 12pt | `component-spacing.md` |
| 选项内边距左右 | `spacing-m` | 20px | 10pt | `component-spacing.md` |
| 步长调整单位 | `spacing-3xs` | 4px | 2pt | `component-spacing.md` |

### 7.4 圆角 Token

| 用途 | Token 名称 | 值 | 来源 |
|------|-----------|-----|------|
| 点状选中条 / 未选圆点 | `radius-full` | 9999px（完全胶囊） | `component-radius.md` |
| 横滑整体 / 横条 | `radius-full` | 9999px | `component-radius.md` |
| 数字分页器容器 | `radius-full` | 9999px | `component-radius.md` |
| 文字分页器容器 | `radius-m` | 12pt | `component-radius.md` |
| 文字分页器选项（选中） | `radius-full` | 9999px（完全胶囊） | `component-radius.md` |
| 进度条段 | `radius-xxs` | 1pt | `component-radius.md` |
| 进度条子进度条 | `radius-full` | 9999px | `component-radius.md` |

---

## 8. Props API（供 AI 生码参考）

```typescript
// ── 点状分页器 ──────────────────────────────────────
export type DotIndicatorProps = {
  /** 组件类型标识 */
  indicatorType: "dot";
  /** 尺寸：紧凑 / 标准 @default "standard" */
  size?: "compact" | "standard";
  /** 总项数（2-5） */
  count: 2 | 3 | 4 | 5;
  /** 当前选中项（0-indexed） */
  activeIndex: number;
  /** 颜色方案 @default "default" */
  colorScheme?: "default" | "light-bg" | "dark-bg";
};

// ── 横滑分页器 ──────────────────────────────────────
export type SwipeIndicatorProps = {
  indicatorType: "swipe";
  /** 总页数 */
  count: number;
  /** 当前页（0-indexed） */
  activeIndex: number;
  /** 颜色方案 @default "brand" */
  colorScheme?: "brand" | "light-bg" | "dark-bg";
  /** 左右边距（pt）@default 12 */
  padding?: 0 | 12 | 16;
  /** 是否随滚动位置动态计算横条位置 @default true */
  trackScroll?: boolean;
};

// ── 数字分页器 ──────────────────────────────────────
export type NumericIndicatorProps = {
  indicatorType: "numeric";
  /** 总页数 */
  count: number;
  /** 当前页（1-indexed，显示用） */
  current: number;
  /** 容器主题 @default "dark" */
  theme?: "dark" | "light";
};

// ── 文字分页器 ──────────────────────────────────────
export type TextIndicatorProps = {
  indicatorType: "text";
  /** 选项文字数组（2-5项） */
  options: string[];
  /** 当前选中项（0-indexed） */
  activeIndex: number;
  /** 是否显示跳转按钮 @default false */
  jumpable?: boolean;
  /** 点击跳转按钮回调（jumpable=true 时有效） */
  onJump?: () => void;
  /** 容器主题 @default "dark" */
  theme?: "dark" | "light";
  /** 切换回调 */
  onChange?: (index: number) => void;
};

// ── 进度条分页器 ────────────────────────────────────
export type ProgressIndicatorProps = {
  indicatorType: "progress";
  /** 总段数（2-12） */
  count: 2 | 3 | 4 | 5 | 6 | 7 | 8 | 9 | 10 | 11 | 12;
  /** 当前激活段（0-indexed） */
  activeIndex: number;
  /** 当前激活段的进度比例（0-1），用于 partial 状态 @default 0 */
  progress?: number;
  /** 左右边距（pt）@default 12 */
  padding?: 0 | 12 | 16;
};

// ── 联合类型 ─────────────────────────────────────────
export type PageIndicatorProps =
  | DotIndicatorProps
  | SwipeIndicatorProps
  | NumericIndicatorProps
  | TextIndicatorProps
  | ProgressIndicatorProps;
```

---

## 9. data-attribute 规范

| 属性 | 值 | 说明 |
|------|----|------|
| `data-slot` | `"page-indicator"` | 组件根容器 |
| `data-indicator-type` | `"dot"` / `"swipe"` / `"numeric"` / `"text"` / `"progress"` | 分页器类型 |
| `data-slot` | `"indicator-dot"` | 点状圆点元素 |
| `data-slot` | `"indicator-dot-active"` | 点状选中条 |
| `data-slot` | `"indicator-track"` | 横滑/进度条滑轨 |
| `data-slot` | `"indicator-bar"` | 横滑横条 |
| `data-slot` | `"indicator-segment"` | 进度条单段 |
| `data-slot` | `"indicator-segment-progress"` | 进度条子进度条 |
| `data-slot` | `"indicator-text-item"` | 文字分页器选项 |
| `data-active` | `"true"` / `"false"` | 是否为选中状态 |
| `data-theme` | `"dark"` / `"light"` | 容器主题（数字/文字类型） |
| `data-color-scheme` | `"default"` / `"light-bg"` / `"dark-bg"` / `"brand"` | 颜色方案 |
| `data-size` | `"compact"` / `"standard"` | 点状分页器尺寸 |

---

## 10. 无障碍（Accessibility）

- 组件根容器：`role="tablist"` 或 `aria-label="分页器"`
- 每个指示项：`role="tab"` / `aria-selected="true/false"` / `aria-label="第N页，共M页"`
- 当前激活项：`aria-current="true"`
- 横滑分页器：`aria-valuenow={当前页}` / `aria-valuemin={1}` / `aria-valuemax={总页数}`
- 进度条：`role="progressbar"` / `aria-valuenow={当前段}` / `aria-valuemax={总段数}`
- 文字分页器跳转按钮：`aria-label="跳转到指定页"`

---

## 11. 变体矩阵（完整 MECE）

### 11.1 点状分页器

| size | count | colorScheme | 组件总宽 |
|------|-------|-------------|---------|
| `compact` | `2` | `default` / `light-bg` / `dark-bg` | **17pt** |
| `compact` | `3` | 同上 | **24pt** |
| `compact` | `4` | 同上 | **31pt** |
| `compact` | `5` | 同上 | **38pt** |
| `standard` | `2` | `default` / `light-bg` / `dark-bg` | **20pt** |
| `standard` | `3` | 同上 | **28pt** |
| `standard` | `4` | 同上 | **36pt** |
| `standard` | `5` | 同上 | **44pt** |

> 共 8 种尺寸×项数组合 × 3 种颜色方案 = **24 个基础变体**，activeIndex 在 0~count-1 之间切换。

### 11.2 数字分页器

| theme | 容器高度 | 容器宽度 |
|-------|---------|--------|
| `dark` | 24pt（固定） | 自适应（随数字位数伸展） |
| `light` | 24pt（固定） | 自适应（随数字位数伸展） |

> 共 **2 个变体**，当前页和总页数通过 props 动态传入。

### 11.3 文字分页器

| theme | count | jumpable | 容器宽度 |
|-------|-------|----------|---------|
| `dark` | `2` | `false` / `true` | 86pt / 132.5pt |
| `dark` | `3` | `false` / `true` | 128pt / 174.5pt |
| `dark` | `4` | `false` / `true` | 170pt / 216.5pt |
| `dark` | `5` | `false` / `true` | 212pt / 258.5pt |
| `light` | `2` | `false` / `true` | 同上 |
| `light` | `3` | `false` / `true` | 同上 |
| `light` | `4` | `false` / `true` | 同上 |
| `light` | `5` | `false` / `true` | 同上 |

> 共 **2 theme × 4 count × 2 jumpable = 16 个变体**（与设计稿 16 variants 对应）。

### 11.4 进度条分页器

| count | padding | segmentState 组合 |
|-------|---------|-----------------|
| 2~12 | `0` / `spacing-l`（@2x 24px）/ `spacing-xl`（@2x 32px） | active + partial + inactive（任意组合） |

> 共 11 段数 × 3 边距选项 = **33 种主要变体**，segment 状态动态变化。

---

## 12. 使用约束（AI 生成时的硬性规则）

1. **点状/横滑项数限制**：建议 ≤ 5 项；超过 5 项时改用 `numeric` 或 `progress`
2. **颜色不可跨方案混用**：`dark-bg` 和 `light-bg` 各有适用背景，不可将 `dark-bg` 颜色用于浅色背景
3. **横条最短限制**：横滑分页器横条宽度 **最短不小于 2 倍高度（≥8pt）**
4. **进度条必须有边距**：撑满页面时必须保留左右边距（默认 `spacing-l` 12pt）；局部使用时可为 0
5. **文字分页器选项与容器宽度自适应**：选项宽度随文字内容撑开（左右 padding 各 `spacing-m` 10pt 固定），容器宽度跟随所有选项总和自动变化，❌ 禁止固定宽度
6. **不可跨类型混用样式**：各分页器类型有独立的颜色体系，禁止将 `dot` 的品牌黄直接用于 `progress`
7. **深色背景配蒙层**：叠加在浅色背景/图片上时，如背景复杂，建议配合半透明蒙层确保分页器可见
8. **进度条总宽自适应**：可根据实际设计调整进度条整体宽度，不强制 750px
9. **Token 强制引用**：禁止直接写 hex / 裸数值，颜色必须引用 `color-semantic.md` 语义 Token，间距必须引用 `component-spacing.md` Token，圆角必须引用 `component-radius.md` Token
10. **文字分页器跳转项分割线**：跳转分割线 opacity 固定 60%，颜色与容器主题保持一致（深色=`white`，浅色=`stroke-default-alpha`）

---

## 13. 常见组合示例

### 13.1 Banner 轮播（点状分页器，默认方案，叠加在图片内）

```
PageIndicator
  indicatorType: dot
  size: standard
  count: 4
  activeIndex: 1
  colorScheme: dark-bg
  // 叠加在 Banner 内部，距底部 spacing-s（8pt）
```

### 13.2 商品图片轮播（横滑分页器，品牌色）

```
PageIndicator
  indicatorType: swipe
  count: 5
  activeIndex: 2
  colorScheme: brand
  padding: 24
  // 横条随滚动位置动态移动，位置 = activeIndex × (1/count)
```

### 13.3 多图集（数字分页器，深色主题）

```
PageIndicator
  indicatorType: numeric
  count: 12
  current: 3
  theme: dark
  // 显示 "3 / 12"
```

### 13.4 内容切换（文字分页器，浅色主题，带跳转）

```
PageIndicator
  indicatorType: text
  options: ["推荐", "附近", "新品"]
  activeIndex: 0
  theme: light
  jumpable: true
  onJump: () => openJumpDialog()
  onChange: (i) => setActiveTab(i)
```

### 13.5 视频章节（进度条分页器，4 段，50% 边距 0）

```
PageIndicator
  indicatorType: progress
  count: 4
  activeIndex: 1
  progress: 0.5  // 第 2 段播放到 50%
  padding: 0     // 局部使用，无边距
```

---

## 14. 与其他组件的关系

| 关联组件 | 关系说明 |
|----------|----------|
| `bottom sheets.md` | Bottom Sheet 底部弹出时，分页器常用于其内部 Banner 轮播 |
| `navigation.md` | 顶部导航配合文字分页器（tab 类使用场景） |
| `dialog.md` | 弹窗内的图片集常用数字分页器显示总数 |
| `filter.md` | 筛选场景下，多组内容切换可使用文字分页器辅助导航 |

---

## 15. 2倍图样式源码（设计稿标注）

> 本章节记录从设计稿组件集中提取的 **@2x 像素级样式代码**，用于与第 2-6 章规格进行比对校验。
> 所有尺寸均为 2x 值（除以 2 即为 pt 逻辑值）。

### 15.1 点状分页器（dot）

> 画板容器：`797×414px`，圆角 `40px`，虚线边框 `3px`（`text-primary`）。
> 包含 6 个变体：3 种 colorScheme × 2 种 size（compact / standard）。

#### compact 尺寸（高度 6px / 逻辑值 3pt）

| 变体 | colorScheme | 选中条尺寸 | 选中条圆角 | 选中条颜色 | 圆点尺寸 | 圆点圆角 | 圆点颜色 | 间距 | 描边 |
|------|-------------|-----------|-----------|-----------|---------|---------|---------|------|------|
| spot-3 | `default` | `20×6px` | `3px`（`radius-full`） | `yellow-default`（`#FFDD00`） | `6×6px` | `3px`（`radius-full`） | `stroke-default-alpha`（`rgba(0,0,0,0.1)`） | `8px`（`spacing-2xs`） | 无 |
| spot-2 | `light-bg` | `20×6px` | `3px`（`radius-full`） | `text-disabled-alpha`（`rgba(0,0,0,0.24)`） | `6×6px` | `3px`（`radius-full`） | `stroke-default-alpha`（`rgba(0,0,0,0.1)`） | `8px`（`spacing-2xs`） | 选中条：`22×8px` 圆角`4px` `rgba(255,255,255,0.48)` 1px；圆点：`8×8px` 圆角`4px` `rgba(255,255,255,0.48)` 1px |
| spot-1 | `dark-bg` | `20×6px` | `3px`（`radius-full`） | `white`（`#FFFFFF`） | `6×6px` | `3px`（`radius-full`） | `white-60`（`rgba(255,255,255,0.6)`） | `8px`（`spacing-2xs`） | 选中条：`22×8px` 圆角`8px` `stroke-default-alpha`（`rgba(0,0,0,0.1)`） 1px；圆点：`8×8px` 圆角`8px` `stroke-default-alpha`（`rgba(0,0,0,0.1)`） 1px |

#### standard 尺寸（高度 8px / 逻辑值 4pt）

| 变体 | colorScheme | 选中条尺寸 | 选中条圆角 | 选中条颜色 | 圆点尺寸 | 圆点圆角 | 圆点颜色 | 间距 | 描边 |
|------|-------------|-----------|-----------|-----------|---------|---------|---------|------|------|
| spot-4 | `default` | `24×8px` | `4px`（`radius-full`） | `yellow-default`（`#FFDD00`） | `8×8px` | `4px`（`radius-full`） | `stroke-default-alpha`（`rgba(0,0,0,0.1)`） | `8px`（`spacing-2xs`） | 无 |
| spot-5 | `light-bg` | `24×8px` | `4px`（`radius-full`） | `text-disabled-alpha`（`rgba(0,0,0,0.24)`） | `8×8px` | `4px`（`radius-full`） | `stroke-default-alpha`（`rgba(0,0,0,0.1)`） | `8px`（`spacing-2xs`） | 选中条：`26×10px` 圆角`6px` `rgba(255,255,255,0.48)` 1px；圆点：`10×10px` 圆角`6px` `rgba(255,255,255,0.48)` 1px |
| spot-6 | `dark-bg` | `24×8px` | `4px`（`radius-full`） | `white`（`#FFFFFF`） | `8×8px` | `4px`（`radius-full`） | `white-60`（`rgba(255,255,255,0.6)`） | `8px`（`spacing-2xs`） | 选中条：`26×10px` 圆角`5px` `stroke-default-alpha`（`rgba(0,0,0,0.1)`） 1px；圆点：`10×10px` 圆角`5px` `stroke-default-alpha`（`rgba(0,0,0,0.1)`） 1px |

### 15.2 横滑分页器（swipe）

> 展示 `brand` 方案（品牌黄横条），2页示例（横条宽 = 滑轨宽 ÷ 2）。

| 属性 | 值（@2x） | 逻辑值（÷2） |
|------|----------|------------|
| 组件整体尺寸 | `48×8px` | **`24×4pt`** |
| 组件圆角 | `5000px`（`radius-full`） | 胶囊形 |
| 滑轨背景色 | `rgba(0,0,0,0.06)`（`bg-overlay-ultra-light-06`） | 黑色 6% |
| 横条尺寸 | `24×8px` | **`12×4pt`** |
| 横条圆角 | `5000px`（`radius-full`） | 胶囊形 |
| 横条颜色（brand） | `yellow-default`（`#FFDD00`） | 品牌黄 |
| 横条间距（column-gap） | `10px` | **`5pt`** |

```css
/* 横滑分页器 @2x 源码（brand 方案）*/
.component {
    width: 48px; height: 8px;
    border-radius: var(--radius-full); /* radius-full */
    overflow: hidden;
    background: var(--color-bg-overlay-ultra-light-06); /* bg-overlay-ultra-light-06 */

    .frame {
        position: absolute; top: 0px; left: 0px;
        width: 48px; height: 8px;
        display: flex; flex-direction: row; justify-content: start; align-items: center; column-gap: 10px; /* spacing-2xs×2.5，间距5pt */

        .rectangle { /* 横条（brand 方案，2页时宽=滑轨/2） */
            flex-shrink: 0;
            width: 24px; height: 8px;
            border-radius: var(--radius-full); /* radius-full */
            background: var(--color-yellow-default); /* yellow-default */
        }
    }
}
```

---

```css
/* 点状分页器 @2x 源码 */
.page-indicator-spot {
    width: 797px;
    height: 414px;
    border-radius: 40px;
    border: 3px dashed var(--color-text-primary); /* text-primary */

    /* ── compact / dark-bg (spot-1) ── */
    .page-indicator-spot-1 {
        position: absolute; top: 80px; left: 677px;
        width: 34px; height: 6px;
        display: flex; flex-direction: row; align-items: center;
        .indicator-slot-3 {
            width: 34px; height: 6px;
            display: flex; flex-direction: row; align-items: center; column-gap: var(--spacing-2xs); /* spacing-2xs */
            .select { /* 选中条 */
                width: 20px; height: 6px; border-radius: 3px; /* radius-full */
                background: var(--color-white); /* white */
                .stroke { /* 描边层 */
                    position: absolute; top: -1px; left: -1px; right: -1px; bottom: -1px;
                    width: 22px; height: 8px; border-radius: 8px; /* radius-full */
                    border: 1px solid var(--color-stroke-default-alpha); /* stroke-default-alpha */
                }
            }
            .dot { /* 未选圆点 */
                width: 6px; height: 6px; border-radius: 3px; /* radius-full */
                background: var(--color-white-60); /* white-60 */
                .stroke-1 {
                    position: absolute; top: -1px; left: -1px; right: -1px; bottom: -1px;
                    width: 8px; height: 8px; border-radius: 8px; /* radius-full */
                    border: 1px solid var(--color-stroke-default-alpha); /* stroke-default-alpha */
                }
            }
        }
    }

    /* ── compact / light-bg (spot-2) ── */
    .page-indicator-spot-2 {
        position: absolute; top: 80px; left: 378px;
        width: 34px; height: 6px;
        display: flex; flex-direction: row; align-items: center;
        .indicator-slot-2 {
            width: 34px; height: 6px;
            display: flex; flex-direction: row; align-items: center; column-gap: var(--spacing-2xs); /* spacing-2xs */
            .select-1 { /* 选中条 */
                width: 20px; height: 6px; border-radius: 3px; /* radius-full */
                background: var(--color-text-disabled-alpha); /* text-disabled-alpha */
                .stroke-2 {
                    position: absolute; top: -1px; left: -1px; right: -1px; bottom: -1px;
                    width: 22px; height: 8px; border-radius: 4px; /* radius-full */
                    border: 1px solid rgba(255, 255, 255, 0.48); /* white-48（无精确 token，设计稿原值） */
                }
            }
            .dot-1 { /* 未选圆点 */
                width: 6px; height: 6px; border-radius: 3px; /* radius-full */
                background: var(--color-stroke-default-alpha); /* stroke-default-alpha */
                .stroke-3 {
                    position: absolute; top: -1px; left: -1px; right: -1px; bottom: -1px;
                    width: 8px; height: 8px; border-radius: 4px; /* radius-full */
                    border: 1px solid rgba(255, 255, 255, 0.48); /* white-48（无精确 token，设计稿原值） */
                }
            }
        }
    }

    /* ── compact / default (spot-3) ── */
    .page-indicator-spot-3 {
        position: absolute; top: 80px; left: 80px;
        width: 34px; height: 6px;
        display: flex; flex-direction: row; align-items: center;
        .indicator-slot-1 {
            width: 34px; height: 6px;
            display: flex; flex-direction: row; align-items: center; column-gap: var(--spacing-2xs); /* spacing-2xs */
            .select-2 { /* 选中条 */
                width: 20px; height: 6px; border-radius: 3px; /* radius-full */
                overflow: hidden;
                background: var(--color-yellow-default); /* yellow-default */
            }
            .dot-2 { /* 未选圆点 */
                width: 6px; height: 6px; border-radius: 3px; /* radius-full */
                overflow: hidden;
                background: var(--color-stroke-default-alpha); /* stroke-default-alpha */
            }
        }
    }

    /* ── standard / default (spot-4) ── */
    .page-indicator-spot-4 {
        position: absolute; top: 326px; left: 80px;
        width: 40px; height: 8px;
        display: flex; flex-direction: row; align-items: center;
        .indicator-slot-4 {
            width: 40px; height: 8px;
            display: flex; flex-direction: row; align-items: center; column-gap: var(--spacing-2xs); /* spacing-2xs */
            .select-3 { /* 选中条 */
                width: 24px; height: 8px; border-radius: 4px; /* radius-full */
                overflow: hidden;
                background: var(--color-yellow-default); /* yellow-default */
            }
            .dot-3 { /* 未选圆点 */
                width: 8px; height: 8px; border-radius: 4px; /* radius-full */
                overflow: hidden;
                background: var(--color-stroke-default-alpha); /* stroke-default-alpha */
            }
        }
    }

    /* ── standard / light-bg (spot-5) ── */
    .page-indicator-spot-5 {
        position: absolute; top: 326px; left: 378px;
        width: 40px; height: 8px;
        display: flex; flex-direction: row; align-items: center;
        .indicator-slot-5 {
            width: 40px; height: 8px;
            display: flex; flex-direction: row; align-items: center; column-gap: var(--spacing-2xs); /* spacing-2xs */
            .select-4 { /* 选中条 */
                width: 24px; height: 8px; border-radius: 4px; /* radius-full */
                background: var(--color-text-disabled-alpha); /* text-disabled-alpha */
                .stroke-4 {
                    position: absolute; top: -1px; left: -1px; right: -1px; bottom: -1px;
                    width: 26px; height: 10px; border-radius: 6px; /* radius-full */
                    border: 1px solid rgba(255, 255, 255, 0.48); /* white-48（无精确 token，设计稿原值） */
                }
            }
            .dot-4 { /* 未选圆点 */
                width: 8px; height: 8px; border-radius: 4px; /* radius-full */
                background: var(--color-stroke-default-alpha); /* stroke-default-alpha */
                .stroke-5 {
                    position: absolute; top: -1px; left: -1px; right: -1px; bottom: -1px;
                    width: 10px; height: 10px; border-radius: 6px; /* radius-full */
                    border: 1px solid rgba(255, 255, 255, 0.48); /* white-48（无精确 token，设计稿原值） */
                }
            }
        }
    }

    /* ── standard / dark-bg (spot-6) ── */
    .page-indicator-spot-6 {
        position: absolute; top: 326px; left: 677px;
        width: 40px; height: 8px;
        display: flex; flex-direction: row; align-items: center;
        .indicator-slot-6 {
            width: 40px; height: 8px;
            display: flex; flex-direction: row; align-items: center; column-gap: var(--spacing-2xs); /* spacing-2xs */
            .select-5 { /* 选中条 */
                width: 24px; height: 8px; border-radius: 4px; /* radius-full */
                background: var(--color-white); /* white */
                .stroke-6 {
                    position: absolute; top: -1px; left: -1px; right: -1px; bottom: -1px;
                    width: 26px; height: 10px; border-radius: 5px; /* radius-full */
                    border: 1px solid var(--color-stroke-default-alpha); /* stroke-default-alpha */
                }
            }
            .dot-5 { /* 未选圆点 */
                width: 8px; height: 8px; border-radius: 4px; /* radius-full */
                background: var(--color-white-60); /* white-60 */
                .stroke-7 {
                    position: absolute; top: -1px; left: -1px; right: -1px; bottom: -1px;
                    width: 10px; height: 10px; border-radius: 5px; /* radius-full */
                    border: 1px solid var(--color-stroke-default-alpha); /* stroke-default-alpha */
                }
            }
        }
    }
}
```

### 15.3 数字分页器（numeric）

> 画板容器：`797×208px`，圆角 `40px`，虚线边框 `3px`（`text-primary`）。
> 包含 2 个变体：`dark` 主题 / `light` 主题。

| 属性 | dark 主题 | light 主题 |
|------|----------|-----------|
| 容器尺寸 | 高度 `48px`（→ **`24pt`**），宽度**自适应** | 高度 `48px`（→ **`24pt`**），宽度**自适应** |
| 容器圆角 | `5000px`（`radius-full`，胶囊） | `5000px`（`radius-full`，胶囊） |
| 容器背景色 | `rgba(0,0,0,0.4)`（`bg-overlay-dark-40`） | `rgba(255,255,255,0.8)`（`white-80`） |
| 内边距 | `8px 20px`（→ **`spacing-2xs` `spacing-m`**，即 `4pt 10pt`） | `8px 20px`（→ **`spacing-2xs` `spacing-m`**，即 `4pt 10pt`） |
| 数字间距（column-gap） | `2px`（→ **`1pt`**） | `2px`（→ **`1pt`**） |
| 字号 | `24px`（→ **`12pt`**，`body-s-12-medium`） | `24px`（→ **`12pt`**，`body-s-12-medium`） |
| 行高 | `32px`（→ **`16pt`**） | `32px`（→ **`16pt`**） |
| 字重 | `500` | `500` |
| 文字颜色 | `#FFFFFF`（`white`） | `#111111`（`text-primary`） |
| 字体 | `PingFang SC` | `PingFang SC` |

```css
/* 数字分页器 @2x 源码 */
.page-indicator-number {
    width: 797px;
    height: 208px;
    border-radius: 40px;
    border: 3px dashed var(--color-text-primary); /* text-primary */

    /* ── light 主题 (number-1) ── */
    .page-indicator-number-1 {
        position: absolute; top: 80px; left: 326px;
        width: 86px; height: 48px;
        border-radius: var(--radius-full); /* radius-full */
        display: flex; flex-direction: row; align-items: center; column-gap: 2px; /* 1pt，数字间距 */
        padding: var(--spacing-2xs) var(--spacing-m); /* spacing-2xs spacing-m（4pt 10pt） */
        background: var(--color-white-80); /* white-80 */
        .current-page { width: 15px; height: 32px; color: var(--color-text-primary); /* text-primary */ font-family: "PingFang SC"; font-size: 24px; /* body-s-12-medium */ line-height: 32px; font-weight: 500; }
        .slash       { width: 12px; height: 32px; color: var(--color-text-primary); /* text-primary */ font-family: "PingFang SC"; font-size: 24px; /* body-s-12-medium */ line-height: 32px; font-weight: 500; }
        .total-pages { width: 15px; height: 32px; color: var(--color-text-primary); /* text-primary */ font-family: "PingFang SC"; font-size: 24px; /* body-s-12-medium */ line-height: 32px; font-weight: 500; }
    }

    /* ── dark 主题 (number-2) ── */
    .page-indicator-number-2 {
        position: absolute; top: 80px; left: 80px;
        width: 86px; height: 48px;
        border-radius: var(--radius-full); /* radius-full */
        display: flex; flex-direction: row; align-items: center; column-gap: 2px; /* 1pt，数字间距 */
        padding: var(--spacing-2xs) var(--spacing-m); /* spacing-2xs spacing-m（4pt 10pt） */
        background: var(--color-bg-overlay-dark-40); /* bg-overlay-dark-40 */
        .current-page-1 { width: 15px; height: 32px; color: var(--color-white); /* white */ font-family: "PingFang SC"; font-size: 24px; /* body-s-12-medium */ line-height: 32px; font-weight: 500; }
        .slash-1        { width: 12px; height: 32px; color: var(--color-white); /* white */ font-family: "PingFang SC"; font-size: 24px; /* body-s-12-medium */ line-height: 32px; font-weight: 500; }
        .total-pages-1  { width: 15px; height: 32px; color: var(--color-white); /* white */ font-family: "PingFang SC"; font-size: 24px; /* body-s-12-medium */ line-height: 32px; font-weight: 500; }
    }
}
```

### 15.4 文字分页器（text）

> 画板容器：`797×1104px`，圆角 `40px`，虚线边框 `3px`（`text-primary`）。
> 包含 4 个变体：2 种 theme（dark / light）× 2 种 jumpable（false / true），均展示 2 个选项。

#### 容器规格

| 属性 | dark 主题 | light 主题 |
|------|----------|-----------|
| 容器尺寸（2项，无跳转） | `172×48px`（→ **`86×24pt`**） | `172×48px`（→ **`86×24pt`**） |
| 容器尺寸（2项，有跳转） | `265×48px`（→ **`132.5×24pt`**） | `265×48px`（→ **`132.5×24pt`**） |
| 容器高度 | `48px`（→ **`24pt`**） | `48px`（→ **`24pt`**） |
| 容器圆角 | `24px`（→ **`12pt`**，`radius-m`） | `24px`（→ **`12pt`**，`radius-m`） |
| 容器内边距 | `2px`（→ **`1pt`**，四边均匀） | `2px`（→ **`1pt`**，四边均匀） |
| 容器背景色 | `rgba(0,0,0,0.4)`（`bg-overlay-dark-40`） | `rgba(245,245,245,0.75)`（浅灰75%，无精确 token） |
| 容器描边 | 无 | `1px solid rgba(0,0,0,0.06)`（→ `0.5pt`，`divider-secondary`） |

#### 选项规格

| 属性 | 选中项 | 未选项 |
|------|-------|-------|
| 选项尺寸 | `84×44px`（→ **`42×22pt`**） | `84×44px`（→ **`42×22pt`**） |
| 选项圆角 | `40px`（`radius-full`，胶囊） | 无圆角 |
| 选项内边距 | `6px 20px`（→ **`3pt`（无精确 token）`spacing-m`（10pt）**） | `6px 20px`（→ **`3pt` `spacing-m`（10pt）**） |
| 选项背景色 | `#FFFFFF`（`white`） | 透明 |
| 文字颜色（dark） | `#111111`（`text-primary`） | `#FFFFFF`（`white`） |
| 文字颜色（light） | `#111111`（`text-primary`） | `#555555`（`text-secondary`） |
| 字号 | `22px`（→ **`11pt`**，`caption-l-11-medium`） | `22px`（→ **`11pt`**，`caption-l-11-regular`） |
| 行高 | `32px`（→ **`16pt`**） | `32px`（→ **`16pt`**） |
| 字重（选中） | `500` | — |
| 字重（未选） | — | `400` |

#### 跳转区规格（jumpable=true）

| 属性 | dark 主题 | light 主题 |
|------|----------|-----------|
| 分割线尺寸 | `1×20px`（→ **`0.5×10pt`**） | `1×20px`（→ **`0.5×10pt`**） |
| 分割线颜色 | `#FFFFFF`（`white`），opacity `0.6` | `rgba(0,0,0,0.1)`（`stroke-default-alpha`） |
| 跳转区尺寸 | `92×44px`（→ **`46×22pt`**） | `92×44px`（→ **`46×22pt`**） |
| 跳转区内边距 | `6px 14px 6px 16px`（→ **`3pt 7pt 3pt spacing-s`（8pt）**） | `6px 14px 6px 16px`（→ **`3pt 7pt 3pt spacing-s`（8pt）**） |
| 跳转文字颜色 | `#FFFFFF`（`white`） | `#555555`（`text-secondary`） |
| 跳转图标尺寸 | `18×18px`（→ **`9×9pt`**） | `18×18px`（→ **`9×9pt`**） |

```css
/* 文字分页器 @2x 源码 */
.page-indicator-text {
    width: 797px;
    height: 1104px;
    border-radius: 40px;
    border: 3px dashed var(--color-text-primary); /* text-primary */

    /* ── dark / jumpable=false (text-1) ── */
    .page-indicator-text-1 {
        position: absolute; top: 192px; left: 80px;
        width: 172px; height: 48px;
        border-radius: var(--radius-m); /* radius-m */
        display: flex; flex-direction: row; align-items: center;
        padding: 2px; /* 1pt 四边 */
        background: var(--color-bg-overlay-dark-40); /* bg-overlay-dark-40 */
        .indicator-slot-1 {
            width: 168px; height: 44px;
            display: flex; flex-direction: row; align-items: center;
            .option { /* 选中项 */
                width: 84px; height: 44px; border-radius: var(--radius-full); /* radius-full */
                display: flex; flex-direction: column; justify-content: center; align-items: center;
                padding: 6px var(--spacing-m); /* 3pt spacing-m（10pt） */
                background: var(--color-white); /* white */
                .text { width: 44px; height: 32px; color: var(--color-text-primary); /* text-primary */ font-family: "PingFang SC"; font-size: 22px; /* caption-l-11-medium */ line-height: 32px; font-weight: 500; text-align: center; }
            }
            .option-1 { /* 未选项 */
                width: 84px; height: 44px;
                display: flex; flex-direction: column; justify-content: center; align-items: center;
                padding: 6px var(--spacing-m); /* 3pt spacing-m（10pt） */
                .text-1 { width: 44px; height: 32px; color: var(--color-white); /* white */ font-family: "PingFang SC"; font-size: 22px; /* caption-l-11-regular */ line-height: 32px; font-weight: 400; }
            }
        }
    }

    /* ── dark / jumpable=true (text-2) ── */
    .page-indicator-text-2 {
        position: absolute; top: 192px; left: 452px;
        width: 265px; height: 48px;
        border-radius: var(--radius-m); /* radius-m */
        display: flex; flex-direction: row; align-items: center;
        padding: 2px; /* 1pt 四边 */
        background: var(--color-bg-overlay-dark-40); /* bg-overlay-dark-40 */
        .indicator-slot-2 {
            width: 168px; height: 44px;
            display: flex; flex-direction: row; align-items: center;
            .option-2 { /* 选中项 */
                width: 84px; height: 44px; border-radius: var(--radius-full); /* radius-full */
                display: flex; flex-direction: column; justify-content: center; align-items: center;
                padding: 6px var(--spacing-m); /* 3pt spacing-m（10pt） */
                background: var(--color-white); /* white */
                .text-2 { width: 44px; height: 32px; color: var(--color-text-primary); /* text-primary */ font-family: "PingFang SC"; font-size: 22px; /* caption-l-11-medium */ line-height: 32px; font-weight: 500; text-align: center; }
            }
            .option-3 { /* 未选项 */
                width: 84px; height: 44px;
                display: flex; flex-direction: column; justify-content: center; align-items: center;
                padding: 6px var(--spacing-m); /* 3pt spacing-m（10pt） */
                .text-3 { width: 44px; height: 32px; color: var(--color-white); /* white */ font-family: "PingFang SC"; font-size: 22px; /* caption-l-11-regular */ line-height: 32px; font-weight: 400; }
            }
        }
        .divider { /* 分割线 */
            width: 1px; height: 20px;
            opacity: 0.6;
            background: var(--color-white); /* white */
        }
        .text-button { /* 跳转区 */
            width: 92px; height: 44px;
            display: flex; flex-direction: row; align-items: center;
            padding: 6px 14px 6px var(--spacing-s); /* 3pt 7pt 3pt spacing-s（8pt） */
            .button-text { width: 44px; height: 32px; color: var(--color-white); /* white */ font-family: "PingFang SC"; font-size: 22px; /* caption-l-11-regular */ line-height: 32px; font-weight: 400; text-align: center; }
            .instance { width: 18px; height: 18px; } /* 箭头图标 */
        }
    }

    /* ── light / jumpable=false (text-3) ── */
    .page-indicator-text-3 {
        position: absolute; top: 864px; left: 80px;
        width: 172px; height: 48px;
        border-radius: var(--radius-m); /* radius-m */
        display: flex; flex-direction: row; align-items: center;
        padding: 2px; /* 1pt 四边 */
        background: rgba(245, 245, 245, 0.75); /* 浅灰75%，无精确 token */
        border: 1px solid var(--color-divider-secondary); /* divider-secondary */
        box-sizing: content-box;
        .indicator-slot-3 {
            width: 168px; height: 44px;
            display: flex; flex-direction: row; align-items: center;
            .option-4 { /* 选中项 */
                width: 84px; height: 44px; border-radius: var(--radius-full); /* radius-full */
                display: flex; flex-direction: column; justify-content: center; align-items: center;
                padding: 6px var(--spacing-m); /* 3pt spacing-m（10pt） */
                background: var(--color-white); /* white */
                .text-4 { width: 44px; height: 32px; color: var(--color-text-primary); /* text-primary */ font-family: "PingFang SC"; font-size: 22px; /* caption-l-11-medium */ line-height: 32px; font-weight: 500; text-align: center; }
            }
            .option-5 { /* 未选项 */
                width: 84px; height: 44px;
                display: flex; flex-direction: column; justify-content: center; align-items: center;
                padding: 6px var(--spacing-m); /* 3pt spacing-m（10pt） */
                .text-5 { width: 44px; height: 32px; color: var(--color-text-secondary); /* text-secondary */ font-family: "PingFang SC"; font-size: 22px; /* caption-l-11-regular */ line-height: 32px; font-weight: 400; text-align: center; }
            }
        }
    }

    /* ── light / jumpable=true (text-4) ── */
    .page-indicator-text-4 {
        position: absolute; top: 864px; left: 452px;
        width: 265px; height: 48px;
        border-radius: var(--radius-m); /* radius-m */
        display: flex; flex-direction: row; align-items: center;
        padding: 2px; /* 1pt 四边 */
        background: rgba(245, 245, 245, 0.75); /* 浅灰75%，无精确 token */
        border: 1px solid var(--color-divider-secondary); /* divider-secondary */
        box-sizing: content-box;
        .indicator-slot-4 {
            width: 168px; height: 44px;
            display: flex; flex-direction: row; align-items: center;
            .option-6 { /* 选中项 */
                width: 84px; height: 44px; border-radius: var(--radius-full); /* radius-full */
                display: flex; flex-direction: column; justify-content: center; align-items: center;
                padding: 6px var(--spacing-m); /* 3pt spacing-m（10pt） */
                background: var(--color-white); /* white */
                .text-6 { width: 44px; height: 32px; color: var(--color-text-primary); /* text-primary */ font-family: "PingFang SC"; font-size: 22px; /* caption-l-11-medium */ line-height: 32px; font-weight: 500; text-align: center; }
            }
            .option-7 { /* 未选项 */
                width: 84px; height: 44px;
                display: flex; flex-direction: column; justify-content: center; align-items: center;
                padding: 6px var(--spacing-m); /* 3pt spacing-m（10pt） */
                .text-7 { width: 44px; height: 32px; color: var(--color-text-secondary); /* text-secondary */ font-family: "PingFang SC"; font-size: 22px; /* caption-l-11-regular */ line-height: 32px; font-weight: 400; text-align: center; }
            }
        }
        .divider-1 { /* 分割线，light主题无opacity */
            width: 1px; height: 20px;
            background: var(--color-stroke-default-alpha); /* stroke-default-alpha */
        }
        .text-button-1 { /* 跳转区 */
            width: 92px; height: 44px;
            display: flex; flex-direction: row; align-items: center;
            padding: 6px 14px 6px var(--spacing-s); /* 3pt 7pt 3pt spacing-s（8pt） */
            .button-text-1 { width: 44px; height: 32px; color: var(--color-text-secondary); /* text-secondary */ font-family: "PingFang SC"; font-size: 22px; /* caption-l-11-regular */ line-height: 32px; font-weight: 400; text-align: center; }
            .instance-1 { width: 18px; height: 18px; } /* 箭头图标 */
        }
    }
}
```

### 15.5 进度条分页器（progress）

> 展示 2 段（1段激活`active` + 1段进行中`partial`），左右边距 `24px`（→ **`12pt`**，`spacing-l`）。

| 属性 | 值（@2x） | 逻辑值（÷2） |
|------|----------|------------|
| 组件整体宽度 | `456px` | **`228pt`** |
| 组件高度 | `4px` | **`2pt`** |
| 左右边距（padding） | `24px`（`spacing-l`） | **`12pt`** |
| 轨道内容宽度 | `408px`（456 - 24×2） | **`204pt`** |
| 段间距（column-gap） | `8px`（`spacing-2xs`） | **`4pt`** |
| 段高度 | `4px` | **`2pt`** |
| 段圆角 | `2px`（`radius-xxs`） | **`1pt`** |
| 激活段（active）颜色 | `rgba(255,255,255,0.8)`（`white-80`） | 白色 80% |
| 未激活段（inactive）颜色 | `rgba(255,255,255,0.4)`（`white-40`） | 白色 40% |
| 子进度条圆角 | `5000px`（`radius-full`） | 胶囊形 |
| 子进度条颜色 | `rgba(255,255,255,0.8)`（`white-80`） | 白色 80% |

```css
/* 进度条分页器 @2x 源码 */
.page-indicator-progress-bar {
    width: 456px;
    height: 4px;
    display: flex; flex-direction: row; align-items: center;
    padding: 0px var(--spacing-l); /* 0 spacing-l（12pt） */

    .progress-bar-slot {
        flex-grow: 1;
        width: 408px; height: 4px;
        display: flex; flex-direction: row; align-items: center; column-gap: var(--spacing-2xs); /* spacing-2xs */

        .progress { /* active 段 */
            flex-grow: 1;
            width: 200px; height: 4px;
            border-radius: var(--radius-xxs); /* radius-xxs */
            overflow: hidden;
            background: var(--color-white-80); /* white-80 */
        }

        .progress-1 { /* partial 段（进行中） */
            flex-grow: 1;
            width: 200px; height: 4px;
            border-radius: var(--radius-xxs); /* radius-xxs */
            overflow: hidden;
            background: var(--color-white-40); /* white-40 */

            .progress-2 { /* 子进度条（50%示例） */
                position: absolute; top: 0px; left: 0px; right: 100px; bottom: 0px;
                width: 100px; height: 4px;
                border-radius: var(--radius-full); /* radius-full */
                background: var(--color-white-80); /* white-80 */
            }
        }
    }
}
```