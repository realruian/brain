# Notice Bar 通告栏

> **组件分类**：Component（组件级）
> **定义**：通告栏用于向用户传递重要信息通知、促销提醒、系统提示等，固定展示于页面顶部或内容区，不可被用户主动打开，可根据业务需求允许用户关闭。
> **Style 依赖**：`color-semantic.md` · `font-semantic.md` · `spacing-semantic.md` · `component-spacing.md` · `radius-semantic.md` · `component-radius.md` · `stroke-semantic.md`

> ⚠️ **核心约束**：
> - 通告栏可分为**基础型**、**跳转型**、**跳转关闭型**三大功能类型
> - 尺寸分为**标准**（对屏效要求适中）和**宽松**（对屏效要求较低）两种
> - 行数分为**单行**和**双行**，不建议超过两行
> - **颜色不属于组件枚举变体**，须由业务根据优先级和使用背景自行配置
> - 通告栏外形分为**留边卡片**（默认，推荐）和**通栏**两种布局方式

---

## 0. 图标 / 间距 / Ownership 约束

- **icon-route（默认）**：组件自带图标按正文规则走 icon route，默认回 `component/atoms/icon.md` 并遵循既定 class / weight。
- **fixed-asset 例外**：正文若指定官方 SVG、`assets/*.svg`、PNG/CDN 或 URL 切图，该位点必须走 fixed-asset。
- **spacing-owner（归属）**：Notice Bar 内部内容区与图标的间距/对齐归本组件；页面外层容器留白与位置归宿主组件。
- **宿主裁决（优先级）**：冲突按 `宿主 > 组合场景 > 本组件`，宿主裁决外部挂载、上下占位与通栏关系。
- **不可跳步**：先回 `references/INDEX.md` 完成区域路由与宿主锁定，再用 `component-quickref.md` 做宿主级收敛；本文件仅承接组件内 ownership 细则，不承担前置路由改判；不得凭语义猜测。


## 1. 组件大类（noticeBarType）

| noticeBarType | 名称 | 右侧操作区 | 适用场景 |
|---------------|------|-----------|---------|
| `basic` | 基础型 | 仅关闭图标（可选） | 信息展示为主，用户可关闭或仅查看 |
| `link` | 跳转型 | 跳转引导（箭头 / 文字+箭头 / 按钮），不可关闭 | 引导用户跳转至详情页或相关页面 |
| `link-close` | 跳转关闭型 | 跳转引导 + 关闭图标 | 引导跳转，同时允许用户手动关闭 |

> **选型原则**：
> - 纯信息展示或可直接关闭 → `basic`
> - 必须引导用户跳转，不允许关闭 → `link`
> - 引导用户跳转，也允许用户关闭 → `link-close`

---

## 2. 行数（rowCount）

| rowCount | 名称 | 文案要求 | 说明 |
|----------|------|---------|------|
| `single` | 单行 | 文案在一行内完整展示 | 适用于简短提示 |
| `double` | 双行 | 文案最多展示两行 | 适用于较长信息，不建议超过两行 |

---

## 3. 尺寸（size）

| size | 名称 | 上下内边距 | 容器高度（单行） | 容器高度（双行） | 说明 |
|------|------|-----------|--------------|--------------|------|
| `standard` | 标准 | 8pt | **32pt** | **48pt** | 推荐，适用于对屏效要求适中的页面 |
| `loose` | 宽松 | 10pt | **36pt** | **52pt** | 适用于对屏效要求较低的页面 |

> ✅ **推荐**：标准 32pt 适用于大部分页面；宽松 36pt 用于屏效要求低的场景。
> 内容区左右内边距：均为 **12pt**（`spacing-l`）。

---

## 4. 跳转区样式（linkStyle）—— 跳转型专有

| linkStyle | 名称 | 操作区容器 @1x | 操作区容器 @2x | 内部结构 | 说明 |
|-----------|------|-------------|-------------|---------|------|
| `arrow` | 箭头 | 24×12pt | 48×24px | 箭头图标 12×12pt | 最简洁，仅箭头引导 |
| `text-arrow` | 文字+箭头 | 48×16pt | 96×32px | `padding-left: 12pt`（内容区安全间距）；跳转文字 12pt（`48×16pt`）+ 箭头图标 12×12pt，**文字与箭头之间无间距** | 文字（如"详情"）+ 右箭头 |
| `button` | 按钮 | 自适应×20pt | 自适应×40px | `padding-left: 12pt`（内容区安全间距）；按钮左右 padding **10pt**，宽度自适应内容，最多 4 个汉字（超出截断），圆角 10pt，字号 11pt/500，文字色 `#111111`，默认黄渐变背景 | 面性按钮，视觉最强 |

> **button 默认渐变色**（来自 2x 图）：`linear-gradient(135deg, #FFE74D 0%, #FFDD00 100%)`，文字色 `#111111`，圆角 `border-radius: 20px`。按钮高度固定 20pt，**左右 padding 10pt**，宽度自适应内容文字（最多 4 字，`max-width = 4字宽 + 10pt×2`）。

> **双行组合限制**：
> - 双行 跳转关闭型 中，"箭头+关闭" 组合视觉较奇怪，**不建议使用**
> - 双行 跳转关闭型 支持：按钮+关闭、文字+箭头+关闭

---

## 5. 布局方式（layout）

| layout | 名称 | 圆角 | 左右间距 | 说明 |
|--------|------|------|---------|------|
| `card` | 留边卡片 | **8pt** | 距页边 12pt | 默认，推荐使用 |
| `full-width` | 通栏 | **0px** | 与页面等宽 | 极度关注屏效时使用，圆角调为 0pt |

> **卡片圆角备注**：默认 8pt，结合实际场景可调整至 12pt（如贴近底部弹窗圆角等）。

> **通栏操作区间距规则**：`arrow` 类型全局无 `padding-left`；`text-arrow` 和 `button` 在留边卡片场景有 `padding-left: 12pt`，通栏（`full-width`）场景下需覆盖为 **0**，由内容区 `flex-grow:1` 自然撑开间距，无需额外 padding。

---

## 6. 结构规格

### 6.1 通用内部结构

```
[通告栏容器]  flex-direction: row，align-items: center（无 column-gap）
  [图标区]  15×15pt（可选，功能图标 12×12pt，flex-shrink: 0）
            └ margin-right: 4pt（仅图标右侧留 4pt 间距，容器本身不设 column-gap）
  [内容区]（flex-grow: 1，min-width: 0）
    [文案]  字号 12pt / 行高 16pt
              └ 单行：height 16pt，overflow hidden，white-space nowrap，text-overflow ellipsis
              └ 双行：height 32pt，无截断限制，自然换行（来自 2x 图 .text { height: 64px }）
  [操作区]（右侧，依类型不同，flex-shrink: 0，align-items: center 垂直居中）
            └ `arrow`：无 padding-left，内容区 flex-grow:1 自然撑开间距
            └ `text-arrow` / `button`：padding-left: 12pt（留边卡片）；通栏场景设为 0
            └ text-arrow: 文字与箭头图标之间无间距（gap: 0）
            └ button: 按钮左右 padding 10pt，宽度自适应内容，最多 4 个汉字
```

### 6.2 容器尺寸（@1x / @2x）

| size | 行数 | 高度 @1x | 高度 @2x | 上下内边距 @1x | 上下内边距 @2x | 左右内边距 @1x | 左右内边距 @2x | 圆角 @1x | 圆角 @2x |
|------|------|---------|---------|-------------|-------------|-------------|-------------|---------|--------|
| `standard` | `single` | **32pt** | 64px | 8pt | 16px | 12pt | 24px | 8pt | 16px |
| `loose` | `single` | **36pt** | 72px | 10pt | 20px | 12pt | 24px | 8pt | 16px |
| `standard` | `double` | **48pt** | 96px | 8pt | 16px | 12pt | 24px | 8pt | 16px |
| `loose` | `double` | **52pt** | 104px | 10pt | 20px | 12pt | 24px | 8pt | 16px |

> ⚠️ 以上 @2x 数据直接来源于组件集 2 倍图样式代码，可与设计稿直接对应。

### 6.3 内部元素尺寸（@1x / @2x）

| 元素 | 尺寸 @1x | 尺寸 @2x | 说明 |
|------|---------|---------|------|
| 左侧图标容器（`.instance`） | 15×15pt | 30×30px | `flex-shrink: 0` |
| 图标与内容区间距（`margin-right`） | **4pt** | 8px | 图标容器右侧 `margin-right`，**不使用** `column-gap`（避免影响内容区→操作区之间的间距） |
| 内容区（`.frame`，`flex-grow: 1`）– 单行 | 308×16pt | 616×32px | `flex-grow: 1`，高度 = 1 × 行高 |
| 内容区（`.frame`，`flex-grow: 1`）– 双行 | 308×32pt | 616×64px | `flex-grow: 1`，高度 = 2 × 行高，来自 2x 图 `.frame { height: 64px }` |
| 操作区容器 – `arrow`（`.action-arrow`） | 24×12pt | 48×24px | `flex-shrink: 0`，**无 padding-left**（内容区 `flex-grow:1` 自然撑开间距），仅含箭头图标 |
| 操作区容器 – `text-arrow`（`.action-text-arrow`） | 48×16pt | 96×32px | `flex-shrink: 0`，`padding-left: 12pt`（内容区与操作区安全间距），含文字+箭头图标，**文字与箭头 gap=0** |
| 操作区容器 – `button`（`.action-button-wrap`） | 自适应×16pt | 自适应×32px | `flex-shrink: 0`，`padding-left: 12pt`（内容区与操作区安全间距），含按钮本体（垂直居中） |
| 按钮本体（`.action-btn`） | **自适应**×20pt | **自适应**×40px | `border-radius: 10pt`，`padding: 0 10pt`，黄渐变背景，宽度自适应内容，最多 4 字 |
| 关闭图标容器（close 区） | 24×12pt | 48×24px | `flex-shrink: 0`，`basic` 型及 `link-close` 型独有，位于操作区最右侧 |
| 关闭图标本体 | 12×12pt | 24×24px | 图标尺寸，默认颜色 `text-tertiary`（`#999999`），居中显示于容器内 |

### 6.4 各类型右侧操作区规格

| noticeBarType | 操作区内容 | 操作区容器 @1x | 操作区容器 @2x |
|---------------|-----------|--------------|---------------|
| `basic` | 关闭图标 12×12pt | 24×12pt | 48×24px |
| `link` – arrow | 箭头图标 12×12pt，无 padding-left | 24×12pt | 48×24px |
| `link` – text-arrow | 跳转文字（48×16pt）+ 箭头图标（12×12pt），`padding-left: 12pt` | **48×16pt** | **96×32px** |
| `link` – button | 按钮本体（自适应×20pt），`padding-left: 12pt` | **自适应×20pt** | **自适应×40px** |
| `link-close` – text-arrow+close | text-arrow 容器（96×32px@2x）+ close 容器（48×24px@2x），内容区 `justify-content: end` | **48×16pt** + **24×12pt** | **96×32px** + **48×24px** |
| `link-close` – arrow+close | 内容区改为 `justify-content: space-between`；左侧：文字（120×16pt）+ 箭头图标（12×12pt），容器 72×16pt；右侧：close 容器 24×12pt | 72pt + 24pt | 144×32px + 48×24px |
| `link-close` – button+close | button 容器（108×32px@2x）+ close 容器（48×24px@2x），内容区 `justify-content: end` | **54×16pt** + **24×12pt** | **108×32px** + **48×24px** |

### 6.5 关闭区域详细规格

#### 结构

```
[close 容器]
  flex-shrink: 0
  width:  24pt (48px@2x)
  height: 12pt (24px@2x)
  display: flex
  justify-content: center
  align-items: center

  [关闭图标（×）]
    width:  12pt (24px@2x)
    height: 12pt (24px@2x)
    color:  #999999（text-tertiary）
```

#### 尺寸规格

| 属性 | @1x | @2x | 说明 |
|------|-----|-----|------|
| 容器宽度 | 24pt | 48px | `flex-shrink: 0`，固定宽度 |
| 容器高度 | 12pt | 24px | 垂直居中于内容区行高 |
| 图标宽度 | 12pt | 24px | 图标本体 |
| 图标高度 | 12pt | 24px | 图标本体 |
| 触控热区（最小） | 22×22pt | 44×44px | 需通过 padding 或透明层外扩，容器本身不足 |

#### 颜色规格

| 状态 | 图标颜色 | Token | 说明 |
|------|---------|-------|------|
| 默认 | `#999999` | `text-tertiary` | 弱化视觉权重，与文案区分 |
| 深色背景 | `#FFFFFF` | `white` | 背景为深色（如`#111111`）时切换 |

#### 各类型使用规则

| noticeBarType | 关闭图标 | 说明 |
|---------------|---------|------|
| `basic` | **可选** | 有关闭图标 = 可关闭；无关闭图标 = 纯展示（操作区为空） |
| `link` | **不可用** | 跳转型不允许关闭 |
| `link-close` | **必须** | 关闭图标容器位于操作区最右侧，跳转容器左侧 |

#### 在各操作区组合中的位置

```
basic（有关闭）：
  内容区 → [close 容器 24×12pt]

link-close – text-arrow+close：
  内容区 → [text-arrow 容器 48×16pt] [close 容器 24×12pt]
           ← justify-content: end ——————————————————→

link-close – arrow+close：
  内容区（justify-content: space-between）
  ← [左侧：文字+箭头 容器 72×16pt] ···· [close 容器 24×12pt] →

link-close – button+close：
  内容区 → [button 容器 54×16pt] [close 容器 24×12pt]
           ← justify-content: end ——————————————————→
```

> ⚠️ **热区外扩提示**：关闭图标容器高度仅 12pt（24px@2x），远小于无障碍最小触控尺寸 22pt。实现时必须通过负 margin、padding 扩展或透明遮罩层，将实际可点击区域扩展至不小于 **22×22pt**。

### 6.6 文案区宽度计算

```
【@1x 计算公式】
内容区宽 = 组件总宽 - 左右padding(12pt × 2) - 图标(15pt) - 图标间距(4pt)
文案宽   = 内容区宽 - 操作区容器宽

【@2x 实测值（来自 2 倍图代码，组件宽 702px）】
内容区宽  = 702 - 24×2 - 30 - 8 = 616px（对应 1x: 308pt）

── link（跳转型）─────────────────────────────────────────────
linkStyle    操作区容器@2x    文案宽@2x   文案宽@1x
──────────────────────────────────────────────────────────────
arrow        48px             568px       284pt   ← .text { width: 568px }
text-arrow   96px             520px       260pt   ← .text-1 { width: 520px }
button       108px            508px       254pt   ← .text-3 { width: 508px }

── link-close（跳转关闭型）────────────────────────────────────
linkStyle          操作区总宽@2x      文案宽@2x   文案宽@1x
──────────────────────────────────────────────────────────────
text-arrow+close   96+48 = 144px     472px       236pt   ← .text-5 { width: 472px }
arrow+close        space-between布局  —           —      ← 左侧 144px 容器（含文字120px+箭头24px），右侧 close 48px
button+close       108+48 = 156px    460px       230pt   ← .text-3/.text-8 { width: 460px }

── double（双行，文案宽度与对应单行 linkStyle 完全一致）────────
rowCount  linkStyle             文案宽@2x   文案宽@1x
──────────────────────────────────────────────────────────────
double    arrow                 568px       284pt   ← .text-9/.text-4 { width: 568px, height: 64px }
double    text-arrow            520px       260pt   ← .text-7/.text-2 { width: 520px, height: 64px }
double    button                508px       254pt   ← .text-5/.text   { width: 508px, height: 64px }
double    text-arrow+close      472px       236pt   ← .text-2/.text-6 { width: 472px, height: 64px }
double    button+close          460px       230pt   ← .text/.text-4   { width: 460px, height: 64px }
```

> ⚠️ 文案宽度随操作区宽度变化而变化，`arrow` 的文案最宽（284pt），`button+close` 最窄（230pt）。以上值均为 2x 图代码直接读取。
> `arrow+close` 因采用 `space-between` 布局，文案宽度由**左侧文字容器**决定（`.text-2 { width: 120px }` → **60pt**），而非右侧挤压。
> **双行与单行文案宽度相同**，区别在于：单行有 `overflow:hidden / white-space:nowrap / text-overflow:ellipsis`，双行无截断，文案高度从 16pt 扩展至 32pt（2x 图：32px → 64px）。

---

## 7. 颜色规格

通告栏颜色**不是组件枚举变体**，而是业务根据使用场景和优先级自行配置。组件中提供默认黄色温馨提醒色，其他颜色为设计参考示例。

### 7.1 颜色优先级与适用场景

| 优先级 | 场景语义 | 背景色（参考） | 图标/文字色（参考） | 使用背景 |
|--------|---------|--------------|----------------|---------|
| P0 | 促销、警告、中止、报错 | `#FFF1F0`（浅红/R1） | `#F52916`（R4） | 白色背景 |
| P1 | 温馨提醒、进行中（**默认**） | `#FFFADB`（浅黄/Y1） | `#7A3100`（黄橙色内容色） | 白色/浅灰色背景 |
| P2 | 品牌蓝色（如美团蓝） | `#E5EBF4`（浅蓝） | `#004099`（品牌蓝） | 白色背景 |
| P2 | 深色/黑色 | `#111111` | `#FFFFFF` | 白色背景 |
| P2 | 中性灰 | `#F5F5F5` | `#111111` | 白色背景 |
| P2 | 业务白色 | `#FFFFFF` | `#111111` | 浅灰色背景（#F5F5F5） |
| custom | 业务品牌色 | 自定义 | 自定义 | 可根据实际品牌色调整 |

> **颜色使用建议**：
> - P0 红色（FFF1F0/F52916）：促销、警告等高优先级信息，背景固定白色，**不建议调整**
> - P1 黄色（FFFADB/7A3100）：温馨提醒，使用背景白色或浅灰色均可，**不建议调整**
> - P2 中性灰（F5F5F5）：一般提示，**文字色与图标色统一使用 `#111111`**，确保在浅灰背景上的对比度
> - P2 业务白色（FFFFFF）：用于浅灰页面背景，**文字色与图标色统一使用 `#111111`**
> - 使用面性按钮时，建议按钮颜色参考对应优先级颜色
> - 底色如需使用渐变色，文字色/按钮颜色可根据实际效果自定义，但需保证**清晰、可识别**

### 7.2 按钮颜色建议

| 场景 | 面性按钮建议 | 线性按钮建议 |
|------|------------|------------|
| 黄色系（P1） | 黄渐变：`linear-gradient(135deg, #FFE74D 0%, #FFDD00 100%)`，文字色 `#111111` | 不建议线性按钮 |
| 红色系（P0） | 原子层样式 红渐变，按钮颜色 R4（`#F52916`），文字色 `#FFFFFF` | — |
| 品牌色（P2） | 按钮底色：品牌色，文字 FFFFFF 或 111111 | 品牌色 线性样式 |
| 黑色/灰色 | 灰色 线性样式（不建议面性按钮） | — |

> **黄渐变数据来源**：2x 图 `.instance-8 { background: linear-gradient(135deg, rgba(255,231,77,1) 0%, rgba(255,221,0,1) 100%) }`

---

## 8. Token 引用

### 8.1 颜色 Token

| 用途 | Token 名称 | 值 | 语义层来源 |
|------|-----------|-----|-----------|
| 温馨提醒背景（默认） | — | #FFFADB（Y1） | 业务色，非语义 Token |
| 温馨提醒文字/图标 | — | #7A3100 | 业务色，非语义 Token |
| 红色警告背景 | — | #FFF1F0（R1） | 业务色，非语义 Token |
| 红色警告文字/图标 | — | #F52916（R4） | 业务色，非语义 Token |
| 品牌蓝背景 | — | #E5EBF4 | 业务色，非语义 Token |
| 品牌蓝文字/图标 | — | #004099 | 业务色，非语义 Token |
| 中性背景（浅灰） | `bg-subtle` | #F5F5F5 | `color-semantic.md` §三 |
| 中性背景（白色） | `white` | #FFFFFF | `color-semantic.md` §一 |
| 中性灰文字/图标色 | `text-primary` | **#111111** | 中性灰（#F5F5F5）背景下文字与图标均使用此色 |
| 业务白色文字/图标色 | `text-primary` | **#111111** | 白色（#FFFFFF）背景下文字与图标均使用此色 |
| 主文字色（深色背景文字） | `text-primary` | #111111 | `color-semantic.md` §二 |
| 关闭图标色（深色主题） | `text-tertiary` | #999999 | `color-semantic.md` §二 |

> ⚠️ 通告栏的主题色（黄/红/蓝）由业务配置，非规范枚举，使用时直接引用 hex 值即可。

### 8.2 字体 Token

| 用途 | Token 名称 | 字号 @1x | 字号 @2x | 字重 | 行高 @1x | 行高 @2x |
|------|-----------|---------|---------|------|---------|--------|
| 通告栏正文 | `body-m-24-regular` | 12pt | 24px | 400 | 16pt | 32px |
| 操作按钮文字 | `caption-l-22-medium` | 11pt | 22px | 500 | 16pt | — |
| 跳转文字（如"详情"） | `body-m-24-regular` | 12pt | 24px | 400 | 16pt | 32px |

> 字体来源 2x 图：`font-size: 24px / line-height: 32px / font-weight: 400 / font-family: "PingFang SC"`

> ⚠️ **HTML 原型生成规则（字体回退）**：苹方（PingFang SC）仅在 macOS / iOS 原生环境存在。生成 HTML 原型时，**必须在 `<head>` 中引入在线中文字体**，否则无苹方的设备会回退到系统黑体（如微软雅黑、宋体），导致 400 字重视觉上明显偏粗，与设计稿不符。
>
> 推荐写法（在所有生成的 HTML `<head>` 中添加，双源并行提高加载成功率）：
> ```html
> <!-- 国内镜像（优先加载，速度快） -->
> <link rel="preconnect" href="https://fonts.loli.net" crossorigin>
> <link href="https://fonts.loli.net/css2?family=Noto+Sans+SC:wght@400;500;700&display=swap" rel="stylesheet">
> <!-- Google 官方（备用回退，镜像失效时兜底） -->
> <link rel="preconnect" href="https://fonts.googleapis.com">
> <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
> <link href="https://fonts.googleapis.com/css2?family=Noto+Sans+SC:wght@400;500;700&display=swap" rel="stylesheet">
> ```
>
> 对应 `font-family` 写法：
> ```css
> font-family: 'PingFang SC', 'Noto Sans SC', 'Source Han Sans SC', 'Microsoft YaHei', 'WenQuanYi Micro Hei', sans-serif;
> ```
>
> `Noto Sans SC` 是苹方的最佳跨平台替代，字形接近、字重感一致，400 字重轻盈不显粗。双源并行写法可在国内镜像不稳定时自动回退到 Google 官方源，确保字体在各种网络环境下均可加载。

### 8.3 间距 Token

| 用途 | Token 名称 | @1x | @2x | 说明 |
|------|-----------|-----|-----|------|
| 左右内边距 | `spacing-l` | 12pt | 24px | padding-left / padding-right |
| 标准尺寸上下内边距 | `spacing-s` | 8pt | 16px | padding-top / padding-bottom（standard） |
| 宽松尺寸上下内边距 | `spacing-m` | 10pt | 20px | padding-top / padding-bottom（loose） |
| 图标与内容区间距 | `spacing-2xs` | 4pt | 8px | 图标容器 `margin-right: 4pt`，**不用** `column-gap`（避免同时影响操作区左侧） |
| 内容区与操作区安全间距 | `spacing-l` | 12pt | 24px | 操作区 `padding-left: 12pt`，仅适用于 **text-arrow / button**（留边卡片），`arrow` 无此值 |
| 按钮左右内边距 | `cs-10` | 10pt | 20px | `button` 左右 padding，宽度自适应，最多 4 字（来自 `component-spacing.md`） |

### 8.4 圆角 Token

| 用途 | Token 名称 | @1x | @2x | 说明 |
|------|-----------|-----|-----|------|
| 留边卡片圆角（默认） | `radius-s` | 8pt | 16px | 来自 2x 图 `border-radius: 16px` |
| 圆角可选调整 | `radius-m` | 12pt | 24px | 贴近底部弹窗圆角时 |
| 通栏圆角 | — | 0px | 0px | 极度关注屏效时使用 |
| 操作按钮圆角 | `radius-full` | — | 9999px | 胶囊形全圆角，实现值固定为 `border-radius: 9999px`，不对应固定 pt 档位 |

---

## 9. Props API（供 AI 生码参考）

```typescript
export type NoticeBarProps = {
  /**
   * 通告栏功能类型
   * @default "basic"
   */
  noticeBarType?: "basic" | "link" | "link-close";

  /**
   * 行数
   * @default "single"
   */
  rowCount?: "single" | "double";

  /**
   * 尺寸
   * @default "standard"
   */
  size?: "standard" | "loose";

  /**
   * 跳转区样式（noticeBarType 为 "link" 或 "link-close" 时有效）
   * @default "arrow"
   */
  linkStyle?: "arrow" | "text-arrow" | "button";

  /**
   * 布局方式
   * @default "card"
   */
  layout?: "card" | "full-width";

  /**
   * 通告栏文案内容
   */
  content: string;

  /**
   * 左侧图标（可选，图标名称或组件）
   */
  icon?: React.ReactNode;

  /**
   * 跳转文字（linkStyle="text-arrow" 时有效）
   * @default "详情"
   */
  linkText?: string;

  /**
   * 操作按钮文字（linkStyle="button" 时有效）
   */
  buttonText?: string;

  /**
   * 背景色（业务自定义）
   * @default "#FFFADB"
   */
  backgroundColor?: string;

  /**
   * 文字/图标主色（业务自定义）
   * @default "#7A3100"
   */
  contentColor?: string;

  /**
   * 点击通告栏整体或跳转区域的回调
   */
  onPress?: () => void;

  /**
   * 点击关闭按钮的回调（noticeBarType 含 close 时有效）
   */
  onClose?: () => void;
};
```

---

## 10. data-attribute 规范

| 属性 | 值 | 说明 |
|------|----|------|
| `data-slot` | `"notice-bar"` | 组件根容器 |
| `data-slot` | `"notice-bar-icon"` | 左侧图标 |
| `data-slot` | `"notice-bar-content"` | 文案区域 |
| `data-slot` | `"notice-bar-link"` | 跳转操作区 |
| `data-slot` | `"notice-bar-close"` | 关闭按钮 |
| `data-notice-bar-type` | `"basic"` / `"link"` / `"link-close"` | 功能类型 |
| `data-row-count` | `"single"` / `"double"` | 行数 |
| `data-size` | `"standard"` / `"loose"` | 尺寸 |
| `data-layout` | `"card"` / `"full-width"` | 布局方式 |

---

## 11. 无障碍（Accessibility）

- 通告栏容器：`role="banner"` 或 `role="alert"`（视内容优先级）
- 关闭按钮：`aria-label="关闭通告栏"`
- 跳转区域：`aria-label="查看详情"` 或与按钮文字一致
- 有操作的通告栏：确保跳转/关闭触控目标不小于 22×22pt（需外扩热区）

---

## 12. 变体矩阵（完整 MECE）

### 基础型（noticeBarType=basic）

| rowCount | size | 容器高度 | 操作 |
|----------|------|---------|------|
| `single` | `standard` | **32pt** | 关闭图标（可无） |
| `single` | `loose` | **36pt** | 关闭图标（可无） |
| `double` | `standard` | **48pt** | 关闭图标（可无） |
| `double` | `loose` | **52pt** | 关闭图标（可无） |

### 跳转型（noticeBarType=link）

| rowCount | size | linkStyle | 容器高度 |
|----------|------|-----------|---------|
| `single` | `standard` | `arrow` / `text-arrow` / `button` | **32pt** |
| `single` | `loose` | `arrow` / `text-arrow` / `button` | **36pt** |
| `double` | `standard` | `arrow` / `text-arrow` / `button` | **48pt** |
| `double` | `loose` | `arrow` / `text-arrow` / `button` | **52pt** |

### 跳转关闭型（noticeBarType=link-close）

| rowCount | size | linkStyle | 容器高度 |
|----------|------|-----------|---------|
| `single` | `standard` | `arrow+close` / `text-arrow+close` / `button+close` | **32pt** |
| `single` | `loose` | `arrow+close` / `text-arrow+close` / `button+close` | **36pt** |
| `double` | `standard` | `text-arrow+close` / `button+close` | **48pt** |
| `double` | `loose` | `text-arrow+close` / `button+close` | **52pt** |

> ⚠️ **双行跳转关闭型**：`arrow+close` 组合视觉奇怪，**不建议使用**（仅支持 text-arrow+close 和 button+close）。

---

## 13. 使用约束（AI 生成时的硬性规则）

1. **颜色非枚举**：颜色不是组件变体，须由业务自行配置，不得使用其他颜色硬编码为"变体"
2. **默认颜色**：黄色温馨提醒色（背景 #FFFADB，内容色 #7A3100）为设计稿默认值
3. **行数不超过两行**：双行文案超出两行时需截断处理
4. **双行箭头+关闭禁用**：`rowCount=double` + `noticeBarType=link-close` + `linkStyle=arrow+close` 组合不可使用
5. **留边卡片左右固定 12pt 间距**：如需对齐页面元素，允许调整左右 padding
6. **圆角推荐 8pt**：结合场景可调整至 12pt，通栏使用 0pt
7. **图标可选**：组件默认带左侧功能图标，可根据业务需要关闭
8. **通告栏位置**：通常固定于导航栏下方或内容区顶部，与上下元素间距建议满足 4N（2pt 的整数倍）
9. **字重说明**：通告栏内容默认使用常规字重（400），需要强调时可调整为加粗（500/600），但应保持全局统一

---

## 14. 页面位置与尺寸选用建议

| 使用位置 | 推荐尺寸 | 推荐圆角 | 布局方式 |
|---------|---------|---------|---------|
| 导航栏下方（全幅） | `loose` | 0px 或 ≤24px | `full-width` 或 `card` |
| 页面内容区顶部 | `standard`（推荐）或 `loose` | 8pt（`card`） | `card` |
| 底部弹窗内顶部 | `loose` | 8pt，下方模块有圆角时顶部圆角可微调 | `full-width` |
| 下方为卡片内容时 | `loose` | 0px（通栏）或 16px | 视觉对齐上方 |

---

## 15. 常见组合示例

### 15.1 温馨提醒（基础型，单行，标准尺寸）

```
NoticeBar
  noticeBarType: basic
  rowCount: single
  size: standard
  content: "当前订单火爆，商品送达时间可能延时"
  backgroundColor: "#FFFADB"
  contentColor: "#7A3100"
  onClose: () => hideBar()
```

### 15.2 促销活动引导（跳转型，单行，按钮样式）

```
NoticeBar
  noticeBarType: link
  rowCount: single
  size: standard
  linkStyle: button
  buttonText: "立即领取"
  content: "限时活动：下单享受双倍积分"
  backgroundColor: "#FFF1F0"
  contentColor: "#F52916"
  onPress: () => navigateToPromotion()
```

### 15.3 系统通知（跳转关闭型，双行，文字+箭头）

```
NoticeBar
  noticeBarType: link-close
  rowCount: double
  size: loose
  linkStyle: text-arrow+close
  linkText: "详情"
  content: "开启系统通知，订单聊天等重要信息不错过，请在设置中开启通知权限"
  backgroundColor: "#E5EBF4"
  contentColor: "#004099"
  onPress: () => navigateToSettings()
  onClose: () => dismissBar()
```

---

## 16. 与其他组件的关系

| 关联组件 | 关系说明 |
|----------|----------|
| `button.md` | 跳转型按钮操作区使用原子层操作按钮，建议使用操作单按钮（小号胶囊） |
| `toast.md` | 关闭通告栏时可配合 Toast 做轻量提示 |
| `navigation.md` | 通告栏通常紧靠导航栏下方，间距满足 4N 原则 |
