# Switch - 开关 - 组件规范

> **组件分类**：Component（组件级）
> **定义**：开关用于在两种互斥状态之间切换（开启/关闭），常用于控制页面列表内的功能项。开关状态**即时生效**，开启态与关闭态必有一个生效。
> **Style 依赖**：`color-semantic.md` · `font-semantic.md` · `component-spacing.md` · `component-radius.md` · `stroke-semantic.md`
---

## 0. 图标 / 间距 / Ownership 约束

- **icon-route（默认）**：本组件内功能图标默认回 `component/atoms/icon.md`，并沿用本文件已声明的 iconfont class / weight。
- **fixed-asset 例外**：若正文已指定 `assets/*.svg`、官方 SVG、PNG/CDN 切图、URL 尖角资源或固定插画，该位点必须走固定资产，不得强行回 iconfont；输出时可标注 `icon-route=fixed-asset`。
- **spacing-owner（归属）**：组件内部 slot、行内/容器内 gap、padding、对齐归本组件；页面边距、吸顶/吸底占位、列表外层留白归宿主。
- **宿主裁决（优先级）**：冲突遵循 `宿主 > 组合场景 > 本组件通用规则`，子组件仅拥有自身内部样式，不反向改宿主排布。
- **不可跳步**：先回 `references/INDEX.md` 完成区域路由与宿主锁定，再用 `component-quickref.md` 做宿主级收敛；本文件仅承接组件内 ownership 细则，不承担前置路由改判；不得凭语义猜测。

## 1. 尺寸规格（size）

| size | 名称 | 滑轨宽 × 高 | 滑块直径 | 圆角（滑轨） | 圆角（滑块） | 典型场景 |
|------|------|-----------|---------|------------|------------|---------|
| `l` | 大号 | 46×28pt | 24pt | `radius-full` | `cr-12` | 控制页面**列表内功能**（如设置页权限、消息通知开关） |
| `m` | 中号 | 39×24pt | 20pt | `radius-full` | `cr-12` | 控制页面**局部模块功能**（如绑定会员功能） |
| `s` | 小号 | 26×16pt | 12pt | `radius-full` | 7.2pt（无对应 Token 档位，保留精确值） | 控制模块内**单个组件功能**（精细控制） |

> **圆角规则**：滑轨始终使用 `radius-full`（全圆角，引用 `component-radius.md`）；`l`/`m` 滑块圆角使用 `cr-12`；`s` 滑块圆角 7.2pt 无对应 Token 档位，保留精确值。

---

## 2. 状态（state）

| state | 名称 | 滑轨颜色 Token | 滑块颜色 Token | 滑块位置 | 可交互 |
|-------|------|--------------|--------------|---------|-------|
| `on` | 开启 | `yellow-default` | `white` | 靠右 | ✅ |
| `off` | 关闭 | `stroke-default` | `white` | 靠左 | ✅ |
| `on-disabled` | 开启禁用 | `yellow-bg-secondary`（浅黄） | `white` | 靠右 | ❌ |
| `off-disabled` | 关闭禁用 | `bg-page`（`#F5F5F5`） | `white` | 靠左 | ❌ |

---

## 3. 完整变体矩阵（12 个）

| size | state | disabled | 滑轨尺寸 | 滑块尺寸 | Figma objectId |
|------|-------|---------|---------|---------|----------------|
| `l` | `on` | `false` | 46×28pt | 24×24pt | `114586:66657` |
| `l` | `off` | `false` | 46×28pt | 24×24pt | `114586:66677` |
| `l` | `on` | `true` | 46×28pt | 24×24pt | `114586:66679` |
| `l` | `off` | `true` | 46×28pt | 24×24pt | `114586:66681` |
| `m` | `on` | `false` | 39×24pt | 20×20pt | `114586:66683` |
| `m` | `off` | `false` | 39×24pt | 20×20pt | `114586:66685` |
| `m` | `on` | `true` | 39×24pt | 20×20pt | `114586:66687` |
| `m` | `off` | `true` | 39×24pt | 20×20pt | `114586:66689` |
| `s` | `on` | `false` | 26×16pt | 12×12pt | `114586:66691` |
| `s` | `off` | `false` | 26×16pt | 12×12pt | `114586:66695` |
| `s` | `on` | `true` | 26×16pt | 12×12pt | `114586:66697` |
| `s` | `off` | `true` | 26×16pt | 12×12pt | `114586:66699` |

---

## 4. 内边距规格（Padding）

滑块通过内边距定位，遵循以下规律：

> **规律**：开启态 `padding-left` 大值 = 滑轨宽 - 2pt - 滑块直径，始终将滑块推至右端；关闭态则反向置于左端。

| size | 开启态 padding（滑块靠右） | 关闭态 padding（滑块靠左） |
|------|----------------------|----------------------|
| `l` | `cs-2 cs-2 cs-2 cs-20` | `cs-2 cs-20 cs-2 cs-2` |
| `m` | `cs-2 cs-2 cs-2 cs-17` | `cs-2 cs-17 cs-2 cs-2` |
| `s` | `cs-2 cs-2 cs-2 cs-12` | `cs-2 cs-12 cs-2 cs-2` |

---

## 5. 布局结构

```
Switch（开关）
└── 滑轨 Track（radius-full，display: flex，flex-direction: row，align-items: center）
    ├── 开启态：justify-content: flex-end；padding-left 大值
    └── 关闭态：padding-right 大值
        └── 滑块 Thumb（圆形，background: white）
```

---

## 6. Props API

```typescript
export type SwitchProps = {
  /**
   * 尺寸规格
   * @default "l"
   */
  size?: "l" | "m" | "s";

  /**
   * 受控模式：是否开启
   */
  checked?: boolean;

  /**
   * 非受控模式：初始是否开启
   * @default false
   */
  defaultChecked?: boolean;

  /**
   * 是否禁用（视觉浅色，不可交互）
   * @default false
   */
  disabled?: boolean;

  /**
   * 状态变化回调
   */
  onChange?: (checked: boolean) => void;
};
```

> **受控 vs 非受控**：
> - 传入 `checked` + `onChange` → 受控模式（外部管理状态）
> - 传入 `defaultChecked` → 非受控模式（内部管理状态）

---

## 7. data-attribute 规范

| 属性 | 值 | 说明 |
|------|----|------|
| `data-slot` | `"switch"` | 全局稳定标识，供父组件 CSS 定向选中 |
| `data-state` | `"on"` / `"off"` | 当前开关状态 |
| `data-disabled` | `"true"` / `"false"` | 是否禁用 |
| `data-size` | `"l"` / `"m"` / `"s"` | 尺寸档位 |

---

## 8. Token 引用

### 8.1 颜色 Token

| 用途 | Token 名称 | 语义层来源 |
|------|-----------|-----------|
| 开启态滑轨背景（品牌黄） | `yellow-default` | `color-semantic.md` §七 Functional Color |
| 关闭态滑轨背景（中灰） | `stroke-default` | `color-semantic.md` §四 Stroke Color |
| 开启禁用滑轨背景（浅黄） | `yellow-bg-secondary` | `color-semantic.md` §七 Functional Color |
| 关闭禁用滑轨背景（`#F5F5F5`） | `bg-page` | `color-semantic.md` §三 Background Color |
| 滑块（所有状态） | `white` | `color-semantic.md` §一 Neutral Color |

### 8.2 圆角 Token

| 用途 | Token 名称 | 语义层来源 |
|------|-----------|-----------|
| 滑轨圆角（全圆角） | `radius-full` | `component-radius.md` |
| 滑块圆角（`l` / `m`） | `cr-12` | `component-radius.md` |
| 滑块圆角（`s`） | 7.2pt（精确值） | 无对应档位，保留裸值 |

### 8.3 间距 Token

| 用途 | Token 名称 | 语义层来源 |
|------|-----------|-----------|
| 滑块四边内边距（基础值） | `cs-2` | `component-spacing.md` |
| `l` 滑块推至右端 padding-left | `cs-20` | `component-spacing.md` |
| `m` 滑块推至右端 padding-left | `cs-17` | `component-spacing.md` |
| `s` 滑块推至右端 padding-left | `cs-12` | `component-spacing.md` |

---

## 9. 交互规范

### 9.1 触发方式

| 交互类型 | 说明 |
|---------|------|
| 手动触发 | 开关的开启和关闭**一般为用户主动操作**触发 |
| 切换动效 | 滑块在滑轨中**滑动至另一侧**（开启/关闭动画） |
| 联动更新 | 提示文字、模块状态**跟随开关状态变化** |

### 9.2 禁用说明

- 禁用态下用户无法进行交互，通过**视觉浅色**（`yellow-bg-secondary` / `bg-page` = `#F5F5F5`）明确告知用户当前操作暂时无法进行
- 禁用时使用 `aria-disabled="true"`，不使用原生 `disabled` 属性（保留 focus 能力）

### 9.3 点击切换规则

**触发条件**：`disabled=false`（非禁用态）时，用户点击开关（手指触摸或鼠标点击）。

每次点击触发一次 `开启 ↔ 关闭` 状态切换，切换时同步发生以下两处视觉变化：

| 变化项 | 关闭 → 开启 | 开启 → 关闭 |
|--------|-----------|-----------|
| **滑块位移** | 圆形滑块从**左端**位移至**右端** | 圆形滑块从**右端**位移至**左端** |
| **背景容器颜色** | `stroke-default`（中灰）→ `yellow-default`（品牌黄） | `yellow-default`（品牌黄）→ `stroke-default`（中灰） |

> - 滑块位移与背景色变化**同步进行**，不分先后。
> - 禁用态（`disabled=true`）下点击事件被拦截，上述变化**不触发**。
> - 受控模式下，状态变化须通过 `onChange` 回调通知外部更新 `checked`，组件本身不自行翻转状态。

---

## 10. 无障碍（Accessibility）

- 使用语义化 `role="switch"`
- `aria-checked`：`"true"`（开启）/ `"false"`（关闭）
- `aria-disabled="true"`（禁用状态）
- 键盘：`Space` 键切换状态，`Tab` 键聚焦
- 配合文案标签：`aria-labelledby` 指向对应标题元素

---

## 11. 文案规范

开关常搭配**主标题（必备）** 和 **副标题（可选）**。

| 文案类型 | 格式 | 示例 |
|---------|------|------|
| 主标题（功能描述） | "功能描述" | `允许他人查看我的粉丝` |
| 主标题（行动引导） | "行动引导 + 功能描述" | `打开在线联系功能，及时解决客户问题` |
| 副标题（功能解释） | 解释功能含义 | `关闭后无法收到个性化内容推荐` |
| 副标题（影响提示） | 开/关后的重要影响 | `关闭后仍会看到广告，但相关性会下降` |

---

## 12. 使用约束（AI 生成时的硬性规则）

1. **禁止直接写 hex 颜色**：颜色必须使用 §8.1 中的 Token 名称
2. **禁止自定义滑轨尺寸**：只能从 §1 表格中选取 size，不能自定义 `width`/`height`
3. **滑轨圆角固定**：始终使用 `radius-full`，不可自定义
4. **开启/关闭态必须二选一**：不存在"中间态"，不允许同时显示两侧滑块
5. **开启态品牌色可定制**：`yellow-default` 和 `yellow-bg-secondary`（禁用）可根据业务品牌色替换；关闭态 `stroke-default` 和 `bg-page` 保持不变
6. **禁用不使用 `disabled` 属性**：改用 `aria-disabled="true"` + 拦截点击事件，保留 focus 能力
7. **禁止设置描边及阴影**：开关组件（滑轨与滑块）不可设置任何 `border`、`outline`、`box-shadow` 等描边或阴影样式

---

## 13. 使用场景速查

| 场景 | size | 默认状态 | 说明 |
|------|------|---------|------|
| 设置页权限开关（如通知开关） | `l` | `off` / `on` | 列表内标准功能控制 |
| 消息通知分类开关 | `l` | `on` | 默认开启的功能 |
| 绑定会员功能模块开关 | `m` | `off` | 局部模块级控制 |
| 内嵌表单局部功能 | `m` | 视业务 | — |
| 精细组件级控制 | `s` | 视业务 | 最小尺寸，密集场景 |
| 系统配置不可更改 | 任意 + `disabled` | 根据当前值 | 禁用态提示 |

---

## 14. AI 决策树

```
用户说"开关" / "switch" / "toggle" / "开启/关闭"
  ├── 确定尺寸：
  │   ├── 全局/页面级设置    → size="l"（46×28pt）
  │   ├── 模块级功能控制      → size="m"（39×24pt）
  │   └── 精细组制控制        → size="s"（26×16pt）
  │
  ├── 确定初始状态：
  │   ├── 功能默认开启（如推荐）→ checked=true / defaultChecked
  │   └── 功能默认关闭（如隐私）→ 默认（checked=false）
  │
  ├── 是否需要禁用？
  │   ├── 条件不满足时 → disabled=true
  │   └── 正常可交互   → 不传 disabled
  │
  └── 颜色 Token 速查（禁止写 hex）：
      ├── 开启       → 滑轨 yellow-default（可替换为业务品牌色）
      ├── 关闭       → 滑轨 stroke-default
      ├── 开启禁用   → 滑轨 yellow-bg-secondary（保持与开启色系一致）
      ├── 关闭禁用   → 滑轨 bg-page（#F5F5F5）
      └── 滑块始终   → white
```

---

## 15. 常见组合示例

### 15.1 设置页完整行

```
Row（display: flex，justify-content: space-between，align-items: center）
├── 文字区
│   ├── 主标题（subtitle-m-16-medium，text-primary）：个性化内容推荐
│   └── 副标题（body-l-14-regular，text-secondary）：关闭后无法收到个性化内容推荐
└── Switch（size="l"，checked，onChange）
```

### 15.2 仅主标题行

```
Row
├── 主标题（subtitle-m-16-medium）：允许他人查看我的粉丝
└── Switch（size="l"，defaultChecked）
```

---

## 16. 与其他组件的关系

| 关联组件 | 关系说明 |
|----------|----------|
| `list` | 开关常嵌入列表行项，作为列表行的右侧控件 |
| `dialog` | 需要二次确认的开关操作搭配弹窗 |

---
