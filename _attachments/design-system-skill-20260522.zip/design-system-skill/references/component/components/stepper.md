# Stepper 步进器

> **组件分类**：Component（组件级）
> **定义**：步进器用于在数字范围内进行调整，用户通过点击加/减按钮改变数值，常用于购物车商品数量调整、预订数量选择等场景。
> **Style 依赖**：`color-semantic.md` · `font-semantic.md` · `spacing-semantic.md` · `component-spacing.md` · `radius-semantic.md` · `component-radius.md` · `stroke-semantic.md`

> ⚠️ **核心约束**：
> - 步进器可分为**分段型**与**连体型**两种结构类型，选型由视觉层级和场景决定
> - 达到最大/最小值时按钮进入**禁用样式**，再次点击弹出轻提示（Toast）
> - 按钮颜色可自定义，**位置**与步进器保持**右对齐**
> - 宽度随数字位数**自适应**，内容区不固定宽度

---
## 0. 图标 / 间距 / Ownership 约束

- **icon-route（默认）**：本组件内功能图标默认回 `component/atoms/icon.md`，并沿用本文件已声明的 iconfont class / weight。
- **fixed-asset 例外**：若正文已指定 `assets/*.svg`、官方 SVG、PNG/CDN 切图、URL 尖角资源或固定插画，该位点必须走固定资产，不得强行回 iconfont；输出时可标注 `icon-route=fixed-asset`。
- **spacing-owner（归属）**：组件内部 slot、行内/容器内 gap、padding、对齐归本组件；页面边距、吸顶/吸底占位、列表外层留白归宿主。
- **宿主裁决（优先级）**：冲突遵循 `宿主 > 组合场景 > 本组件通用规则`，子组件仅拥有自身内部样式，不反向改宿主排布。
- **不可跳步**：先回 `references/INDEX.md` 完成区域路由与宿主锁定，再用 `component-quickref.md` 做宿主级收敛；本文件仅承接组件内 ownership 细则，不承担前置路由改判；不得凭语义猜测。

## 1. 组件大类（stepperType）

| stepperType | 名称 | 结构说明 | 适用场景 |
|-------------|------|---------|---------|
| `segmented` | 分段型 | 减号 + 数字 + 加号，三者分离，按钮为圆形 | 轻量场景，如酒旅预订、外卖加购（需要弱化数量控件） |
| `integrated` | 连体型 | 减号 + 数字 + 加号，三者共享矩形容器，视觉一体化 | 购物车、商品选规格弹窗（需要强化数量操作感） |
| `integrated-input` | 连体输入型 | 默认收起为单个矩形数字框，点击后展开为减号 + **可输入数字框** + 加号 | 购物车页，需对数值进行精确调整，最小值为 1 |
| `add-button` | 添加按钮 | 仅加号（圆形胶囊），商品未加入时展示，加入后切换为步进器 | 商品列表卡片右下角，0 件时展示「加入」入口 |

> **选型原则**：
> - 酒旅/娱乐/预订类（非购物车）→ `segmented`（分段型，弱化操作）
> - 购物车/选规格场景 → `integrated`（连体型，强化操作）
> - 购物车页需精确输入数量 → `integrated-input`（连体输入型，点击唤起键盘）
> - 商品列表未加入状态 → `add-button`（添加按钮）

---

## 2. 分段型（stepperType=segmented）

### 2.1 尺寸变体（size）

| size | 名称 | 整体宽度 | 整体高度 | 数字区宽 | 数字字号 | 数字行高 | 适用场景 |
|------|------|---------|---------|---------|---------|---------|---------|
| `large` | 大号 26pt | **82pt**（单位数时） | 26pt | **min 30pt**（自适应，详见 §2.4） | 15pt | 22pt | 对屏效要求低，需重点突出步进器的页面 |
| `standard` | 标准 22pt | **74pt**（单位数时） | 22pt | **min 30pt**（自适应，详见 §2.4） | 15pt | 22pt | 适用于大部分场景的页面 |
| `small` | 小号 18pt | **62pt**（单位数时） | 18pt | **min 26pt**（自适应，详见 §2.4） | 14pt | 20pt | 对屏效要求较高、空间紧凑的页面 |

> ✅ **推荐**：标准 22pt（`standard`）适用于大部分页面；小号 18pt（`s`）用于屏效要求高的紧凑场景（如内容嵌套）

### 2.2 按钮样式逻辑（Style Logic）

根据业务场景，分段型步进器支持两种按钮组合逻辑：

| 逻辑类型 | 样式特征 | 适用场景 | 示例 |
|----------|---------|---------|------|
| **强调型** | **加号样式强于减号**。加号用 `yellow-default`（#FFDD00）填充（面性），减号按钮外描边也使用 `yellow-default` 颜色（线性）；加号视觉权重明显强于减号，引导用户注意「增加」操作。 | 需对增加操作进行突出引导，增加样式较强，适合引导加购场景。 | 外卖商品列表页 |
| **同级型** | **加减按钮样式一致**。加号和减号均为线性（描边样式），均使用 `stroke-default`（#E5E5E5）颜色，按钮视觉权重相同，方便快速对数据进行小范围调整。 | 用户已完成加购，需管理商品数量，无需引导偏向。 | 提单页、购物车数量管理 |

> **样式选型说明**：
> - **强调型**：加号为黄色面性按钮，减号按钮外描边也为黄色（线性），整体强调「加入」动作。常用于外卖商品列表页等需要引导加购的场景。
> - **同级型**：加号和减号均为线性，颜色统一为 `#E5E5E5`（`stroke-default`），样式一致，不做方向引导，方便用户快速调整数量。常用于提单页等管理商品数量的场景。

#### 按钮状态规格

| 状态 | 加号按钮（强调型） | 减号按钮（强调型） | 同级型按钮（通用） |
|------|------------------|------------------|------------------|
| 默认态 | `yellow-default`（#FFDD00）填充 | 1pt `stroke-default`（#E5E5E5）描边 | 1pt `stroke-default` 描边 |
| **点击态（pressed）** | 白色 50% 叠层 + 黄底（浅黄）/ 图标 opacity 0.5 | 浅灰背景 `#F5F5F5` / 图标 opacity 0.5 | 浅灰背景 `#F5F5F5` / 图标 opacity 0.5 |
| 禁用态 | `bg-overlay-light`（#F0F0F0）填充 | 1pt `bg-overlay-light` 描边 | 1pt `bg-overlay-light` 描边 |
| 图标色 | `text-primary`（#111111） | `text-primary`（#111111） | `text-primary` |
| 禁用图标色 | `text-disabled`（#C2C2C2） | `text-disabled` | `text-disabled` |

### 2.3 数字区规格

| 属性 | 值 | Token |
|------|-----|-------|
| 字号（小号 18pt） | **14pt** | `body-l-28-regular` |
| 字号（标准 22pt / 大号 26pt） | **15pt** | `subtitle-s-30-regular` |
| 字色 | `#111111` | `text-primary` |
| 有单位时 | 数字 + 单位文字并排显示（如「1 间」「3 个」），数字与单位之间间距 **2pt**，三个尺寸（large/standard/small）均相同；**单位文字字号与数字字号一致**：小号 14pt（@2x: 28px），标准/大号 15pt（@2x: 30px），❌ 禁止单位字号小于数字字号 | — |

### 2.4 数字区宽度与内边距规格

数字区宽度根据**数值内容**分为两种状态，规则如下：

- **无单位**：1–9（1位数）固定宽度；10 及以上（多位数）自适应宽度
- **有单位**（如「9 间」「12 份」）：无论数字几位，统一走**自适应宽度**（内容 = 数字 + 单位，整体撑开），左右 padding 同多位数规则（8pt），数字与单位之间间距 2pt

左右 padding 随之变化：

#### 大号（26pt）/ 标准（22pt）

| 数值范围 | 数字文本宽 | 左右 padding | 数字容器总宽 | 实现说明 |
|---------|-----------|-------------|------------|------|
| 1–9（1位数） | **18pt**（固定，数字 `p`/`span` 设固定宽） | **6pt** | **30pt** | 数字文本固定宽 36px（@2x），外层容器仅设 `padding: 0 12px`，不设固定宽 |
| 10 及以上（多位数） / 有单位 | 自适应 | **8pt** | 数字宽 + 16pt | 外层容器仅设 `padding: 0 16px`，不设任何固定宽，内容自然撑开 |

#### 小号（18pt）

| 数值范围 | 数字区宽度 | 左右 padding | 数字容器总宽 | 说明 |
|---------|-----------|-------------|------------|------|
| 1–9（1位数） | **18pt**（固定） | **4pt** | **26pt** | 数字居中，固定宽度 |
| 10 及以上（多位数） | 自适应 | **8pt** | 数字宽 + 16pt | 随内容撑开 |

| 尺寸 | 数字区高度 |
|------|----------|
| `small`（18pt） | 20pt（@2x: 40px） |
| `standard`（22pt） | 22pt（@2x: 44px） |
| `large`（26pt） | 22pt（@2x: 44px） |

---

## 3. 连体型（stepperType=integrated）

### 3.1 尺寸变体（size）

| size | 名称 | 按钮尺寸 | 数字区宽 | 整体高度 | 图标尺寸 | 数字字号 |
|------|------|---------|---------|---------|---------|---------|
| `large` | 大号 26pt | 26×26pt | min 30pt | **26pt** | 12×12pt | 14pt |
| `standard` | 标准 22pt | 22×22pt | min 30pt | **22pt** | 10×10pt | 13pt |

> ⚠️ 连体型**无小号（18pt）**变体，最小为标准 22pt（`standard`）。

### 3.2 布局规格（固定，不可修改）

| 属性 | 大号（large/26pt） | 标准（standard/22pt） | Token / 说明 |
|------|------------|------------|------------|
| 减号按钮圆角 | **6pt**（左侧） | **4pt**（左侧） | `radius-xs` |
| 加号按钮圆角 | **0pt**（右侧） | **0pt**（右侧） | — |
| 按钮边框 | 0.5pt solid `stroke-strong`（#CCCCCC） | 0.5pt solid `stroke-strong`（#CCCCCC） | `stroke-default` |
| 数字字重 | **500（Medium）** | **500（Medium）** | 连体型数字加粗 |
| 数字字色 | `#111111` | `#111111` | `text-primary` |
| 数字行高（大号） | **20pt** | **18pt** | — |
| 数字区背景 | 透明（共享边框） | 透明 | — |

### 3.3 状态样式

| 状态 | 减号图标色 | 加号图标色 | 按钮背景 | 说明 |
|------|----------|---------|---------|------|
| 默认态 | `#111111`（`text-primary`） | `#111111` | 透明 | 正常操作 |
| **点击态（pressed）** | `#111111` opacity 0.5 | `#111111` opacity 0.5 | `#F5F5F5` | 手指按下瞬间，背景变浅灰，图标半透明 |
| 减号禁用 | `#C2C2C2`（`text-disabled`） | `#111111` | 透明 | 已到最小值 |
| 加号禁用 | `#111111` | `#C2C2C2`（`text-disabled`） | 透明 | 已到最大值 |
| 全禁用 | `#C2C2C2` | `#C2C2C2` | 透明 | 加减均达到限制 |

### 3.4 连体型单按钮变体（integratedButtonOnly）

用于订单维度的「×N」展示，仅显示数量，无减号按钮。

| 尺寸 | 宽度 | 高度 | 内容 | 圆角 |
|------|------|------|------|------|
| 大号 26pt | 约 26pt | 26pt | `×` + 数字，14pt字号 | 6pt（`radius-xs`） |
| 标准 22pt | 约 22pt | 22pt | `×` + 数字，13pt字号 | 4pt |

---

## 4. 连体输入型（stepperType=integrated-input）

> **定义**：由加号、减号、数值输入框 3 部分组成。适用于购物车页，数字区为可交互输入框，点击唤起键盘直接输入，支持对数值进行精确调整。最小值为 1。

### 4.1 两态切换逻辑

| 状态 | 外观 | 触发方式 |
|------|------|--------|
| **默认态（收起）** | 单个矩形数字框，显示当前数值，无加减按钮 | 初始渲染 |
| **激活态（展开）** | 减号按钮 + 数字输入框 + 加号按钮，三者连体 | 点击数字框后展开，同时唤起键盘 |

> ⚠️ **最小值固定为 1**，不可减至 0。收起态点击后才展开交互区域。

### 4.2 尺寸变体（size）

| size | 名称 | 默认态尺寸 | 激活态整体宽 | 整体高 | 圆角规则 |
|------|------|---------|-----------|-------|--------|
| `large` | 大号 26pt | **26×26pt** | **82pt**（减 26 + 数 30 + 加 26） | **26pt** | 默认态 6pt 全角；激活态左端 6pt、右端 6pt，中间直角 |
| `standard` | 标准 22pt | **22×22pt** | **74pt**（减 22 + 数 30 + 加 22） | **22pt** | 默认态 4pt 全角；激活态左端 4pt、右端 4pt，中间直角 |

> ⚠️ **无小号（18pt）变体**，最小尺寸为标准 22pt（`standard`）。

### 4.3 默认态（收起）规格

| 属性 | 大号（large/26pt） | 标准（standard/22pt） | 说明 |
|------|------------|------------|------|
| 容器尺寸 | **26×26pt**（@2x: 52×52px） | **22×22pt**（@2x: 44×44px） | 正方形矩形 |
| 圆角 | **6pt**（@2x: 12px） | **4pt**（@2x: 8px） | 全四角 |
| 边框 | **0.5pt** solid `#CCCCCC` | **0.5pt** solid `#CCCCCC` | `stroke-strong` |
| 内边距（左右） | **4.5pt**（@2x: 9px） | **3pt**（@2x: 6px） | 数字居中 |
| 内边距（上下） | **3pt**（@2x: 6px） | **2pt**（@2x: 4px） | — |
| 数字字号 | **14pt**（@2x: 28px） | **13pt**（@2x: 26px） | — |
| 数字行高 | **20pt**（@2x: 40px） | **18pt**（@2x: 36px） | — |
| 数字字重 | **500（Medium）** | **500（Medium）** | — |
| 数字字色 | `#111111` | `#111111` | `text-primary` |
| 背景色 | 透明 | 透明 | 与边框视觉一体 |

### 4.4 激活态（展开）规格

| 属性 | 大号（large/26pt） | 标准（standard/22pt） | 说明 |
|------|------------|------------|------|
| 减号按钮尺寸 | **26×26pt**（@2x: 52×52px） | **22×22pt**（@2x: 44×44px） | 左端 |
| 减号按钮圆角 | **6pt** 左侧，0pt 右侧 | **4pt** 左侧，0pt 右侧 | — |
| 减号内边距 | **7pt**（@2x: 14px） | **6pt**（@2x: 12px） | 图标居中 |
| 减号图标尺寸 | **12pt**（@2x: 24px） | **10pt**（@2x: 20px） | 自定义图标（横线） |
| 数字输入框宽 | **30pt**（@2x: 60px） | **30pt**（@2x: 60px） | 左右内边距各 6pt |
| 数字输入框高 | **26pt** | **22pt** | 与整体高一致 |
| 数字输入框边框 | 上下各 0.5pt `#CCCCCC`，左右无边框 | 同左 | 与按钮共享左右外边框 |
| 数字内边距（上下） | **3pt**（@2x: 6px） | **2pt**（@2x: 4px） | — |
| 数字内边距（左右） | **6pt**（@2x: 12px） | **6pt**（@2x: 12px） | — |
| 数字字号 | **14pt**（@2x: 28px） | **13pt**（@2x: 26px） | — |
| 数字行高 | **20pt**（@2x: 40px） | **18pt**（@2x: 36px） | — |
| 数字字重 | **500（Medium）** | **500（Medium）** | — |
| 加号按钮尺寸 | **26×26pt**（@2x: 52×52px） | **22×22pt**（@2x: 44×44px） | 右端 |
| 加号按钮圆角 | 0pt 左侧，**6pt** 右侧 | 0pt 左侧，**4pt** 右侧 | — |
| 加号内边距 | **7pt**（@2x: 14px） | **6pt**（@2x: 12px） | 图标居中 |
| 加号图标尺寸 | **12pt**（@2x: 24px） | **10pt**（@2x: 20px） | 自定义图标（十字） |
| 整体边框 | 0.5pt solid `#CCCCCC` | 0.5pt solid `#CCCCCC` | 三段共享外边框 |
| 图标颜色 | `#111111` | `#111111` | `text-primary` |
| 禁用图标色 | `#C2C2C2` | `#C2C2C2` | `text-disabled` |

### 4.5 交互行为规范

| 行为 | 规范 |
|------|------|
| 点击数字框 | 展开为三段式，同时**唤起系统数字键盘** |
| 键盘输入 | 直接替换数字，支持任意正整数（受 min/max 约束） |
| 最小值 | **固定为 1**，不可减至 0 |
| 减到最小值 | 减号按钮进入禁用样式，再次点击弹出 Toast |
| 失焦/确认 | 收起键盘，数字框保持展开态（不收回三段式） |
| 非法输入 | 清空或超出范围时，重置为最近合法值 |

---

## 6. 添加按钮（stepperType=add-button）

### 4.1 图标类型（iconType）

| iconType | 图标来源 | 图标 | 说明 |
|----------|---------|------|------|
| `plus` | **自定义图标**（❌ 非 iconfont，内联 SVG/图片） | 十字加号（`+`） | 默认，搭配黄色圆底，表示添加 |
| `cart` | **图标库 iconfont** | 购物车图标 | 适用于电商购物场景，图标尺寸比 `plus` 大 |
| `text` | 无图标 | 纯文字（胶囊形） | 如「加入购物车」「选规格」 |

> ⚠️ **图标来源区别**：
> - `plus`（加号）和分段型中的加减图标均为**自定义图标**，❌ 不使用 iconfont 类名，尺寸按设计稿精确标注。
> - ❌ **严禁使用以下 iconfont 类名替代加减号**：`icon-iconfont-add-line-*`（加号-框，任意字重）、`icon-iconfont-pluscircle-*`（加号-圈，任意字重）、`icon-iconfont-add-fill`、`icon-iconfont-minus-*` 等一切 iconfont 变体，均不得用于步进器加减图标。
> - `cart`（购物车）使用**图标库 iconfont**，图标尺寸比 `plus` 大 2pt（每个尺寸档），因图标库图标视觉上相对偏小。
> - 加号图标颜色：默认态 `#111111`（搭配黄色 #FFDD00 圆底），禁用态变为 `#C2C2C2`（`text-disabled`）。
> - **点击态（pressed）**：`plus` 型按钮按下时背景变为白色 50% 叠层 + 黄底（`linear-gradient(rgba(255,255,255,0.5),rgba(255,255,255,0.5)),#FFDD00`），图标 opacity 0.5；`cart` 型按下时背景变 `#EBEBEB`，图标 opacity 0.5；禁用态无点击态。

### 4.2 尺寸变体规格

| size | 图标类型 | 按钮宽高 | 图标尺寸 | 图标来源 | 背景色 | 图标色 | 说明 |
|------|---------|---------|---------|---------|-------|-------|------|
| `large` (26pt) | `plus` | 26×26pt | **12pt** | 自定义图标 | `yellow-default`（#FFDD00） | `#111111` | 默认态 |
| `large` (26pt) | `cart` | 26×26pt | **14pt** | iconfont | `bg-page`（#F5F5F5） | `#111111` | 默认态 |
| `large` (26pt) | `plus` | 26×26pt | **12pt** | 自定义图标 | `bg-overlay-light`（#F0F0F0） | `#C2C2C2` | 不可点击态 |
| `large` (26pt) | `cart` | 26×26pt | **14pt** | iconfont | `bg-overlay-light`（#F0F0F0） | `#C2C2C2` | 不可点击态 |
| `standard` (22pt) | `plus` | 22×22pt | **10pt** | 自定义图标 | `yellow-default`（#FFDD00） | `#111111` | 默认态 |
| `standard` (22pt) | `cart` | 22×22pt | **12pt** | iconfont | `bg-page`（#F5F5F5） | `#111111` | 默认态 |
| `standard` (22pt) | `plus` | 22×22pt | **10pt** | 自定义图标 | `bg-overlay-light`（#F0F0F0） | `#C2C2C2` | 不可点击态 |
| `standard` (22pt) | `cart` | 22×22pt | **12pt** | iconfont | `bg-overlay-light`（#F0F0F0） | `#C2C2C2` | 不可点击态 |
| `small` (18pt) | `plus` | 18×18pt | **8pt** | 自定义图标 | `yellow-default`（#FFDD00） | `#111111` | 默认态 |
| `small` (18pt) | `cart` | 18×18pt | **10pt** | iconfont | `bg-page`（#F5F5F5） | `#111111` | 默认态 |
| `small` (18pt) | `plus` | 18×18pt | **8pt** | 自定义图标 | `bg-overlay-light`（#F0F0F0） | `#C2C2C2` | 不可点击态 |
| `small` (18pt) | `cart` | 18×18pt | **10pt** | iconfont | `bg-overlay-light`（#F0F0F0） | `#C2C2C2` | 不可点击态 |

### 4.3 纯文字按钮（iconType=text）规格

| size | 宽 | 高 | 字号 | 字重 | 字色（默认） | 字色（禁用） | 背景色 |
|------|-----|-----|------|------|-----------|-----------|-------|
| `large` (26pt) | 80pt | 26pt | 12pt | 500 | `text-primary`（#111111） | `text-disabled`（#C2C2C2） | `yellow-default` / `bg-overlay-light` |
| `standard` (22pt) | 49pt | 22pt | 11pt | 500 | `text-primary` | `text-disabled` | 同上 |
| `small` (18pt) | 42pt | 18pt | 10pt | 500 | `text-primary` | `text-disabled` | 同上 |

> 所有添加按钮圆角：`radius-full`（胶囊形）

---

## 7. 通用规格

### 5.1 宽度适配规则

| 场景 | 位置 | 宽度 |
|------|------|------|
| 标准 22pt 及 26pt | 商品列表/卡片 | 固定宽度，对齐右侧 |
| 18pt（小号） | 预订/日历/信息类 | 随右侧内容自动推入，保持右对齐 |
| 全屏通栏 | 购物车列表 | 步进器宽度固定，价格在左自适应 |

### 5.2 数字宽度自适应规则

| 数字范围 | 估算宽度 | 说明 |
|---------|---------|------|
| 0–9（1位） | ~26pt | 单字符最小宽度 |
| 10–99（2位） | ~33–42pt | 自适应 |
| >99（3位） | ~42pt | 最大常规数字宽度 |
| 有单位（如「9 间」） | 数字 + 单位同行 | 自适应展示 |

---

## 8. Token 引用

### 6.1 颜色 Token

| 用途 | Token 名称 | 值 | 语义层来源 |
|------|-----------|-----|-----------|
| 主操作按钮背景（激活，默认） | `yellow-default` | #FFDD00 | `color-semantic.md` §七 |
| 主操作按钮背景（小象超市覆盖） | `dpt12-g` | #00CF22 | `color-business.md` — grocery 场景必须覆盖 |
| 主操作按钮边框（激活） | `yellow-default` | #FFDD00 | — |
| 数字文字色 | `text-primary` | #111111 | `color-semantic.md` §二 |
| 图标默认色 | `text-primary` | #111111 | — |
| 图标禁用色 | `text-disabled` | #C2C2C2 | `color-semantic.md` §二 |
| 默认描边（分段型按钮默认） | `stroke-default` | #E5E5E5 | `color-semantic.md` §四 |
| 连体型按钮描边 | `stroke-strong` | #CCCCCC | `color-semantic.md` §四 |
| 禁用按钮背景 | `bg-overlay-light` | #F0F0F0 | `color-semantic.md` §三 |
| 购物车图标按钮背景 | `bg-page` | #F5F5F5 | `color-semantic.md` §三 |

### 6.2 字体 Token

| 用途 | Token 名称 | 字号 | 字重 | 行高 |
|------|-----------|------|------|------|
| 数字（小号18pt） | `body-l-28-regular` | 14pt | 400 | 20pt |
| 数字（标准22pt/大号26pt，分段型） | `subtitle-s-30-regular` | 15pt | 400 | 22pt |
| 数字（连体型，所有尺寸） | `body-l-28-medium`（大号14pt）/ `body-m-26-medium`（标准13pt） | 13–14pt | 500 | — |
| 文字按钮内容（11pt） | `caption-l-22-medium` | 11pt | 500 | 16pt |
| 文字按钮内容（10pt） | `caption-s-20-medium` | 10pt | 500 | 14pt |

### 6.3 圆角 Token

| 用途 | Token 名称 | 值 |
|------|-----------|-----|
| 分段型按钮（小号18pt） | `radius-full` | 9pt（= 高度的50%） |
| 分段型按钮（标准22pt） | `radius-full` | 11pt |
| 分段型按钮（大号26pt） | `radius-full` | 13pt |
| 连体型减号按钮（大号） | `radius-xs` | 6pt（左侧圆角） |
| 连体型减号按钮（标准） | `radius-xxs` | 4pt（左侧圆角） |
| 添加按钮（所有尺寸） | `radius-full` | 胶囊形 |

### 6.4 图标尺寸

> ⚠️ 加减号（`plus`/minus）为**自定义图标**，购物车（`cart`）为 **iconfont**，两者尺寸不同（iconfont 视觉偏小，需补 2pt 补偿）。
> 分段型与连体型（含连体输入型）的加减号图标**共用相同尺寸**（大号 12pt、标准 10pt、小号 8pt）。

| 尺寸变体 | 加/减号图标（自定义）| 购物车图标（iconfont） | 适用类型 | 说明 |
|---------|-------------------|---------------------|---------|------|
| 大号 26pt | **12×12pt** | **14×14pt** | 分段型 / 连体型 / 连体输入型 / 添加按钮 | cart 比 plus 大 2pt |
| 标准 22pt | **10×10pt** | **12×12pt** | 分段型 / 连体型 / 连体输入型 / 添加按钮 | cart 比 plus 大 2pt |
| 小号 18pt | **8×8pt** | **10×10pt** | 分段型 / 添加按钮（连体型无小号） | cart 比 plus 大 2pt |

### 6.5 图标实现规范（HTML 生成专用）

> ⚠️ **加减号图标 ❌ 不使用 iconfont**，必须用 **inline SVG** 实现。CSS 尺寸为 @2x px（规范值 ×2）。
> ❌ **以下 iconfont 类名一律禁用**（含所有字重变体 light / regular / medium / semibold / fill）：
> - 加号-框：`icon-iconfont-add-line-light` / `add-line-regular` / `add-line-medium` / `add-line-semibold`
> - 加号-圈：`icon-iconfont-pluscircle-line-light` / `pluscircle-line-regular` / `pluscircle-line-medium` / `pluscircle-line-semibold`
> - 加号-填充：`icon-iconfont-add-fill`
> - 减号同理，任何 iconfont 减号类名均禁止用于步进器。

#### CSS 类定义

```css
/* Stepper 加减图标 — 三档尺寸（@2x） */
/* 大号 26pt → 12pt × 2 = 24px */
.stepper-icon-lg { width:24px; height:24px; display:block; flex-shrink:0; }
/* 标准 22pt → 10pt × 2 = 20px */
.stepper-icon-md { width:20px; height:20px; display:block; flex-shrink:0; }
/* 小号 18pt → 8pt × 2 = 16px */
.stepper-icon-sm { width:16px; height:16px; display:block; flex-shrink:0; }
```

#### 单按钮（add-button）CSS 规范（HTML 生成专用）

> ⚠️ **add-button 按钮容器必须使用以下结构**，胶囊圆角固定为 `border-radius: 5000px`，背景色 `#FFDD00`，按钮内部用 flex 居中布局。

```css
/* add-button 按钮容器 — 三档尺寸（@2x） */
/* 大号 26pt → 52px；标准 22pt → 44px；小号 18pt → 36px */

/* 大号（26pt @2x: 52px） */
.stepper-add-btn-lg {
  position: absolute;
  width: 52px;
  height: 52px;
  border-radius: 5000px;
  background: #FFDD00;
  display: flex;
  flex-direction: column;
  justify-content: center;
  align-items: center;
  padding: 14px;
  box-sizing: border-box;
  opacity: 1;
}

/* 标准（22pt @2x: 44px） */
.stepper-add-btn-md {
  position: absolute;
  width: 44px;
  height: 44px;
  border-radius: 5000px;
  background: #FFDD00;
  display: flex;
  flex-direction: column;
  justify-content: center;
  align-items: center;
  padding: 12px;
  box-sizing: border-box;
  opacity: 1;
}

/* 小号（18pt @2x: 36px） */
.stepper-add-btn-sm {
  position: absolute;
  width: 36px;
  height: 36px;
  border-radius: 5000px;
  background: #FFDD00;
  display: flex;
  flex-direction: column;
  justify-content: center;
  align-items: center;
  padding: 10px;
  box-sizing: border-box;
  opacity: 1;
}
```

> ⚠️ **add-button 内部图标**（SVG）尺寸由 padding 控制留白，图标本身继承 flex 居中，**不需要额外 margin**：
> - 大号：容器 52px，padding 14px → 图标区域 24px（对应 `.stepper-icon-lg`）
> - 标准：容器 44px，padding 12px → 图标区域 20px（对应 `.stepper-icon-md`）
> - 小号：容器 36px，padding 10px → 图标区域 16px（对应 `.stepper-icon-sm`）

#### 加号 SVG

```html
<!-- 大号（24px）默认态 -->
<svg class="stepper-icon-lg" width="24" height="24" viewBox="0 0 32 32" fill="none" xmlns="http://www.w3.org/2000/svg" aria-hidden="true" style="display:block;flex-shrink:0;">
  <rect x="13.5" y="2.5" width="5" height="27" rx="2.5" fill="#111111"/>
  <rect x="2.5" y="13.5" width="27" height="5" rx="2.5" fill="#111111"/>
</svg>

<!-- 标准（20px）默认态 -->
<svg class="stepper-icon-md" width="20" height="20" viewBox="0 0 32 32" fill="none" xmlns="http://www.w3.org/2000/svg" aria-hidden="true" style="display:block;flex-shrink:0;">
  <rect x="13.5" y="2.5" width="5" height="27" rx="2.5" fill="#111111"/>
  <rect x="2.5" y="13.5" width="27" height="5" rx="2.5" fill="#111111"/>
</svg>

<!-- 小号（16px）默认态 -->
<svg class="stepper-icon-sm" width="16" height="16" viewBox="0 0 32 32" fill="none" xmlns="http://www.w3.org/2000/svg" aria-hidden="true" style="display:block;flex-shrink:0;">
  <rect x="13.5" y="2.5" width="5" height="27" rx="2.5" fill="#111111"/>
  <rect x="2.5" y="13.5" width="27" height="5" rx="2.5" fill="#111111"/>
</svg>

<!-- 禁用态：将所有 fill="#111111" 改为 fill="#C2C2C2" -->
```

#### 减号 SVG

```html
<!-- 大号（24px）默认态 -->
<svg class="stepper-icon-lg" width="24" height="24" viewBox="0 0 32 32" fill="none" xmlns="http://www.w3.org/2000/svg" aria-hidden="true" style="display:block;flex-shrink:0;">
  <rect x="2.5" y="13.5" width="27" height="5" rx="2.5" fill="#111111"/>
</svg>

<!-- 标准（20px）默认态 -->
<svg class="stepper-icon-md" width="20" height="20" viewBox="0 0 32 32" fill="none" xmlns="http://www.w3.org/2000/svg" aria-hidden="true" style="display:block;flex-shrink:0;">
  <rect x="2.5" y="13.5" width="27" height="5" rx="2.5" fill="#111111"/>
</svg>

<!-- 小号（16px）默认态 -->
<svg class="stepper-icon-sm" width="16" height="16" viewBox="0 0 32 32" fill="none" xmlns="http://www.w3.org/2000/svg" aria-hidden="true" style="display:block;flex-shrink:0;">
  <rect x="2.5" y="13.5" width="27" height="5" rx="2.5" fill="#111111"/>
</svg>

<!-- 禁用态：将所有 fill="#111111" 改为 fill="#C2C2C2" -->
```

> ⚠️ **分段型/连体型按钮内图标居中**：按钮容器设 `display:flex; align-items:center; justify-content:center`，SVG 自带 `style="display:block;flex-shrink:0"`，无需额外 padding 控制图标位置。

> ⚠️ **add-button 单按钮**：使用 `.stepper-add-btn-lg/md/sm` 类，通过 `padding` 控制图标留白，`border-radius:5000px` 实现胶囊圆角，不可使用百分比或其他圆角值。

#### 点击态（pressed）CSS 规范（HTML 生成专用）

> ⚠️ **所有按钮必须实现点击态**，使用 `:active` 伪类，禁用按钮排除在外。`transition` 建议设 `0.1s` 保证过渡顺滑。

```css
/* ── 分段型：填充黄色按钮（引导型加号）按压 ── */
/* 背景：白色50%叠层覆盖黄底 → 视觉浅黄；图标半透明 */
.btn-plus-guide:active:not(.btn-disabled),
.btn-minus-fill:active:not(.btn-disabled) {
  background: linear-gradient(rgba(255,255,255,0.5),rgba(255,255,255,0.5)),#FFDD00;
}
.btn-plus-guide:active:not(.btn-disabled) svg,
.btn-minus-fill:active:not(.btn-disabled) svg { opacity: 0.5; }

/* ── 分段型：描边灰色型（引导型减号 / 对称型）按压 ── */
/* 背景变浅灰，描边颜色不变 */
.btn-minus-guide:active:not(.btn-disabled),
.btn-sym:active:not(.btn-disabled) { background: #F5F5F5; border-color: #E5E5E5; }
.btn-minus-guide:active:not(.btn-disabled) svg,
.btn-sym:active:not(.btn-disabled) svg { opacity: 0.5; }

/* ── 连体型：加减按钮按压 ── */
/* 使用 aria-disabled="true" 排除禁用状态（连体型用 aria 标记而非 disabled 属性） */
.stepper-int .int-minus:active:not([aria-disabled="true"]) { background: #F5F5F5; }
.stepper-int .int-minus:active:not([aria-disabled="true"]) svg { opacity: 0.5; }
.stepper-int .int-plus:active:not([aria-disabled="true"]) { background: #F5F5F5; }
.stepper-int .int-plus:active:not([aria-disabled="true"]) svg { opacity: 0.5; }

/* ── 连体输入型：加减按钮按压 ── */
.stepper-input-expanded .exp-minus:active { background: #F5F5F5; }
.stepper-input-expanded .exp-minus:active svg { opacity: 0.5; }
.stepper-input-expanded .exp-plus:active { background: #F5F5F5; }
.stepper-input-expanded .exp-plus:active svg { opacity: 0.5; }

/* ── add-button：plus 型按压（黄底叠白） ── */
.stepper-add-plus:active:not(:disabled) {
  background: linear-gradient(rgba(255,255,255,0.5),rgba(255,255,255,0.5)),#FFDD00;
}
.stepper-add-plus:active:not(:disabled) svg { opacity: 0.5; }

/* ── add-button：cart 型按压（灰底加深） ── */
.stepper-add-cart:active:not(:disabled) { background: #EBEBEB; }
.stepper-add-cart:active:not(:disabled) .font { opacity: 0.5; }

/* ── add-button：文字型按压 ── */
.stepper-add-text:active:not(.disabled) {
  background: linear-gradient(rgba(255,255,255,0.5),rgba(255,255,255,0.5)),#FFDD00;
  color: rgba(17,17,17,0.5);
}
```

> ⚠️ **关键注意事项**：
> - 分段型禁用按钮用 class `.btn-disabled` 排除，连体型用 `[aria-disabled="true"]` 排除，add-button 用 `:not(:disabled)` HTML 属性排除，三者机制不同，**不可混用**
> - 所有按钮容器需设 `transition: background 0.1s, border-color 0.1s`，SVG 需设 `transition: opacity 0.1s`，保证点击有过渡感

---

## 9. Props API（供 AI 生码参考）

```typescript
export type StepperProps = {
  /**
   * 步进器大类
   * @default "segmented"
   */
  stepperType?: "segmented" | "integrated" | "add-button";

  /**
   * 尺寸
   * @default "standard"
   */
  size?: "large" | "standard" | "small";

  /**
   * 当前数值
   */
  value: number;

  /**
   * 最小值
   * @default 0
   */
  min?: number;

  /**
   * 最大值
   */
  max?: number;

  /**
   * 步长
   * @default 1
   */
  step?: number;

  /**
   * 数值单位（可选，如「间」「份」）
   */
  unit?: string;

  /**
   * 数值变更回调
   */
  onChange?: (value: number) => void;

  /**
   * 达到最大/最小值后再次点击的回调（通常触发 Toast 提示）
   */
  onLimit?: (type: "min" | "max") => void;

  /**
   * 添加按钮图标类型（stepperType=add-button 时有效）
   * @default "plus"
   */
  iconType?: "plus" | "cart" | "text";

  /**
   * 文字按钮内容（iconType=text 时有效）
   */
  buttonText?: string;

  /**
   * 是否禁用（不可点击态）
   */
  disabled?: boolean;

  /**
   * 自定义加号按钮颜色（可覆盖默认黄色 #FFDD00）
   * 业务线覆盖规则：
   * - 小象超市（grocery / dpt12）→ 必须传 dpt12-g（#00CF22）
   * - 其他业务线 → 保持默认 #FFDD00，不跟随页面主色
   */
  addButtonColor?: string;
};
```

---

## 10. data-attribute 规范

| 属性 | 值 | 说明 |
|------|----|------|
| `data-slot` | `"stepper"` | 组件根容器 |
| `data-slot` | `"stepper-minus"` | 减号按钮 |
| `data-slot` | `"stepper-value"` | 数值显示区 |
| `data-slot` | `"stepper-plus"` | 加号/添加按钮 |
| `data-stepper-type` | `"segmented"` / `"integrated"` / `"add-button"` | 步进器大类 |
| `data-size` | `"large"` / `"standard"` / `"small"` | 尺寸变体 |
| `data-disabled` | `"true"` / `"false"` | 整体禁用状态 |
| `data-at-min` | `"true"` / `"false"` | 是否在最小值 |
| `data-at-max` | `"true"` / `"false"` | 是否在最大值 |

---

## 11. 无障碍（Accessibility）

- 减号按钮：`aria-label="减少数量"` / `aria-disabled="true"`（禁用时）
- 加号按钮：`aria-label="增加数量"` / `aria-disabled="true"`（禁用时）
- 数值区：`role="spinbutton"` / `aria-valuenow={value}` / `aria-valuemin={min}` / `aria-valuemax={max}`
- 触控目标最小 22×22pt（小号按钮外扩点击区域）

---

## 12. 变体矩阵（完整）

### 10.1 分段型（stepperType=segmented）

| size | 按钮直径 | 图标尺寸 | 数字字号 | 圆角 |
|------|---------|---------|---------|------|
| `large` | 26pt | 12pt | 15pt | radius-full（13pt） |
| `standard` | 22pt | 10pt | 15pt | radius-full（11pt） |
| `small` | 18pt | 8pt | 14pt | radius-full（9pt） |

### 10.2 连体型（stepperType=integrated）

| size | 按钮尺寸 | 图标尺寸 | 数字字号 | 减号左圆角 |
|------|---------|---------|---------|----------|
| `large` | 26×26pt | 12pt | 14pt（Medium） | 6pt（radius-xs） |
| `standard` | 22×22pt | 10pt | 13pt（Medium） | 4pt（radius-xxs） |

### 10.3 添加按钮（stepperType=add-button）

| size | 图标类型 | 按钮尺寸 | 图标尺寸 | 图标来源 | 背景 |
|------|---------|---------|---------|---------|------|
| `large` | `plus` | 26pt | **12pt** | 自定义图标 | `yellow-default`（#FFDD00） |
| `large` | `cart` | 26pt | **14pt** | iconfont | `bg-page`（#F5F5F5） |
| `large` | `text` | 26pt | — | 无图标 | `yellow-default` |
| `standard` | `plus` | 22pt | **10pt** | 自定义图标 | `yellow-default` |
| `standard` | `cart` | 22pt | **12pt** | iconfont | `bg-page`（#F5F5F5） |
| `standard` | `text` | 22pt | — | 无图标 | `yellow-default` |
| `small` | `plus` | 18pt | **8pt** | 自定义图标 | `yellow-default` |
| `small` | `cart` | 18pt | **10pt** | iconfont | `bg-page`（#F5F5F5） |

---

## 13. 使用约束（AI 生成时的硬性规则）

1. **连体型无小号**：`stepperType=integrated` 不支持 `size=small`（18pt），最小为 `standard`（22pt）
2. **禁用态必须保留视觉**：达到最大/最小值时，对应按钮必须切换为禁用样式，**不得隐藏**
3. **触达限制必须 Toast**：达到最大/最小值后再次点击，必须通过 `Toast` 组件弹出轻提示
4. **数字宽度自适应**：数字区宽度随位数自动变化，**不得设置固定宽度**
5. **添加按钮圆角固定**：`radius-full` 胶囊形，HTML 实现必须用 `border-radius: 5000px`，不可使用百分比（`50%`）或其他值
6. **颜色使用 Token**：禁止直接写 hex，必须引用 `color-semantic.md` 语义 Token
7. **自定义颜色限加号**：仅加号/添加按钮颜色可自定义，减号保持规范样式
8. **位置右对齐**：步进器在容器内始终保持**右对齐**布局

---

## 14. 常见组合示例

### 12.1 商品列表（小号分段型）

```
Stepper
  stepperType: segmented
  size: small
  value: 0
  min: 0
  max: 99
  unit: "份"
  // 数值为0时：减号禁用，加号默认
```

### 12.2 购物车（标准连体型）

```
Stepper
  stepperType: integrated
  size: standard
  value: 1
  min: 1
  max: 99
  // 连体型，减到1时减号禁用
```

### 12.3 商品卡片添加入口（小号添加按钮）

```
Stepper
  stepperType: add-button
  size: small
  iconType: plus
  // value=0，点击后切换为 segmented/integrated 步进器
```

### 12.4 酒旅预订（大号分段型带单位）

```
Stepper
  stepperType: segmented
  size: large
  value: 2
  min: 1
  max: 9
  unit: "间"
  // 按钮使用自定义品牌色
  addButtonColor: "#FFB800"
```

---

## 15. 与其他组件的关系

| 关联组件 | 关系说明 |
|----------|----------|
| `toast.md` | 达到最大/最小值后再次点击时，弹出 Toast 轻提示 |
| `button.md` | 添加按钮视觉上类似胶囊型按钮，但语义为步进器入口 |
| `input.md` | 部分场景下数字区可支持输入，需与 input 组件协同 |
