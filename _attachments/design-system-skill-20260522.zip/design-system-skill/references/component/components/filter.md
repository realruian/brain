# Filter 筛选器

> **组件分类**：Component（组件级）
> **定义**：筛选器（Filter Bar）是列表 / 搜索结果页对内容进行筛选的横向栏组件，由**文字筛选**和**按钮筛选**两大类型构成，支持单行滑动、多列等分及右侧功能区三种排列场景。
> **Style 依赖**：`color-semantic.md` · `font-semantic.md` · `spacing-semantic.md` · `component-spacing.md` · `radius-semantic.md` · `stroke-semantic.md`
> **滚动行为**：按钮筛选栏的按钮选项区域**默认开启横向滚动**（`overflow-x: auto; white-space: nowrap`），超出屏幕宽度时用户可左右滑动浏览所有选项；滚动条默认隐藏（`scrollbar-width: none`）。
> **⚡ 联动组件**：筛选器是**筛选面板（`filter-panel.md`）的触发入口**。按钮的 `expand-arrow` 及右侧功能区的 `filter-icon` / `text-filter-icon` 点击后均会弹出筛选面板；**筛选器与筛选面板必须配套使用**，不可单独出现。

---

## 0. 图标 / 间距 / Ownership 约束

- **icon-route（默认）**：Filter 触发条内功能图标默认回 `component/atoms/icon.md`，并遵循正文指定 iconfont class / weight。
- **fixed-asset 例外**：正文若指定 `assets/*.svg`、官方 SVG、PNG/CDN 或 URL 资源，触发条对应位点必须走 fixed-asset。
- **spacing-owner（Filter 自持）**：触发条本身的按钮排列、行内间距、右侧功能区对齐归 Filter。
- **宿主裁决（边界）**：Filter 拥有触发条，展开内容区 ownership 归 `filter-panel.md`；冲突遵循 `宿主 > 组合场景 > 本组件`。
- **不可跳步**：先回 `references/INDEX.md` 完成区域路由与宿主锁定，再用 `component-quickref.md` 做宿主级收敛；本文件仅承接组件内 ownership 细则，不承担前置路由改判；不得凭语义猜测。


## 1. 组件类型（type）

| type | 名称 | 说明 |
|------|------|------|
| `text` | 文字筛选 | 以文字选项形式横向排列，点击切换选中态 |
| `button` | 按钮筛选 | 以胶囊形按钮横向排列，支持单选 / 多选 / 自定义 |

---

## 2. 按钮筛选规格（size）

按钮筛选按**高度**分 3 种规格，规格不可自定义。

| size | 名称 | 高度 | 圆角 Token | 字体（未选中） | 字体（选中） | 适用场景 |
|------|------|------|-----------|-------------|------------|---------|
| `loose` | 宽松 | 34pt | `radius-s`（8pt） | `body-m-13-regular` | `body-m-13-medium`（**中黑**，500） | 快筛入口、视觉强调场景 |
| `standard` | 标准 | 30pt | `radius-xs`（6pt） | `body-s-12-regular` | `body-s-12-medium`（**中黑**，500） | 常规筛选栏 |
| `compact` | 紧凑 | 26pt | `radius-xs`（6pt） | `body-s-12-regular` | `body-s-12-medium`（**中黑**，500） | 信息密集 / 空间紧张场景 |

> ⚠️ **高度为精确约束值**，不使用 spacing token，不可调整。

---

## 3. 按钮选中态（selectedState）

| selectedState | 名称 | 背景 Token | 描边 | 文字 Token |
|--------------|------|-----------|------|-----------|
| `unselected-gray` | 灰底未选中 | `white`（#FFFFFF） | 无 | `text-secondary` |
| `unselected-white` | 白底未选中 | `bg-surface`（#F7F7F7） | 无 | `text-secondary` |
| `weak-selected` | 弱选中 | `bg-fill-brand-light`（`#FFFADB`） | 无 | `color-brand-emphasis` |
| `selected` | 中选中 | `bg-fill-brand-light`（`#FFFADB`） | `cs-0.5`（0.5pt）`stroke-brand`（`#FFDD00`） | `color-brand-emphasis` |
| `multi-selected` | 多选选中 | `bg-fill-brand-light` | `cs-0.5`（0.5pt）`stroke-brand` | `color-brand-emphasis` |
| `strong-selected` | 强选中 | `gradient-yellow`（渐变） | 无 | `text-primary` |
| `custom` | 自定义 | `bg-fill-tertiary` | 无 | — |

> `unselected-gray` 与 `unselected-white` 均为**未选中**交互状态，二者的差异由**筛选栏下方的页面底色**决定：
> - 页面底色为**灰色**（`bg-page`，`#F5F5F5`）→ 按钮未选中用**白色** → 使用 `unselected-gray`（按钮背景 `white`，`#FFFFFF`）
> - 页面底色为**白色**（`white`，`#FFFFFF`）→ 按钮未选中用浅灰色 → 使用 `unselected-white`（按钮背景 `bg-surface`，`#F7F7F7`）
>
> ❌ 禁止将二者视为不同的交互态混用。

---

## 4. 按钮内容构成（slots）

按钮筛选内容区由以下元素按顺序组合（均可选）：

```
[ 左图标（可选） ] + [ 主文字 ] + [ 副信息（双行时）] + [ 展开箭头（可选）]
```

| slot | 说明 |
|------|------|
| `icon-left` | 左侧图标（可选），`aria-hidden="true"` |
| `label` | 主文字（**必须**） |
| `sub-label` | 副信息（仅宽松规格 `double-line` 模式时有效） |
| `expand-arrow` | 右侧展开箭头（可选）。**点击此处触发筛选面板（`filter-panel.md`）弹出**；面板打开时箭头逐开（`icon-iconfont-retract-line-bold`），面板关闭时还原（`icon-iconfont-expand-line-bold`）；与文字间距 `spacing-3xs`（2pt） |

### 4.1 筛选按钮图标规范（必须来自 icon.md）

#### 图标尺寸

| 按钮规格 | 左图标尺寸 | 展开箭头尺寸 | 图标与文字 gap | 图标颜色 |
|---------|----------|------------|--------------|---------|
| `loose`（宽松，34pt） | 15pt | 11pt × 11pt | `spacing-3xs`（2pt） | 与文字色一致 |
| `standard`（标准，30pt） | 14pt | 10pt × 10pt | `spacing-3xs`（2pt） | 与文字色一致 |
| `compact`（紧凑，26pt） | 14pt | 10pt × 10pt | `spacing-3xs`（2pt） | 与文字色一致 |

> `expand-arrow`（展开箭头）宽高均取上表对应值，与左侧文字 gap 同为 `spacing-3xs`（2pt）。

> 图标颜色跟随当前按钮的文字 Token（见 §3 选中态表「文字 Token」列），❌ 禁止单独指定图标颜色。

筛选按钮内的图标（`icon-left` 和 `expand-arrow`）**必须**使用 `component/atoms/icon.md` 中定义的 iconfont 图标库，类名格式 `font icon-iconfont-{name}-{weight}`：

```tsx
// ✅ 正确 — 左图标 + 展开箭头
<FilterButton
  iconLeft={<span className="font icon-iconfont-locate-line-regular" aria-hidden />}  {/* 定位 */}
  label="附近"
  hasExpand
  expandArrow={<span className="font icon-iconfont-expand-line-regular" aria-hidden />}  {/* 展开 */}
/>

// ✅ 正确 — 右侧功能区图标（激活态只改颜色，图标类名不变）
<span className="font icon-iconfont-filter-line-regular" aria-hidden />  {/* filter-icon 变体：筛选漏斗 常规体 18pt — 未激活 #555555，激活 #111111 */}
<span className="font icon-iconfont-filter-line-medium" aria-hidden />   {/* text-filter-icon 变体：筛选漏斗 中黑体 15pt — 未激活 #555555，激活 #111111 */}
<span className="font icon-iconfont-expand-line-bold" aria-hidden />      {/* 展开箭头 中粗体 12pt — 未激活 #555555，激活 #111111 */}

// ❌ 错误 — mtdicon 旧类名或 SVG 内联
<i className="mtdicon-filter" />  {/* ❌ mtdicon 已废弃 */}
```

> ⚠️ 激活态只改图标颜色，图标类名不变。未激活 `#555555`，激活 `#111111`。

> ⚠️ **iconfont 字重由类名后缀决定**（`-regular` / `-medium` / `-bold`），`font-weight` CSS 属性对 iconfont 图标**无效**，不可用 `font-weight: 500` 代替中黑体类名。

| 右侧功能区场景 | 图标类名 | 字重 | 尺寸 |
|-------------|---------|------|------|
| `filter-icon` 变体 — 筛选漏斗 | `icon-iconfont-filter-line-regular` | 常规体 | 18pt |
| `text-filter-icon` 变体 — 筛选漏斗 | `icon-iconfont-filter-line-medium` | **中黑体** | 15pt |
| 展开箭头（向下） | `icon-iconfont-expand-line-bold` | 中粗体 | 12pt |
| 收起箭头（向上） | `icon-iconfont-retract-line-bold` | 中粗体 | 12pt |

### 4.2 宽松规格双行模式（double-line）

宽松规格（`size=loose`）除单行外，还支持**双行**内容排列，两行上下居中对齐，行间距 **-1pt**。`standard` 和 `compact` 不支持双行。

| 状态 | 第一行主文字 | 主文字颜色 | 第二行副信息 | 副信息颜色 |
|------|------------|----------|------------|---------|
| 未选中 | 12pt 常规（400） | `text-secondary`（`#555555`） | 10pt 常规（400） | `text-tertiary`（`#999999`） |
| 选中 | 12pt **中黑**（500） | `color-brand-emphasis`（`#FF7700`） | 10pt 常规（400） | `color-brand-emphasis`（`#FF7700`） |

> ⚠️ **CSS 实现注意**：Flexbox 的 `gap` 属性不支持负值，**-1pt 行间距须用 `margin-top: -2px`（@2x）加在副信息元素上**实现，而非 `gap: -2px`。

---

## 5. 文字筛选布局（layout）

| layout | 名称 | 布局规则 |
|--------|------|---------|
| `space-between` | 间距等分式 | `justify-content: space-between`，选项间 gap `spacing-3xl`（24pt） |
| `screen-equal` | 屏幕等分式 | 选项等宽分摊整行，`padding: spacing-m 0`（上下 10pt） |
| `left-align` | 左对齐式 | 选项靠左，左右两个区块独立 |

文字筛选容器：375pt 宽 × 40pt 高，`bg-surface`，`display: flex; flex-direction: row; flex-wrap: nowrap`。

### 5.1 文字选项颜色

| 状态 | 颜色 Token | 颜色值 | 字重 |
|------|-----------|--------|------|
| 未选中（默认） | `text-secondary` | `#555555` | `regular`（400） |
| 选中 | `color-brand-emphasis` | `#FF7700` | `medium`（**中黑**，500） |

> 文字筛选未选中文字色为 `text-secondary`（`#555555`），仅**选中态**使用品牌强调色 `color-brand-emphasis`（`#FF7700`）。

### 5.2 文字选项展开箭头

每个文字筛选选项**右侧均需带展开箭头**，规格如下：

| 属性 | 规范值 |
|------|-------|
| 图标 | `icon-iconfont-expand-line-bold`（中粗体） |
| 尺寸 | 12pt（@2x：24px） |
| 与文字间距 | 2pt（@2x：4px） |
| 颜色 | 跟随文字色：未选中 `text-secondary`（`#555555`），选中 `color-brand-emphasis`（`#FF7700`） |

> ⚠️ 展开箭头颜色跟随文字，❌ 禁止单独指定图标颜色。

---

## 6. 右侧功能区（rightAction）

右侧功能区与按钮筛选规格对应，共 3 种规格：

| size | 高度 | 适配场景 |
|------|------|---------|
| `loose` | 34pt | 宽松按钮筛选栏 |
| `standard` | 30pt | 标准按钮筛选栏 |
| `compact` | 26pt | 紧凑按钮筛选栏 |

### 6.1 样式变体（style）

| style | 名称 | 内容说明 |
|-------|------|---------|
| `gradient-only` | 渐变遮罩 | 仅渐变遮罩，无功能图标 |
| `expand-arrow` | 展开箭头 | 渐变遮罩 + 展开箭头图标（12pt、中粗体）；图标色：未激活 `#555555`，激活 `#111111` |
| `filter-icon` | 筛选图标 | 渐变遮罩 + 漏斗筛选图标（18pt、常规体）；图标色：未激活 `#555555`，激活 `#111111` |
| `text-filter-icon` | 文字 + 筛选图标 | 渐变遮罩 + 筛选文字（13pt、`body-m-13-regular`） + 2pt 间距 + 漏斗筛选图标（15pt、**中黑体**）；图标与文字色：未激活 `#555555`，激活 `#111111` |

> ❌ **右侧功能区 style 为必填项**，不可省略。按钮筛选栏存在右侧功能区时，必须从上表四种 style 中选取其一，禁止留空或自定义。

各变体适用场景如下：

| style | 适用场景 |
|-------|---------|
| `gradient-only` | 渐变隐喻可横滑，适合筛选项较少、无需操作入口的场景；**不触发筛选面板** |
| `expand-arrow` | 适合筛选项较多、维度单一的场景；**点击展开筛选面板（`filter-panel.md`）** |
| `filter-icon` | 适合多维度综合筛选；**点击打开筛选面板（`filter-panel.md`）**，激活态图标变色表示已有筛选条件 |
| `text-filter-icon` | 适合多维度综合筛选；**点击打开筛选面板（`filter-panel.md`）**，可显示已选数量及提供清空操作入口 |

> 🤖 **AI 生成决策规则**：生成按钮筛选栏时，若含右侧功能区，必须依据以下逻辑自动选取 style，❌ 禁止不选或自创：
>
> | 场景特征 | 应选 style |
> |---------|-----------|
> | 筛选项较少（≤5个），无需操作入口，仅需提示可横滑 | `gradient-only` |
> | 筛选项较多，但维度单一（如排序），点击可展开更多 | `expand-arrow` |
> | 多维度综合筛选，需显示"已筛选"状态 | `filter-icon` |
> | 多维度综合筛选，需显示已选数量或提供清空入口 | `text-filter-icon` |

渐变遮罩以 `position: absolute` 叠在按钮区右侧，方向 `270deg`（从右向左渐出）。各变体白底 / 灰底渐变精确值如下：

遮罩高度 = 对应筛选栏高度（`loose` 34pt / `standard` 30pt / `compact` 26pt），下表宽度为各变体固定值。

**白底（`#FFFFFF`）**

| style | 遮罩宽度（pt） | 渐变 |
|-------|-------------|------|
| `gradient-only` | 18 | `linear-gradient(270deg, #FFFFFF 0%, #FFFFFF 33%, rgba(255,255,255,0) 100%)` |
| `expand-arrow` | 42 | `linear-gradient(270deg, #FFFFFF 0%, #FFFFFF 70%, rgba(255,255,255,0) 100%)` |
| `filter-icon` | 46 | `linear-gradient(270deg, #FFFFFF 0%, #FFFFFF 70%, rgba(255,255,255,0) 100%)` |
| `text-filter-icon` | 67 | `linear-gradient(270deg, #FFFFFF 0%, #FFFFFF 80%, rgba(255,255,255,0) 100%)` |

**灰底（`#F5F5F5`）**

| style | 遮罩宽度（pt） | 渐变 |
|-------|-------------|------|
| `gradient-only` | 18 | `linear-gradient(270deg, #F5F5F5 0%, #F5F5F5 33%, rgba(245,245,245,0) 100%)` |
| `expand-arrow` | 42 | `linear-gradient(270deg, #F5F5F5 0%, #F5F5F5 70%, rgba(245,245,245,0) 100%)` |
| `filter-icon` | 46 | `linear-gradient(270deg, #F5F5F5 0%, #F5F5F5 80%, rgba(245,245,245,0) 100%)` |
| `text-filter-icon` | 67 | `linear-gradient(270deg, #F5F5F5 0%, #F5F5F5 80%, rgba(245,245,245,0) 100%)` |

### 6.2 右侧功能区选中态

> **默认展示未激活态**（`default`，`#555555`）。仅在用户已触发筛选操作后，切换为激活态（`selected`，`#111111`）。❌ 禁止初始状态使用激活态。

| 选中态 | 图标 / 文字颜色 | 说明 |
|--------|--------------|------|
| `default` | `#555555` | **默认态**，未筛选状态 |
| `selected` | `#111111` | 已筛选，图标类名不变，只改颜色 |
| `clear` | `#111111` | 显示清空操作 |

---

## 7. Token 引用

### 7.1 颜色 Token

| 用途 | Token 名称 | 语义层来源 |
|------|-----------|-----------|
| 白底筛选栏背景 | `bg-surface` | `color-semantic.md` §三 Background Color |
| 灰底按钮 / 灰底筛选栏背景 | `bg-fill-tertiary` | `color-semantic.md` §三 Background Color |
| 弱/中/多选背景 | `bg-fill-brand-light` | `color-semantic.md` §三 Background Color |
| 强选中渐变背景 | `gradient-yellow` | `color-semantic.md` §八 Gradient Color |
| 未选中文字（首选） | `text-secondary` | `color-semantic.md` §二 Text Color |
| 选中文字 / 图标 | `color-brand-emphasis` | `color-semantic.md` §七 Brand Color |
| 强选中文字 | `text-primary` | `color-semantic.md` §二 Text Color |
| 中/多选描边 | `stroke-brand` | `color-semantic.md` §四 Stroke Color |

### 7.2 字体 Token

| 用途 | Token 名称 | 语义层来源 |
|------|-----------|-----------|
| 宽松按钮文字（未选中） | `body-m-13-regular`（regular，400） | `font-semantic.md` §一 Body |
| 宽松按钮文字（选中） | `body-m-13-medium`（**中黑**，500） | `font-semantic.md` §一 Body |
| 宽松双行主文字（`label`） | `body-s-12-medium`（**中黑**，500） | `font-semantic.md` §一 Body |
| 宽松双行副信息（`sub-label`） | `caption-s-10-regular`（regular，400） | `font-semantic.md` §一 Caption |
| 标准 / 紧凑按钮文字（未选中） | `body-s-12-regular`（regular，400） | `font-semantic.md` §一 Body |
| 标准 / 紧凑按钮文字（选中） | `body-s-12-medium`（**中黑**，500） | `font-semantic.md` §一 Body |
| 文字筛选选项（未选中） | `body-l-14-regular`（regular，400） | `font-semantic.md` §一 Body |
| 文字筛选选项（选中） | `body-l-14-medium`（**中黑**，500） | `font-semantic.md` §一 Body |

### 7.3 圆角 Token（`component-radius`）

> 圆角统一使用 `component-radius` 语义层，不直接写 px 数值。

| 用途 | Token 名称 | 值 |
|------|-----------|-----|
| 宽松按钮 | `component-radius-s`（`radius-s`） | 8pt |
| 标准 / 紧凑按钮 | `component-radius-xs`（`radius-xs`） | 6pt |
| **中选中 / 弱选中按钮** | `component-radius-m`（`radius-m`） | 16pt（卡片嵌套组件，四级圆角） |
| 筛选栏容器（快筛场景） | `component-radius-full`（`radius-full`） | 胶囊全圆角 |

### 7.4 间距 Token（`component-spacing`）

> 间距统一使用 `component-spacing` 语义层，不直接写 px 数值。

| 用途 | Token 名称 | 值 | 适用规格 |
|------|-----------|-----|----------|
| 筛选栏左侧边距（第一个按钮距页面边） | `component-spacing-l`（`spacing-l`） | 12pt | 三种规格通用 |
| 按钮间 gap | `component-spacing-xs`（`spacing-xs`） | 6pt | 三种规格通用 |
| 筛选栏容器上下内边距 | `component-spacing-s`（`spacing-s`） | 8pt | 三种规格通用 |
| 间距等分式文字筛选 gap | `component-spacing-3xl`（`spacing-3xl`） | 24pt | 文字筛选 |
| 按钮内图标与文字 gap（含展开箭头） | `component-spacing-3xs`（`spacing-3xs`） | 2pt | 三种规格通用 |
| 中选中 / 弱选中按钮上下内边距 | `component-spacing-m`（`spacing-m`） | 16pt | 卡片嵌套场景 |
| 中选中 / 弱选中按钮左右内边距 | `component-spacing-xl`（`spacing-xl`） | 24pt | 卡片嵌套场景 |
| 中选中 / 弱选中按钮内容 gap | `component-spacing-s`（`spacing-s`） | 10pt | 卡片嵌套场景 |

---

## 8. 筛选栏容器滚动规范

按钮筛选栏的按钮区域**默认启用横向滚动**，具体 CSS 规范如下：

| 属性 | 值 | 说明 |
|------|-----|------|
| `overflow-x` | `auto` | 超出宽度时可横向滑动 |
| `overflow-y` | `hidden` | 垂直方向不滚动 |
| `white-space` | `nowrap` | 禁止按钮换行，保持单行排列 |
| `scrollbar-width` | `none`（Firefox）/ `::-webkit-scrollbar { display: none }`（WebKit） | 隐藏滚动条，保持视觉干净 |
| `-webkit-overflow-scrolling` | `touch` | iOS 开启惯性滚动 |
| `scroll-snap-type` | `x mandatory` | 可选：开启吸附对齐，提升滑动体验 |
| `scroll-snap-align` | `start`（每个按钮） | 配合 `scroll-snap-type` 使用 |

> ⚠️ **滚动约束**：
> - 按钮区滚动容器**不包含右侧功能区**，右侧功能区固定在容器右端（`position: sticky; right: 0`）
> - 右侧功能区的渐变遮罩承担视觉上「内容被遮住」的提示作用，不可省略
> - 文字筛选的 `space-between` / `screen-equal` 布局**不启用滚动**，选项始终填满容器宽度
> - 文字筛选的 `left-align` 布局**可启用滚动**（规则同按钮筛选）

---

## 9. Props API（供 AI 生码参考）

```typescript
export type FilterButtonProps = {
  /**
   * 按钮规格
   * @default "standard"
   */
  size: "loose" | "standard" | "compact";

  /**
   * 选中态
   * @default "unselected-gray"
   */
  selectedState?: "unselected-gray" | "unselected-white" | "weak-selected" | "selected" | "multi-selected" | "strong-selected" | "custom";

  /**
   * 是否显示左侧图标
   * @default false
   */
  hasIcon?: boolean;

  /**
   * 是否显示右侧展开箭头
   * @default false
   */
  hasExpand?: boolean;

  /**
   * 双行模式（仅 size=loose 支持）
   * @default "default"
   */
  doubleLineMode?: "default" | "double-line";

  /** 主文字 */
  label: string;

  /** 副信息（双行模式时有效） */
  subLabel?: string;

  /** 点击回调 */
  onClick?: () => void;
};

export type FilterBarProps = {
  /**
   * 筛选器类型
   * @default "button"
   */
  type: "text" | "button";

  /**
   * 按钮规格（type=button 时有效）
   * @default "standard"
   */
  size?: "loose" | "standard" | "compact";

  /**
   * 文字筛选布局（type=text 时有效）
   * @default "space-between"
   */
  layout?: "space-between" | "screen-equal" | "left-align";

  /** 是否显示右侧功能区 */
  hasRightAction?: boolean;

  /** 右侧功能区样式 */
  rightActionStyle?: "gradient-only" | "expand-arrow" | "filter-icon" | "text-filter-icon";

  /** 背景色 */
  background?: "white" | "gray";

  /** 筛选项列表 */
  items: Array<{
    label: string;
    selectedState?: string;
    subLabel?: string;
  }>;

  /** 右侧功能区点击回调 */
  onRightActionClick?: () => void;
};
```

---

## 10. data-attribute 规范

| 属性 | 值 | 说明 |
|------|-----|------|
| `data-slot` | `"filter-bar"` | 全局稳定标识 |
| `data-type` | `"text"` / `"button"` | 筛选器类型 |
| `data-size` | `"loose"` / `"standard"` / `"compact"` | 按钮规格 |
| `data-state` | `"unselected-gray"` / `"unselected-white"` / `"weak-selected"` / `"selected"` / `"multi-selected"` / `"strong-selected"` | 选中态 |
| `data-has-right-action` | `"true"` / `"false"` | 是否有右侧功能区 |

---

## 11. 无障碍（a11y）

- 筛选栏整体建议用 `role="toolbar"` 或 `<nav aria-label="筛选选项">` 包裹
- 每个筛选按钮使用 `<button>` 元素，选中时 `aria-pressed="true"`，未选中时 `aria-pressed="false"`
- 展开箭头按钮添加 `aria-expanded="true|false"` + `aria-haspopup="dialog"`
- 右侧筛选图标按钮添加 `aria-label="打开筛选面板"`
- 禁用态使用 `aria-disabled="true"`，不使用 HTML `disabled`

---

## 12. 使用约束（AI 生成时的硬性规则）

1. **禁止跳过规格**：只能从 `loose` / `standard` / `compact` 中选取，不可自定义高度
2. **禁止直接写 hex 颜色**：颜色必须引用 §7.1 中的语义层 Token
3. **禁止直接写 px 间距**：间距必须使用 `component-spacing` 语义层 Token（见 §7.4）
4. **禁止直接写 px 圆角**：圆角必须使用 `component-radius` 语义层 Token（见 §7.3）
5. **双行模式仅宽松支持**：`doubleLineMode` 仅在 `size=loose` 时有效
6. **强选中仅用于强调**：`strong-selected` 仅在单选且需要强视觉反馈时使用
7. **按钮规格需与右侧功能区对应**：`size` 和 `rightActionStyle` 必须使用同一规格
8. **筛选栏容器背景**：白底页面使用 `bg-surface`，灰底页面使用 `bg-fill-tertiary`
9. **展开箭头尺寸**：`loose` 规格使用 11pt × 11pt，`standard` / `compact` 规格使用 10pt × 10pt
10. **文字筛选颜色**：未选中用 `text-secondary`（`#555555`），仅选中态用 `color-brand-emphasis`（`#FF7700`），不直接写 hex
11. **选中态字重**：所有筛选按钮及文字筛选的**选中态**均使用**中黑体**（`medium`，`font-weight: 500`）；未选中态一律使用常规体（`regular`，`font-weight: 400`）
12. **按钮区横向滚动**：按钮筛选栏的按钮选项区域**必须默认开启横向滚动**（`overflow-x: auto; white-space: nowrap`），不可设置为 `overflow: hidden` 或允许换行

---

## 13. 选型决策树

```
需要筛选器
├─ 文字列表形式（点击切换，无按钮感）?
│    └─ 文字筛选（text）
│         ├─ 选项等间距? → space-between
│         ├─ 选项等宽分摊? → screen-equal
│         └─ 选项靠左? → left-align
│
└─ 胶囊按钮形式?
     └─ 按钮筛选（button）
          ├─ 快筛入口 / 视觉强调? → size=loose
          ├─ 常规列表筛选? → size=standard
          └─ 空间紧张? → size=compact

选中态选择:
  用户未操作      → unselected-gray / unselected-white
  轻触激活单选    → weak-selected
  已确认单选      → selected
  多选已选        → multi-selected
  全量确认/强调   → strong-selected（渐变黄）
```

---

## 15. 使用场景速查

| 场景 | 推荐类型 | 关键配置 |
|------|---------|---------|
| 列表页顶部排序切换 | 文字筛选 | `layout="space-between"` |
| 搜索结果页快筛 | 按钮筛选宽松 | `size="loose"`，`hasExpand=true` |
| 常规多维度筛选 | 按钮筛选标准 | `size="standard"`，可横滑 |
| 密集信息页筛选 | 按钮筛选紧凑 | `size="compact"` |
| 带筛选面板入口 | 按钮筛选 + 右侧筛选图标 | `hasRightAction=true`，`rightActionStyle="filter-icon"` |

---

## 16. 与其他组件的关系

| 关联组件 | 关系说明 |
|---------|---------|
| `filter panel.md` | 点击筛选按钮右侧展开箭头时，弹出筛选面板；二者配合使用 |
| `tabs.md` | 选项卡负责内容分类，筛选器负责条件过滤，在同一页面可上下叠用 |
| `search bar.md` | `size=88` + `layout="with-tags"` 的搜索框下部筛选标签栏可与筛选器配合使用 |
| `list.md` | 筛选器通常位于列表头部，过滤并刷新列表内容 |
