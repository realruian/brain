# Popover 气泡浮层

> **组件分类**：Component（组件级）
> **定义**：气泡浮层是一种从被触发元素附近弹出的浮层面板，通过尖角指向触发项，以操作列表的形式呈现多个可点击选项。与 Tooltip（气泡提示）的区别在于：Popover 面向用户**主动操作**触发，承载**菜单式选项列表**，支持图标 + 文字组合及数字徽标；Tooltip 面向系统**自动出现**，承载**引导说明文案**。
> **Style 依赖**：`color-semantic.md` · `font-semantic.md` · `spacing-semantic.md` · `component-spacing.md` · `radius-semantic.md` · `shadow-semantic.md` · `stroke-semantic.md`
> **Style 层级**：Reference（`color-reference` / `radius-reference` / `shadow-reference` / `spacing-reference`）→ Semantic（`color-semantic` / `radius-semantic` / `shadow-semantic` / `spacing-semantic` / `component-spacing`）→ Component（本文件）

> ⚠️ **核心约束**：
> - 气泡浮层最多支持 **7 个选项（行）**，最少 **1 个**
> - 主题分为**浅色容器**和**深色容器**，浅色带阴影，深色无阴影
> - 尖角位置分为**尖角在上**（气泡在触发项下方）和**尖角在下**（气泡在触发项上方）
> - 每行选项固定包含：图标（16×16pt）+ 文字 + 可选数字徽标
> - 气泡宽度为**固定宽度 108pt**（内容区 76pt），不随内容自适应
> - 与屏幕边缘最小间距 **6pt**（设计稿 12px @2x）

---

## 0. 图标 / 间距 / Ownership 约束

- **icon-route（默认）**：Popover 行内功能图标默认回 `component/atoms/icon.md`，并遵循正文 iconfont class / weight。
- **fixed-asset 例外**：尖角、close icon、URL 切图及 CSS/SVG 降级位点属于 fixed-asset 或显式例外，必须按正文指定路由，不得被通用 icon 规则覆盖。
- **spacing-owner（归属）**：气泡容器、列表行间距、尖角与容器对齐归 Popover；页面外层留白归宿主。
- **宿主裁决（优先级）**：冲突遵循 `宿主 > 组合场景 > Popover 通用规则`，避免子组件反向改浮层布局。
- **不可跳步**：先回 `references/INDEX.md` 完成区域路由与宿主锁定，再用 `component-quickref.md` 做宿主级收敛；本文件仅承接组件内 ownership 细则，不承担前置路由改判；不得凭语义猜测。


## 1. 主题（theme）

| theme | 名称 | 背景色 | 文字色 | 图标色 | 分割线色 | 阴影 | 适用场景 |
|-------|------|-------|-------|-------|---------|------|---------|
| `light` | 浅色容器 | `#FFFFFF` | `#111111` | `#111111` | `rgba(0,0,0,0.1)` | 根容器 `filter: drop-shadow(0px 4px 16px rgba(0,0,0,0.12))`（@1x） | 浅色页面背景，通用 |
| `dark` | 深色容器 | `rgba(0,0,0,0.8)` | `#FFFFFF` | `#FFFFFF` | `rgba(255,255,255,0.15)` | 无阴影 | 深色背景或蒙层之上 |

> **选型原则**：
> - 常规浅色/白色页面 → `light`（浅色容器，带阴影）
> - 深色背景、图片叠加蒙层 → `dark`（深色容器，无阴影）
> - 两种主题的尖角图片颜色与气泡背景色保持一致：`light` 使用白色尖角切图，`dark` 使用黑色尖角切图

---

## 2. 尖角位置（arrowPosition）

| arrowPosition | 名称 | 尖角所在区域 | 气泡与触发项的位置关系 |
|--------------|------|-----------|-------------------|
| `top` | 尖角在上 | 气泡顶部（"顶部区域"） | 气泡在触发项**下方** |
| `bottom` | 尖角在下 | 气泡底部（"底部区域"） | 气泡在触发项**上方** |

> **尖角对齐规则**：
> - 默认：尖角与气泡**水平方向居中**对齐
> - 实际使用时，尖角应与触发元素（如 Icon Button）**水平方向居中**对齐
> - 尖角距触发元素 **8pt**（设计稿 16px @2x 行间距，实际与元素的像素间距依场景而定）
> - 触发元素靠近屏幕边缘时，尖角与气泡边缘保持 **12pt**（设计稿 24px @2x）最小间距，允许不完全居中

---

## 3. 选项数（itemCount）

| itemCount | 名称 | 整体高度（含尖角）@1x | 内容区高度 @1x | 说明 |
|-----------|------|-------------------|-------------|------|
| `1` | 1 个选项 | **50pt** | 44pt | 最小用法，单一操作 |
| `2` | 2 个选项 | **94pt** | 88pt | 最常见用法 |
| `3` | 3 个选项 | **138pt** | 132pt | 适合 3 个并列操作 |
| `4` | 4 个选项 | **182pt** | 176pt | 内容较多时使用 |
| `5` | 5 个选项 | **226pt** | 220pt | 接近建议上限 |
| `6` | 6 个选项 | **270pt** | 264pt | 较多，需评估是否拆分 |
| `7` | 7 个选项 | **314pt** | 308pt | 上限，超过时应考虑其他容器 |

> **说明**：
> - 高度计算：`尖角高度(6pt) + 内容区高度`
> - 内容区高度 = `itemCount × 44pt`（每行固定 44pt）
> - 建议选项数控制在 **1~4** 个，超过 5 个时应评估是否使用底部弹窗（Half-screen Dialog）

---

## 4. 尺寸规格（@1x，单位 pt）

> **注意**：设计稿为 @2x（750px 基准），以下所有数值已换算为 @1x（375pt 基准）。

### 4.1 整体容器

| 属性 | 值（@1x） | 设计稿值（@2x） | 说明 |
|------|---------|-------------|------|
| 容器宽度 | **108pt** | 216px | 固定宽度，不随内容变化 |
| 圆角 | **8pt** | 16px | 内容容器圆角（`radius-s`，来自 `radius-semantic.md`） |
| 布局方向 | `column` | — | 纵向堆叠结构 |
| 对齐方式 | `center` | — | 水平居中 |

### 4.2 尖角（Arrow）

| 属性 | 值（@1x） | 设计稿值（@2x） | 说明 |
|------|---------|-------------|------|
| 尖角宽度 | **16pt** | 32px | 固定 |
| 尖角高度 | **6pt** | 12px | 固定 |
| 尖角实现方式 | 切图（`<img>`） | — | ❌ 禁止使用 CSS border 三角形，必须使用切图资源 |
| 浅色尖角切图（向上） | — | `https://p0.meituan.net/ingee/f3547f12e4ddd6476c61a115e946b9f8315.png` | `light` 主题，`arrowPosition=top` |
| 浅色尖角切图（向下） | — | 同上 + `transform: scaleY(-1)` | `light` 主题，`arrowPosition=bottom` |
| 深色尖角切图（向上） | — | `https://p0.meituan.net/ingee/176849195dfbc677a2f8fdae2569ba0a379.png` | `dark` 主题，`arrowPosition=top` |
| 深色尖角切图（向下） | — | 同上 + `transform: scaleY(-1)` | `dark` 主题，`arrowPosition=bottom` |
| 水平对齐 | 与容器居中 | `justify-content: center` | 默认居中，可按需调整 |

### 4.3 选项行（Row Item）

| 属性 | 值（@1x） | 设计稿值（@2x） | 说明 |
|------|---------|-------------|------|
| 行宽度 | **76pt** | 152px | 内容区宽度 |
| 行高度 | **44pt** | 88px | 固定行高 |
| 图标尺寸 | **16×16pt** | 32×32px | 功能图标（1：1） |
| 图标与文字间距 | **4pt** | 8px | `cs-4`（`component-spacing.md`） |
| 文字区宽度 | **56pt** | 112px | 标签文字占位宽度 |
| 文字高度 | **20pt** | 40px | 单行文字高度 |
| 布局方向 | `row` | — | 横向排列 |
| 垂直对齐 | `center` | — | 垂直居中 |
| 分割线厚度 | **0.5pt** | 1px / 0.5px | 行间分割线（头部和尾部行有明确分割线，中间行无） |

### 4.4 内容容器内边距

| 属性 | 值（@1x） | 设计稿值（@2x） | 说明 |
|------|---------|-------------|------|
| 上内边距 | **0pt** | 0px | 无上下 padding，高度由行高撑起 |
| 下内边距 | **0pt** | 0px | 无上下 padding，高度由行高撑起 |
| 左内边距 | **16pt** | 32px | `cs-16`（`component-spacing.md`） |
| 右内边距 | **16pt** | 32px | `cs-16`（`component-spacing.md`） |
| 行间间距（row-gap） | **0pt** | 0px | 行间无额外间距，高度由各行 88px 行高构成 |

### 4.5 文字规格

| 属性 | 值（@1x） | 设计稿值（@2x） | Token |
|------|---------|-------------|-------|
| 字体 | PingFang SC | — | — |
| 字号 | **14pt** | 28px | `body-s-28-regular` |
| 行高 | **20pt** | 40px | — |
| 字重 | 400（Regular） | — | — |
| 浅色文字色 | `#111111` | — | `text-primary` |
| 深色文字色 | `#FFFFFF` | — | `white` |

---

## 5. Token 引用

### 5.1 颜色 Token

| 用途 | Token 名称 | 值 | 语义层来源 |
|------|-----------|-----|-----------|
| 浅色容器背景 / 尖角 | `white` | `#FFFFFF` | `color-semantic.md` §一 |
| 深色容器背景 / 尖角 | `bg-overlay-dark` | `rgba(0,0,0,0.8)`（80%黑） | `color-semantic.md` §六 |
| 浅色容器文字 / 图标 | `text-primary` | `#111111` | `color-semantic.md` §二 |
| 深色容器文字 / 图标 | `white` | `#FFFFFF` | — |
| 浅色分割线 | `divider-default` | `rgba(0,0,0,0.1)`（10%黑） | `color-semantic.md` §五 |
| 深色分割线 | `divider-inverse` | `rgba(255,255,255,0.15)`（15%白） | `color-semantic.md` §五 |
| 浅色阴影 | `shadow-overlay` | `rgba(0,0,0,0.12)`（12%黑，Y=4pt B=16pt @1x） | `shadow-semantic.md` §一 |

> **深色容器**背景 `rgba(0,0,0,0.8)` 即 80% 不透明黑色（设计稿对应十六进制 `#000000CC`）。

### 5.2 字体 Token

| 用途 | Token 名称 | 字号 | 字重 | 行高 |
|------|-----------|------|------|------|
| 选项文字 | `body-s-28-regular` | 14pt（28px @2x） | 400（Regular） | 20pt（40px @2x） |

### 5.3 间距 Token

> **引用规则**：组件内部 padding / gap 从 `component-spacing.md`（`cs-{N}`）引用；页面级/模块级间距从 `spacing-semantic.md` 引用。

| 用途 | Token 名称 | 来源文件 | 值（@1x） | 说明 |
|------|-----------|---------|---------|------|
| 容器上下内边距 | — | — | 0pt | 无上下 padding，高度由行高撑起 |
| 容器左右内边距 | `cs-16` | `component-spacing.md` | 16pt | 组件内部 padding |
| 图标与文字间距（gap） | `cs-4` | `component-spacing.md` | 4pt | 同 `spacing-2xs` 数值，但组件层优先引用 `cs-4` |
| 行间距（row-gap） | — | — | 0pt | 行间无额外间距 |
| 尖角与气泡边缘最小间距 | `spacing-xs` | `spacing-semantic.md` | 6pt | 边缘安全距离约束，属页面/布局层规则 |

### 5.4 圆角 Token

> **引用规则**：Popover 内容容器圆角 ≥ 4pt，属页面级浮层圆角，从 `radius-semantic.md` 引用（`radius-s`）。

| 用途 | Token 名称 | 来源文件 | 值（@1x） |
|------|-----------|---------|----------|
| 内容容器圆角 | `radius-s` | `radius-semantic.md` | 8pt（16px @2x） |

### 5.5 阴影 Token（浅色容器专用）

> **三层溯源链**：`shadow-overlay`（`shadow-semantic.md`）→ `Shadow/.Large`（`shadow-reference.md`）→ `0 4pt 16pt 12% #000000`

| 用途 | Token 名称 | 来源文件 | 值（@1x） | 施加位置 |
|------|-----------|---------|---------|--------|
| 浅色容器外阴影 | `shadow-overlay` | `shadow-semantic.md` | `filter: drop-shadow(0px 4px 16px rgba(0,0,0,0.12))` | **根容器**（`data-slot="popover"`） |

> ⚠️ **阴影必须加在根容器上，不得加在 `popover-content` 上。**
> - `box-shadow` 只对矩形边界框投影，会遮盖尖角切图，导致尖角上方出现阴影截断线。
> - `filter: drop-shadow()` 基于实际渲染像素轮廓计算，将尖角切图与内容容器作为整体统一投影，视觉上形成完整气泡轮廓阴影。

---

## 6. 结构规格

### 6.1 组件树结构

```
[Popover 根容器]                     — 108pt 宽，flex column，居中
                                       ⚠️ 浅色主题：filter: drop-shadow() 加在此层
  ├── [顶部区域]（arrowPosition=top 时存在）
  │     └── [尖角切图] 16×6pt，<img> 切图，水平居中
  │           light+top  → 白色向上切图（正常显示）
  │           dark+top   → 黑色向上切图（正常显示）
  ├── [内容容器] 圆角 8pt，左右 padding 16pt，无上下 padding
  │             ❌ 禁止在此层加 box-shadow
  │     ├── [行 1（Row Item）] 76×44pt，flex row，图标 + 文字 + 徽标（可选）
  │     │     ├── [图标] 16×16pt（功能图标）
  │     │     ├── [文字] 56×20pt，14pt/20pt，PingFang SC Regular
  │     │     └── [数字徽标] 可选，默认隐藏
  │     ├── [行 2] 同上
  │     └── ... （最多至行 7）
  └── [底部区域]（arrowPosition=bottom 时存在）
        └── [尖角切图] 16×6pt，<img> 切图，水平居中
              light+bottom → 白色向上切图 + transform: scaleY(-1)
              dark+bottom  → 黑色向上切图 + transform: scaleY(-1)
```

### 6.2 分割线规则

| 行位置 | 浅色容器分割线 | 深色容器分割线 |
|--------|-------------|-------------|
| 首行（第 1 行）| 无分割线（`border-width: 0px`） | 无分割线 |
| 第 2 行及后续行 | 顶部 `0.5px solid rgba(0,0,0,0.1)` | 顶部 `0.5px solid rgba(255,255,255,0.15)` |
| 仅 1 行时 | 无分割线 | 无分割线 |

> **规律说明**：分割线规则为**从第 2 行开始，每行顶部各有一条 0.5pt（@1x）分割线**，首行无分割线。等价于每两个相邻行之间各有一条间隔线，视觉上形成行间分隔效果。

### 6.3 数字徽标（Badge）

- 默认**不显示**（设计稿中 `数字徽标 INSTANCE` 尺寸为 0×0，即隐藏状态）
- 如需展示，参考对应的 Badge 组件规范，叠加在每行末尾
- 显示时建议使用数字类型徽标（Badge），颜色遵循相应主题

---

## 7. 交互规则（来自设计稿说明）

### 7.1 触发与消失

| 行为 | 说明 |
|------|------|
| **触发** | 用户点击 / 长按触发元素后弹出 |
| **消失** | 用户点击选项后 / 点击气泡外区域后消失 |
| **出现** | 从触发元素附近弹出，默认带淡入动画 |

> 设计稿中有「操作」「消失」「出现」「触发」四个流程节点，具体动效参数由开发约定。

### 7.2 尖角位置自适应

- **默认**：尖角随被引导项位置水平方向居中对齐
- **边缘处理**：被引导项靠近屏幕边缘时，气泡需整体平移，保证气泡与屏幕边缘 **≥ 6pt** 的间距；此时尖角允许偏移，但需与气泡边缘保持 **≥ 12pt** 的最小间距
- **竖向方向**：根据触发项与屏幕剩余空间，自动选择 `top`（气泡在下）或 `bottom`（气泡在上）

### 7.3 宽度规则

| 场景 | 宽度 |
|------|------|
| 默认宽度 | **108pt** 固定（设计稿 216px @2x） |
| 内容字数 < 4 字 | 宽度为最小宽度（约 88pt，设计稿 176px @2x） |
| 内容字数 ≥ 4 字 | 宽度随文字内容自适应，固定边距 **16pt**（32px @2x） |

> ⚠️ 由于自适应宽度的特性，多选项时分割线宽度可能不一致，属于正常现象。

---

## 8. Props API（供 AI 生码参考）

```typescript
export type PopoverProps = {
  /**
   * 容器主题（浅色 / 深色）
   * @default "light"
   */
  theme?: "light" | "dark";

  /**
   * 尖角位置（上 / 下）
   * @default "top"
   */
  arrowPosition?: "top" | "bottom";

  /**
   * 选项列表
   * 1~7 条，每条包含图标、文字，以及可选数字徽标
   */
  items: PopoverItem[];

  /**
   * 点击选项的回调
   */
  onItemPress?: (item: PopoverItem, index: number) => void;

  /**
   * 气泡宽度（可选，默认 108）
   */
  width?: number;

  /**
   * 尖角水平偏移量（可选，用于对齐触发元素；0 表示居中）
   * @default 0
   */
  arrowOffset?: number;
};

export type PopoverItem = {
  /**
   * 图标（React 节点，16×16pt 大小）
   */
  icon: React.ReactNode;

  /**
   * 选项文字
   */
  label: string;

  /**
   * 数字徽标数值（可选，不传则不显示）
   */
  badge?: number;

  /**
   * 唯一标识（可选）
   */
  key?: string | number;
};
```

---

## 9. data-attribute 规范

| 属性 | 值 | 说明 |
|------|----|------|
| `data-slot` | `"popover"` | 组件根容器 |
| `data-slot` | `"popover-arrow"` | 尖角（顶部/底部区域） |
| `data-slot` | `"popover-content"` | 内容容器 |
| `data-slot` | `"popover-item"` | 单个选项行 |
| `data-slot` | `"popover-icon"` | 选项图标 |
| `data-slot` | `"popover-label"` | 选项文字 |
| `data-slot` | `"popover-badge"` | 数字徽标 |
| `data-theme` | `"light"` / `"dark"` | 容器主题 |
| `data-arrow-position` | `"top"` / `"bottom"` | 尖角位置 |
| `data-item-count` | `"1"` ~ `"7"` | 选项数量 |

---

## 10. 无障碍（Accessibility）

- 气泡根容器：`role="menu"` / `aria-haspopup="true"`（触发元素上）
- 选项行：`role="menuitem"`
- 触发元素：`aria-expanded="true/false"` 控制显示状态，`aria-controls` 指向气泡 ID
- 尖角元素：`aria-hidden="true"`（纯装饰性）
- 数字徽标：`aria-label="X 条未读"` 或 `aria-label="X"`
- 键盘交互：
  - `ArrowDown` / `ArrowUp`：在选项间移动焦点
  - `Enter` / `Space`：确认当前选项
  - `Escape`：关闭气泡浮层

---

## 11. 变体矩阵（完整 MECE）

> 共 **2（theme）× 7（itemCount）× 2（arrowPosition）= 28 个变体**，与设计稿一一对应。

| theme | itemCount | arrowPosition | 内容区高度（@1x） | 整体高度（@1x） |
|-------|-----------|--------------|--------------|-------------|
| `light` | 1 | `top` | 44pt | **50pt** |
| `light` | 1 | `bottom` | 44pt | **50pt** |
| `light` | 2 | `top` | 88pt | **94pt** |
| `light` | 2 | `bottom` | 88pt | **94pt** |
| `light` | 3 | `top` | 132pt | **138pt** |
| `light` | 3 | `bottom` | 132pt | **138pt** |
| `light` | 4 | `top` | 176pt | **182pt** |
| `light` | 4 | `bottom` | 176pt | **182pt** |
| `light` | 5 | `top` | 220pt | **226pt** |
| `light` | 5 | `bottom` | 220pt | **226pt** |
| `light` | 6 | `top` | 264pt | **270pt** |
| `light` | 6 | `bottom` | 264pt | **270pt** |
| `light` | 7 | `top` | 308pt | **314pt** |
| `light` | 7 | `bottom` | 308pt | **314pt** |
| `dark` | 1 | `top` | 44pt | **50pt** |
| `dark` | 1 | `bottom` | 44pt | **50pt** |
| `dark` | 2 | `top` | 88pt | **94pt** |
| `dark` | 2 | `bottom` | 88pt | **94pt** |
| `dark` | 3 | `top` | 132pt | **138pt** |
| `dark` | 3 | `bottom` | 132pt | **138pt** |
| `dark` | 4 | `top` | 176pt | **182pt** |
| `dark` | 4 | `bottom` | 176pt | **182pt** |
| `dark` | 5 | `top` | 220pt | **226pt** |
| `dark` | 5 | `bottom` | 220pt | **226pt** |
| `dark` | 6 | `top` | 264pt | **270pt** |
| `dark` | 6 | `bottom` | 264pt | **270pt** |
| `dark` | 7 | `top` | 308pt | **314pt** |
| `dark` | 7 | `bottom` | 308pt | **314pt** |

---

## 12. 使用约束

### 12.1 与 Tooltip（气泡提示）的区别

| 维度 | Popover 气泡浮层 | Tooltip 气泡提示 |
|------|---------------|--------------|
| 触发方式 | 用户**主动**点击/长按 | 系统**自动**触发 |
| 内容类型 | **操作列表**（图标 + 文字选项） | **引导说明**（文字 + 可选按钮） |
| 交互 | 点击选项执行操作 | 点击关闭或自动消失 |
| 宽度 | **固定 108pt** | 随文案自适应 |
| 选项数 | 1~7 个 | N/A（文字） |
| 内容结构 | 多行 Row Item | 单文本区块 |

### 12.2 使用建议

- 选项数 **1 个**：考虑是否直接用 Icon Button 触发操作，省略 Popover
- 选项数 **≥ 5 个**：评估是否使用**底部半屏弹窗（Half-screen Dialog）**，避免浮层过长
- **浅色主题**（`light`）为默认首选；仅当背景为深色或有蒙层时切换为 `dark`
- 气泡触发位置应保证弹出方向有足够空间；系统应自动判断上/下弹出
- 建议为每个选项提供**有意义的图标**，纯文字列表请对齐 icon 区域（留空位）

### 12.3 常见组合示例

```
// 场景 1：商品卡片右上角"更多"按钮，2 个操作选项
<Popover
  theme="light"
  arrowPosition="top"
  items={[
    { icon: <ShareIcon />, label: "分享" },
    { icon: <ReportIcon />, label: "举报" }
  ]}
/>

// 场景 2：内容页深色蒙层上的操作菜单，3 个选项，尖角在下
<Popover
  theme="dark"
  arrowPosition="bottom"
  items={[
    { icon: <EditIcon />, label: "编辑", badge: 3 },
    { icon: <DeleteIcon />, label: "删除" },
    { icon: <ArchiveIcon />, label: "归档" }
  ]}
/>
```
