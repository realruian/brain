# Filter Panel 筛选面板 - 组件规范

> **组件分类**：Component（组件级）
> **定义**：筛选面板（Filter Panel）是筛选器的可展开选项区域，点击筛选栏后从顶部向下展开出现，支持平铺和级联两大类、9 种子类型，覆盖单选 / 多选 / 自定义全部交互模式。
> **Style 依赖**：`color-semantic.md` · `font-semantic.md` · `spacing-semantic.md` · `component-spacing.md` · `radius-semantic.md` · `component-radius.md` · `stroke-semantic.md`
> **⚡ 联动组件**：筛选面板**不独立存在**，必须由**筛选器（`filter.md`）触发**。触发入口为筛选器按钮的 `expand-arrow`（展开箭头）或右侧功能区的 `filter-icon` / `text-filter-icon`。面板关闭后，筛选结果（选中态）需同步回筛选器按钮显示。
---
## 0. 图标 / 间距 / Ownership 约束

- **icon-route（默认）**：Filter Panel 展开面板内图标默认回 `component/atoms/icon.md`，并沿用正文 iconfont class / weight。
- **fixed-asset 例外**：正文若明确官方 SVG、`assets/*.svg`、PNG/CDN 或 URL 资源，该位点必须走 fixed-asset。
- **spacing-owner（Panel 自持）**：展开内容区的布局、分组间距、面板内 padding/对齐归 Filter Panel。
- **宿主裁决（边界）**：Filter 仅拥有触发条，Filter Panel 拥有展开内容区；冲突遵循 `宿主 > 组合场景 > 本组件`。
- **不可跳步**：先回 `references/INDEX.md` 完成区域路由与宿主锁定，再用 `component-quickref.md` 做宿主级收敛；本文件仅承接组件内 ownership 细则，不承担前置路由改判；不得凭语义猜测。


## 1. 组件类型（type）
| type | 大类 | 子类型 | 适用场景 |
|------|------|--------|---------|
| `list-flat-single` | 平铺面板 | 列表平铺 / 单行 | 单层选项点击即生效（单选） |
| `list-flat-double` | 平铺面板 | 列表平铺 / 双行 | 单层带辅助说明的选项（单选） |
| `btn-flat-single` | 平铺面板 | 按钮平铺 / 单模块 | 同一维度按钮网格，单 / 多选均适用 |
| `btn-flat-multi` | 平铺面板 | 按钮平铺 / 多模块 | 多维度分组按钮网格 |
| `btn-flat-custom` | 平铺面板 | 按钮平铺 / 自定义 | 非标准按钮布局，使用插槽自定义内容 |
| `cascade-2-list` | 级联面板 | 二层级联 / 文字列表 | 左一级列表 + 右二级文字列表 |
| `cascade-2-btn` | 级联面板 | 二层级联 / 按钮平铺多模块 | 左一级列表 + 右二级按钮网格 |
| `cascade-2-custom` | 级联面板 | 二层级联 / 自定义 | 左一级列表 + 右侧自定义内容 |
| `cascade-3-list` | 级联面板 | 三层级联 / 文字列表 | 三级联动文字列表（如省 / 市 / 区） |
| `cascade-3-custom` | 级联面板 | 三层级联 / 自定义 | 三级联动 + 第三级自定义内容 |
---
## 2. 尺寸与布局约束
### 2.1 面板整体
| 属性 | 规则 |
|------|------|
| 外圆角 | 底部两角 `radius-xl`（20pt）；顶部两角 0（顶部贴合屏幕） |
| 最大高度 | 从上向下展开时，底部保留屏幕高度的 10% 空白；超出须可滚动 |
| 面板背景 | 按钮平铺型（btn-flat）为 `white`（`#FFFFFF`）纯白；列表平铺及级联型为 `bg-surface` |
| 背景遮罩 | `bg-mask`（`rgba(0,0,0,0.6)`，一级遮罩色 60%） |
| 内容左右内边距 | `spacing-xl`（16pt）（默认，可调为 `spacing-l` 12pt / `spacing-s` 8pt） |
### 2.2 筛选按钮规格
筛选按钮按**列数**选择规格，同一面板内所有按钮保持尺寸一致：

| 列数 | 尺寸档位 | 高度（@1x） | 上下内边距 | 左右内边距 | 圆角 | 字体 Token |
|------|---------|------------|-----------|-----------|------|-----------|
| 3 列 | 宽松（loose） | **34pt**（@2x 68px） | `cs-8`（8pt） | `spacing-l`（12pt） | `cr-8`（8pt） | `body-s-26-regular` / `body-s-26-medium` |
| 4 列及以上 | 标准（standard） | **30pt**（@2x 60px） | `cs-7`（7pt） | `spacing-l`（12pt） | `cr-6`（6pt） | `body-xs-24-regular` / `body-xs-24-medium` |

> **尺寸档位选择原则**：`btn-flat-multi`（多模块）默认使用3 列宽松尺寸；`btn-flat-single`（单模块）默认使用4 列标准尺寸；`cascade-2-btn` 中 2 列使用宽松、3 列及以上使用标准。
>
> ⚠️ **`cascade-2-btn` 例外说明**：`cascade-2-btn` 的 3 列同样使用标准（standard）尺寸（`cr-6`），这是因为级联面板右侧内容区较窄、按钮已在受限宽度内排列。`btn-flat-multi` 的 3 列则使用宽松（loose）尺寸（`cr-8`）。二者请勿混淆。
### 2.3 底部操作区
| 属性 | 值 |
|------|-----|
| 顶部分割线 | `divider-primary`（`border-color: rgba(0,0,0,0.06)`，`border-width: 1px 0 0 0`） |
| 内边距 | `spacing-l`（12pt / @2x 24px）上下 / `spacing-xl`（16pt / @2x 32px）左右 |
| 按钮间距 | `spacing-s`（8pt / @2x 16px）`column-gap` |
| 操作区整体高度 | @2x 128px → @1x **64pt**（含上下内边距 + 按钮高度） |
| 操作区背景 | `#FFFFFF`（白色） |
| 按钮布局 | `flex-direction: row`，`justify-content: start`，`align-items: start` |

**底部按钮插槽（@2x 80px 高度按钮）：**

> 底部操作区支持**双按钮**（重置 + 确认）和**单按钮**（仅确认）两种变体。

**① 双按钮变体（重置 + 确认）：**

| 属性 | @2x 实测 | @1x 规格 | Token | 说明 |
|------|---------|---------|-------|------|
| 按钮高度 | 80px | **40pt** | — | 含上下 padding |
| 按钮最小宽度 | 188px | **94pt** | — | `min-width` 保底 |
| 按钮宽度 | `flex-grow: 1`，各占一半 | 自适应（默认各 @2x 335px → @1x ~168pt） | — | 等分容器 |
| 按钮圆角 | 40px | **20pt → `radius-full`** | `radius-full` | 全圆角胶囊 |
| 按钮上下内边距 | 18px | **9pt** | `cs-9`（`component-spacing.md`） | |
| 按钮左右内边距 | 48px | **24pt** | `cs-24`（`component-spacing.md`） | |
| 文字字号 / 行高 | 30px / 44px | **15pt / 22pt** | `body-l-30-medium`（500） | `font-weight: 500`，`text-align: center` |
| 文字颜色 | `#111111` | — | `text-primary` | 重置与确认按钮文字均为主色 |
| 重置按钮描边 | 1px `#CCCCCC` | 0.5pt | `stroke-default` | 无填充背景（透明） |
| 确认按钮背景 | `linear-gradient(135deg, #FFE74D 0%, #FFDD00 100%)` | — | `gradient-yellow` | 品牌黄渐变 |

**② 单按钮变体（仅确认）：**

| 属性 | @2x 实测 | @1x 规格 | Token | 说明 |
|------|---------|---------|-------|------|
| 按钮高度 | 80px | **40pt** | — | 同双按钮 |
| 按钮最小宽度 | 188px | **94pt** | — | `min-width` 保底 |
| 按钮宽度 | `flex-grow: 1`，占满容器 | @2x 686px → @1x **343pt** | — | 独占整行 |
| 按钮圆角 | 40px | **20pt → `radius-full`** | `radius-full` | 全圆角胶囊 |
| 按钮上下内边距 | 18px | **9pt** | `cs-9`（`component-spacing.md`） | |
| 按钮左右内边距 | 48px | **24pt** | `cs-24`（`component-spacing.md`） | |
| 文字字号 / 行高 | 30px / 44px | **15pt / 22pt** | `body-l-30-medium`（500） | `font-weight: 500`，`text-align: center` |
| 文字颜色 | `#111111` | — | `text-primary` | |
| 按钮背景 | `linear-gradient(135deg, #FFE74D 0%, #FFDD00 100%)` | — | `gradient-yellow` | 品牌黄渐变 |
---
## 3. 子类型规范
### 3.1 列表平铺（list-flat）
**适用**：单层选项，文字列表形式。点击即生效，通常无底部按钮。
| 属性 | 单行（single-line） | 双行（double-line） |
|------|-----------------|-----------------|
| 内容 | 主文字（`body-l-28-regular`） | 主文字（`body-l-28-regular`）+ 辅助说明（`body-xs-24-regular`，`text-tertiary`） |
| 选项行高 | 20pt（`body-l-28-regular` 行高） | 主文 20pt + 辅助文 16pt + gap `spacing-2xs`（4pt） |
| 选项内边距 | `spacing-xl`（16pt）左右 | `spacing-xl`（16pt）左右 |
| 选项间距 | `spacing-m`（`spacing-semantic.md`，20pt）上下 gap | `spacing-m`（`spacing-semantic.md`，20pt）上下 gap |
| 底部按钮 | 通常无 | 通常无 |
**选项颜色规则**：
| 状态 | 文字 Token |
|------|-----------|
| 未选中 | `text-secondary` |
| 选中 | `text-primary`，`font-weight: medium（500）` |
### 3.2 按钮平铺 / 单模块（btn-flat-single）
**适用**：简单的单一层级、按钮选项罗列的场景；同一维度按钮网格；有底部按钮 → 多选，无底部按钮 → 单选。

| Prop | 类型 | 可选值 | 默认值 | 说明 |
|------|------|--------|--------|------|
| `bottomBtn` | boolean | `true` / `false` | `false` | 是否显示底部操作区 |
| `columns` | number | `3` / `4` | `4` | 按钮列数 |
| `showCheck` | boolean | `true` / `false` | `false` | 是否显示右下角对钩（强化多选感知） |

**精确规格（来自组件集 @2x 代码，已换算至 @1x）：**

| 属性 | @2x 实测 | @1x 规格 | Token | 说明 |
|------|---------|---------|-------|------|
| 面板背景 | `#FFFFFF` | `white` | — | 纯白，非 `bg-surface` |
| 内容底部内边距 | 24px | **12pt** | `cs-12`（`component-spacing.md`） | 内容区与面板底部的间距 |
| 行容器左右内边距 | 32px | **16pt** | `spacing-xl` | 按钮行距面板左右边缘 |
| 按钮高度 | 60px | **30pt** | — | 含上下 padding |
| 按钮上下内边距 | 14px | **7pt** | `cs-7`（`component-spacing.md`） | |
| 按钮左右内边距 | 24px | **12pt** | `spacing-l` | |
| 按钮圆角 | 12px | **6pt** | `cr-6`（`component-radius.md`） | |
| 按钮列间距（column-gap） | 12px | **6pt** | `cs-6`（`component-spacing.md`） | 同行按钮间 |
| 按钮行间距（row-gap） | 12px | **6pt** | `cs-6`（`component-spacing.md`） | 行与行之间 |
| 文字字号 / 行高 | 24px / 32px | **12pt / 16pt** | `body-xs-24-regular` / `body-xs-24-medium` | 4 列标准；3 列可升为 `body-s-26` |

**筛选按钮两态颜色规格：**

| 状态 | 背景 | 描边 | 文字色 | 字重 |
|------|------|------|--------|------|
| 未选中 | `bg-surface`（`#F7F7F7`） | 无 | `text-secondary`（`#555555`） | 400 regular |
| 选中 | `bg-fill-brand-light`（`#FFFADB`，浅黄） | 1px `stroke-brand`（`#FFDD00`） | `orange-default`（`#FF7700`） | 500 medium |

> ⚠️ **选中文字色为橙色** `#FF7700`（`orange-default`），不是黄色品牌色。
### 3.3 按钮平铺 / 多模块（btn-flat-multi）
**适用**：两个层级以上或模块较多的场景；多个筛选维度分组展示，每组独立模块标题。

| Prop | 类型 | 可选值 | 默认值 | 说明 |
|------|------|--------|--------|------|
| `columns` | number | `3` / `4` | `3` | 按钮列数（3 列为宽松尺寸，4 列为标准尺寸） |
| `showExpand` | boolean | `true` / `false` | `false` | 模块标题右侧是否显示展开/收起选项 |

**精确规格（来自组件集 @2x 代码，已换算至 @1x）：**

> 多模块型默认使用 3 列**宽松（loose）尺寸**，按钮比单模块 4 列更大。

**① 模块标题行：**

| 属性 | @2x 实测 | @1x 规格 | Token | 说明 |
|------|---------|---------|-------|------|
| 标题行高度 | 40px | **20pt** | — | 含文字行高 |
| 标题行左右内边距 | 32px | **16pt** | `spacing-xl` | |
| 标题文字字号 / 行高 | 28px / 40px | **14pt / 20pt** | `body-m-28-medium` | `font-weight: 500`，`color: #111111`（`text-primary`） |
| 展开文字字号 / 行高 | 24px / 32px | **12pt / 16pt** | `body-xs-24-regular` | `color: #555555`（`text-secondary`） |
| 展开图标尺寸 | 20px × 20px | **10pt × 10pt** | — | 标题右侧，与展开文字间距 4px → 2pt |

**② 按钮区（3 列宽松尺寸）：**

| 属性 | @2x 实测 | @1x 规格 | Token | 说明 |
|------|---------|---------|-------|------|
| 按钮行左右内边距 | 32px | **16pt** | `spacing-xl` | |
| 按钮高度 | 68px | **34pt** | — | 含上下 padding |
| 按钮上下内边距 | 16px | **8pt** | `cs-8`（`component-spacing.md`） | |
| 按钮左右内边距 | 24px | **12pt** | `spacing-l` | |
| 按钮圆角 | 16px | **8pt** | `cr-8`（`component-radius.md`） | 比 4 列标准 6pt 更大 |
| 按钮列间距（column-gap） | 12px | **6pt** | `cs-6`（`component-spacing.md`） | |
| 按钮行间距（row-gap） | 12px | **6pt** | `cs-6`（`component-spacing.md`） | |
| 文字字号 / 行高 | 26px / 36px | **13pt / 18pt** | `body-s-26-regular` / `body-s-26-medium` | |

**③ 模块结构间距：**

| 属性 | @2x 实测 | @1x 规格 | Token | 说明 |
|------|---------|---------|-------|------|
| 模块标题与按钮区间距 | 18px | **9pt** | `cs-9`（`component-spacing.md`） | 模块内标题行与按钮行之间的 row-gap |
| 模块与模块间距 | 42px | **21pt** | `cs-21`（`component-spacing.md`） | 相邻模块之间的 row-gap |
| 内容区底部内边距 | 24px | **12pt** | `cs-12`（`component-spacing.md`） | 同 btn-flat-single |

**筛选按钮两态颜色规格（与 btn-flat-single 一致）：**

| 状态 | 背景 | 描边 | 文字色 | 字重 |
|------|------|------|--------|------|
| 未选中 | `bg-surface`（`#F7F7F7`） | 无 | `text-secondary`（`#555555`） | 400 regular |
| 选中 | `bg-fill-brand-light`（`#FFFADB`，浅黄） | 1px `stroke-brand`（`#FFDD00`） | `orange-default`（`#FF7700`） | 500 medium |
### 3.4 按钮平铺 / 自定义（btn-flat-custom）
**适用**：规范未包含的特殊按钮布局，使用 `children` 插槽自定义内容。
| Prop | 类型 | 可选值 | 默认值 |
|------|------|--------|--------|
| `bottomBtn` | boolean | `true` / `false` | `false` |
| `children` | ReactNode | — | — |

**精确规格（来自组件集 @2x 代码，已换算至 @1x）：**

> 自定义型有两个变体：**带底部操作区**（`bottomBtn=true`）和**无底部操作区**（`bottomBtn=false`）。

**① 面板容器：**

| 属性 | @2x 实测 | @1x 规格 | Token | 说明 |
|------|---------|---------|-------|------|
| 面板背景 | `#FFFFFF` | `white` | — | 纯白 |
| 面板底部圆角 | 40px | **20pt** | `radius-xl` | 底部两角；顶部两角 0 |
| 面板布局 | `flex-direction: column` | — | — | 纵向排列：内容区 + 底部操作区 |
| 溢出处理 | `overflow: hidden` | — | — | 裁切超出内容 |

**② 内容区（children 插槽）：**

| 属性 | @2x 实测 | @1x 规格 | Token | 说明 |
|------|---------|---------|-------|------|
| 宽度 | 750px | **375pt**（满宽） | — | 与面板同宽 |
| 高度 | `flex-grow: 1` | 自适应 | — | 占满剩余空间 |
| 溢出处理 | `overflow: hidden` | — | — | 内容超出时裁切（可内部滚动） |

**③ 带底部操作区变体（`bottomBtn=true`）：**

| 属性 | @2x 实测 | @1x 规格 | Token | 说明 |
|------|---------|---------|-------|------|
| 面板总高（示例） | 878px | **439pt** | — | 内容区 750px + 底部操作区 128px |
| 底部操作区高度 | 128px | **64pt** | — | 含上下内边距 + 按钮高度 |
| 底部操作区内边距 | 24px 32px | **12pt 上下 / 16pt 左右** | `spacing-l` / `spacing-xl` | |
| 按钮间距 | 16px | **8pt** | `spacing-s` | `column-gap` |
| 分割线 | `1px 0 0 0 solid rgba(0,0,0,0.06)` | — | `divider-primary` | 顶部分割线 |
| 重置按钮 | 同 §2.3 双按钮变体 | — | — | 80px 高度，描边 `#CCCCCC`，`radius-full` |
| 确认按钮 | 同 §2.3 双按钮变体 | — | — | 80px 高度，`gradient-yellow`，`radius-full` |

**④ 无底部操作区变体（`bottomBtn=false`）：**

| 属性 | @2x 实测 | @1x 规格 | Token | 说明 |
|------|---------|---------|-------|------|
| 面板总高（示例） | 750px | **375pt** | — | 仅内容区，无底部操作区 |
| 内容区 | 占满面板全部高度 | — | — | `flex-grow: 1` |
### 3.5 二层级联 / 文字列表（cascade-2-list）
**适用**：左侧一级列表（灰底）+ 右侧二级文字列表（白底）。
| Prop | 类型 | 可选值 | 默认值 | 说明 |
|------|------|--------|--------|------|
| `bottomBtn` | boolean | `true` / `false` | `false` | 有 → 多选，无 → 单选 |
| `textType` | string | `single-line` / `double-line` | `single-line` | 二级选项文字类型 |
| `showIndicator` | boolean | `true` / `false` | `true` | 是否显示一级选项左侧选中指示器 |
| `showTopDivider` | boolean | `true` / `false` | `false` | 是否显示顶部分割线 |

**精确规格（来自组件集 @2x 代码，已换算至 @1x）：**

> 面板整体 `flex-direction: row`，左右并列；底部圆角 40px → 20pt（`radius-xl`）；`overflow: hidden`。

**① 面板容器：**

| 属性 | @2x 实测 | @1x 规格 | Token | 说明 |
|------|---------|---------|-------|------|
| 面板宽度 | 750px | **375pt**（满屏） | — | |
| 面板布局 | `flex-direction: row` | — | — | 左右并列：一级侧边栏 + 二级内容区 |
| 面板底部圆角 | 40px | **20pt** | `radius-xl` | 底部两角；顶部两角 0 |
| 溢出处理 | `overflow: hidden` | — | — | |

**② 一级侧边栏（左侧）：**

| 属性 | @2x 实测 | @1x 规格 | Token | 说明 |
|------|---------|---------|-------|------|
| 宽度 | 176px | **88pt** | — | 固定宽度 `flex-shrink: 0` |
| 高度 | `align-self: stretch` | 撑满面板 | — | 与面板等高 |
| 背景 | `#F7F7F7` | — | `bg-fill-tertiary` | 灰色底 |
| 布局 | `flex-direction: column` | — | — | 垂直排列选项 |
| 选项高度 | 88px | **44pt** | — | 含上下 padding |
| 选项最小宽度 | 176px | **88pt** | — | `min-width` 保底 |
| 选项内边距 | 24px 32px | **12pt 上下 / 16pt 左右** | `spacing-l` / `spacing-xl` | |
| 选项文字字号 / 行高 | 28px / 40px | **14pt / 20pt** | `body-l-28-regular` / `body-l-28-medium` | |
| 选中项背景 | `#FFFFFF` | `white` | `white` | 白色突出 |
| 选中项文字 | `#111111`，`font-weight: 500` | — | `text-primary`，medium | |
| 未选中项文字 | `#555555`，`font-weight: 400` | — | `text-secondary`，regular | |
| 选中指示器宽度 | 6px | **3pt** | — | 竖条形状 |
| 选中指示器高度 | 28px | **14pt** | — | |
| 选中指示器圆角 | 40px | `radius-full` | `radius-semantic.md` | 全圆角 |
| 选中指示器颜色 | `#FFDD00` | — | `stroke-brand` | 品牌黄 |
| 选中指示器位置 | `top: 30px; left: 20px` | **距顶 15pt / 距左 10pt** | — | 绝对定位于选项内 |

**③ 二级内容区（右侧）：**

| 属性 | @2x 实测 | @1x 规格 | Token | 说明 |
|------|---------|---------|-------|------|
| 宽度 | 574px（`flex-grow: 1`） | **287pt**（自适应） | — | 占满剩余空间 |
| 背景 | `#FFFFFF` | `white` | `white` | 白色底 |
| 布局 | `flex-direction: column` | — | — | 垂直排列选项 |
| 上内边距 | 24px | **12pt** | `cs-12`（`component-spacing.md`） | |
| 下内边距 | 48px | **24pt** | `cs-24`（`component-spacing.md`） | |
| 左右内边距 | 0px（选项自身有 32px 左右 padding） | — | — | 间距由选项自控 |
| 选项间距（row-gap） | 42px | **21pt** | `cs-21`（`component-spacing.md`） | 选项行之间的间距 |
| 溢出处理 | `overflow: hidden` | — | — | 可内部滚动 |

**④ 二级选项行（单行 single-line）：**

| 属性 | @2x 实测 | @1x 规格 | Token | 说明 |
|------|---------|---------|-------|------|
| **选项容器（插槽内容）**： | | | | |
| 选项总宽度 | 660px | **330pt** | — | 二级内容区 574px - 左右留白（由 padding 32px × 2 实现） |
| 选项高度 | 80px | **40pt** | — | 单行：仅含主文字行高 |
| 选项布局 | `flex-direction: row` | — | — | 横向：主文字居左 + 选中图标居右 |
| 选项横向对齐 | `justify-content: space-between` | — | — | 两端对齐 |
| 选项纵向对齐 | `align-items: center` | — | — | 垂直居中 |
| 选项左右内边距 | 32px | **16pt** | `spacing-xl` | 作用于选项内部 |
| **主文字**： | | | | |
| 主文字宽度（示例） | 112px | **56pt** | — | `flex-shrink: 0`，实际宽度由内容决定 |
| 主文字字号 / 行高 | 28px / 40px | **14pt / 20pt** | `body-l-28-regular` / `body-l-28-medium` | |
| 未选中文字颜色 | `#555555`，`font-weight: 400` | — | `text-secondary`，regular | |
| 选中文字颜色 | `#111111`，`font-weight: 500` | — | `text-primary`，medium | |
| **选中图标**： | | | | |
| 图标尺寸 | 32×32px | **16×16pt** | — | 仅选中态显示，`flex-shrink: 0` |
| 图标位置 | `justify-content: space-between` 右端 | — | — | 与主文字间距由 `space-between` 自动撑开 |

**⑤ 二级选项行（双行 double-line）：**

| 属性 | @2x 实测 | @1x 规格 | Token | 说明 |
|------|---------|---------|-------|------|
| **选项容器（插槽内容）**： | | | | |
| 选项总宽度 | 750px | **375pt** | — | `flex-shrink: 0`，撑满二级内容区宽度 |
| 选项高度 | 80px | **40pt** | — | 双行：主文字 + 辅助说明整体垂直居中 |
| 选项布局 | `flex-direction: row` | — | — | 横向：左侧文字区 + 右侧图标 |
| 选项对齐 | `justify-content: start`，`align-items: center` | — | — | 左对齐，垂直居中 |
| 图文间距（column-gap） | 12px | **6pt** | `spacing-xs` | 文字区与右侧图标之间 |
| 选项左右内边距 | 32px | **16pt** | `spacing-xl` | 作用于选项内部 |
| **左侧文字区（flex-grow: 1）**： | | | | |
| 文字区布局 | `flex-direction: column` | — | — | 纵向：主文字 + 辅助说明 |
| 文字区对齐 | `justify-content: center`，`align-items: start` | — | — | 垂直居中，水平左对齐 |
| 主文字与辅助说明间距（row-gap） | 8px | **4pt** | `spacing-2xs` | |
| **主文字**： | | | | |
| 主文字高度 | 40px | **20pt** | — | `align-self: stretch` 撑满宽度 |
| 主文字字号 / 行高 | 28px / 40px | **14pt / 20pt** | `body-l-28-regular` / `body-l-28-medium` | |
| 未选中主文字颜色 | `#111111`，`font-weight: 400` | — | `text-primary`，regular | |
| 选中主文字颜色 | `#111111`，`font-weight: 500` | — | `text-primary`，medium | |
| **辅助说明**： | | | | |
| 辅助说明高度 | 32px | **16pt** | — | `align-self: stretch` 撑满宽度 |
| 辅助说明字号 / 行高 | 24px / 32px | **12pt / 16pt** | `body-xs-24-regular` | |
| 辅助说明颜色 | `#888888`，`font-weight: 400` | — | `text-tertiary` | |
| **选中图标**： | | | | |
| 图标尺寸 | 32×32px | **16×16pt** | — | 仅选中态显示，`flex-shrink: 0`，位于行右侧 |

**颜色规则**：
| 区域 | 背景 Token | 文字（选中）Token | 文字（未选中）Token |
|------|-----------|-----------------|-----------------|
| 一级侧边栏 | `bg-fill-tertiary` | `text-primary`，`font-weight: medium` | `text-secondary` |
| 一级选中项 | `white` | `text-primary` | — |
| 二级内容区 | `white` | `text-primary` | `text-secondary` |
| 双行辅助文字 | — | — | `text-tertiary` |
### 3.6 二层级联 / 按钮平铺多模块（cascade-2-btn）
**适用**：左侧一级列表 + 右侧按钮平铺多模块。适用于两个层级以上或模块较多的场景。
| Prop | 类型 | 可选值 | 默认值 |
|------|------|--------|--------|
| `columns` | number | `2` / `3` | `3` |
> 2 列 → 宽松尺寸筛选按钮；3 列及以上 → 标准尺寸筛选按钮。

**精确规格（来自组件集 @2x 代码，已换算至 @1x）：**

> 面板 `flex-direction: column`（纵向：内容区 + 底部操作区）；内容区 `flex-direction: row`（横向：一级侧边栏 + 二级按钮区）。

**① 面板容器：**

| 属性 | @2x 实测 | @1x 规格 | Token | 说明 |
|------|---------|---------|-------|------|
| 面板宽度 | 750px | **375pt**（满屏） | — | |
| 面板布局 | `flex-direction: column` | — | — | 纵向：内容区 + 底部操作区 |
| 面板底部圆角 | 40px | **20pt** | `radius-xl` | 底部两角；顶部两角 0 |
| 溢出处理 | `overflow: hidden` | — | — | |
| 面板总高（示例） | 1184px | **592pt** | — | 内容区 1056px + 底部操作区 128px |

**② 一级侧边栏（左侧，与 cascade-2-list 一致）：**

| 属性 | @2x 实测 | @1x 规格 | Token | 说明 |
|------|---------|---------|-------|------|
| 宽度 | 176px | **88pt** | — | 固定宽度 `flex-shrink: 0` |
| 背景 | `#F7F7F7` | — | `bg-fill-tertiary` | 灰色底 |
| **选项容器（插槽内容）**： | | | | |
| 选项高度 | 88px | **44pt** | — | 含上下 padding |
| 选项最小宽度 | 176px | **88pt** | — | `min-width` 保底 |
| 选项布局 | `flex-direction: row` | — | — | 横向：文字 + 右侧留白 |
| 选项对齐 | `justify-content: start`，`align-items: center` | — | — | 左对齐，垂直居中 |
| 图文间距（column-gap） | 10px | **5pt** | — | 内部元素之间 |
| 选项内边距 | 24px 32px | **12pt 上下 / 16pt 左右** | `spacing-l` / `spacing-xl` | |
| **选中态**（`background: #FFFFFF`）： | | | | |
| 选中项背景 | `#FFFFFF` | `white` | `white` | |
| 选中项文字 | `#111111`，`font-weight: 500` | — | `text-primary`，medium | |
| 选中指示器位置 | `top: 30px; left: 20px`（绝对定位） | **距顶 15pt / 距左 10pt** | — | 绝对定位于选项左侧 |
| 选中指示器尺寸 | 6×28px | **3×14pt** | — | |
| 选中指示器圆角 | 40px | `radius-full` | `radius-semantic.md` | 全圆角 |
| 选中指示器颜色 | `#FFDD00` | — | `stroke-brand` | 品牌黄 |
| **未选中态**（无背景）： | | | | |
| 未选中项文字 | `#555555`，`font-weight: 400` | — | `text-secondary`，regular | |
| **选项分割线**（选项之间）： | | | | |
| 分割线尺寸 | 16×16px | **8×8pt** | — | 绝对定位，`top: -16px`（上边缘）/ `bottom: -16px`（下边缘） |
| 分割线说明 | — | — | `divider-primary` | 通过 `booleanoperation` 节点实现，覆盖于相邻选项交界处 |

**③ 二级按钮平铺多模块区（右侧）：**

| 属性 | @2x 实测 | @1x 规格 | Token | 说明 |
|------|---------|---------|-------|------|
| 宽度 | 574px（`flex-grow: 1`） | **287pt**（自适应） | — | 占满剩余空间 |
| 背景 | `#FFFFFF` | `white` | `white` | 白色底 |
| 布局 | `flex-direction: column` | — | — | 垂直排列多个模块 |
| 上内边距 | 24px | **12pt** | `cs-12`（`component-spacing.md`） | |
| 模块间距（row-gap） | 42px | **21pt** | `cs-21`（`component-spacing.md`） | 相邻模块之间 |

**④ 单个模块结构（标题行 + 按钮网格）：**

| 属性 | @2x 实测 | @1x 规格 | Token | 说明 |
|------|---------|---------|-------|------|
| 模块总高（示例） | 190px | **95pt** | — | 标题行 40px + gap 18px + 按钮网格 132px |
| 标题行与按钮区间距 | 18px | **9pt** | `cs-9` | `row-gap` |
| **标题行**： | | | | |
| 标题行高度 | 40px | **20pt** | — | |
| 标题行左右内边距 | 24px | **12pt** | `spacing-l` | |
| 标题行布局 | `justify-content: space-between` | — | — | 标题居左，展开按钮居右 |
| 标题文字字号 / 行高 | 28px / 40px | **14pt / 20pt** | `body-m-28-medium` | `font-weight: 500`，`#111111`（`text-primary`） |
| 展开按钮宽度 | 72px | **36pt** | — | 文字 + 图标 |
| **展开 / 收起按钮（插槽内容）**： | | | | |
| 按钮容器布局 | `flex-direction: row` | — | — | 横向：文字 + 图标 |
| 按钮容器对齐 | `justify-content: start`，`align-items: center` | — | — | 左对齐，垂直居中 |
| 按钮图文间距（column-gap） | 4px | **2pt** | — | 文字与图标之间 |
| 展开文字尺寸 | 48px × 32px | **24pt × 16pt** | — | `flex-shrink: 0`，`white-space: nowrap` |
| 展开文字字号 / 行高 | 24px / 32px | **12pt / 16pt** | `body-xs-24-regular` | `#555555`（`text-secondary`），`font-weight: 400`，`text-align: center` |
| 展开图标尺寸 | 20×20px | **10×10pt** | — | `flex-shrink: 0` |

**⑤ 按钮网格区（3 列标准尺寸）：**

| 属性 | @2x 实测 | @1x 规格 | Token | 说明 |
|------|---------|---------|-------|------|
| 按钮网格总高（示例） | 132px | **66pt** | — | 2 行 × 60px + 行间距 12px |
| 按钮行左右内边距 | 24px | **12pt** | `spacing-l` | |
| 按钮行间距（row-gap） | 12px | **6pt** | `cs-6` | |
| 按钮列间距（column-gap） | 12px | **6pt** | `cs-6` | |
| 按钮列数 | 3 列 | — | — | `flex-grow: 1`，每列约 167.33px → ~84pt |
| 按钮高度 | 60px | **30pt** | — | 含上下 padding |
| 按钮上下内边距 | 14px | **7pt** | `cs-7` | 标准尺寸 |
| 按钮左右内边距 | 24px | **12pt** | `spacing-l` | |
| 按钮圆角 | 12px | **6pt** | `cr-6` | 标准尺寸 |
| 文字字号 / 行高 | 24px / 32px | **12pt / 16pt** | `body-xs-24-regular` / `body-xs-24-medium` | 标准尺寸 |

**⑥ 筛选按钮两态颜色（与 btn-flat-single / btn-flat-multi 一致）：**

| 状态 | 背景 | 描边 | 文字色 | 字重 |
|------|------|------|--------|------|
| 未选中 | `bg-surface`（`#F7F7F7`） | 无 | `text-secondary`（`#555555`） | 400 regular |
| 选中 | `bg-fill-brand-light`（`#FFFADB`） | 1px `stroke-brand`（`#FFDD00`） | `orange-default`（`#FF7700`） | 500 medium |

**⑦ 底部操作区（同 §2.3 双按钮变体）：**

| 属性 | @2x 实测 | @1x 规格 | Token | 说明 |
|------|---------|---------|-------|------|
| 操作区高度 | 128px | **64pt** | — | 含上下内边距 + 按钮高度 |
| 分割线 | `1px 0 0 0 solid rgba(0,0,0,0.06)` | — | `divider-primary` | |
| 按钮规格 | 同 §2.3 双按钮变体 | — | — | 80px 高度，重置 `stroke-default` + 确认 `gradient-yellow` |
### 3.7 二层级联 / 自定义（cascade-2-custom）
左侧一级列表 + 右侧 `children` 插槽自定义内容，可根据实际场景灵活自定义第二级区域内容。
| Prop | 类型 | 可选值 | 默认值 |
|------|------|--------|--------|
| `bottomBtn` | boolean | `true` / `false` | `false` |
| `children` | ReactNode | — | — |

**精确规格（来自组件集 @2x 代码，已换算至 @1x）：**

> 面板结构与 cascade-2-list / cascade-2-btn 完全一致；唯一区别是二级区域为纯空容器，由 `children` 插槽完全控制内容。

**① 面板容器：**

| 属性 | @2x 实测 | @1x 规格 | Token | 说明 |
|------|---------|---------|-------|------|
| 面板布局 | `flex-direction: column` | — | — | 纵向：内容区 + 底部操作区 |
| 面板底部圆角 | 40px | **20pt** | `radius-xl` | 底部两角；顶部两角 0 |
| 溢出处理 | `overflow: hidden` | — | — | |
| 面板总高（示例） | 1184px | **592pt** | — | 内容区 1056px + 底部操作区 128px |

**② 一级侧边栏（左侧，与 cascade-2-list / cascade-2-btn 完全一致）：**

| 属性 | @2x 实测 | @1x 规格 | Token | 说明 |
|------|---------|---------|-------|------|
| 宽度 | 176px | **88pt** | — | 固定宽度 `flex-shrink: 0` |
| 背景 | `#F7F7F7` | — | `bg-fill-tertiary` | 灰色底 |
| 选项高度 | 88px | **44pt** | — | 含上下 padding |
| 选项内边距 | 24px 32px | **12pt 上下 / 16pt 左右** | `spacing-l` / `spacing-xl` | |
| 选项文字字号 / 行高 | 28px / 40px | **14pt / 20pt** | `body-l-28-regular` / `body-l-28-medium` | |
| 选中项背景 | `#FFFFFF` | `white` | `white` | |
| 选中项文字 | `#111111`，500 | — | `text-primary`，medium | |
| 未选中项文字 | `#555555`，400 | — | `text-secondary`，regular | |
| 选中指示器尺寸 | 6×28px | **3×14pt** | — | |
| 选中指示器圆角 | 40px | `radius-full` | `radius-semantic.md` | 全圆角 |
| 选中指示器颜色 | `#FFDD00` | — | `stroke-brand` | 品牌黄（同 cascade-2-list） |

**③ 二级自定义区（右侧，children 插槽）：**

| 属性 | @2x 实测 | @1x 规格 | Token | 说明 |
|------|---------|---------|-------|------|
| 宽度 | 574px（`flex-grow: 1`） | **287pt**（自适应） | — | 占满剩余空间 |
| 高度 | `align-self: stretch` | 撑满内容区 | — | 与一级侧边栏等高 |
| 背景 | `#FFFFFF` | `white` | `white` | 白色底 |
| 内边距 | 无（0px） | — | — | ❌ 不设置任何 padding，由 `children` 完全控制布局 |
| 溢出处理 | `overflow: hidden` | — | — | 超出内容裁切 |

**④ 底部操作区（同 §2.3 双按钮变体）：**

| 属性 | @2x 实测 | @1x 规格 | Token | 说明 |
|------|---------|---------|-------|------|
| 操作区高度 | 128px | **64pt** | — | 含上下内边距 + 按钮高度 |
| 内边距 | 24px 32px | **12pt 上下 / 16pt 左右** | `spacing-l` / `spacing-xl` | |
| 按钮间距 | 16px | **8pt** | `spacing-s` | `column-gap` |
| 分割线 | `1px 0 0 0 solid rgba(0,0,0,0.06)` | — | `divider-primary` | |
| 重置按钮 | `flex-grow: 1`，80px 高，描边 `#CCCCCC` | — | `stroke-default`，`radius-full` | |
| 确认按钮 | `flex-grow: 1`，80px 高，黄色渐变 | — | `gradient-yellow`，`radius-full` | |

### 3.8 三层级联 / 文字列表（cascade-3-list）
**适用**：三个层级联动文字列表（如省 / 市 / 区）。第三级区域宽度较窄，仅建议放文字内容。
| Prop | 类型 | 可选值 | 默认值 |
|------|------|--------|--------|
| `bottomBtn` | boolean | `true` / `false` | `false` |
| `textType` | string | `single-line` / `double-line` | `single-line` |
**颜色规则**：与二层级联一致，一级灰底 `bg-fill-tertiary`，二 / 三级白底 `white`。
### 3.9 三层级联 / 自定义（cascade-3-custom）
三层级联 + 第三级 `children` 插槽自定义内容。
| Prop | 类型 | 可选值 | 默认值 |
|------|------|--------|--------|
| `bottomBtn` | boolean | `true` / `false` | `false` |
| `children` | ReactNode | — | — |
---
## 4. Token 引用
### 4.1 颜色 Token

> ⚠️ 以下表格中括号内的 hex 色値（如 `#F7F7F7`）**仅供读者直观参考**，实际代码引用以 Token 名称为准。禁止在组件代码中直接使用视觉层原始色値。

| 用途 | Token 名称 | 语义层来源 |
|------|-----------|-----------|
| 按钮平铺面板背景 | `white` | `color-semantic.md` §一 Neutral Color |
| 列表平铺 / 级联外层面板背景 | `bg-surface` | `color-semantic.md` §三 Background Color |
| 一级级联侧边栏背景 | `bg-fill-tertiary` | `color-semantic.md` §三 Background Color |
| 级联选中项 / 二三级内容区背景 | `white` | `color-semantic.md` §一 Neutral Color |
| 遮罩背景 | `bg-mask` | `color-semantic.md` §三 Background Color |
| 筛选按钮选中背景 | `bg-fill-brand-light` | `color-semantic.md` §三 Background Color |
| 确认按钮渐变 | `gradient-yellow` | `color-semantic.md` §八 Gradient Color |
| 选中文字 | `text-primary` | `color-semantic.md` §二 Text Color |
| 未选中文字 | `text-secondary` | `color-semantic.md` §二 Text Color |
| 辅助说明文字 | `text-tertiary` | `color-semantic.md` §二 Text Color |
| 筛选按钮选中文字 | `orange-default`（`#FF7700`） | 橙色，非黄色品牌色；见 `color-semantic.md` |
| 筛选按钮选中描边 | `stroke-brand` | `color-semantic.md` §四 Stroke Color |
| 重置按钮描边 | `stroke-default` | `color-semantic.md` §四 Stroke Color |
| 底部操作区顶部分割线 | `divider-primary` | `color-semantic.md` §五 Divider Color |
### 4.2 字体 Token
| 用途 | Token 名称 | 语义层来源 |
|------|-----------|-----------|
| 列表 / 级联选项主文字 | `body-l-28-regular` | `font-semantic.md` §一 Body |
| 列表 / 级联选项主文字（选中） | `body-l-28-medium` | `font-semantic.md` §一 Body |
| 双行辅助说明文字 | `body-xs-24-regular` | `font-semantic.md` §一 Body |
| 4 列标准筛选按钮 | `body-xs-24-regular` / `body-xs-24-medium` | `font-semantic.md` §一 Body |
| 2–3 列宽松筛选按钮 | `body-s-26-regular` / `body-s-26-medium` | `font-semantic.md` §一 Body |
| 模块标题 | `body-m-28-medium` | `font-semantic.md` §一 Body；@2x 28px/40px，`font-weight: 500` |
| 展开 / 收起文字 | `body-xs-24-regular` | `font-semantic.md` §一 Body；`color: text-secondary` |
### 4.3 圆角 Token

> **三层来源说明**：
> - **Semantic 层**（`radius-semantic.md`）：`radius-xl`（20pt 浮层圆角）、`radius-full`（胶囊全圆角）
> - **Component 层**（`component-radius.md`）：`cr-6`（6pt 按钮圆角）、`cr-8`（8pt 按钮圆角）——组件内细粒度圆角，`radius-semantic.md` 最小仅 4pt，需从此文件补充

| 用途 | Token 名称 | 来源层级 | 说明 |
|------|-----------|---------|------|
| 面板底部两角 | `radius-xl` | `radius-semantic.md` | 20pt，所有子类型统一 |
| 筛选按钮（4 列标准）圆角 | `cr-6` | `component-radius.md` | 6pt（@2x `border-radius: 12px`）；`btn-flat-single`（4 列）和 `cascade-2-btn`（3 列）均使用 |
| 筛选按钮（3 列宽松）圆角 | `cr-8` | `component-radius.md` | 8pt（@2x `border-radius: 16px`）；`btn-flat-multi`（3 列）使用，注意 `cascade-2-btn` 3 列例外用 `cr-6` |
| 底部操作按钮 / 选中指示器圆角 | `radius-full` | `radius-semantic.md` | 胶囊全圆角（`border-radius: 9999px`） |
### 4.4 间距 Token

> **三层来源说明**：
> - **Semantic 层**（`spacing-semantic.md`）：`spacing-xl`（16pt）、`spacing-l`（12pt）、`spacing-s`（8pt）、`spacing-xs`（6pt）、`spacing-2xs`（4pt）——页面 / 模块级间距
> - **Component 层**（`component-spacing.md`）：`cs-{N}` 系列——组件内部细粒度间距，`spacing-semantic.md` 步进无法覆盖时从此文件补充

| 用途 | Token 名称 | 来源层级 | 值 |
|------|-----------|---------|-----|
| 面板内容左右内边距（默认） | `spacing-xl` | `spacing-semantic.md` | 16pt |
| 面板内容左右内边距（紧凑） | `spacing-l` | `spacing-semantic.md` | 12pt |
| 按钮 / 选项左右内边距 | `spacing-l` | `spacing-semantic.md` | 12pt |
| 底部双按钮间距（column-gap） | `spacing-s` | `spacing-semantic.md` | 8pt |
| 一级选项内边距（级联，上下） | `spacing-l` | `spacing-semantic.md` | 12pt |
| 一级选项内边距（级联，左右） | `spacing-xl` | `spacing-semantic.md` | 16pt |
| 底部操作区内边距（上下） | `spacing-l` | `spacing-semantic.md` | 12pt |
| 底部操作区内边距（左右） | `spacing-xl` | `spacing-semantic.md` | 16pt |
| 双行辅助说明与主文字间距 | `spacing-2xs` | `spacing-semantic.md` | 4pt |
| 图文间距（展开按钮，column-gap） | `spacing-xs` | `spacing-semantic.md` | 6pt（@2x 12px） |
| 筛选按钮列间距（column-gap） | `cs-6` | `component-spacing.md` | 6pt（@2x 12px） |
| 筛选按钮行间距（row-gap） | `cs-6` | `component-spacing.md` | 6pt（@2x 12px） |
| 按钮上下内边距（4 列标准） | `cs-7` | `component-spacing.md` | 7pt（@2x 14px） |
| 按钮上下内边距（3 列宽松） | `cs-8` | `component-spacing.md` | 8pt（@2x 16px，多模块型） |
| 底部操作按钮上下内边距 | `cs-9` | `component-spacing.md` | 9pt（@2x 18px） |
| 底部操作按钮左右内边距 | `cs-24` | `component-spacing.md` | 24pt（@2x 48px） |
| 模块标题与按钮区间距（row-gap） | `cs-9` | `component-spacing.md` | 9pt（@2x 18px） |
| 二级内容区上内边距（列表 / 级联） | `cs-12` | `component-spacing.md` | 12pt（@2x 24px） |
| 面板内容底部（btn-flat，无底部按钮） | `cs-12` | `component-spacing.md` | 12pt（@2x 24px） |
| 选项间距 / 模块间距（row-gap） | `cs-21` | `component-spacing.md` | 21pt（@2x 42px） |
| 二级内容区下内边距（列表 / 级联） | `cs-24` | `component-spacing.md` | 24pt（@2x 48px） |
| 面板内容底部（`list-flat` / `cascade-*`无底部按钮时，内容区最下方内边距） | `cs-23` | `component-spacing.md` | 23pt（@2x 46px） |
| `list-flat` 选项间距 / `cascade-*` 二级选项间距（row-gap） | `spacing-m` | `spacing-semantic.md` | 20pt（与 `spacing-semantic` 重叠，优先引用 Semantic 层） |
---
## 5. Props API（供 AI 生码参考）
```typescript
export type FilterPanelProps = {
  /**
   * 子类型
   */
  type:
    | "list-flat-single"
    | "list-flat-double"
    | "btn-flat-single"
    | "btn-flat-multi"
    | "btn-flat-custom"
    | "cascade-2-list"
    | "cascade-2-btn"
    | "cascade-2-custom"
    | "cascade-3-list"
    | "cascade-3-custom";
  /**
   * 是否显示底部操作区（多选时为 true）
   * @default false
   */
  bottomBtn?: boolean;
  /**
   * 按钮列数（btn-flat-* 和 cascade-2-btn 适用）
   * @default 4
   */
  columns?: 2 | 3 | 4;
  /**
   * 文字类型（cascade-2-list / cascade-3-list 适用）
   * @default "single-line"
   */
  textType?: "single-line" | "double-line";
  /**
   * 是否显示一级选项选中指示器（cascade-2/3-list 适用）
   * @default true
   */
  showIndicator?: boolean;
  /**
   * 是否显示顶部分割线（cascade-2-list 适用）
   * @default false
   */
  showTopDivider?: boolean;
  /**
   * 是否展示多选对钩（btn-flat-single 适用）
   * @default false
   */
  showCheck?: boolean;
  /**
   * 是否显示模块标题展开选项（btn-flat-multi 适用）
   * @default false
   */
  showExpand?: boolean;
  /** 自定义内容插槽（custom 类型适用） */
  children?: React.ReactNode;
  /** 平铺面板选项数据 */
  items?: Array<{
    id: string;
    label: string;
    desc?: string;
    selected?: boolean;
  }>;
  /** 多模块数据（btn-flat-multi 适用） */
  modules?: Array<{
    title: string;
    showExpand?: boolean;
    items: Array<{ id: string; label: string; selected?: boolean }>;
  }>;
  /** 一级选项（cascade 类型适用） */
  level1Items?: Array<{ id: string; label: string; selected?: boolean }>;
  /** 二级选项（cascade-2-list 适用） */
  level2Items?: Array<{ id: string; label: string; desc?: string; selected?: boolean }>;
  /** 三级选项（cascade-3-list 适用） */
  level3Items?: Array<{ id: string; label: string; desc?: string; selected?: boolean }>;
  /** 当前选中的一级 ID */
  selectedLevel1Id?: string;
  /** 当前选中的二级 ID */
  selectedLevel2Id?: string;
  onSelect?: (id: string) => void;
  onLevel1Select?: (id: string) => void;
  onLevel2Select?: (id: string) => void;
  onLevel3Select?: (id: string) => void;
  onReset?: () => void;
  onConfirm?: (ids: string[]) => void;
};
```
---
## 6. data-attribute 规范
| 属性 | 值 | 说明 |
|------|-----|------|
| `data-slot` | `"filter-panel"` | 全局稳定标识 |
| `data-type` | 对应 type 字符串 | 当前子类型 |
| `data-has-bottom-btn` | `"true"` / `"false"` | 是否有底部操作区 |
| `data-columns` | `"2"` / `"3"` / `"4"` | 按钮列数（btn 类型适用） |
| `data-state` | `"selected"` / `"unselected"` | 选项选中态（作用于选项项） |
---
## 7. 无障碍（a11y）
- 面板使用 `role="dialog"` + `aria-modal="true"` + `aria-label="筛选面板"`
- 遮罩点击 / ESC 键关闭面板
- 一级 / 二级 / 三级选项使用 `<button>` 或 `role="option"` + `aria-selected`
- 筛选按钮选中时 `aria-pressed="true"`，多选时追加 `aria-label` 描述选中数量
- 底部重置按钮添加 `aria-label="清空筛选"`；确认按钮添加 `aria-label="确认筛选"`
- 面板打开时焦点自动移入，关闭时还原到触发元素
---
## 8. 使用约束（AI 生成时的硬性规则）
1. **面板底圆角固定**：所有子类型底部两角统一使用 `radius-xl`（20pt），禁止自定义
2. **禁止直接写 hex 颜色**：颜色必须引用 §4.1 中的语义层 Token
3. **遮罩必须使用**：所有子类型均需叠加 `bg-mask` 遮罩层（`rgba(0,0,0,0.6)`）
4. **最大高度限制**：底部保留屏幕高度 10% 空白；内容超出时面板内部可滚动
5. **底部按钮与交互逻辑对应**：多选逻辑必须开启 `bottomBtn=true`；单选点击即生效不得添加底部按钮
6. **按钮尺寸统一**：同一面板内所有筛选按钮必须使用相同列数档位规格，不可混用
7. **三级只放文字**：`cascade-3-list` 的第三级区域宽度窄，禁止放复杂控件
---
## 9. 选型决策树
```
用户说"筛选" / "filter panel" / "筛选面板"
  │
  ├─ 层级数量?
  │   ├─ 1 层（单层选项）→ 平铺面板
  │   │   ├─ 文字列表形式? → list-flat-single / list-flat-double
  │   │   └─ 按钮网格形式?
  │   │       ├─ 单一维度 → btn-flat-single
  │   │       ├─ 多维度分组 → btn-flat-multi
  │   │       └─ 特殊布局 → btn-flat-custom
  │   │
  │   ├─ 2 层 → 二层级联面板
  │   │   ├─ 右侧文字列表 → cascade-2-list
  │   │   ├─ 右侧按钮网格 → cascade-2-btn
  │   │   └─ 右侧特殊内容 → cascade-2-custom
  │   │
  │   └─ 3 层 → 三层级联面板
  │       ├─ 文字列表 → cascade-3-list
  │       └─ 特殊内容 → cascade-3-custom
  │
  ├─ 是否有底部确认按钮?
  │   ├─ 有 → bottomBtn=true（多选逻辑，确认后生效）
  │   └─ 无 → bottomBtn=false（单选逻辑，点击即生效）
  │
  └─ 按钮列数选择（btn 类型）:
      ├─ 2 列 → 宽松尺寸筛选按钮
      ├─ 2–3 列 → 宽松尺寸筛选按钮
      └─ 4 列及以上 → 标准尺寸筛选按钮
```
---
## 10. 使用场景速查
| 场景 | 推荐类型 | 关键配置 |
|------|---------|---------|
| 单层排序 / 筛选（点击即生效） | `list-flat-single` | `bottomBtn=false` |
| 单层带说明的筛选项 | `list-flat-double` | `bottomBtn=false` |
| 单维度按钮网格（单选） | `btn-flat-single` | `bottomBtn=false`，`columns=4` |
| 单维度按钮网格（多选） | `btn-flat-single` | `bottomBtn=true`，`columns=3/4` |
| 多维度分组筛选 | `btn-flat-multi` | `columns=3`（宽松）/ `columns=4`（标准） |
| 两层级联（单选点击即生效） | `cascade-2-list` | `bottomBtn=false`，`textType="single-line"` |
| 两层级联（多选确认生效） | `cascade-2-list` | `bottomBtn=true`，`textType="single-line"` |
| 两层级联 + 二级按钮网格 | `cascade-2-btn` | `columns=2`（宽松）/ `columns=3`（标准） |
| 省市区三级联动 | `cascade-3-list` | `bottomBtn=false`，`textType="single-line"` |
| 特殊 / 非标准布局 | `*-custom` 类型 | 使用 `children` 插槽 |
---
## 11. 与其他组件的关系
| 关联组件 | 关系说明 |
|---------|---------|
| `filter.md` | **触发关系（必须配套）**：筛选器是筛选面板的唯一触发入口。① 按钮的 `expand-arrow` 点击 → 弹出面板，箭头图标切换为收起态；② 右侧功能区 `filter-icon` / `text-filter-icon` 点击 → 弹出面板，图标切换为激活态。面板确认 / 关闭后，筛选结果需**回写**至触发该面板的筛选器按钮选中态（`selected` / `multi-selected`）。`gradient-only` 不触发面板。 |
| `button.md` | 底部操作区的确认按钮使用 `Button variant=primary size=xl`，重置使用 `variant=secondary` |
| `list.md` | 面板中的列表平铺选项样式参考 list 组件选项行规范 |
| `search bar.md` | `size=88` 带筛选标签的搜索框可联动筛选面板 |

