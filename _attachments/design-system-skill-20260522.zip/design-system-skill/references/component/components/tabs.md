# Tabs 选项卡 - 组件规范

> **组件分类**：Component（组件级）
> **定义**：选项卡（Tabs）用于在同一层级下将内容分组展示，用户通过点击不同 Tab 项在内容区间切换。支持单行/双行、居中/居左、模块/分段型共 4 大类变体。

---

## 0. 图标 / 间距 / Ownership 约束

- **icon-route（默认）**：Tabs 内功能图标默认回 `component/atoms/icon.md`，并遵循正文指定的 iconfont class / weight。
- **fixed-asset 例外**：若正文位点明确使用官方 SVG、`assets/*.svg`、PNG/CDN 或 URL 固定资源，必须走 fixed-asset。
- **spacing-owner（Tabs 自持）**：Tab 容器 padding、等宽/自适应策略、指示器位置与 Tab 项间距归 Tabs。
- **宿主裁决（优先级）**：Tab 内嵌 `badge` / `tag` 时，子组件仅拥有内部样式；摆放锚点与间距归 Tabs，冲突按 `宿主 > 组合场景 > 子组件`。
- **不可跳步**：先回 `references/INDEX.md` 完成区域路由与宿主锁定，再用 `component-quickref.md` 做宿主级收敛；本文件仅承接组件内 ownership 细则，不承担前置路由改判；不得凭语义猜测。


## 1. 组件类型（type）

| type | 名称 | 说明 | 适用场景 |
|------|------|------|---------|
| `single-line` | 单行选项卡 | 每个 Tab 项仅显示一行文字 | 选项数量不定、标签字数不一；常用于**页面头部导航** |
| `double-line` | 双行选项卡 | 每个 Tab 项含主标题 + 副标题双行内容 | 需要副标题补充说明的选项 |
| `module` | 模块选项卡 | 整体仅两个选项，圆角样式，用于局部模块切换 | 页面内**单模块**的局部导航 |
| `segmented` | 分段型选项卡 | 胶囊形外观，分单行 / 双行两种 | 信息分组展示；可叠加在沉浸式图片背景上 |

---

## 2. 布局对齐方式（align）

| align | 说明 | 数量限制 |
|-------|------|---------|
| `center` | Tab 选项等宽排列，均分整行 | ≤ 4 项 |
| `left` | Tab 项靠左、宽度随内容自适应；超出一屏可横向滑动 | 不限 |

---

## 3. 尺寸规格（level / size）

尺寸不可自定义，必须从下表选取。

### 3.1 单行选项卡（single-line）

| level | 名称 | 条高 | 字体 Token | 指示器 |
|-------|------|------|-----------|--------|
| `primary` | 一级 | 44pt | `subtitle-m-16-semibold`（选中）/ `subtitle-m-16-regular`（未选中） | 32×4pt，`cr-4`，`color-brand` |
| `secondary` | 二级 | 38pt | `body-l-14-semibold`（选中）/ `body-l-14-regular`（未选中） | 28×3pt，`cr-2`（1.5pt），`color-brand` |

> **上下内边距**：顶部 `cs-12`（12pt）/ 底部 `cs-6`（6pt）；⚠️ 此处精确约束，不可调整。

### 3.2 双行选项卡（double-line）

| 元素 | 字体 Token | 颜色 Token |
|------|-----------|-----------|
| 主标题 | `subtitle-m-16-medium` | `text-primary` |
| 副标题 | `caption-s-10-regular` | `text-secondary` |
| 条高 | 58pt | — |

> 指示器同一级单行规格：32×4pt，`cr-4`（2pt），`color-brand`。

### 3.3 模块选项卡（module）

| 元素 | 值 |
|------|-----|
| 容器宽 | 351pt（单行）/ 双行同宽 |
| 条高 | 44pt（单行）/ 54pt（双行） |
| 字体 Token | `subtitle-m-16-semibold`（选中）/ `subtitle-m-16-regular`（未选中） |
| 外圆角 | `cr-18`（18pt）或 `cr-12`（12pt），顶部两角 |
| 拼接处圆角 | 外圆角 − 2pt（如外圆角 `cr-18` 18pt → 拼接处 16pt；`cr-12` 12pt → 10pt） |

### 3.4 分段型选项卡（segmented）

| 元素 | 单行 | 双行 |
|------|------|------|
| 容器圆角 | `radius-full`（胶囊） | `radius-full`（胶囊） |
| 容器高 | 32pt | 42pt |
| 容器内边距 | `cs-2`（2pt）四周 | `cs-2`（2pt）四周 |
| 选中项背景 | `white` | `white` |
| 选中项圆角 | `radius-full` | `radius-full` |
| 主标题字体 Token | `body-l-14-semibold`（选中）/ `body-l-14-regular`（未选中） | `body-s-12-medium` |
| 副标题字体 Token | — | `caption-s-10-regular` |
| 容器宽（单行） | `fit-content`，由选项内容自动撑开 | 351pt（固定） |

---

## 4. 状态（state）

| state | `data-state` | 视觉表现 |
|-------|-------------|---------|
| 选中 | `active` | 文字加粗（`semibold` 或 `medium`），颜色 `text-primary`，指示器可见（`opacity: 1`） |
| 未选中 | `inactive` | 文字常规（`regular`），颜色 `text-secondary`，指示器隐藏（`opacity: 0`） |
| 分段型深色 | `dark` | 容器背景 `bg-overlay-dark`（`rgba(0,0,0,0.4)`，`color-semantic.md` §三），未选中文字 `white` |

---

## 5. 内容构成（slots）

### 5.1 单行选项卡 Tab 项

```
[ 左图标（可选） ] + [ 主文字 ] + [ 角标（可选） ]
                 [ 活动指示器（下划线）]
```

| slot | 说明 |
|------|------|
| `icon-left` | 左侧图标（可选），`aria-hidden="true"` |
| `label` | 主文字（**必须**） |
| `badge` | 数字角标（可选） |
| `indicator` | 活动指示器下划线（32×4pt） |

### 5.2 双行选项卡 Tab 项

```
[ 主标题（text-primary） ]
[ 副标题（text-secondary / text-tertiary）]
[ 活动指示器（下划线）]
```

### 5.3 分段型 Tab 项

```
[ 选中项白色背景 ] + [ 主文字 ] + [ 副信息（双行时）]
```

---

## 6. Token 引用

### 6.1 颜色 Token

| 用途 | Token 名称 | 语义层来源 |
|------|-----------|-----------|
| 选项卡背景 | `white` | `color-semantic.md` §三 Background Color |
| 分段型容器背景（正常） | `bg-fill-tertiary` | `color-semantic.md` §三 Background Color |
| 分段型选中项背景 | `white` | `color-semantic.md` §三 Background Color |
| 选中文字 | `text-primary` | `color-semantic.md` §二 Text Color |
| 未选中文字 | `text-secondary` | `color-semantic.md` §二 Text Color |
| 副标题（未选中） | `text-tertiary` | `color-semantic.md` §二 Text Color |
| 深色模式未选中文字 | `white` | `color-semantic.md` §一 Neutral Color |
| 活动指示器颜色 | `color-brand` | `color-semantic.md` §七 Brand Color |
| 模块选项卡容器背景 | `bg-fill-tertiary` | `color-semantic.md` §三 Background Color |

> **特殊说明**：指示器颜色默认为 `color-brand`（`color-semantic.md` §七 Brand Color，`#FFDD00` 美团黄），可根据业务品牌色自定义，但必须通过 Token 引用，禁止直接写 hex 值。

### 6.2 字体 Token

| 用途 | Token 名称 | 语义层来源 |
|------|-----------|-----------|
| 一级单行（选中） | `subtitle-m-16-semibold` | `font-semantic.md` §一 Subtitle |
| 一级单行（未选中） | `subtitle-m-16-regular` | `font-semantic.md` §一 Subtitle |
| 二级单行（选中） | `body-l-14-semibold` | `font-semantic.md` §一 Body |
| 二级单行（未选中） | `body-l-14-regular` | `font-semantic.md` §一 Body |
| 双行主标题 | `subtitle-m-16-medium` | `font-semantic.md` §一 Subtitle |
| 双行副标题 | `caption-s-10-regular` | `font-semantic.md` §一 Caption |
| 模块选项卡文字 | `subtitle-m-16-semibold` / `subtitle-m-16-regular` | `font-semantic.md` §一 Subtitle |
| 分段型单行（选中） | `headline-l-28-semibold` | `font-semantic.md` §一 Headline |
| 分段型单行（未选中） | `headline-l-28-regular` | `font-semantic.md` §一 Headline |
| 分段型双行主标题 | `body-s-12-medium` | `font-semantic.md` §一 Body |
| 分段型双行副标题 | `caption-s-10-regular` | `font-semantic.md` §一 Caption |

### 6.3 间距 Token

| 用途 | Token 名称 | 值 |
|------|-----------|-----|
| 选项卡顶部内边距 | `cs-12` | 12pt |
| 选项卡底部内边距 | `cs-6` | 6pt |
| 文字与指示器间距 | `cs-2` | 2pt |
| 图标与文字间距 | `cs-2` | 2pt |
| 分段型容器内边距 | `cs-2` | 2pt |

### 6.4 圆角 Token

| 用途 | Token 名称 | 说明 |
|------|-----------|------|
| 分段型容器 / 选中项 | `radius-full` | 胶囊全圆角 |
| 活动指示器（下划线） | `cr-4` | 4pt，下划线两端圆角 |
| 模块选项卡（外部） | `cr-18` 或 `cr-12` | 视设计场景选择 |

---

## 7. Props API（供 AI 生码参考）

```typescript
export type TabsProps = {
  /**
   * 选项卡类型
   * @default "single-line"
   */
  type: "single-line" | "double-line" | "module" | "segmented";

  /**
   * 布局对齐方式（single-line / double-line 适用）
   * @default "center"
   */
  align?: "center" | "left";

  /**
   * 场景级别（single-line 适用）
   * @default "primary"
   */
  level?: "primary" | "secondary";

  /**
   * 是否紧凑模式（仅居中型单行支持）
   * @default false
   */
  compact?: boolean;

  /**
   * 是否开启深色模式（仅分段型单行支持）
   * @default false
   */
  dark?: boolean;

  /**
   * 分段行数（分段型适用）
   * @default "single-line"
   */
  contentType?: "single-line" | "double-line";

  /**
   * 当前激活 index
   * @default 0
   */
  activeIndex?: number;

  /** Tab 项数组 */
  items: Array<{
    /** 主标题 */
    label: string;
    /** 副标题（double-line / segmented double-line 时有效） */
    subLabel?: string;
    /** 数字角标（single-line 时可选） */
    badge?: number | string;
    /** 左侧图标（single-line 时可选） */
    icon?: React.ReactNode;
    /** 是否选中 */
    active?: boolean;
  }>;

  /** 切换回调 */
  onChange?: (index: number) => void;
};
```

---

## 8. data-attribute 规范

| 属性 | 值 | 说明 |
|------|-----|------|
| `data-slot` | `"tabs"` | 全局稳定标识，供父组件 CSS 定向选中 |
| `data-type` | `"single-line"` / `"double-line"` / `"module"` / `"segmented"` | 当前选项卡类型 |
| `data-align` | `"center"` / `"left"` | 布局对齐方式 |
| `data-level` | `"primary"` / `"secondary"` | 场景级别（单行适用） |
| `data-state` | `"active"` / `"inactive"` | 单个 Tab 项的选中状态 |
| `data-dark` | `"true"` / `"false"` | 深色模式（分段型单行适用） |
| `data-compact` | `"true"` / `"false"` | 紧凑模式（单行居中型适用） |

---

## 9. 无障碍（a11y）

- 使用 `role="tablist"` 包裹整个选项卡栏，每个 Tab 项使用 `role="tab"`
- 选中 Tab 设置 `aria-selected="true"`，未选中设置 `aria-selected="false"`
- 关联内容区使用 `role="tabpanel"` + `aria-labelledby` 对应 Tab 的 `id`
- Tab 项使用 `<button>` 元素实现，不用 `<div>` 模拟
- 支持键盘左右方向键在 Tab 项间切换（`ArrowLeft` / `ArrowRight`）
- 角标（badge）需添加 `aria-label` 描述（如"3条未读"）

---

## 10. 使用约束（AI 生成时的硬性规则）

1. **禁止自定义尺寸**：高度、字号必须从 §3 表格中选取，不可自定义 `height` / `font-size`
2. **禁止直接写 hex 颜色**：颜色必须引用 §6.1 中的语义层 Token
3. **居中型最多 4 项**：`align=center` 时 `items` 数量不超过 4 个
4. **模块型仅支持 2 项**：`type=module` 固定两个选项，不可增减
5. **紧凑模式限制**：`compact=true` 仅在 `type=single-line` + `align=center` 时有效
6. **深色模式限制**：`dark=true` 仅在 `type=segmented` + `contentType=single-line` 时有效
7. **指示器颜色**：默认使用 `color-brand`，业务自定义颜色需在设计稿明确标注
8. **分段型数量**：`type=segmented` 的 `items` 数量为 2–4 个
9. **选项卡仅限 7 种**：整体选项卡样式只允许使用 §17.2.1–§17.2.7 定义的 7 种，禁止以单独选项（§17.1）自由拼接新变体
10. **单独选项不可跨组件复用**：§17.2.1–§17.2.7 各自引用的单独选项，只能在该选项卡内部使用，不得挪用至其他选项卡或在选项卡之外单独渲染
11. **❌ 禁止在选项卡容器底部自行添加分割线**：Tabs 规范中不包含底部分割线（`border-bottom`）诉求，AI 生码时不得在 `.tabs` / `.tab-bar` 等容器上擅自添加 `border-bottom`、`box-shadow` 或任何形式的底部分隔线样式

---

## 11. 变体矩阵

### 11.1 单行选项卡

| align | level | compact | 选项数 |
|-------|-------|---------|--------|
| `center` | `primary` | `false` / `true` | 2 / 3 / 4 |
| `center` | `secondary` | `false` / `true` | 2 / 3 / 4 |
| `left` | `primary` | — | 2 / 3 / 4 / 超出滑动 |
| `left` | `secondary` | — | 2 / 3 / 4 / 超出滑动 |

### 11.2 双行选项卡

| align | 选项数 |
|-------|--------|
| `center` | 2 / 3 / 4 |
| `left` | 2 / 3 / 4 / 5+ |

### 11.3 模块选项卡

| contentType | defaultActive |
|-------------|---------------|
| `single-line` | `left` / `right` |
| `double-line` | `left` / `right` |

### 11.4 分段型选项卡

| contentType | dark | 选项数 |
|-------------|------|--------|
| `single-line` | `false` / `true` | 2 / 3 / 4 |
| `double-line` | — | 2 / 3 / 4 |

---

## 12. 布局结构（伪代码）

### 12.1 单行居中型一级

```
<TabBar data-slot="tabs" data-type="single-line" data-level="primary" data-align="center"
        background=white height=44pt paddingTop=cs-12 paddingBottom=cs-6>
  <TabItem data-state="active|inactive" flex=1>
    <Icon? aria-hidden="true" />
    <Text font=subtitle-m-16-semibold|subtitle-m-16-regular color=text-primary|text-secondary />
    <Badge? />
    <Indicator width=32pt height=4pt radius=cr-4
               color=color-brand opacity=active:1|inactive:0 />
  </TabItem>
</TabBar>
```

### 12.2 分段型单行

```
<SegmentContainer data-slot="tabs" data-type="segmented" data-dark="false|true"
                  background=bg-fill-tertiary|bg-overlay-dark radius=radius-full padding=cs-2>
  <Segment data-state="active|inactive" flex=1>
    <ActiveBackground background=white radius=radius-full />   ← 仅选中时显示
    <Text font=body-l-14-semibold|body-l-14-regular
          color=text-primary|text-secondary|white(dark未选中) />
  </Segment>
</SegmentContainer>
```

### 12.3 模块选项卡

```
<ModuleTabBar data-slot="tabs" data-type="module"
              background=bg-fill-tertiary radius="cr-18 cr-18 0 0"（或 cr-12）>
  <Tab data-state="active|inactive" flex=1>
    <ActiveBackground background=white />   ← 仅选中项显示
    <Text font=subtitle-m-16-semibold|subtitle-m-16-regular
          color=text-primary|text-secondary />
    <SubText? font=caption-s-10-regular />   ← 双行时显示
  </Tab>
</ModuleTabBar>
```

---

## 13. 选型决策树

```
需要 Tab 组件
├─ 仅 2 个选项 + 局部模块切换？
│    └─ 模块选项卡（module）
├─ 需要副标题/辅助信息？
│    └─ 双行选项卡（double-line）或分段型双行（segmented + double-line）
├─ 需要胶囊形分组感 / 叠加图片背景？
│    └─ 分段型（segmented）
└─ 普通单行 Tab
     ├─ 选项数 ≤ 4 且标签字数基本一致？
     │    └─ 居中型（center）
     └─ 选项数不确定 / 标签字数差异大？
          └─ 居左型（left）
```

---

## 14. 常见组合示例

### 14.1 页面头部主导航（4 项居中）

```
Tabs
  type: single-line
  align: center
  level: primary
  items: ["推荐", "附近", "美食", "活动"]
  activeIndex: 0
```

### 14.2 功能区局部切换（模块型）

```
Tabs
  type: module
  contentType: single-line
  items: ["外卖", "堂食"]
  activeIndex: 0
```

### 14.3 信息分组（分段型深色，叠加图片）

```
Tabs
  type: segmented
  contentType: single-line
  dark: true
  items: ["全部", "热销", "新品"]
  activeIndex: 0
```

---

## 15. 与其他组件的关系

| 关联组件 | 关系说明 |
|---------|---------|
| `navigation.md` | 选项卡通常紧接导航栏下方；`level=primary` 常用于导航栏内 |
| `filter.md` | 选项卡负责内容分类，筛选器负责条件过滤，二者在同一页面可上下叠用 |
| `list.md` | 不同 Tab 项对应的内容区通常为列表 |

---

## 16. 设计稿来源

- **印迹画板 ID**：`1414146`
- **画板 URL**：`https://ingee.meituan.com/#/artboard/1414146/pos_t`
- **数据提取时间**：2026-04-03
- **组件集节点索引**：
  - 单行居中型：`137921:074979`
  - 单行居左型：`137921:074936`
  - 双行居中型：`137921:074038`
  - 双行居左型：`137921:073851`
  - 模块选项卡：`137921:074917`
  - 分段型单行：`137921:074071`
  - 分段型双行：`137921:074916`

---

## 17. 2 倍图样式数据（组件集源码）

> 以下数据直接提取自设计稿组件集 2 倍图 CSS，所有尺寸为 2x 像素值，换算 1x 规格请 ÷2。
> 分为「单独选项」与「选项卡」两类，选项卡引用单独选项中的内容。

---

### 17.1 单独选项

> **图标使用约束**
>
> 1. **图标来源**：优先选用 iconfont 中的图标。
> 2. **图标尺寸**：固定值，**不可更改**。
>    - 单行一级选项（`level=primary`）：**`18pt`**（@2x = `36px`）
>    - 单行二级选项（`level=secondary`）：**`16pt`**（@2x = `32px`）
>    - 对 iconfont 图标的整体外尺寸进行缩放，无需关注路径本身的尺寸。
> 3. **图标颜色**：遵循组件状态颜色规则——选中态 `text-primary`，未选中态 `text-secondary`。

#### 17.1.1 单行一级选项（`type=single-line` `level=primary`）

| 属性 | 选中态（active） | 未选中态（inactive） |
|------|----------------|-------------------|
| 整体高度 | `54px` | `54px` |
| 文字颜色 | `text-primary`（`#111111`） | `text-secondary`（`#555555`） |
| 字体 Token | `display-s-32-semibold` | `display-s-32-regular` |
| 指示器宽 | `64px` | `64px` |
| 指示器高 | `8px` | `8px` |
| 指示器圆角 | `4px` | `4px` |
| 指示器颜色 | `color-brand`（`#FFDD00`） | `color-brand`（`#FFDD00`） |
| 指示器透明度 | `1` | `0` |
| 文字与指示器间距（row-gap） | `2px` | `2px` |
| 角标字体 Token | `headline-s-24-regular` | `headline-s-24-regular` |
| **图标尺寸（固定，不可更改）** | **`18pt`（@2x = `36px`）** | **`18pt`（@2x = `36px`）** |

> **指示器约束**：
> - **高度**：固定 `8px`，不可更改。
> - **宽度**：取当前选中文字中 **2 个中文字符** 的宽度（即 `font-size × 2`）；一级选项字号 `32px`，故指示器宽 = `64px`。
> - **水平对齐**：指示器仅与 **`label` 文字**水平对齐，不受左侧图标或右侧数字影响；实现方式为将图标、label、数字横向排列后，指示器单独一行并通过 `align-self: auto`（继承父级 `align-items: center`）居中，**指示器宽度与 label 文字等宽（64px），而非与整行内容等宽**。
> - **颜色**：默认 `#FFDD00`（`color-brand` Token）；可根据用户指令替换为对应的 **Business Color Token**，禁止直接写 hex 值。

> **数字角标约束**：
> - **表达形式**：使用圆括号包裹数字，格式为 `(n)`，例如 `(7)`、`(13)`；左右括号与数字均属同一文本节点，不可拆分为独立组件。
> - **字体**：`headline-s-24-regular`（`font-size: 24px / font-weight: 400`），与括号共享同一字体设置。
> - **可修改范围**：仅允许修改括号内的**数字数值**；字号、括号字符、字重均不可更改。
> - **无组件嵌套**：不使用任何 Badge 组件或胶囊容器，直接以纯文本 `<span>` 渲染在 label 右侧。

| 对齐关系（2倍图） | 数值 | 说明 |
|---|---|---|
| 图标框顶部 距 label 文字框顶部 | `4px` | 图标偏上对齐于 label 文字框 |
| 图标框底部 距 label 文字框底部 | `14px` | 图标高度 = label文字框高度 − 4 − 14 |
| 数字框顶部 距 label 文字框顶部 | `9px` | 数字偏上对齐于 label 文字框 |
| 数字框底部 距 label 文字框底部 | `13px` | 数字高度 = label文字框高度 − 9 − 13 |
| 图标与 label 间距（column-gap） | `4px` | cs-2 |
| label 与数字间距（column-gap） | `4px` | cs-2 |

> **对齐实现说明**：`tab-content` 使用 `align-items: flex-start`（顶对齐），图标通过 `margin-top: 4px` 下移、数字通过 `margin-top: 9px` 下移，精确还原设计稿中相对 label 文字框的偏移关系。

```css
/* 单行一级选项 - 选中态 */
.tab-item {
  height: 54px;
  display: flex;
  flex-direction: column;
  justify-content: center;
  align-items: center;   /* 文字行整体水平居中于 cell */
}
/* 文字行：图标(可选) + label-wrap + 数字(可选) 横向排列，顶对齐 */
.tab-item .tab-content {
  display: flex;
  flex-direction: row;
  align-items: flex-start; /* 顶对齐，配合各子项 margin-top 精确还原设计稿偏移 */
  gap: cs-2; /* 4px */
}
/*
 * label-wrap：label 与 indicator 的共同父容器
 * indicator 作为其子元素，天然与 label 水平中心对齐，
 * 不受图标或数字的存在影响。
 */
.tab-item .label-wrap {
  display: flex;
  flex-direction: column;
  align-items: center;   /* indicator 与 label 同轴居中 */
  row-gap: cs-2; /* 2pt@2x：文字与指示器间距 */
}
.tab-item .label {
  color: text-primary; /* text-primary：#111111 */
  /* font: display-s-32-semibold → font-size:32px / line-height:44px / font-weight:600 */
  /* 未选中态：color: text-secondary; font: display-s-32-regular */
}
/* 图标：尺寸固定 18pt → @2x 36px，不可更改；margin-top:4px 使图标框顶部距 label 文字框顶部 4px */
.tab-item .tab-icon {
  font-size: 36px;   /* 18pt × 2，固定，不可更改 */
  line-height: 36px; /* 紧凑包裹，与 font-size 相等 */
  margin-top: 4px;
  flex-shrink: 0;
}
/* 数字角标：纯文本，不嵌套组件，margin-top:9px，使数字框顶部距 label 文字框顶部 9px（2倍图实测值） */
.tab-item .badge-text {
  /* font: headline-s-24-regular → font-size:24px / line-height:32px / font-weight:400 */
  /* 颜色同 label（选中态 text-primary，未选中态 text-secondary） */
  /* 内容格式：(n)，仅数字可变 */
  margin-top: 9px;
}
/* 指示器：在 label-wrap 内，宽度固定 = label 2字符宽，与 label 天然同轴 */
.tab-item .indicator {
  width: 64px;  /* = 32px × 2，不随图标/数字存在而偏移 */
  height: 8px;
  border-radius: cr-4; /* 4px */
  background: color-brand; /* #FFDD00，可替换为 Business Color Token */
  /* 未选中态：opacity: 0 */
}
```

> **结构示意**（HTML 伪代码）：
> ```
> <button class="tab-item">
>   <div class="tab-content">              ← align-items: flex-start
>     <span class="tab-icon" />          ← 可选，margin-top:4px
>     <div class="label-wrap">
>       <span class="label">文字</span>
>       <div class="indicator" />        ← 在 label-wrap 内，天然与 label 同轴
>     </div>
>     <span class="badge-text">(n)</span> ← 可选，margin-top:9px
>   </div>
> </button>
> ```

---

#### 17.1.2 单行二级选项（`type=single-line` `level=secondary`）

| 属性 | 选中态（active） | 未选中态（inactive） |
|------|----------------|-------------------|
| 整体高度 | `48px` | `48px` |
| 文字颜色 | `text-primary`（`#111111`） | `text-secondary`（`#555555`） |
| 字体 Token | `headline-l-28-semibold` | `headline-l-28-regular` |
| 指示器宽 | `56px` | `56px` |
| 指示器高 | `6px` | `6px` |
| 指示器圆角 | `3px` | `3px` |
| 指示器颜色 | `color-brand`（`#FFDD00`） | `color-brand`（`#FFDD00`） |
| 指示器透明度 | `1` | `0` |
| 文字与指示器间距（row-gap） | `2px` | `2px` |
| 角标字体 Token | `headline-s-24-regular` | `headline-s-24-regular` |
| **图标尺寸（固定，不可更改）** | **`16pt`（@2x = `32px`）** | **`16pt`（@2x = `32px`）** |

> **指示器约束**：
> - **高度**：固定 `6px`，不可更改。
> - **宽度**：取当前选中文字中 **2 个中文字符** 的宽度（即 `font-size × 2`）；二级选项字号 `28px`，故指示器宽 = `56px`。
> - **水平对齐**：指示器仅与 **`label` 文字**水平对齐，不受左侧图标或右侧数字影响；指示器宽度固定为 `56px`（与 label 文字宽度对齐），不随图标或数字的存在而扩展。
> - **颜色**：默认 `#FFDD00`（`color-brand` Token）；可根据用户指令替换为对应的 **Business Color Token**，禁止直接写 hex 值。

> **数字角标约束**：
> - **表达形式**：使用圆括号包裹数字，格式为 `(n)`，例如 `(9)`、`(18)`；左右括号与数字均属同一文本节点，不可拆分为独立组件。
> - **字体**：`headline-s-24-regular`（`font-size: 24px / font-weight: 400`），与括号共享同一字体设置。
> - **可修改范围**：仅允许修改括号内的**数字数值**；字号、括号字符、字重均不可更改。
> - **无组件嵌套**：不使用任何 Badge 组件或胶囊容器，直接以纯文本 `<span>` 渲染在 label 右侧。

| 对齐关系（2倍图） | 数值 | 说明 |
|---|---|---|
| 图标框顶部 距 label 文字框顶部 | `4px` | 图标偏上对齐于 label 文字框 |
| 图标框底部 距 label 文字框底部 | `12px` | 图标高度 = label文字框高度 − 4 − 12 |
| 数字框顶部 距 label 文字框顶部 | `5px` | 数字偏上对齐于 label 文字框 |
| 数字框底部 距 label 文字框底部 | `11px` | 数字高度 = label文字框高度 − 5 − 11 |
| 图标与 label 间距（column-gap） | `4px` | cs-2 |
| label 与数字间距（column-gap） | `4px` | cs-2 |

> **对齐实现说明**：`tab-content` 使用 `align-items: flex-start`（顶对齐），图标通过 `margin-top: 4px` 下移、数字通过 `margin-top: 5px` 下移，精确还原设计稿中相对 label 文字框的偏移关系。

```css
/* 单行二级选项 - 选中态 */
.tab-item--secondary {
  height: 48px;
  display: flex;
  flex-direction: column;
  justify-content: center;
  align-items: center;   /* 文字行整体水平居中于 cell */
}
/* 文字行：图标(可选) + label-wrap + 数字(可选) 横向排列，顶对齐 */
.tab-item--secondary .tab-content {
  display: flex;
  flex-direction: row;
  align-items: flex-start; /* 顶对齐，配合各子项 margin-top 精确还原设计稿偏移 */
  gap: cs-2; /* 4px */
}
/*
 * label-wrap：label 与 indicator 的共同父容器
 * indicator 作为其子元素，天然与 label 水平中心对齐，
 * 不受图标或数字的存在影响。
 */
.tab-item--secondary .label-wrap {
  display: flex;
  flex-direction: column;
  align-items: center;   /* indicator 与 label 同轴居中 */
  row-gap: cs-2; /* 2pt@2x：文字与指示器间距 */
}
.tab-item--secondary .label {
  color: text-primary; /* text-primary：#111111 */
  /* font: headline-l-28-semibold → font-size:28px / line-height:40px / font-weight:600 */
  /* 未选中态：color: text-secondary; font: headline-l-28-regular */
}
/* 图标：尺寸固定 16pt → @2x 32px，不可更改；margin-top:4px 使图标框顶部距 label 文字框顶部 4px */
.tab-item--secondary .tab-icon {
  font-size: 32px;   /* 16pt × 2，固定，不可更改 */
  line-height: 32px; /* 紧凑包裹，与 font-size 相等 */
  margin-top: 4px;
  flex-shrink: 0;
}
/* 数字角标：纯文本，不嵌套组件，margin-top:5px，使数字框顶部距 label 文字框顶部 5px（2倍图实测值） */
.tab-item--secondary .badge-text {
  /* font: headline-s-24-regular → font-size:24px / line-height:32px / font-weight:400 */
  /* 颜色同 label（选中态 text-primary，未选中态 text-secondary） */
  /* 内容格式：(n)，仅数字可变 */
  margin-top: 5px;
}
/* 指示器：在 label-wrap 内，宽度固定 = label 2字符宽，与 label 天然同轴 */
.tab-item--secondary .indicator {
  width: 56px;  /* = 28px × 2，不随图标/数字存在而偏移 */
  height: 6px;
  border-radius: cr-2; /* 3px */
  background: color-brand; /* #FFDD00，可替换为 Business Color Token */
  /* 未选中态：opacity: 0 */
}
```

> **结构示意**（HTML 伪代码）：
> ```
> <button class="tab-item--secondary">
>   <div class="tab-content">              ← align-items: flex-start
>     <span class="tab-icon" />          ← 可选，margin-top:4px
>     <div class="label-wrap">
>       <span class="label">文字</span>
>       <div class="indicator" />        ← 在 label-wrap 内，天然与 label 同轴
>     </div>
>     <span class="badge-text">(n)</span> ← 可选，margin-top:5px
>   </div>
> </button>
> ```

---

#### 17.1.3 双行选项（`type=double-line`）

| 属性 | 选中态（active） | 未选中态（inactive） |
|------|----------------|-------------------|
| 整体高度 | `82px` | `82px` |
| 主标题颜色 | `text-primary`（`#111111`） | `text-primary`（`#111111`） |
| 主标题字体 Token | `display-s-32-medium` | `display-s-32-medium` |
| 副标题颜色 | `text-secondary`（`#555555`） | `text-secondary`（`#555555`） |
| 副标题字体 Token | `title-m-20-regular` | `title-m-20-regular` |
| 主副标题间距 | `margin-top: -2px` | `margin-top: -2px` |
| 文字区与指示器间距（row-gap） | `4px` | `4px` |
| 指示器宽 | `64px` | `64px` |
| 指示器高 | `8px` | `8px` |
| 指示器圆角 | `4px` | `4px` |
| 指示器颜色 | `color-brand`（`#FFDD00`） | `color-brand`（`#FFDD00`） |
| 指示器透明度 | `1` | `0` |

> **指示器约束**：
> - **高度**：固定 `8px`，不可更改。
> - **宽度**：取当前选中文字中 **2 个中文字符** 的宽度（即上方主标题 `font-size × 2`）；双行选项主标题字号 `32px`，故指示器宽 = `64px`。双行时以**上方主标题**字号为准，不以副标题取值。
> - **颜色**：默认 `#FFDD00`（`color-brand` Token）；可根据用户指令替换为对应的 **Business Color Token**，禁止直接写 hex 值。

```css
/* 双行选项 - 选中态 */
.tab-item--double {
  height: 82px;
  display: flex;
  flex-direction: column;
  justify-content: center;
  align-items: center;
  row-gap: cs-4; /* 4px */
}
.tab-item--double .title-group {
  display: flex;
  flex-direction: column;
  align-items: center;
}
.tab-item--double .title-group .main-label {
  color: text-primary; /* text-primary：#111111 */
  /* font: display-s-32-medium → font-size:32px / line-height:44px / font-weight:500 */
}
.tab-item--double .title-group .sub-label {
  color: text-secondary; /* text-secondary：#555555 */
  /* font: title-m-20-regular → font-size:20px / line-height:28px / font-weight:400 */
  margin-top: -2px;
}
.tab-item--double .indicator {
  width: 64px;
  height: 8px;
  border-radius: cr-4; /* 4px */
  background: color-brand; /* #FFDD00，可替换为 Business Color Token */
  /* 未选中态：opacity: 0 */
}
```

---

#### 17.1.4 单行分段型选项（`type=segmented` `contentType=single-line`）

| 属性 | 选中态（active） | 未选中态（inactive） |
|------|----------------|-------------------|
| 选项高度 | `56px` | `56px` |
| 选项宽度 | `flex-shrink: 0`，宽度由文字内容 + 左右各 `32px` padding 撑开，**不得设置固定宽度，不得均分** | 同左 |
| 文字颜色 | `text-primary`（`#111111`） | `text-secondary`（`#555555`）；深色模式：`white`（`#FFFFFF`） |
| 字体 Token | `headline-l-28-semibold` | `headline-l-28-regular` |
| font-size | `28px` | `28px` |
| line-height | `40px` | `40px` |
| font-weight | `600`（Semibold） | `400`（Regular） |
| 选中项背景 | `white`（`#FFFFFF`） | 无背景 |
| 选中项圆角 | `radius-full`（胶囊） | — |
| 内边距 | `8px 32px`（上下 8px，左右 32px = 16pt；文字 `<span>` 不设宽度，随内容自适应） | `8px 32px` |

```css
/* 单行分段型选项 - 选中态 */
.segment-item--active {
  height: 56px;
  border-radius: radius-full; /* 胶囊，40px */
  background: white; /* white：#FFFFFF */
  padding: 8px 32px;
  display: flex;
  align-items: center;
  justify-content: center;
}
.segment-item--active .label {
  color: text-primary;  /* text-primary：#111111 */
  font-size: 28px;      /* headline-l-28-semibold */
  line-height: 40px;
  font-weight: 600;     /* Semibold */
  white-space: nowrap;
}
/* 未选中态 */
.segment-item--inactive .label {
  color: text-secondary; /* text-secondary：#555555；深色模式：white */
  font-size: 28px;       /* headline-l-28-regular */
  line-height: 40px;
  font-weight: 400;      /* Regular */
  white-space: nowrap;
}
```

---

#### 17.1.5 双行分段型选项（`type=segmented` `contentType=double-line`）

| 属性 | 选中态（active） | 未选中态（inactive） |
|------|----------------|-------------------|
| 选项高度 | `76px` | `76px` |
| 主标题颜色 | `text-primary`（`#111111`） | `text-secondary`（`#555555`） |
| 主标题字体 Token | `headline-s-24-medium` | `headline-s-24-medium` |
| 副标题颜色 | `text-secondary`（`#555555`） | `text-tertiary`（`#888888`） |
| 副标题字体 Token | `title-m-20-regular` | `title-m-20-regular` |
| 选中项背景 | `white`（`#FFFFFF`） | 无背景 |
| 选中项圆角 | `radius-full`（胶囊） | — |
| 内边距 | `8px 0px` | `8px 0px` |
| 描边 | ❌ 禁止（不得出现 `border` / `outline`） | — |
| 阴影 | ❌ 禁止（不得出现 `box-shadow`） | — |
| 字号 | ⚠️ 不建议调整，应遵循 Token 定义值 | ⚠️ 不建议调整，应遵循 Token 定义值 |
| 字色 | ⚠️ 不建议调整，应遵循 Token 定义值 | ⚠️ 不建议调整，应遵循 Token 定义值 |

```css
/* 双行分段型选项 - 选中态 */
.segment-item-double--active {
  height: 76px;
  border-radius: radius-full; /* 胶囊，40px */
  background: white; /* white：#FFFFFF */
  padding: 8px 0;
  display: flex;
  flex-direction: column;
  align-items: center;
  justify-content: center;
  /* ❌ 禁止添加 border / outline / box-shadow，选中态仅靠白色背景与容器灰色背景对比区分 */
}
.segment-item-double--active .main-label {
  color: text-primary; /* text-primary：#111111；⚠️ 不建议修改字色 */
  /* font: headline-s-24-medium → font-size:24px / line-height:32px / font-weight:500；⚠️ 不建议修改字号 */
}
.segment-item-double--active .sub-label {
  color: text-secondary; /* text-secondary：#555555；⚠️ 不建议修改字色 */
  /* font: title-m-20-regular → font-size:20px / line-height:28px / font-weight:400；⚠️ 不建议修改字号 */
}
/* 未选中态 */
.segment-item-double--inactive .main-label { color: text-secondary; /* text-secondary：#555555；⚠️ 不建议修改字色 */ }
.segment-item-double--inactive .sub-label  { color: text-tertiary;  /* text-tertiary：#888888；⚠️ 不建议修改字色 */ }
```

---

### 17.2 选项卡

> ⛔ **强制性规定（AI 生成时必须遵守）**
>
> 1. **选项卡样式仅限以下 7 种**：`17.2.1` 至 `17.2.7`，禁止大模型以「单独选项（§17.1）」为积木自由拼接出新的选项卡变体。
> 2. **单独选项不可跨组件复用**：`17.2.1`–`17.2.7` 各自内部引用的单独选项，只允许在该选项卡内部使用；禁止将某一选项卡中的单独选项样式挪用到其他选项卡中，或在选项卡之外单独渲染。

#### 17.2.1 单行居中型选项卡（`type=single-line` `align=center`）

引用：[17.1.1 单行一级选项](#1711-单行一级选项typesingl-linelevelPrimary) / [17.1.2 单行二级选项](#1712-单行二级选项typesingl-linelevelSecondary)

| 属性 | 一级（primary） | 二级（secondary） |
|------|---------------|-----------------|
| 容器高度 | `88px` | `76px` |
| 容器背景 | `white`（`#FFFFFF`） | `white`（`#FFFFFF`） |
| 上内边距 | `22px` | `18px` |
| 下内边距 | `12px` | `10px` |
| 左右内边距 | `10px`（各 Tab 项） | `10px` |
| Tab 项布局 | `flex-grow: 1`（均分） | `flex-grow: 1`（均分） |

```css
/* 单行居中型选项卡容器 */
.tabbar--center {
  width: 750px;
  height: 88px;
  display: flex;
  flex-direction: row;
  justify-content: start;
  align-items: start;
  background: white; /* white：#FFFFFF */
  padding: 22px 0 12px 0; /* 一级：顶22px / 底12px；二级：顶18px / 底10px */
  /* 二级（secondary）覆盖：height: 76px（18+48+10）；padding: 18px 0 10px 0 */
}
.tabbar--center .tab-cell {
  flex-grow: 1;
  display: flex;
  justify-content: center;
  align-items: start;
  padding: 0 10px;
}
```

---

#### 17.2.2 单行居左型选项卡（`type=single-line` `align=left`）

引用：[17.1.1 单行一级选项](#1711-单行一级选项typesingl-linelevelPrimary) / [17.1.2 单行二级选项](#1712-单行二级选项typesingl-linelevelSecondary)

| 属性 | 值 |
|------|-----|
| 容器宽度 | 可拉伸（`width: 100%`）或指定固定值；内容超出时以 `overflow: hidden` 截断 |
| 容器高度 | `88px`（一级）/ `76px`（二级） |
| 容器背景 | `white`（`#FFFFFF`） |
| 上内边距 | `22px`（一级）/ `18px`（二级） |
| 下内边距 | `12px`（一级）/ `10px`（二级） |
| 左内边距 | `24px` |
| Tab 项间距（column-gap） | `48px` |
| 超出处理 | `overflow: hidden`，超出部分直接截断 |
| 右侧渐变遮罩 | 固定贴在容器右侧，宽度 `60px`；从透明 → `white`（`#FFFFFF`）渐变，提示屏幕外仍有内容 |

```css
/* 单行居左型选项卡容器 */
.tabbar--left {
  width: 100%; /* 可拉伸，也可指定固定值 */
  height: 88px; /* 一级；二级为 76px（18+48+10） */
  display: flex;
  flex-direction: row;
  justify-content: start;
  align-items: center;
  column-gap: 48px;
  background: white; /* white：#FFFFFF */
  padding: 22px 0 12px 24px; /* 一级：顶22px / 底12px；二级覆盖：顶18px / 底10px */
  overflow: hidden;
  position: relative;
}
/* 右侧渐变遮罩 */
.tabbar--left::after {
  content: '';
  position: absolute;
  right: 0;
  top: 0;
  width: 60px;
  height: 100%;
  background: linear-gradient(to right, transparent, white /* white：#FFFFFF */);
  pointer-events: none;
}
```

---

#### 17.2.3 双行居中型选项卡（`type=double-line` `align=center`）

引用：[17.1.3 双行选项](#1713-双行选项typedouble-line)

| 属性 | 值 |
|------|-----|
| 容器高度 | `116px` |
| 容器背景 | `white`（`#FFFFFF`） |
| 上内边距 | `22px` |
| 下内边距 | `12px` |
| 左右内边距 | `0px` |
| Tab 项布局 | `flex-grow: 1`（均分，2/3/4 项分别为 375/250/187.5px） |

```css
/* 双行居中型选项卡容器 */
.tabbar-double--center {
  width: 750px;
  height: 116px;
  display: flex;
  flex-direction: row;
  justify-content: start;
  align-items: start;
  background: white; /* white：#FFFFFF */
  padding: 22px 0 12px 0; /* cs-12 顶 / cs-6 底 */
}
.tabbar-double--center .tab-cell {
  flex-grow: 1;
  display: flex;
  flex-direction: column;
  justify-content: center;
  align-items: center;
}
```

---

#### 17.2.4 双行居左型选项卡（`type=double-line` `align=left`）

引用：[17.1.3 双行选项](#1713-双行选项typedouble-line)

| 属性 | 值 |
|------|-----|
| 容器宽度 | 可拉伸（`width: 100%`）或指定固定值；内容超出时以 `overflow: hidden` 截断 |
| 容器高度 | `116px` |
| 容器背景 | `white`（`#FFFFFF`） |
| 上内边距 | `22px` |
| 下内边距 | `12px` |
| 左内边距 | `24px` |
| Tab 项间距（column-gap） | `60px` |
| 超出处理 | `overflow: hidden`，超出部分直接截断 |
| 右侧渐变遮罩 | 固定贴在容器右侧，宽度 `60px`；从透明 → `white`（`#FFFFFF`）渐变，提示屏幕外仍有内容 |

```css
/* 双行居左型选项卡容器 */
.tabbar-double--left {
  width: 100%; /* 可拉伸，也可指定固定值 */
  height: 116px;
  display: flex;
  flex-direction: row;
  justify-content: start;
  align-items: start;
  column-gap: 60px;
  background: white; /* white：#FFFFFF */
  padding: 22px 0 12px 24px; /* cs-12 顶 / cs-6 底 / cs-12 左 */
  overflow: hidden;
  position: relative;
}
/* 右侧渐变遮罩 */
.tabbar-double--left::after {
  content: '';
  position: absolute;
  right: 0;
  top: 0;
  width: 60px;
  height: 100%;
  background: linear-gradient(to right, transparent, white /* white：#FFFFFF */);
  pointer-events: none;
}
```

---

#### 17.2.5 模块型选项卡（`type=module`）

> 不引用单独选项，样式独立定义。

| 属性 | 单行（single-line） | 双行（double-line） |
|------|-------------------|-------------------|
| 容器宽 | `702px` | `702px` |
| 容器高 | `88px` | `108px` |
| 容器背景 | `bg-fill-tertiary`（`#F5F5F5`） | `bg-fill-tertiary`（`#F5F5F5`） |
| 容器圆角 | `cr-12`（`24px 24px 0 0`） | `cr-12`（`24px 24px 0 0`） |
| 选中主标题颜色 | `text-primary`（`#111111`） | `text-primary`（`#111111`） |
| 选中主标题字体 Token | `display-s-32-semibold` | `display-s-32-semibold` |
| 未选中主标题颜色 | `text-secondary`（`#555555`） | `text-secondary`（`#555555`） |
| 未选中主标题字体 Token | `display-s-32-regular` | `display-s-32-regular` |
| 选中副标题颜色 | — | `text-tertiary`（`#888888`） |
| 未选中副标题颜色 | — | `text-quaternary`（`#999999`） |
| 副标题字体 Token | — | `title-m-20-regular` |
| 内容区上间距 | — | `top: 16px` |
| 主副标题间距（row-gap） | — | `4px` |

```css
/* 模块型选项卡容器 */
.tabbar--module {
  width: 702px;
  border-radius: cr-12; /* cr-12：24px 24px 0 0 */
  display: flex;
  flex-direction: row;
  background: bg-fill-tertiary; /* bg-fill-tertiary：#F5F5F5 */
}
/* 单行：height: 88px；双行：height: 108px */

/* 模块型 - 单行 Tab 项 */
.module-tab-item .label {
  /* font: display-s-32-semibold/display-s-32-regular → 32px/44px */
  text-align: center;
}
.module-tab-item--active .label   { color: text-primary;   /* text-primary：#111111 font-weight:600 */ }
.module-tab-item--inactive .label { color: text-secondary; /* text-secondary：#555555 font-weight:400 */ }

/* 模块型 - 双行 Tab 项 */
.module-tab-item-double {
  display: flex;
  flex-direction: column;
  align-items: center;
  row-gap: cs-4; /* 4px */
  padding-top: 16px;
}
.module-tab-item-double--active .main-label   { color: text-primary;   /* display-s-32-semibold */ }
.module-tab-item-double--inactive .main-label { color: text-secondary; /* display-s-32-regular  */ }
.module-tab-item-double--active .sub-label    { color: text-tertiary;  /* text-tertiary：#888888 title-m-20-regular */ }
.module-tab-item-double--inactive .sub-label  { color: text-quaternary; /* text-quaternary：#999999 title-m-20-regular */ }
```

#### 17.2.5-A 拼接处异形块规范（SVG）

> 模块型选项卡两个 Tab 项之间的拼接处，**必须使用指定 SVG 文件**实现异形拼接效果，禁止用 CSS 伪元素或其他方式替代。SVG 尺寸及内部样式不可更改。

##### SVG 文件路径

| 变体 | SVG 文件路径 |
|------|------------|
| 单行（`contentType=single-line`） | `assets/Module Tabs Shape 1.svg` |
| 双行（`contentType=double-line`） | `assets/Module Tabs Shape 2.svg` |

##### SVG 原始尺寸与缩放规则

> SVG 文件本身为 **1倍图（1x）**规格。根据生成目标的倍图规格，需对 SVG 整体进行等比缩放：

| 属性 | 单行 Shape 1（1x） | 单行 Shape 1（2x） | 双行 Shape 2（1x） | 双行 Shape 2（2x） |
|------|-----------------|-----------------|-----------------|-----------------|
| `width` | `55px` | `110px` | `60px` | `120px` |
| `height` | `44px` | `88px` | `54px` | `108px` |
| `fill` | SVG 自身默认颜色，禁止覆盖 | SVG 自身默认颜色，禁止覆盖 | SVG 自身默认颜色，禁止覆盖 | SVG 自身默认颜色，禁止覆盖 |

> - **1倍图输出**：使用 SVG 原始尺寸，不做缩放。
> - **2倍图输出**：SVG 整体缩放至 2x，即 `width` / `height` 均 × 2。
> - **缩放方式**：通过 `<img>` 的 `width` / `height` 属性或 `<svg>` 的 `width` / `height` 属性显式指定目标尺寸，SVG 内部路径自动等比缩放，**fill 颜色不变**。
> ⚠️ **SVG 必须使用自身默认颜色**：禁止通过任何方式（包括 CSS `fill`、`color`、`style` 属性、`currentColor` 或外部 Token 覆盖）修改 SVG 的 fill 颜色，只允许通过外部 `width` / `height` 属性控制缩放比例。

##### SVG 内联时必须添加背景矩形

> ⚠️ **强制要求（内联 SVG 时）**：SVG 以内联方式嵌入 HTML 时，**必须在 `<path>` 之前添加一个与 SVG 等尺寸的 `<rect>` 背景矩形**，fill 值为容器底色 `bg-fill-tertiary`（`#F5F5F5`）。
>
> **原因**：SVG 是 `position: absolute; z-index: 10`，其矩形边界框（bounding box）完全覆盖在选中 Tab 的白色背景之上。SVG path 为异形区域，path 以外的区域在 SVG 中是透明的——透明区域会透出下方选中 Tab 的 `white`（`#FFFFFF`）背景，产生一块多余的白色矩形。`<rect>` 背景矩形可将该透明区域填充为 `bg-fill-tertiary`（`#F5F5F5`），完整遮挡下方白色，仅让 path 内的白色正确显示。

```html
<!-- ✅ 正确：内联 SVG，path 前先放 rect 底色矩形 -->
<!-- 单行 Shape 1（2x）-->
<svg class="module-connector" aria-hidden="true"
     xmlns="http://www.w3.org/2000/svg" fill="none" version="1.1"
     width="110" height="88" viewBox="0 0 55 44">
  <rect width="55" height="44" fill="#F5F5F5"/>  ← 必须，遮挡透明区域（bg-fill-tertiary）
  <path d="M0,44L42.156036,..." fill="#FFFFFF" fill-opacity="1"/>  ← white（禁止用 token 覆盖，仅注释导向）
</svg>

<!-- 双行 Shape 2（2x）-->
<svg class="module-connector" aria-hidden="true"
     xmlns="http://www.w3.org/2000/svg" fill="none" version="1.1"
     width="120" height="108" viewBox="0 0 60 54">
  <rect width="60" height="54" fill="#F5F5F5"/>  ← 必须，遮挡透明区域（bg-fill-tertiary）
  <path d="M0,0L0,54L46.960133,..." fill="#FFFFFF" fill-opacity="1"/>  ← white（禁止用 token 覆盖，仅注释导向）
</svg>

<!-- ❌ 错误：缺少 rect，SVG 透明区域透出选中 Tab 白色背景，产生多余白色矩形 -->
<svg ...>
  <path ... fill="#FFFFFF"/>  ← white（禁止用 token 覆盖）
</svg>
```

> **`<img>` 方式引用 SVG 时无需此操作**：通过 `<img src="...">` 引用 SVG 文件时，浏览器将其视为独立图像，SVG 透明区域显示为透明（即页面背景色），不会出现上述问题；`<rect>` 背景矩形仅在内联 SVG 时为必须项。

##### 定位规则

- `position: absolute`，垂直方向居中（`top: 50%`）
- **水平方向**：SVG 整体在 Tab 容器中**水平居中**，使用 `left: 50%` 配合 `translateX(-50%)` 实现；⚠️ 定位基准为 **SVG 的总尺寸（含空白区域）**，即 `width` / `height` 所声明的完整矩形边界，禁止仅以路径可见区域计算偏移
- SVG 必须是 tabs 容器内**层级最高**的元素（`z-index` 最大）
- 选左、选右共用同一个 SVG，通过 `transform` 区分方向

##### 选左 / 选右方向控制

| 状态 | `transform` | 说明 |
|------|------------|------|
| 选左（左侧选中） | `translateX(-50%) translateY(-50%)` | SVG 水平居中 + 垂直居中，朝向默认正确，异形切角朝右 |
| 选右（右侧选中） | `translateX(-50%) translateY(-50%) scaleX(-1)` | 在水平/垂直居中基础上叠加水平镜像，异形切角翻转朝左 |

> ⚠️ **禁止使用 `rotate(180deg)` 实现选右**：会同时翻转上下方向，导致形状错误。必须使用 `scaleX(-1)` 做纯水平镜像。

```html
<!-- 选左：单行（内联 SVG，含必须的 rect 背景矩形） -->
<svg class="module-connector" aria-hidden="true"
     xmlns="http://www.w3.org/2000/svg" fill="none" version="1.1"
     width="110" height="88" viewBox="0 0 55 44">
  <rect width="55" height="44" fill="#F5F5F5"/>  ← bg-fill-tertiary
  <path d="M0,44L42.156036,44C37.876755,44,34.071747,41.277119,32.690933,37.226738L22.309067,6.7732606C20.928255,2.7228785,17.123243,0,12.843964,0L0,0L0,44Z" fill="#FFFFFF" fill-opacity="1"/>  ← white（禁止用 token 覆盖）
</svg>

<!-- 选右：单行，水平镜像 -->
<svg class="module-connector module-connector--right" aria-hidden="true"
     xmlns="http://www.w3.org/2000/svg" fill="none" version="1.1"
     width="110" height="88" viewBox="0 0 55 44">
  <rect width="55" height="44" fill="#F5F5F5"/>  ← bg-fill-tertiary
  <path d="M0,44L42.156036,44C37.876755,44,34.071747,41.277119,32.690933,37.226738L22.309067,6.7732606C20.928255,2.7228785,17.123243,0,12.843964,0L0,0L0,44Z" fill="#FFFFFF" fill-opacity="1"/>  ← white（禁止用 token 覆盖）
</svg>

<!-- 选左：双行（内联 SVG，含必须的 rect 背景矩形） -->
<svg class="module-connector" aria-hidden="true"
     xmlns="http://www.w3.org/2000/svg" fill="none" version="1.1"
     width="120" height="108" viewBox="0 0 60 54">
  <rect width="60" height="54" fill="#F5F5F5"/>  ← bg-fill-tertiary
  <path d="M0,0L0,54L46.960133,54C42.776806,54,39.035576,51.396053,37.582645,47.473145L22.417355,6.5268569C20.964426,2.6039481,17.22319,0,13.039865,0L0,0Z" fill="#FFFFFF" fill-opacity="1"/>  ← white（禁止用 token 覆盖）
</svg>

<!-- 选右：双行，水平镜像 -->
<svg class="module-connector module-connector--right" aria-hidden="true"
     xmlns="http://www.w3.org/2000/svg" fill="none" version="1.1"
     width="120" height="108" viewBox="0 0 60 54">
  <rect width="60" height="54" fill="#F5F5F5"/>  ← bg-fill-tertiary
  <path d="M0,0L0,54L46.960133,54C42.776806,54,39.035576,51.396053,37.582645,47.473145L22.417355,6.5268569C20.964426,2.6039481,17.22319,0,13.039865,0L0,0Z" fill="#FFFFFF" fill-opacity="1"/>  ← white（禁止用 token 覆盖）
</svg>
```

```css
.module-connector {
  position: absolute;
  left: 50%;                                        /* 水平锚点：容器中心 */
  top: 50%;                                         /* 垂直锚点：容器中心 */
  transform: translateX(-50%) translateY(-50%);     /* 以 SVG 总尺寸（含空白）为基准，整体居中 */
  display: block;
  z-index: 10;                                      /* 必须是容器内最高层级 */
  pointer-events: none;
}

/* 选右：在居中基础上叠加水平镜像，left 值不变 */
.module-connector--right {
  transform: translateX(-50%) translateY(-50%) scaleX(-1);
}
```

---

#### 17.2.6 单行分段型选项卡（`type=segmented` `contentType=single-line`）

引用：[17.1.4 单行分段型选项](#1714-单行分段型选项typesegmented-contentTypesingl-line)

| 属性 | 正常模式 | 深色模式（dark） |
|------|---------|---------------|
| 页面行容器高度 | `88px` | `88px` |
| 页面行容器上下内边距 | `12px` | `12px` |
| 页面行容器左右内边距 | `10px` | `10px` |
| 分段容器高度 | `64px` | `64px` |
| 分段容器圆角 | `40px`（胶囊） | `40px`（胶囊） |
| 分段容器内边距 | `4px` | `4px` |
| 分段容器背景（正常） | `bg-fill-tertiary`（`#F5F5F5`） | — |
| 分段容器背景（深色） | — | `bg-overlay-dark`（`rgba(0,0,0,0.4)`） |
| 容器宽度 | `width: fit-content`，由内部选项内容自动撑开，**不得硬编码** | 同左 |

> **⚠️ 宽度自适应规则（必读）**：
> - **选项（`.segment-item`）**：使用 `flex-shrink: 0`，宽度 = 文字实际宽 + 左右各 `32px` padding，完全由内容撑开，**禁止使用 `flex: 1` 或固定 `width`**。
> - **容器（`.segment-container`）**：使用 `width: fit-content`，宽度随内部所有选项内容之和自动撑开，**禁止按项数硬编码宽度（如 304/452/600px）**。
> - 参考值：字号 `28px`，每个汉字宽 `28px`；2字 = `56px`，3字 = `84px`，加左右各 `32px` padding，2字选项宽 `120px`，3字选项宽 `148px`。
> - **文案字数**：每项建议 **2–3 字**，不得超过 **4 字**；超出会导致选项过宽、整体比例失调。

```css
/* 单行分段型选项卡 - 外层行容器 */
.tabbar--segmented-row {
  width: 750px;
  height: 88px;
  display: flex;
  flex-direction: column;
  justify-content: center;
  align-items: center;
  padding: 12px 10px; /* cs-6 上下 */
  background: white; /* white：#FFFFFF */
}
/* 分段容器 */
.segment-container {
  height: 64px;
  border-radius: radius-full; /* 胶囊，40px */
  padding: cs-2; /* 4px */
  display: flex;
  flex-direction: row;
  align-items: center;
  background: bg-fill-tertiary; /* bg-fill-tertiary：#F5F5F5；深色模式：bg-overlay-dark */
  width: fit-content; /* ⚠️ 容器宽度由内容撑开，禁止按项数硬编码 */
  box-sizing: border-box;
}
/* 单行分段型选项 */
.segment-item {
  flex-shrink: 0;        /* ⚠️ 禁止使用 flex:1，宽度由 padding + 文字内容撑开 */
  height: 56px;
  border-radius: radius-full; /* 胶囊，40px */
  padding: 8px 32px;     /* 上下 8px，左右 32px = 16pt */
  display: flex;
  align-items: center;
  justify-content: center;
  background: transparent;
  box-sizing: border-box;
}
.segment-item[data-state="active"] {
  background: white; /* white：#FFFFFF */
}
```

---

#### 17.2.7 双行分段型选项卡（`type=segmented` `contentType=double-line`）

引用：[17.1.5 双行分段型选项](#1715-双行分段型选项typesegmented-contentTypedouble-line)

| 属性 | 值 |
|------|-----|
| 页面行容器高度 | `84px` |
| 页面行容器左右内边距 | `24px` |
| 分段容器高度 | `84px` |
| 分段容器宽度 | `702px`（`align-self: stretch`，减去两侧 24px） |
| 分段容器圆角 | `84px`（胶囊） |
| 分段容器内边距 | `4px` |
| 分段容器背景 | `bg-fill-tertiary`（`#F5F5F5`） |
| Tab 项布局 | `flex-grow: 1`（均分，2/3/4 项均撑满 702px） |

```css
/* 双行分段型选项卡 - 外层行容器 */
.tabbar--segmented-double-row {
  width: 750px;
  height: 84px;
  display: flex;
  flex-direction: column;
  justify-content: center;
  align-items: center;
  padding: 0 cs-12; /* cs-12 左右：24px */
  background: white; /* white：#FFFFFF */
}
/* 分段容器 */
.segment-container-double {
  align-self: stretch;
  height: 84px;
  border-radius: radius-full; /* 胶囊，84px */
  padding: cs-2; /* 4px */
  display: flex;
  flex-direction: row;
  align-items: center;
  background: bg-fill-tertiary; /* bg-fill-tertiary：#F5F5F5 */
}
.segment-container-double .segment-item {
  flex-grow: 1;
}
```
