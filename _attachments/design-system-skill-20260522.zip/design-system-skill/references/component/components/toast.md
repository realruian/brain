# Toast 轻提示

> **组件分类**：Component（组件级）
> **定义**：轻提示是对即时性操作或状态变化的轻量型反馈，承载信息少，流程性阻断相对较弱，用于提示优先级较弱及不需要决策的信息。
> **Style 依赖**：`color-semantic.md` · `font-semantic.md` · `spacing-semantic.md` · `component-spacing.md` · `radius-semantic.md`

> ⚠️ **核心约束**：
> - 轻提示（出现 + 停滞 + 消失）总时长**不超过 4s**（尼尔森诺曼用户等待心理模型）
> - 仅用于即时反馈，**不适合**承载过多文字或需要用户决策的重要信息；信息复杂时改用 `dialog.md`
> - 层级始终置于**页面顶层**，出现后倒计时自动消失，无需用户操作

---

## 0. 图标 / 间距 / Ownership 约束

- **icon-route（默认）**：组件自带图标按正文规则走 icon route，默认回 `component/atoms/icon.md` 并遵循既定 class / weight。
- **fixed-asset 例外**：正文若指定官方 SVG、`assets/*.svg`、PNG/CDN 或 URL 切图，该位点必须走 fixed-asset。
- **spacing-owner（归属）**：Toast 内部文本与自带图标间距归本组件；页面外层浮层位置、容器留白与避让关系归宿主。
- **宿主裁决（优先级）**：冲突按 `宿主 > 组合场景 > 本组件`，宿主裁决挂载点和外部占位。
- **不可跳步**：先回 `references/INDEX.md` 完成区域路由与宿主锁定，再用 `component-quickref.md` 做宿主级收敛；本文件仅承接组件内 ownership 细则，不承担前置路由改判；不得凭语义猜测。


## 1. 组件大类（toastType）

| toastType | 名称 | 适用场景 |
|-----------|------|---------|
| `text` | 文字型 | 常规信息内容提示和反馈，文字在气泡内居中对齐；用于无需图标强化的轻量通知 |
| `icon-text` | 图标文字型 | 与状态图标结合反馈操作结果（成功/失败/警示/加载中等），遮挡面积偏大、识别性强 |
| `custom` | 自定义型 | 承载复杂图文结合的特殊样式，不适用于标准场景 |

> **选型原则**：
> - 常规操作反馈（复制成功、提交成功）→ `text`
> - 有明确状态结果（支付成功、网络失败、警告）→ `icon-text`（上下组合）
> - 高频业务、PC 端兼容或特殊布局需求 → `icon-text`（左右组合，不建议常规使用）
> - 营销/活动/特殊游戏化 → `custom`

---

## 2. 文字型（toastType=text）

### 2.1 行数变体（rowCount）

| rowCount | 名称 | 字符范围 | 气泡宽度 | 气泡高度 |
|----------|------|---------|---------|---------|
| `single` | 单行 | 1–14 个字符 | **最小 92pt，最大 228pt**（自适应） | **44pt** |
| `double` | 双行（无标题） | 15–28 个字符 | 自适应（内边距 16pt） | **64pt** |
| `double-with-title` | 双行 + 主标题 | — | 自适应（内边距 16pt） | **70pt** |

> **字符约束**：
> - 单行：字符数 ≤ 14；当字符数 < 4 时，气泡宽度保持最小宽度 **92pt**
> - 双行（无标题）：字符总数最多 **28 个字符**；当第一行达到 14 个字符且第二行 ≤ 4 个字符时，推荐**手动断句换行**确保阅读舒适性
> - 双行（有标题）：**标题控制在 1 行**；副标题最多 2 行

### 2.2 布局规格（固定，不可修改）

| 属性 | 值（pt） | @2x 设计稿值（px） | Token / 说明 |
|------|---------|-----------------|------------|
| 圆角 | **12pt** | 24px | `radius-m` |
| 背景色 | `rgba(0,0,0,0.8)` | — | `mask-heavy`（`color-semantic.md` §六） |
| 内边距（上下） | **12pt** | 24px | `cs-12`（`component-spacing.md`） |
| 内边距（左右） | **16pt** | 32px | `cs-16`（`component-spacing.md`） |
| 气泡内容区排列 | 列方向（`flex-direction: column`）、主轴居中、交叉轴居中 | — | — |
| 正文字号 | **14pt** | 28px | `body-l-14-regular` |
| 正文字重 | **400（常规体）** | — | — |
| 正文字色 | `#FFFFFF` | — | `text-on-dark` |
| 正文行高 | **20pt** | 40px | — |
| 正文字体 | 'PingFang SC', 'Noto Sans SC', 'Source Han Sans SC', 'Microsoft YaHei', 'WenQuanYi Micro Hei', sans-serif | — | — |
| 正文对齐 | 居中（`text-align: center`） | — | — |
| 主标题字号 | **16pt** | 32px | `subtitle-m-16-medium` |
| 主标题字重 | **500（中黑体）** | — | — |
| 主标题字色 | `#FFFFFF` | — | `text-on-dark` |
| 主标题行高 | **22pt** | 44px | — |
| 主标题字体 | 'PingFang SC', 'Noto Sans SC', 'Source Han Sans SC', 'Microsoft YaHei', 'WenQuanYi Micro Hei', sans-serif | — | — |
| 主标题对齐 | 居中（`text-align: center`） | — | — |
| 标题与正文间距 | **4pt** | 8px（父容器 `gap`） | `cs-4`（`component-spacing.md`）；⚠️ **只用父容器 `gap:8px`（@2x）实现，❌ 禁止再给正文子元素加 `margin-top`，否则间距翻倍** |
| 文字整体对齐 | 居中 | — | — |
| 位置 | 页面**垂直居中** | — | 默认位置；特殊场景可调整（见第 6 节） |

> 💡 **字重原则**：**仅主标题**（`double-with-title` 中的标题行）使用 **500 中黑体**；正文（所有描述性长文案）一律使用 **400 常规体**。❌ 禁止将正文字重设为 500。

### 2.3 内容变体矩阵

| rowCount | 有主标题 | 有正文 | 气泡高度（pt） | 气泡高度（@2x px） | 字符上限 |
|----------|---------|--------|-------------|-----------------|---------|
| `single` | ❌ | ✅ 单行 | 44pt | 88px | 14 字符 |
| `double` | ❌ | ✅ 双行 | 64pt | 128px | 28 字符（两行合计） |
| `double-with-title` | ✅（1 行） | ✅（最多 2 行） | 70pt | 140px | 标题 1 行，正文 2 行 |

### 2.4 实测变体尺寸（源自组件集设计稿，@2x）

以下数据直接从组件集 CSS 提取，供 AI 生码与走查核对使用：

| 变体 | 气泡尺寸（@2x） | 气泡尺寸（pt） | 内容区宽（@2x） | 说明 |
|------|--------------|-------------|--------------|------|
| `single`（单行） | 232×88px | **116×44pt** | 168px（84pt） | 仅含一行正文，无 frame 嵌套层 |
| `double`（双行无标题） | 456×128px | **228×64pt** | 392px（196pt） | 正文两行，`flex-direction: column`，`gap` 为 0 |
| `double-with-title`（双行+标题，窄版） | 361×140px | **180.5×70pt** | 297px（148.5pt） | 标题 + 单行正文 |
| `double-with-title`（双行+标题，宽版） | 456×180px | **228×90pt** | 392px（196pt） | 标题 + 双行正文 |

> **@2x → pt 换算规则**：所有 @2x 设计稿尺寸均除以 2 得到 pt 值。
>
> ⚠️ **注意**：双行+标题存在**宽度自适应**特性——正文字数少时气泡较窄（180.5pt），正文字数多时气泡较宽（228pt），宽度由正文内容区决定，不得硬编码为固定宽度。

### 2.5 DOM 结构规范（文字型）

```
toast（气泡容器，flex-column，padding 12pt/16pt）
└── frame（内容区，flex-column，gap 4pt，align-items: center）
    ├── title（主标题，仅 double-with-title 变体）
    └── body-text（正文，可为 1 行或 2 行）
```

> - `single` 变体：内容区**不需要** frame 嵌套层，正文文字直接挂载在气泡容器内
> - `double` 变体：正文两行共享同一 frame，frame 内用 `flex-direction: column` 且**无 gap**（两行文字通过自然换行呈现）
> - `double-with-title` 变体：frame 内上为标题、下为正文内容区（正文内容区可再嵌套一层处理双行换行），frame `gap: 4pt`（@2x: 8px）控制标题与正文间距

---

## 3. 图标文字型（toastType=icon-text）

### 3.1 图标布局方式（iconLayout）

| iconLayout | 名称 | 说明 | 推荐使用场景 |
|------------|------|------|------------|
| `vertical` | 上下组合 | 图标在上方居中，文字在下方；识别感强，关注度高 | **主推**：常规操作结果反馈 |
| `horizontal` | 左右组合 | 图标在左、文字在右横向排列；类 PC 端样式，关注度偏弱 | 仅适用于业务特殊要求，不建议常规使用 |

> **注意**：左右组合在关注识别方面弱于上下组合，**常规需求中不建议使用**，仅作为业务特殊形式补充。

### 3.2 图标状态（iconState）

| iconState | 中文名 | 图标 | 说明 |
|-----------|--------|------|------|
| `success` | 成功 | `icon-iconfont-select-line-regular`（单选圆勾） | 操作成功、支付完成、订阅成功 |
| `failure` | 失败 | `icon-iconfont-cancelcircle-line-regular`（取消圈） | 操作失败、请求出错 |
| `warning` | 警示 | `icon-iconfont-warning-line-regular`（警示） | 异常提示、风险告知 |
| `loading` | 加载中 | **菊花图**（`loading_white_1_iSpt.webp` Base64 内联）；spinner 容器 **36×36pt**（vertical）/ **18×18pt**（horizontal）；⚠️ webp 为 **@2x 资源**，HTML 实现时容器用 **36px / 18px**，❌ 禁止写成 72px / 144px；菊花图片本身渲染尺寸为 **30×30pt**（vertical）/ **约 15pt**（horizontal），小于容器，居中显示；❌ 无对应 iconfont，❌ 禁止用 CSS 伪元素或 border-spin | 操作进行中，需等待 |
| `custom` | 自定义图标 | 业务自定义图标 | 特殊场景（非以上四种） |

> **图标字重**：Toast 背景为深色，图标一律用**常规体（`line-regular`）**，❌ 禁止使用 `fill` 填充体。
>
> **图标尺寸**：上下组合（`vertical`）统一 **36×36pt**；左右组合（`horizontal`）统一 **18×18pt**。
> **loading 尺寸特殊**：spinner 容器与其他图标等尺寸（vertical 36pt / horizontal 18pt），但 webp 图片本身渲染为 **30pt**（vertical）/ **约 15pt**（horizontal），小于容器，居中显示。❌ 容器尺寸 ≠ 图片渲染尺寸，`<img>` 需显式设置 `width:30px; height:30px`（vertical）/ `width:15px; height:15px`（horizontal），**不可让图片填满容器**。

### 3.3 上下组合（iconLayout=vertical）布局规格

#### 行数变体（rowCount）

| rowCount | 有标题 | 气泡尺寸 | 说明 |
|----------|--------|---------|------|
| `single` | ❌ | **96×96pt**（气泡正方形） | 图标 + 单行文字，字符 ≤ 5 |
| `double` | ❌ | **236×114pt** | 图标 + 双行正文，字符最多 28 |
| `double-with-title` | ✅ | **236×144pt** | 图标 + 主标题 + 双行正文 |

#### 固定布局规格（不可修改）

| 属性 | 单行（96×96pt） | 双行（236×114pt） | 双行+标题（236×144pt） |
|------|----------------|----------------|---------------------|
| 圆角 | **12pt** | **12pt** | **12pt** |
| 背景 | `mask-heavy`（#000000CC） | `mask-heavy` | `mask-heavy` |
| 图标尺寸 | **36×36pt**（所有 iconState 容器统一）；loading 的 webp 图片渲染 **30×30pt**，居中 | **36×36pt** | **36×36pt** |
| 图标颜色 | `#FFFFFF` | `#FFFFFF` | `#FFFFFF` |
| 气泡内边距（上） | **18pt** | **18pt** | **18pt** |
| 气泡内边距（下） | **16pt** | **16pt** | **16pt** |
| 气泡内边距（左右） | `cs-20`（20pt） | `cs-20`（20pt） | `cs-20`（20pt） |
| 图标对齐 | 居中（气泡宽居中对齐） | 居中（内容区居中对齐） | 居中（内容区居中对齐） |
| 正文最大宽度 | — | **196pt**（超出换行） | **196pt**（超出换行） |
| 图标与文字间距 | `cs-6`（6pt） | `cs-6`（6pt） | `cs-6`（6pt，图标→标题） |
| 正文字体 | `body-l-14-regular` | `body-l-14-regular` | `body-l-14-regular` |
| 正文字号 | **14pt** | **14pt** | **14pt** |
| 正文字色 | `#FFFFFF` | `#FFFFFF` | `#FFFFFF` |
| 正文行高 | **20pt** | **20pt** | **20pt** |
| 主标题字体 | — | — | `subtitle-m-16-medium` |
| 主标题字号 | — | — | **16pt** |
| 主标题字重 | — | — | **500（中黑体）** |
| 主标题字色 | — | — | `#FFFFFF` |
| 主标题行高 | — | — | **22pt** |
| 标题与正文间距 | — | — | `cs-4`（4pt）；⚠️ **只用父容器 `gap:8px`（@2x）实现，❌ 禁止给正文子元素加 `margin-top`** |
| 文字对齐 | 居中 | 居中 | 居中 |

> 💡 **字重原则**：**仅主标题**（`double-with-title` 中的标题行）使用 **500 中黑体**；图标下方的正文（单行或双行描述文案）一律使用 **400 常规体**。❌ 禁止将正文字重设为 500。
>
> 文字建议不超过 **5 个字符**（单行上下组合）；双行组合单行最多 **14 个字符**。
>
> ⚠️ **内边距上下不对称**：气泡上内边距为 18pt，下内边距为 16pt（@2x 设计稿对应 36px 上、32px 下），与文字型的上下均等内边距不同，实现时需拆分 `padding-top` / `padding-bottom`，不可使用统一值。

#### 实测变体尺寸（源自组件集设计稿，@2x）

| 变体 | 气泡尺寸（@2x） | 气泡尺寸（pt） | 图标容器（@2x） | 图标尺寸（pt） | 说明 |
|------|--------------|-------------|--------------|-------------|------|
| `single`（单行，success/failure/warning/custom） | 192×192px | **96×96pt** | 72×72px | **36×36pt** | 图标直接用 `.instance`，气泡正方形 |
| `single`（单行，loading） | 192×192px | **96×96pt** | 72×72px（spinner 容器） | spinner 容器 **36×36pt**，webp 图片渲染 **30×30pt** 居中 | loading 用 `<span class="spinner lg">` 包裹 webp 图片实现 |
| `double`（双行无标题） | 472×228px | **236×114pt** | 72×72px | **36×36pt** | 图标 + 双行正文，无标题；正文区 frame 内两行无 gap，`justify-content: start` |
| `double-with-title`（双行+标题） | 472×280px | **236×140pt** | 72×72px | **36×36pt** | 图标 + 标题 + 双行正文，气泡宽度固定 |

> **@2x → pt 换算规则**：所有 @2x 设计稿尺寸均除以 2 得到 pt 值。
>
> ⚠️ **loading 图标特殊说明**：loading 变体使用 **`loading_white_1_iSpt.webp`（Base64 内联）** 实现菊花动画，❌ 不使用 iconfont，❌ 不使用 CSS 伪元素或 border-spin。HTML 结构为 `<span class="spinner lg" role="progressbar" aria-label="加载中"><img src="[BASE64_WEBP]" alt="" aria-hidden="true"></span>`。⚠️ webp 为 **@2x 资源**，spinner 容器写 **36px**（❌ 禁止写 72px），图片渲染尺寸 **30×30pt**，小于容器 36pt，在容器内居中显示。

#### DOM 结构规范（vertical 图标文字型）

```
toast（气泡容器，flex-column，justify-center，align-center，padding 18pt上/16pt下/20pt左右）
├── icon（图标区，36×36pt）
│   ├── [success/failure/warning/custom] iconfont span，aria-hidden="true"
│   └── [loading] span.spinner.lg（36pt容器，role="progressbar" aria-label="加载中"）> img[BASE64_WEBP]（30pt webp 菊花，居中）
└── frame（文字内容区，flex-column，gap 4pt，align-center）
    ├── title（主标题，仅 double-with-title 变体，16pt/500/22pt行高）
    └── body-area（正文区）
        ├── [single/double] text（14pt/400，直接挂在 frame 内或 body-area 内）
        └── [double-with-title] frame-inner（flex-column，无 gap）
            ├── text-line-1（14pt/400，第一行正文）
            └── text-line-2（14pt/400，第二行正文，宽度可能更窄）
```

> - `single` 变体：文字内容**不需要** frame 嵌套，直接作为 text 节点挂在图标下方的气泡容器内
> - `double` 变体：正文区 frame 为 `flex-column`、`justify-content: start`、**无 gap**，两行 text 自然叠放；第一行正文宽度与 frame 等宽（392px@2x / 196pt），第二行正文宽度更窄（308px@2x / 154pt），不可等宽处理
> - `double-with-title` 变体：文字区 frame（gap 4pt）内上为 title、下为正文子 frame；正文子 frame 同 `double` 变体，`justify-content: start` 且**无 gap**
> - `loading` 单行变体：图标区与文字区 `gap` 为 `6pt`（@2x: 12px）；其余变体图标与 frame 的 `gap` 为 `4pt`（@2x: 8px）

### 3.4 左右组合（iconLayout=horizontal）布局规格

| 属性 | 规格值（pt） | @2x 设计稿值（px） | 说明 |
|------|------------|-----------------|------|
| 气泡高度 | **44pt**（固定） | 88px | 固定，不随内容变化 |
| 气泡宽度 | 根据文字内容自适应 | — | — |
| 气泡最小宽度 | **92pt** | 184px | `min-width`，防止气泡过窄 |
| 气泡最大宽度 | **228pt** | 456px | `max-width`，超出截断 |
| 圆角 | **12pt** | 24px | `radius-m` |
| 背景 | `mask-heavy`（#000000CC） | — | — |
| 布局方向 | 行方向（`flex-direction: row`） | — | 图标左、文字右，水平居中对齐 |
| 图标尺寸 | **18×18pt** | 36×36px | 使用 `.instance` 实例 |
| 图标颜色 | `#FFFFFF` | — | — |
| 图标与文字间距 | **4pt** | 8px（`column-gap`） | `cs-4` |
| 文字字号 | **14pt** | 28px | `body-l-14-regular` |
| 文字字重 | **400（常规体）** | — | — |
| 文字字色 | `#FFFFFF` | — | `text-on-dark` |
| 文字行高 | **20pt** | 40px | — |
| 文字字体 | `'PingFang SC','Noto Sans SC','Source Han Sans SC','Microsoft YaHei','WenQuanYi Micro Hei',sans-serif` | — | — |
| 文字最大宽度 | **168pt** | 336px（`max-width`） | 超出宽度截断，不换行（`white-space: nowrap`） |
| 内边距（上下） | **12pt** | 24px | `cs-12` |
| 内边距（左右） | **16pt** | 32px | `cs-16` |
| 文字字符上限 | **12 个字符** | — | 超出建议截断或改用 vertical |

> ⚠️ **此变体仅适用于业务特殊要求，不作为常规首选。**
>
> ⚠️ **loading 图标特殊说明**：horizontal 的 loading 变体同样使用 **`loading_white_1_iSpt.webp`（Base64 内联）**，HTML 结构与 vertical 一致（`<span class="spinner">` 包裹 `<img>`）。spinner 容器 **18pt**（❌ 禁止写 36px），webp 图片渲染约 **15pt**，居中显示。❌ 禁止使用 `border-spin` CSS 伪元素替代；❌ 禁止使用任何 iconfont 类名。

#### 实测变体尺寸（源自组件集设计稿，@2x）

| 变体 | 气泡尺寸（@2x） | 气泡尺寸（pt） | 图标容器（@2x） | 图标尺寸（pt） | 说明 |
|------|--------------|-------------|--------------|-------------|------|
| `single`（短文字，success/failure/warning/custom） | 220×88px | **110×44pt** | 36×36px | **18×18pt** | 文字宽 112px（56pt），图标为 `.instance` |
| `single`（长文字，success/failure/warning/custom） | 248×88px | **124×44pt** | 36×36px | **18×18pt** | 文字宽 140px（70pt），气泡宽度随文字自适应 |
| `single`（loading） | 192×88px | **96×44pt** | 36×36px（spinner 容器） | spinner **18×18pt**，webp 图片渲染约 **15pt** 居中 | loading 用 `<span class="spinner">` 包裹 webp 实现，文字宽 84px（42pt） |

> **@2x → pt 换算规则**：所有 @2x 设计稿尺寸均除以 2 得到 pt 值。

#### DOM 结构规范（horizontal 图标文字型）

```
toast（气泡容器，flex-row，justify-center，align-center，column-gap 4pt，padding 12pt上下/16pt左右）
├── icon（图标区，18×18pt）
│   ├── [success/failure/warning/custom] iconfont span，aria-hidden="true"
│   └── [loading] span.spinner（18pt容器，role="progressbar" aria-label="加载中"）> img[BASE64_WEBP]（约15pt webp 菊花，居中）
└── text（文字，14pt/400/20pt行高，max-width 168pt，white-space: nowrap）
```

> - horizontal 变体结构扁平，图标与文字**直接并排**，无额外 frame 嵌套层
> - 气泡宽度由 `min-width`（92pt）和 `max-width`（228pt）约束，不可硬编码固定宽度
> - loading 使用同一份 webp（`loading_white_1_iSpt.webp`），horizontal 容器 18pt，图片渲染约 15pt；vertical 容器 36pt，图片渲染 30pt

### 3.5 图标文字型变体矩阵

| iconLayout | rowCount | iconState | 气泡尺寸 | 图标尺寸 | 推荐 |
|------------|----------|-----------|---------|---------|------|
| `vertical` | `single` | success/failure/warning/custom | 96×96pt | 36×36pt | ✅ |
| `vertical` | `single` | loading | 96×96pt | webp 菊花图（容器 36pt，图片 30pt 居中） | ✅ |
| `vertical` | `double` | success/failure/warning/custom | 236×114pt | 36×36pt | ✅ |
| `vertical` | `double-with-title` | success/failure/warning/custom | 236×140pt | 36×36pt | ✅ |
| `horizontal` | `single` | success/failure/warning/custom | 高 44pt，宽 110–124pt（自适应） | 18×18pt | ⚠️ |
| `horizontal` | `single` | loading | 高 44pt，宽 96pt | webp 菊花图（容器 18pt，图片约 15pt 居中） | ⚠️ |

---

## 4. 自定义型（toastType=custom）

### 4.1 说明

自定义型轻提示承载**复杂图文结合**的内容，由业务方自定义插槽内容（如营销活动、游戏化奖励、视频试看等）。

### 4.2 布局规格（固定，不可修改）

| 属性 | 值 |
|------|-----|
| 外容器背景 | `mask-heavy`（#000000CC） |
| 外容器圆角 | **12pt**（`radius-m`） |
| 插槽（slot）圆角 | **6pt**（`radius-xs`） |
| 插槽内边距 | **20pt**（四边） |
| 气泡形状约束 | **宽度须大于高度**（横向扁平，不可做成竖向长条） |

### 4.3 设计约束

| 约束 | 说明 |
|------|------|
| 颜色 | 使用 `color-semantic.md` 原子层语义 Token，不得直接使用 hex |
| 文字 | 使用 `font-semantic.md` 字体 Token |
| 栅格 | 内部布局建议遵循页面栅格规范（12pt 或 8pt 倍数对齐） |
| 宽高比 | 宽度 > 高度（保持横向布局） |

---

## 5. 通用固定规格（所有类型）

### 5.1 背景色规范

| 背景场景 | 背景色 | Token | 说明 |
|---------|-------|-------|------|
| 浅色背景页面（默认） | `#000000CC`（80% 黑） | `mask-heavy` | 标准深色气泡 |
| 深色背景页面 | `#FFFFFF26`（15% 白） | — | 为避免与深色背景混淆，改用浅色半透明 |
| 特殊营销/活动场景 | 业务自定义 | 按需 | 文字色可根据实际场景调整（如 `#FFE2BC`、`#FFF6B8`） |

> 💡 深色背景适配规则：当页面背景为深色时，轻提示背景色改用 **15% 白（#FFFFFF26）**，以确保可见性。

### 5.2 自动消失时间规则（触发后倒计时）

| 条件 | 停滞时长 | 触发规则 |
|------|---------|---------|
| 信息字符数 ≤ 14 | **2s** | — |
| 信息字符数 ≤ 22 | **3s** | — |
| 信息字符数 > 22 | **3.5s** | — |
| 所有类型总时长（出现+停滞+消失） | **≤ 4s** | 超过 4s 用户易产生焦虑，严禁超出 |

### 5.3 位置规则

| 场景 | 位置 |
|------|------|
| 默认（常规页面） | 页面**垂直居中** |
| 特殊沉浸式场景（小说、短视频等）遮挡核心内容 | 可调整为屏幕**靠上或靠下 30%** 左右位置 |

---

## 6. 交互说明

| 阶段 | 说明 |
|------|------|
| 触发 | 用户主动操作后，触发对应状态的轻提示（手动触发） |
| 出现 | 层级始终置于页面顶层 |
| 停滞 | 根据文字字符数自动计算停滞时长（见 5.2 节） |
| 消失 | 倒计时结束后自动消失，无需用户操作 |

> 加载中（`loading`）状态的动效请参考「刷新和加载」规范文档。

---

## 7. Token 引用

### 7.1 颜色 Token

| 用途 | Token 名称 | 值 | 语义层来源 |
|------|-----------|-----|-----------|
| 气泡背景（默认） | `mask-heavy` | #000000 80%（#000000CC） | `color-semantic.md` §六 Mask Color |
| 深色页面气泡背景 | — | #FFFFFF 15%（#FFFFFF26） | — |
| 文字色 | `text-on-dark` | #FFFFFF | `color-semantic.md` §二 Text Color |
| 图标色 | `text-on-dark` | #FFFFFF | — |

### 7.2 字体 Token

| 用途 | Token 名称 | 字号 | 字重 | 行高 |
|------|-----------|------|------|------|
| 正文（单行/双行） | `body-l-14-regular` | 14pt | 400（常规体） | 20pt |
| 主标题（有标题变体） | `subtitle-m-16-medium` | 16pt | 500（中黑体） | 22pt |

### 7.3 圆角 Token

| 用途 | Token 名称 | 值 |
|------|-----------|-----|
| 气泡外圆角（所有类型） | `radius-m` | 12pt |
| 自定义型插槽圆角 | `radius-xs` | 6pt |

### 7.4 间距 Token

| 用途 | Token 名称 | 值 | 适用范围 |
|------|-----------|-----|--------|
| 气泡内边距（上下） | `cs-12` | 12pt | text 型、horizontal 型 |
| 气泡内边距（左右） | `cs-16` | 16pt | text 型、horizontal 型 |
| 气泡内边距（上） | `cs-18` | 18pt | vertical 图标文字型（上下不对称，需拆分） |
| 气泡内边距（下） | `cs-16` | 16pt | vertical 图标文字型（上下不对称，需拆分） |
| 气泡内边距（左右） | `cs-20` | 20pt | vertical 图标文字型 |
| 图标与文字间距 | `cs-4` | 4pt | vertical 图标文字型（@2x: 8px；loading single 变体为 cs-6 / 12px） |
| 图标与文字间距 | `cs-4` | 4pt | horizontal 图标文字型 |
| 标题与正文间距 | `cs-4` | 4pt | 所有含标题变体 |

---

## 8. Props API（供 AI 生码参考）

```typescript
export type ToastProps = {
  /**
   * 轻提示大类
   * @default "text"
   */
  toastType?: "text" | "icon-text" | "custom";

  /**
   * 文字型行数（toastType=text 时有效）
   * @default "single"
   */
  rowCount?: "single" | "double" | "double-with-title";

  /**
   * 正文内容
   */
  message: string;

  /**
   * 主标题（rowCount=double-with-title 时必填）
   */
  title?: string;

  /**
   * 图标布局方式（toastType=icon-text 时有效）
   * @default "vertical"
   */
  iconLayout?: "vertical" | "horizontal";

  /**
   * 图标状态（toastType=icon-text 时有效）
   */
  iconState?: "success" | "failure" | "warning" | "loading" | "custom";

  /**
   * 自定义图标内容（iconState=custom 时）
   */
  customIcon?: React.ReactNode;

  /**
   * 自定义内容插槽（toastType=custom 时）
   */
  children?: React.ReactNode;

  /**
   * 自动消失时长（ms）
   * 不传时根据 message 字符数自动计算（≤14字符:2000ms / ≤22字符:3000ms / >22字符:3500ms）
   */
  duration?: number;

  /**
   * 消失回调
   */
  onClose?: () => void;

  /**
   * 位置配置
   * @default "center"
   */
  position?: "center" | "top-30" | "bottom-30";
};
```

---

## 9. data-attribute 规范

| 属性 | 值 | 说明 |
|------|----|------|
| `data-slot` | `"toast"` | 组件根容器 |
| `data-slot` | `"toast-icon"` | 图标区域（icon-text 类型） |
| `data-slot` | `"toast-title"` | 主标题文字 |
| `data-slot` | `"toast-message"` | 正文文字 |
| `data-slot` | `"toast-custom"` | 自定义插槽（custom 类型） |
| `data-toast-type` | `"text"` / `"icon-text"` / `"custom"` | 轻提示大类 |
| `data-icon-layout` | `"vertical"` / `"horizontal"` | 图标布局（icon-text 有效） |
| `data-icon-state` | `"success"` / `"failure"` / `"warning"` / `"loading"` / `"custom"` | 图标状态 |
| `data-row-count` | `"single"` / `"double"` / `"double-with-title"` | 行数变体 |

---

## 10. 无障碍（Accessibility）

- 使用 `role="status"` 或 `role="alert"`（成功/失败/警告状态）声明语义
- `aria-live="polite"`（常规提示）/ `aria-live="assertive"`（失败/警告）
- 图标设置 `aria-hidden="true"`，文字承担语义
- 加载中图标添加 `aria-label="加载中"` 并向屏幕阅读器声明

```tsx
// 成功状态
<div role="status" aria-live="polite" data-slot="toast">
  <span class="font icon-iconfont-select-line-regular" aria-hidden="true" />
  <span data-slot="toast-message">操作成功</span>
</div>

// 失败状态
<div role="alert" aria-live="assertive" data-slot="toast">
  <span class="font icon-iconfont-cancelcircle-line-regular" aria-hidden="true" />
  <span data-slot="toast-message">网络错误，请重试</span>
</div>
```

### 10.2 图标文字型（vertical）HTML 模板

```html
<!-- ── 成功（vertical single）──
     气泡 96×96pt，图标 36×36pt，内边距 17pt/20pt，图标↔文字 cs-6 -->
<div class="toast toast-v-single"
     role="status" aria-live="polite"
     data-slot="toast" data-variant="icon-text"
     data-icon-layout="vertical" data-size="single" data-icon-state="success">
  <span class="ico lg font icon-iconfont-select-line-regular" aria-hidden="true"></span>
  <span class="t-body">操作成功</span>
</div>

<!-- ── 失败（vertical single）── -->
<div class="toast toast-v-single"
     role="alert" aria-live="assertive"
     data-slot="toast" data-variant="icon-text"
     data-icon-layout="vertical" data-size="single" data-icon-state="failure">
  <span class="ico lg font icon-iconfont-cancelcircle-line-regular" aria-hidden="true"></span>
  <span class="t-body">操作失败</span>
</div>

<!-- ── 警示（vertical single）── -->
<div class="toast toast-v-single"
     role="alert" aria-live="assertive"
     data-slot="toast" data-variant="icon-text"
     data-icon-layout="vertical" data-size="single" data-icon-state="warning">
  <span class="ico lg font icon-iconfont-warning-line-regular" aria-hidden="true"></span>
  <span class="t-body">请注意</span>
</div>

<!-- ── 加载中（vertical single）──
     spinner 容器 36×36pt，内嵌 30×30pt 的 @2x webp 菊花图，居中显示 -->
<div class="toast toast-v-single"
     role="status" aria-live="polite"
     data-slot="toast" data-variant="icon-text"
     data-icon-layout="vertical" data-size="single" data-icon-state="loading">
  <span class="spinner lg" role="progressbar" aria-label="加载中"
        style="display:flex;align-items:center;justify-content:center;width:36px;height:36px;">
    <img src="data:image/webp;base64,UklGRnw3AABXRUJQVlA4WAoAAAASAAAAdwAAdwAAQU5JTQYAAAD/////AABBTk1G4AYAAAAAAAAAAHcAAHcAAFMAAAJBTFBITAIAAAG/oLBtGxSOGSIiIEI5jMIoHCPQA59sIEu2nbiBkAwBh9gZ6ex/qx5AT4iePyL678BtJEVKpfYYluEJ7v+bcLrfMw1I+ny3/EjDEb6nhNH4nPkMhv9W4gd7vUb6dwnHxJ0h6nPvXkopT+4IT1u4Q1/lkBcrgLSLz1JqoiDtIZdSEwbsNGmvJ6UuCtqJdImloTo89YNLSwy0k/Zb1qYQaFn/i5oiKNSCQhRqQilYzSgEqiFlILVnqIPUoFyDkJr0fuaF1Kb8OZ0eMVJbrrX/s3NHas7amFAK1dFq155R+ueoWYMmOY1aVD4yjVr0Cfy1ai36QsaGa7Xlc+eOjQ2fay0UIz4yRH8fr7GGKEsg5RWOWBjgz/vnW56VFe/5izziyRbfUJ6s1nCBwrJ/+sR4Zy1OVb2b3mhYiQsalpBhvNIKAeN7EJRe6UGEIRuwbA8Lsmq9xaNvEa4CY3yR+vYqs3MGDIxckhTGs/ZWHtk+/1UMeQ+vCcQmj9qvjy2ZsOP6eUska10fh6zA6FCaD0lksttdOXGeaxrs4yEeG5rnugb7EB928NzQVBVoaKayB8S+8aChvebaenPbcq2MWBBop40vonw7JFP1ixoarbveTkkO0WLdrRKCNFhfgx2kpQrwDtNIASBNFAHSQiEgLRTCkrldEMigfdsuCibpEgSFQGVdvKAgAvvBjcKgar9xaRQFNOp/UaMwMvttOPLOlZwC9g7jKZxPTFCQ05bep9oKDJV/RjhuHD8PlXwmu8Hw9dvBPNzN3g2YkJIn999NHFZQOCB0BAAAkCEAnQEqeAB4AD6NPplHpSOioTJ1OOCgEYlpCHAGv4M5z/xP8A7nv6n/APXPo0elHKAZE/mP5d5Qd4P4B3Lft04EzHu4x/rf5NyAdtb6Efx3wMPEvUa/vPqQ/sn+8+8L2I/jH8+/9H+W/vPyAfzH+of9P1KPUR+uHsAfpX9////NzRlBOmpKuDR11iXwq1rshOemtIOmbQFSuQU/zFD9/IKDy5CILSp2ljFyAkbLNtGsPbME5+ls0ksU7KM1Ni05ZbDXcbVhAHSixa8lAjGVLYUHZZQg5WslFcgTT0V/UyFX68Wae5FZrcMZmDOVhtieyoIZPEAV9z3TvtrutdGD5fGCHR2rq2ri3a1kBRDbhlhzdSLDGAD+s92uIBiDHTRvWvGr+7WxH4pTBp2JX4YyWWU6jTbTQBxeHwdm783VHFPZfrX/c9do3ybI3VIbHff45SGPqoElg9VUzJArX3A3T6MvDML7urMOHEiNoLAccAEF1XQafOZOh6MQGqdQyAPYHgARUMtpUSfjINdq4MYroe2kEhv9bKCY/IWT/cg3pITxYaspuF3Vcp+Gfcuqmlx1wGY8opv4sV/1uAQqSW9a+z7JZquojxOEfdNiAZ1WtJPYXuISOTKrH7WGumnGFD/ABxzhOZXVJHPOuXk9X0JyjS+URviQU97FVP9uQmCMmG/1+wX3CHLFgsMB1gvb/6COoNo/CirPdxjE7nxY82IeP+zlfncCcYdPb0m6uT5uj/qwuYb7ferCsP6dB0JN8koru1KBs8Q1PrVmtSY7sRtuxBZe42gCy6+CfkMf1OWXhKgR/I2/gWfYsLvodneAergl+huGQloOEGNf8PwZexkx2g7VMpRZEXD7p5RAWn+aTgUdAxlJTfhysymmykIMLJpI3+sDWOvfPcXvpHLJjPbt2exobHff45SGPqoElU4OAHHzDMxzIxbNCOY8ePjOg/wj8qf/UkmwKKBr3KZDrP+OUulBS1b2Av70aXhVG9PG7/G4ABDAXFqrmraPGJ+wTJQgT824t2V2PPoZI6+k9Kb0J3nqI8vNKXdcK0h30IXhqQyVWeiBVxTDe+qvTM4fboERkHlr/3CFDXO8ndVxCo3vqy2S81GEUsr2V94i/8hF9fuV5ApxTMLoBjHxiZWDOlr8zV41sQAsjlbmbVWPLrKwVQOjoNmf1KnIac7ASyf0YgNGDjwt/PEdF30P21wwcMpA1sqZzjukbQS1QY+X/f1Xwj14YuDdJAK3kDZ7ckY4BkwkvxOvGcFMjm7yEkcc/4eJrElXRXZE3Ql4l5j7gEIOYUU9gml946FzT+1ZDrsqoYCx/WneIFQMabhq7+BFEdK+0ByOdfP0GnzoxFLmqDjwFdqEtUd4Xpq+4e/Q6tQ6gXypX/xV8Y+hENU1ikIn+zMfO2uV03U3T2NeNBUtohu92/3BQ1oj6RwbLbCLFysbvew+09vai5QXDUdJxV7kuNwDGMN0FiLJ3BbonHankk+xSET/Zlx/P1NS2l6t+p+KNTdSAAAAQU5NRuIGAAAEAAAEAABmAABmAABTAAACQUxQSDECAAABv6CwbRs01HYMERHoDutUp7qmWc1q5QOWbLtNJEltg8nQif1vlQFZz/Lkn4j+O3DbNpJka/a+t+3sPoG+rEiapp7rp91eRx6pduLrklg525WtbsJLSaiapNF+FtIfKhJb8UVSCiWOTfcjk/gh835kE9j1fsoqXshzP+UtINP9rhUFc98f4OH9rhUGdN+xG7R3vSioOzYC4j1TGIvFkHuuGKg7eMUhWwjUrcAdZYoA+hQqXgTcwkUAdaoRTLfagPRuzOxRIbpXNBiygk5XVswKKpe96k0QXTtoz+cDbbndDDpXe97cRvVJGPSu+QdOyuveFiCjf8X81HL6dyJzVl3PIjsK2h0V0Hl38TqCP5iFvMMxCvwWpCj0ZxIJ0ZbApceCNcpfJtNiz1DyiNzskdOTjwuUiQsKhYl4wlj6KrwJUbug4ULc0DD1MKHQvcHI5yF+khP4VYZqrvJJ7gieFvpapgXlf5vaJ7m/knDAH5FFKjiWxiPYsOXYHIns7DCeMjDmtf6OY7JzqNXfcWQzTaPX39G83EmTqacFyNTd0TxuuMnX2V77RndHWuV1BEPdzNwRp+6UxOodZVqH1HaXREJagdQpYaj+ioYQVE8tYPXTBFgPEZB6iIDVQwTH9nkhwAbwMC8GWoYIWUHQCkhGHEOLIRlh0OJXyYgCNRa4I1UYawsN2NPRxFQEpJGL7t6iIF8sYSoZR4jo/wHW9w+rTrqSiD7HSaHaezqahOpPiNFhTiYAVlA4IJAEAAAwHwCdASpnAGcAPok6lkelI6IhODN4AKARCWkAFe1f4D+H+4zvC+nfYh8A9Jv0AydH3n+Z8QOhr/G71AO2Oy/uRf7HjA+lfN3/J/0A8jCKv1Jf3D/Vfdn7Hfxn+Qfsj8AH8v/nv48+5F6nv139gT9Qvv//+yDlb3K+my6124rKHTd6t7li1R+gvi9dp13Hes9Yec6azHu1ufala3hUWZUjOyRqJ0ORl/hgDI726BiIizgcCryBwVFIzuB0Rx49yKBUrXIAVKUq6a9Ixthw4wiFqFCuC65eazh9E0NGxrNOINkIn+ghx2q6zxG0VjLkXokMis5muzhnFxGiSzovFf9yHwAA/vtAILM5MRMxkYl4to5JnG4dbP6EjGZUKHQiS7w3zDMaYg3+OKbTQjs22HkqfQfKq25Q5svk7LNowG5HSxeqzlc7/p8jHGoY/BRlGy7Xme1kPfNnsEvuAlUM5Pi2jkmcbh1s/oSEeaGkymu93jRr8stwVgKFJTZLxRQ82PY4JIwNVfcvp85yH5ziMntd8Y0pBp2gTm6P1ukWta0FxAu6xogsCZihgOoCj6V3OdPCg4FI1m1hfU1VXe4ciVfvRqxhAVc0harHBZwWuISkqP+CobQyL1Pm5H2E5zzt0yER/8HwoXIaVLguh2qJvf8VhyYxRN+EoZvql/J4CyNuwsyrnyT0mtPgFGXGDZkVw+HpBzcdtl2nKFYN8dzp1yG5zsKwYkgsXROfutCf7oVjqOqPjbVLXyyD0roZNgIqFsFpeJDgqwRFmp6jSDBYR/OJIqhNv/Ks6erkiBlo3Fi04qSlRCPh/ESkYB7DO8SWQFCSVfyT74W/nFHQLYb98V28MkhkjFQsqWgbMpRQTIrh3/BvNSx5reQ/BJAIIw/gOz3ejpyNKzF+RhnWT5CFFNtlXc3RF0QwiP8yHDraFQK5xl2CSkygnh1VR9uux31cn1Num36GnkQ/lC3mrjmVMeuDbNDozYHXLF4ZPSSkgeZwqIEvIm7aJ8VgXrejo7XS9er/Z0Cfi/WontZ15wA2BInqvrEBl9ePVNRyr1s/O/ewPrnXyel1FZ+QJ4srIC2PZGHjYo4TLFFtB5k2rX8ZEPG3gVP90d7M1Xs2Xnvq/vP4WeKXxrXPu1itbzoxKC9Y26QEuxzXntKKQZoDOaXHFRa40F9PjBbrhYvwErgVrb3V7PRuV8oPVj32fy6O+ShT77PK1lD5gElVhj2Ja/FSS6ywJ7Bv1AX7l711R+1ONqKYtbLgb/g+VF9Dy42zFHdMsl81QBQ0Ob9C1St6frqqoIDCiWXm8AEUCu7hjJxssrtYU6jC5qaA7CN7eyy566cpb3wOQtTn4Y7zfbh8b41Mb/si9J9ypHBWAoUlNkeAhJ+xgZACtqB5e8cqoMmxWtVxyMpwA/zZX1S93SYbhHb4A4lPfCCLzrv6fRfGOnnfkFAnU24FxRrSjysEoE5XPsUT2mVqcJkoGpZWCIs1PRREtDylcdji+ZyVLgFKrbsnPDKVQw2IXGAG052ZvMCbLlA1ODalKY9lJXjKP1Bj+IQIxgAAQU5NRuIGAAAEAAAEAABmAABmAABTAAACQUxQSD0CAAABv6CwbRs01HYMERHoDutUp7qmWc1q5UOWbKtxAwks2XIUT+m4s/+tekA8UHr8iei/A7dtI0m2MHvMPbO7xT4h/LLCQymZ2ietryPr0DrxdUtsnPXO2vhMLyHcNINE+haGf6cEiol84SFHi0dlOVLID572IyvDTsslE3nB237JD7RlWeRiYB4PwemyVIoBuu/YAmmpFAR1xz4BcakUBHXP8JNKIVB3cMaHpgiYq8GKKsWA3DhYF8FA4yKAOlUFqls1gHo3iiMqTPeyBEE20HJnwmygvN7G1Izo2of0c3lShKNYNfpWWgGlKB0EaXSu+mdr0OjcBFDRv6SFa/q3BHUmWf9OpIc3G52Hi7dP8MnEDQx+IwUwPCQO/0zCURvrnU9Zmfvec3nq8yDDR/NHn3e6jCueUAqZ+f5AyefvPcYzW7F9MN4c0hON0YQ+aHLIMGxDhpkNiDYkAyKM1ZwwJVABeVjNMoP8pK9ZEfq1kC2/FjZkrRn9kmMy/t3NyJfcP5IQG2yRqIFHaTwyEPZJ7Y6wt3m8JBPmrQ14PAS9tQHHkdR0ndgGHNU7T51YP63puAFH+WPD8pNKPa3OQrE/kkiapVJPKyui1PdwmzCk/pYYgLZg6IUQ0gZkGaSOauCA1FMVSJ1EQOoiAlIPETw7aERwLOlEwIrBKiGwEkhFcwKbQRUNwArOkmUNgMrwiiR9CGz2gR1OEgUTkLLl8NaAFga/zoTwHwKqDNxaTrqTWv9vWZ623XR5zN/xZznbPw4AVlA4IIQEAACQHwCdASpnAGcAPoU6lkelI6IhODPoAKAQiWkIcAAqnz+7/wD+Ad5n9O9PekH6Acg1i/+P4TcpX6gHamZZ4Lny3/RcYHek8g/5b+kvkmd7+oz/OPUn/bf9992Xsg/FP4//7PcA/ln88/H/3RvVT+yHsCfpn9///3QslOiUw0Vi8YWRlhYzVvcsWrFlm1P/M63JsjHpUgCyxtHocEsnXfQH8iwiyDxFGP8dcx8qYps8cN75WxZwfRN206nyj3TktkflykxRr5WujHyLi9RNTOevXiWVWaNnQZp+OdObLzrgSW6KF83Th8rEyniDNwsrI8k7TwpCgF5sxV7K6uNFR2dNHUVW/AAA/r57w2A76XvI8lHsFQImN8ZSJbbOJn6ApobNvAE3waFben/8cHBrQjllorYUmXWCZbj3eeSnI7hotcJ/kpV2oAT3lLLt1ZsoPPR8WtM0GBMSgVeCb+32X6/ksJEYKbVQ+Msg1jHB7r9GosWNIsBzOwt9ZxwL7Bxh4JArrtUOt1c+hxt2ZEcMf32zhXb6ZEgQgV12qHt3Yuu1RUCO1InLOOBfYOM7oQ2HuaW0gS2WFjtwGlHCfx5t0TeGMDsSqhLrPABcpc5Bnzn20den/VQNPhZYCZzc3+m+r/rqFFpi8HAr6urVPewhj1eVlJAuIaHwEX1qQW5KWnWHAFylo8bGh2X33roctvr02B1Vqluo23S7tSHZKHUj94VIh0ZvnHHq7sUV6fvz86Jx2SUhbMICMxAQHvOpKEkZHiHWVlTXCuB7Ac9fYEO8SSR9b6UOYc4a9WoOT/rLS+L3G9vKzIHx4qPFDAnzUS+KhkbT229/sqEROfgZPAF81Zig4xPfoZsyVK7VQSdla+gvAVA8RGJ613a+y22ZFYpIwyrdldzH1dUyHWIsWKS72GzY5g2kxR9Z7aq34J9EFKCCP3QfDOOAZ6IIf/0kVg2+4dMHl0Kv7QmeIX7I+qhr58IrbVYxXQ//9MWE2Z8j7pAApPb76jHGA+R35YsaRWfu+34bZca+uWqzidFNTNGZciGOjWAICkaKbuFZVL9gxTxSd85lZecHmY0AWjenweNABMJfa8YEHCx/a9FrfkLZlfFbGEWNjlgBPhTS6Zr1E3Q9PhL9nBa8nwbHWGMT+PCuhc+oCPgcO3CZ5cKb25vSBDi/r82OAM+JSX1DaDemvnuUpIX9hrPVfB8Yc2MdAjGJc8vrrRIulW8NXYehNy8INCDKbZLfOPEaq5nvCBV999SZiVkmYQoHQoVGSN+J99Yoc4AKNH/iZdkj+jsKhRJCGZklwJ7qzhQsIWUkR4b0HCFHhMQb0GMFgbnz3g+PJSF1qUYc0e5bav+dhMpD1czH7UIGEqQ93Qzffg4g0Cv7ZFMgoQsYsewId4kof/F411KBJRECT34d4Do2SjxsDKcP9UA8vs7JgrrDmpT6xiAsMqRPjAUPyN5wp+t9rc4K9s+azG9u04KRXOhhL7pJszDwHI8j/Zax5mOQG6zfAml6FH7fhKlOhGtLW9P353cNnXsQrvroAAAAQU5NRuoGAAAEAAAEAABmAABmAABTAAACQUxQSDECAAABv6C2bRs2ZjtNcyIiBFNs2HAGHz7ykCXbbttIBJpJoRUd9r9VBRIPYKeZn4j+O3AbSZFSqWOG2b57gvu2QqHvE7VPmJYjU2gdv9ziG2e6M7UNL4Vw2+eX8F+F8A8V8p5s4ZBY41A/HunJDh72IxPDHcZLBrKC1/2SlUH6cSyLgnTfZ3B/HCuiQN13bM+PFWGw7gGmIgjWPcFHKoJg3cELZoEQWCeFG6qIAXVlpy2CQpVFAGuhFLQmSgFrrS9OVFjNpRIEtQH7OwPWBqTpNlMTUlNz6fGclDa3k6DGknR4IEGtFY/qoV47FajUXpLCtdrbO3E+y7V3IDm8qlR1XAScTgZu4Ne0JweGg2f3zyTE0ijDIcuS7ssj506eRIqHppc822Vc4Q5KJrVuLyjJOZcxuqDF+sLY2PkOjdIevdBkF2BYhwQztUJQgGG0LgnTO8ogSesiE8iDvsgNZXhZCJrLworcaoIXOVJeKZN8kfuXsqnF7ytnsj/k45FA2ILwPrJZD7shRlR+vi95cguN0cvZ3u+S9o2RxPvvd9EGGllKfpc1rQJl7RvLj4gqRyqaN5Se0MeR0tOYq1qXKi3KT4HtFLeBuo9CHGIDpRKEaFcpiFaVg2hTBESTIkBaFMFQQUEgZxBBQTAZggUFwcwolcIIVIMqVQCT4YtUigG6wTdUKYxM3S+sJ6eA/bh4+z2FAw2/qts6BbBB/v8DlfmwSaTT7lc4Su3/oL8cpi/xz4HFIQcAVlA4IJgEAADwHwCdASpnAGcAPo06l0elI6IhODHIAKARiWkAFe6f4T+I9u/9T9Felb6J8pnwruJ/ZL8Pws2wDtTMi7jH+t4wOJn+PfpF5A3av6ge4//TPUg/Yf99/lvy19kH4n/Hv/N/l/gA/lP88/7Hqjeo39c/YE/UL7///se+F53yGcpcX2S1jv2CRHaxaYO2BImt0BYTT035XFId1WsOuFjYHSXDTy6H6cP4oeM8TIiDRlBawatYrEAhIRMW0GyY905LZGRtFBkDO2IB17GlN6ShNdibLCHXjOlSx5JhK+jYb/XGEgbOIjGK78Ws4xro+/tHYCeaEuREnTZCgE5q7eYzn0+A/SSAxi2VCQAA/vtAILSCf/VMEZ0KOPLMNPVQudnF3aYyv4KBWOFf1nzNAaWiPjHVlR6Nta0n5sX4J1UEo+B9vn3+eFs9dN98t61QcGB4SDkl5coMg5LsiNi26wMhzqAnseD/8pgjOhRx5Zhp6qFzs4u7SzilJqQZG9PZ8G+23PACxzqOYz3E+ip3GeoKXaI8qmVlMf+NqHxvndnSIoM+lVtiLEFDt0s0Sx8QTDw60KwN9ueV9d7v15DT18Ag5N5frItFJuKZLHYwWDxVOylJIDaXn7vCr6IzYZnvdYrKlGhlVnEZQHNEV/QdiSnM8F9QCLFFU4biHQmmOVky79d4GEIOzrubQBk14BquzBxq982EXSa6fw2czT9QmMGkcCkm4rjQ83eP5SINpSxYj92A67OeMy5BCunQlATY3O6pFJOiqEaZKXke4v8MqWdw4O3Mj3Do51igJ85hzYsQz0RotAizYXe1vkL6TndeoIqabGvdn0+MRO0mB4aL0VXgGSQ8wM9J0KeN0wh/ttoFlLHfPtS/sAdV37dESCW25EeqIq47duGBYC6SLyMutEIKWLA/Oz6Nz/kC518L7R2XMddo6f3blGEtdbakCH2Qq79gbKUUbY+K5qd9+p3C8M97fKtc7WWlnMNm3n4A/zLh4MWVGF774lcrzVX9aBwAl7/a5Rw5x40eFgcKiwkuM4+6AAE/DjpU22w05ZnYKHZ/5L9XeuhONxrH+NO14vRZ+mQ41j6rvuYCmSBahwojEGoia+WN9qlTG78CYX2R+FlOxv9GPxwUvTE7yT6fsLTBF6JUWJpbNFIaMFIIC1EbvhxDOGi1Tw2Aki1QTL8c7xuhGndDE3PMTUKGWDxqB/NR8LM/mlOfwPcwuIV2sa7ORPpqlJ/p1mtn6xb9PcxOqqvUYc/aPs8D3mAQGQDjKC7wm6V3QIDVxMQH5MwzZeyLfhkieESLoxGYxuU2kZ/LrVv3RkjnFqh9732bAS4WJwmKpVbYixBQ7dLDS3C6EjCwho/z94zZlhDcIwW3e5hZo+rCqYy6uKf0EWHy25EdNbEi5aRLoU525ke4dIQOTAQB+w+N87s6j/WmtwIr6HSNzgOnebktO/QjFqyQMVawyStOTX67ZCoMXEn6x5qi5QknYDBtzh5J7WgjX94/oO/uvxAfW4EWF+d6aEVgkLa+DAe76BR9cH48eH7YkUdK8l+laA/XtL09tzk9LpMpAABBTk1G4AYAAAQAAAQAAGYAAGYAAFMAAAJBTFBIPAIAAAG/oLBtGxSOGSIiIEI5jMIoHCPQA59sIMu23batAJgUKTNRVzz/qaqQvAD16k9E/x24jaRIqdTyHsPcPYF+WWEXo38ALn0dSa515OsWaZx0Jz1g/oSZy+H+P8AibAs7LxpLoT8S2A5+T0cSw439JZGt4GG6ZGCQ0Pd5MbBO0zc47/uCGGCnCTtB+oIgaCcHUxAC7eThlYIQaCfwQF8WAW1SuKCCCGAHJm0R4KqLANfASvAaWAtYayULVnM5B9YGjHfeWBuQb6PqxEhN9bmvy5Pcw5oqamz+wrODB66otdVfW65cOxUo1N7qm86l2hvqb1rK194I3HYedGo8XLy9g0/e3MAPUGH4IXCO6Z9JWGqj/U5woS5e7ku+q49nxaW01md2lxvWdV0DyrxC8UTkMTqnxbBizHLM0SjNeEUTyLWBh0kKiA5OAYHROhImEnsQr3VIQg/hh1xQgD8WnObHwoAse/RDjln5k9LXf8j9Q/muxa9HQmhhdPg6Av6LNe5HZrEvqiz7JYtYF3be9waUVyb1t2zfG1BeOapfXGFvQHlpkdWsdSviIxdW8ppXcu+bz5Hc/RiKNtPtc8km2Qsq2EZp+dwyEmID5U8mgmhfijk8IVq2gkiIRkWANCgCqHoRYJULgataDNABpFgQVIHgUlFQgxpCMKhRa0UIB1WUDhFSAHRWuiAhDerVfMMKmUEyn4yiObw1gkhiEFKMBi3n3zPkcjhqOtudjdom5kahrftzWY4P+N8gjWMU0oYAVlA4IIQEAAAwHwCdASpnAGcAPo06l0elJiIhODIoAMARiWkAFe+foB/G+7n+o/Y38N9Fz0i5MTGX8Tws5UD1AO1By7uMcQHEl/D/0g8lrwD1Hv6V6j/6//u/8j+UPsd/Ff5J/6v8t8AH8u/nf/c9Tf1HfrJ7A/6i/f//9T7jmIWO39rCZJYj92bt7M204dsCRXFjruOpnyR6RBPVL8yBloAMaZnp55J/5/dbcQfGBtkiCk9oeDoxvWNUFXyoBEwAqvh43d+A1m/LA7KDTCu3nJsMZbGscyqzFn+se7Pg1JPERbLVSDS2QCJCkhYgT1ZfM5MaqVcFccE5q3Em+VkDX6GA7DAgG6ujOAAA/vtAIL4Jr778LF+nZNNMsEH1zSQC+Ebxw47e5Dx82x2n0p6fGv4K6XDDvsdZYv1cv/sHbH5ZGkqJu9gedm9wf+Ty1CEncEtL1rJ6t2VhHN8fMnwTL3l8zp+WOad88NE1LVRMkxQcwG2Xa7PT0rOSecA65Y6XRN3MsTdIfwt3pq/d6nyMh3x5qYbIx7y6K7uzpktDPWQb3NwQCqwVSwdR/Khy6Ju5libpcFf6WysBe3g3A5RoRnCJC3apGf3TjHqkVyo1pUi5R1weS4O6n2xClBRGXfnGR0NsCn9iTjB7mTlk3jYkivpHiTJz/YEy5KwkrGFiE98TDDPeTwEBsmIHkxj5LDUlfVAyRp6qLyaBVj+13VJ0JW2moZuz6sva0854Kug5cqpfuZMKL+Ib66+TDp3ujoi6hTcJ5cNsw6YlfGdfn0QCisTNN0cDNz83VzaTg9nnY5TlfHy/Ll5M1gvBSQPo2R1TocPCQxTOEOelaKKX7O1DQg4EnsUlylfoKnb/x+GMhi0jUrwZIDX0quR9LNdQnLBeFy7Yrrsd3XpI81uveGM2Ko9gnFWv3QgXvNvHPLOIHDoa31L5PZ6EA/zAIHZCgP7A2/Cl7/rmoBmIhIPFyjIUkggr+P9X3L3MOQgq5nn4fRW2uvxavixMjtSupHts5hdfNv1oVUMtvgq9BQfj3TLBPWAHWm1Zj9Q1+qHpciFGLdM44Z3E8UXmxWHHL2J90isNd6PLV+4BoRUDDV+DtMRjaoqGemxoKqgj8tNIFDX3nP265qObx3OKvKKUt9xqZ/X7qfY/rU6bBJ2logARAFIvu+qE620j89usLkopqOXES2eq79zLRubg3GBMTnhZgKJM3T6yrgbWSst/YDHrtrySIDcCYAAPTdhi0c/ZCAaIKVkvHjivvvHgB5FrzDcD9cPG1LDdn8GiWqYQhod1lfaIfwtcbqy//6qrLm1/8/3hte9H0HYSJ3nSfG5A1U5ZXKtbsWcK36VM3vB1VpVVcOaqdqH+el8hlL7jLzoN15yE/ETZk7kRj9bLvSAd2pzMso5iA3CcBVMJNa4XPnIgmio8ruyPFXDY3WqgbNcfoOyXNmBm6VSc2m3XB/MBSLJxIGZ/X/tSrsAGLrYOj2sGrl6/ZSfsF4zSIV28dTRywCoMyJltqX4T8tpXU0ieFCOxbbj1mzRVSJ88XKVfgAAAQU5NRtgGAAAEAAAEAABmAABmAABTAAACQUxQSC8CAAABv6CwbRs01HYMERHoDutUp7qmWc1q5QOWbLttGwImRaoX29H+t9pAPILpPxH9d+A2kiKlUlrG43uC+7JCHIL/BHBqjySuvu0tXDnpTqp8pVYI1T0twf8PELMx5D2XGAvNkUB2UBqOdFSikhZQP1zSox6VRUF6jII0TUYUqMOAbcBNRhisg4fJCKFrMahRCIF1AFf0CiGwdgV2lBEDak+uuAh4C4sA1kItcC3UAtdMBWiNJQm05oY7Eay9dPtWnQirocI7I8UT6bZ2ihor75zFk1DUWla/9ypqZgEytVd/avlaG4Dfc5maGwg4s16utYGgM+tOkmEVrxvk6y2T+zsJaVP63H3QxbPwe+2hD5cc62Z9Rn85scfjUYE0zlDOt0g+qMB+xhjpGKIpNZzRBMcwVAYP030ePslErGaVDl/ls+yooreFHhkPn+dN7o8knBL8HOUQyH5s2o+s0AiP25GRjfvaL3kBZ8/LdsnCNXTfFz3jtknad9/VJ8/bJlpB96QlbLKmLYCsfXcSXzeRMhOy5l2l1837iHQdfVbDZnbE6/uSlcUdZayjbnnfMjrECkpvIYxoXxclgkM0r0sSySFaVgWkTREQLYqAaVEEQ9d8IUB7cJgvBipDpGxBUAOKXBTUiP0MyxQGFVzxKRYHdER39CEVR2uxF+x6MrErAPx1seTXWxuc4xjYlUwBas5fGlEiVo2X8K7qrHdWVzdR/BZad9LzMh4/wV/l3TgmdqVxAFZQOCCIBAAAUB8AnQEqZwBnAD6NOpdHpSOiITgxWACgEYlpABXuX+Z/h/8t7zv6R9j3xD0aPRTJx/dvAz8GcrN6gHaFZR3Gt07zbfw79D/JT8S9SD+c+pF+uf7T/FflL7GvxT+N/+v/LfAB/MP55/2vUi9Rv7G+wJ+n33///Y8hmG0l2UnKX3RYXLSjLMUM06zxGusK5CV8z8/ec1vqlgAtLR7R8dgbR5MkXU3F4SQQqAXuvDlaOItJ26MxHrDm6qNEQoR3uTfKBoJvEBUQZ6K9bUPnappkDLMl30MVCg/1+P8fDLrOoa+MAWXpIWIE3oIo+O0sbI1iBpqRAQjKPcxYPeyuffUXF4doAAD++0Agtm4+4G2GhDs9JZfOaqSJ64kXWMCW0BysPK3VwNoq4AfPVLR/adlUo4WyIX4Nzl/h68z+7paOXujqIdMphKLAcoGrm74uppF2LsurGbp/uLq0w1XmcX0j1BXOFiwdBwPTbnP8tpEiU8kFhio1sUQ5tXsUZyRaLOmSSfM6ujuVL6nMcx/S1eC0gZ3sBKaJji2mX1OY5jMx82DoVzDeCplLvdJVvaKrG43jVjPaDGUyksrmhBfn6gkJWnT5jH+nDt1sCzo5CcnzE4Oi5V8L27k37mTEM0Quly+FkMOmOKMuz6mi4Spop5wQcLEVnN/bcYwPt0UldLGtk5BIrPOMM7irHBUqHnpNckjGECdIjk3VpqlQic/htnXEBwP7mHfS+RIPYhJFC3qypFfKgegMp3LqT1kYGesq5v1+LObhhDPQ9X4pTCp5pOwCnwgxgSCLlGpG8+V2LyMWmKnIS8gKsEJMhtWHAqNVfiFJ+MUOGWfmndMR8r9POc0EjdQSqDJAbkO6kGHkViVBqsRlsy4ah4aQLj5XsuxpdmsJjzXs1qKDvH1veaMPgN8PwCii1P2gkeKhgADi0G0iC2qlrVAB0vUNntOoFnNGyHGCSjKztU/8tJoV/BL7WmEJG9ca/DqSFgvDTM0EbUMrfjr47E5x0oSKeQP+UIT6YXXE893gwAAlY5aimsHHtp591ZisnVaHNAwFSqjCpHEsYtS3apea09boXUZukPqnol4GtXTd7ZRhnp5PuFMfp3zb4WX7Mglj3tgWdHIUFJoLlPOyTXmMf6cPYMEbKcybJ4DB7AZkBjlXRxOKds0PcL9Y6kVVC57Z2JfuImKFr1A4QJbcTHCrG9HKRVskmC11mxDywb5bZpmpZwiXupmodrS7KpvbH/wgnaxOxzfZYjmRJfeesO5lEetWkps6eYbRY7a0NTwYIDrUWRd0u3Y8B23zmkbjLwuARNzmP7ON0keidPCeJINiJkS+BKCI7/Y2ZdsTr5DxRnJFos6Vhc4rH7Eg5uTojxOhp/SvMc9ukmD8rK+bOxOZJLzQsG5VLaJOr7EpZpTOtk5BIrPOMM7irG07MXBvxmAtsG5oC8E5YtumVOuFsCu3htsJVD6f9q6AqVbHHkhST9T0KelY6OO+URMfcKlCV4T2lkQEf5Yrt6oUZbnpxChB9mcuvzrarVEYP/XsQNP4r6AAAABBTk1G6AYAAAQAAAQAAGYAAGYAAFMAAAJBTFBIPAIAAAG/oLBtGzTUdgwREegO61SnuqZZzWrlQ5Zku3FbARAZUqYlD7Hi/W9VkUBcgHnjT0T/HbiNpEipyuIxLD2BfllhSUl+AJI/9uThJ/jjFB6cfCYPP/4ZI9GQ/xAwB8Mi7PJBTXskEM7znsI+7g2D63xIZQe1wpg9FmRSIg5gzjM2Yo1JHMCcxY1JUOy6QDqTwGDODN+kUxDMQuRdBMjK5F4EXOciwHoXAdW/AKCx5Q6Yce2DGt6kHu1CxpfzSUYcqUl5F8VgcPUXxOqbMBhdNr82g2F1oGN8yQr3ja6QOaVjaEGJq250hZBw+SbzSAe/6OHtP5Kkag27X6sy5vwvzK+3PQ9xnKpXe5p8U99QXm7ldoWSiPgL4716cbliNKb2RiNOXNEkWmGy028XpjpQnTbsDlQYp2dgmEzyAnl43aSiN/k5D4RuFlbPzQLyoC2hGzn3y88J2cj9I4mUIvBzpcTxU8u25y7YBuG2p3Gwj+0QZO/Ny+2QhUdw2xY77XbTGu+2mUd8u+mNdyvmDdut00gd6DTcjbUXlDJ3ZjqN9q68nvbcsyg/kYuhYXYeSO7PQ+6iPlCnY0jL85RGSAeQn0oEariUNRJBjZaKRiGsMQJAjRABa4AIWANECOzdIAbUCzg2CIKVIapBEKwJohgEwZohUkcHsDJ8k44YYBv6QJ8dQax1+8MeJhchB8IPF6UWIYqDiLPzwa8DI+dfGlkjj31mqh8fDp37mTuNTdaOQgdPuR+mMw0frq0V/xsRVlA4IIwEAAAwHwCdASpnAGcAPo04l0elIyIhODIoAKARiWkAFfC/4Xtp/qv4089h6H5QR7lws6IjyAO2OyXwVvif+q4wO9L5F/wD9FvJv7s/Tn3B/536kX7N/yfIX+I/yj/0f5L4AP5X/O/+n6gHqe/W/2BP09/P/////Q+45jSjedHEW1HvdZm7e4Ij7QoqNa4ataObUkI1xPYHZttV7XJyGTYgyzJLS6guZhp3n7l/UiRlaX9tk+5a2Ecw4qouYnYPe5u8ROTAf3leCFG9qjarnpuUuVe1ybdBHzcCpsGhi6sW4t8HE1QMz5AIvacO4w7aT9B+MEYMw2tMOVbyjOfTaLPQTsq2DsAA/vuc3KxRLStmoHINptNfn5iUjt0pgKdvlXlPRReKtHHjGAIuk/Fpu/Z0jWFIxDh3R3NC/UcnQVYero2jKxoYQbkY0LLS4KJITZLvXZEsgYoK9qgXSQm39P5S3W6MBmxYoNvNENJLp2CANze0U2NRUh6sxPxXK4fPprKFBd+jze/XFoSK5sBce4GZvbbO3cRTvdQq9GPKWVMc9MozykBBTsSWU3yoK+8taS0KqEFp9L4m9ZfzjBa2sj9xQnnXSIRazZqTXh1atNNHQXFM8Ff1qtHnFhTLaOKZB9KkXBun2XekVuzymLYCdjyB00JWCn7YGBV5AcWHULiGO8cPxgx4Ujh3yhoas4E0av7izisrvf/qu2XwvyYyKvFAPwTG1pWYi2EGHYe4i0zoZh6whH1hLWPS1n1cGHqQfz0D9ssYoL6DPsrCNE4gfn1D4Fzty5xWnpaJ41wkAlG/69bP8B1ZvFx47TuMG9RQCr06YJJ+Hm/12BoQRVnbI2s39mcIMZtSVKHN4AAJrdM+SNx+pzaUt4vhlpk/isot/7yko8PzLe2OqL7v6k4pKfFF0I2CuCo/jbfgLXE0GlgG2uH0BGr/pAZyHglNfhvamo5UERBCsXYLVBq/Lcajqohnah5Vkaz4pVz1W6i1BZoiVE+tfl5iPuJFEFnxNXrNKfIzvv5uC/LW6h0B+T+8vFaxTwrLwgIjx3mPv8voXtW7XslDU67ZngCTgby92fF/i3uolUh45tPJn0SWwd/kz1VZlwpwTpqs2iX0vhTc4+p3qIGwLVl/jI8EKbyJm7aKElxTPBYb9Hyn0R6RZER0n0w8J9FTXqFhyF0fGXg+Ms5xyDnJ/K1zDxa9I/jR0Fvcaqyqcxm6UmW+KAgagPb+n8pbrdGAzYsRXOHKML2XcFumHVgpB5fiHJdHdYyfpHpvMG9erQK6X+4xtgIEDr7jYYqBUKQt3o01ZSm9WfVuu+MWtH6MfqvNAYehR4pRH552KuMaEvssF+MTM05xdcbBshGjmP6ccdWSy3Lt0Q7TrEM8MMu/j3P2W12+qoAzl71y1YhWe5kPN4bSmi12wEetNej5NADmcIWlRvzdY6izeCqkqtE3uw1o5PR4IfWyjcmOYLK+RO5r+e6GbG3uVCVzTb4/rUJOmRjsohSsls4qAI69bWagtse31gfQh5SJzkSDZL+05nrTnpCDX7xejkAAAABBTk1G6gYAAAQAAAQAAGYAAGYAAFMAAAJBTFBIOQIAAAG/oLZtGzZmO01zIiIEU2zYcAYfPvKQZdtu21YATEpUiWpszX+qLiAuwLz6E9F/B24jKVIqdcx3A/cF+nWFRfhHnLo90/4Jvn2EG0c+kca5KWn8vAb/f0BKER+Cp3Q5rmcOiYNT90xmuPfrLXeJgnPXuXhclyYK1q7L4PF1acKA7TqGKJcuCtpOYFRhLHVDrpoYaDvwJmtVCLTZ4YEqIqBl8hYBrrsIcEM0gTZMC2ADNYA1Tsv+EGukht0u2CZ0aKgrVRT6xNJg9QfX34Oh0Rbzi6s3TgcqjVescK3xHmRO0hvvXexwdqnrdhE1cfw+uhTBPwNm+meS1BdbeucfLos1/LmGHA97dnE8lQd73gdieUA5xG9UD1CEiL8xHosX/YBRmMYHGnFiQCO0wGSnKRcmO9C3QoFxegaGSSQHyO51k4ze5PXj/BkPhE4Li+e0gDyosk6mYkwW7xUemeT+kUQy/oycUgOnpvMZbNjyOD8zcnD38y3I6s3T/JaJW+h5ftkZ51kzvudpPuJ5Vm2gZ7aSZt3IOlAxvifr44b1MxXDu2jjZntGex+lamArD8TL9paF1Qeq2EZp2j4yEmID5U0JI8aXkkYixPBS1siEGFU7iDFFQIwoBGREEQJd6gWBLOBxvSiYDNFXC4OZIHKtOAbdkEodwARvuFaKAzk6PJBaEKtuA3Z5MQk5EL5dlD4LUQSVzYNnHGg5/8Kw7aja/meqIdR0lk8WapusnW/dt5NLpubD/ThmJm8IAFZQOCCQBAAAsCEAnQEqZwBnAD6FOJZHpSOiITg0WACgEIlpABXs/6Re4nvj+WfkB7k9AL0AzhH2A/H+0DsN2rf8B+T35AcYVlfgs/Jv9n/N9RL+GHqr/AP038gbwD1AP516ln7Z/0vu39kH4h/Lv/L/l/gA/k/88/7X7C+4n6j/1w9gD9R/z/////3RC/cIlaKT2CXXXitM7JzEp0INZfYU/8MFcppfx0f3Y4+zSi71+aWkeFtEZeNtMRp3NDOMZ9M9cc4Hsze+6CMAZ1y8iV5xDZH4JbsRHE1U/dSjKeXARO9EiZlsmEk5LZoa0YzYbgq+6FRoyvSymx8/aCs4xrpCB4ukvHNV/9uZcwsKFCWN53wYavQ2SCSaAp5NPAAA/vuc3L46YARha/3KqAh2XeTLGxuYct7EAyFmR2iitOSgy2PRgCT+7nOc6K+R2HwjN+Uc+fQb50ou4Al+N6vVdjlDyZ0z1a+b8e80WWsC4Cz9WWRKfxXHOK/LaZeS+whraCr/T3k9vNRheumVC+5zFvKQ7d4YeAFGuKBagkH47IzN8cCiXcvlKmYUS7lUdilhSeHC9IfjsjL43v1xJahwi4845j6FdoqYbmJyj+SNmOacOoUwG9nMDalcq+BHA2pQD0JTwGIiGNkDJjBBgHewqWhvmYidEDNhAImEP0eJCG45Q2mnzVjQnM/VQOUL+lVLAvxRjF0L+m08P3Jh8FJ/8C415SslQokt9YhAqgMYGtb0ZbltYcugUz8KaAi6/0JP6EJPy7wBzI8yZnYtEDsu1Pburp2zbG3g1oL5nO2oARH6RpbOIpEU/UvHCmhceff7m5JLp7zExeu3q+vI4X09si7i0W/F4VahSrmzJy2mae31l0NDdBsQnF94BQEp10GDSHSQAMwA3l7+ED7zfCr/tolHMH3WW2Vx7y9BZpxM5qy5uzbMU0aN9scJwzAd7EBCT/QEuIpibQAMbw63whG8O37B/IgMX2S+3AP7obF9e7EyNMQ2kanqiCMqIiEFVX3jOe2JIDaCbi+8qAJt9tKSYIDRFn6QAPqdR+ADyCVV2dZosEa7xN13gaa5KP7hpinTAkonEYQD329cq6yRMIBo/sPf3UwxgU5CpadRdR8RvuMlvCmuwwpIjxluJlm4REl5Cp0bY5vw/EPNrZTz9NadzHLl3Iyep6wqR8y5KUE+7CD4ZaCXzY+TT8NjR2ehXMMwVOm7lSq9qej6rxxENXrc/zWcduccSiblAODtewC9SJ87RoBJu7uKJfMSpbAxSQ8KTBTGDlQ3IIuqO387bIsb+5rCoXSvjIC+JsEbHpY4j5rXkh57OwJ8cUkRqCWJIlWdQsmSV7I3v+NSkezaYRt8MCTXCx7s0KUFneSXZC5CtacMOResCrOIsBG9nfl1J/K//suTQZurNmKmW2JVoGDFXFbOz8CTg+HLbVtJ8U22nsR1uS/BLSjqBOK1q0voQ+g9xb76WjN04Q1a3mEfwIejLeFNB0+lE/JqkSbHR7YchyKJT3xlTFg4Cpc3KVujpOvfkvVdzLheJ3eJHQNudwxi7XF8pKne+AAAAA==" alt="" aria-hidden="true"
         width="30" height="30" style="width:30px;height:30px;">
  </span>
  <span class="t-body">加载中</span>
</div>
```

> ⚠️ **图标类名规则**：
> - `success` → `icon-iconfont-select-line-regular`
> - `failure` → `icon-iconfont-cancelcircle-line-regular`
> - `warning` → `icon-iconfont-warning-line-regular`
> - 所有图标必须用 **`line-regular`（常规体）**，❌ 禁止使用 `fill`（填充体）

---

## 11. 使用约束（AI 生成时的硬性规则）

1. **总时长不超过 4s**：轻提示从出现到消失不得超过 4 秒
2. **字重严格区分**：**表示状态的标题**（`double-with-title` 变体中的主标题）使用 **500 中黑体**；所有描述性正文（含单行、双行、图标下方文案）一律使用 **400 常规体**，❌ 禁止将正文设为 500/中黑体
3. **不含操作按钮**：轻提示不含任何可交互按钮；如需操作引导，改用 `snackbar.md`
4. **圆角不可修改**：气泡圆角固定 12pt（`radius-m`），自定义插槽固定 6pt（`radius-xs`）
5. **字符严格限制**：单行 ≤ 14 字符，双行最多 28 字符，左右组合 ≤ 12 字符
6. **图标来源**：图标必须来自 `component/atoms/icon.md`，类名格式 `font icon-iconfont-{name}-{weight}`
7. **颜色使用 Token**：代码层必须引用 `color-semantic.md` 语义 Token（如 `mask-heavy`、`text-on-dark`）；规格表中的 hex 值（如 `#000000CC`、`#FFFFFF`）仅作注释说明，不得直接硬编码进样式
8. **深色背景适配**：深色页面必须将背景色改为 15% 白（`#FFFFFF26`）
9. **位置默认居中**：默认垂直居中，特殊场景才可调整为靠上/下 30%
10. **左右组合非常规**：`iconLayout=horizontal` 仅用于业务特殊要求，常规需求必须使用 `vertical`
11. **自定义型宽 > 高**：自定义型气泡宽度必须大于高度，不得做成竖向长条

---

## 12. 常见组合示例

### 12.1 常规操作反馈（文字型，单行）

```
Toast
  toastType: text
  rowCount: single
  message: "复制成功"
  // 自动停滞 2s 后消失（字符数 ≤ 14）
```

### 12.2 网络错误提示（文字型，双行）

```
Toast
  toastType: text
  rowCount: double
  message: "您今日还未咨询商家，咨询后才能对商家进行评价"
  // 自动停滞 3.5s 后消失（字符数 > 22）
```

### 12.3 订阅成功带标题（文字型，双行+标题）

```
Toast
  toastType: text
  rowCount: double-with-title
  title: "订阅成功"
  message: "你将收到商场活动优惠推送"
```

### 12.4 支付成功（图标文字型，上下组合，单行）

```
Toast
  toastType: icon-text
  iconLayout: vertical
  rowCount: single
  iconState: success
  message: "支付成功"
  // 图标 36×36pt，气泡 96×96pt，停滞 2s
```

### 12.5 操作失败带说明（图标文字型，上下组合，双行+标题）

```
Toast
  toastType: icon-text
  iconLayout: vertical
  rowCount: double-with-title
  iconState: failure
  title: "失败状态"
  message: "字符限制最多两行，手动断句换行，确保信息阅读舒适性"
  // 图标 36×36pt，气泡 236×144pt，停滞 3.5s
```

### 12.6 加载中状态

```
Toast
  toastType: icon-text
  iconLayout: vertical
  rowCount: single
  iconState: loading
  message: "加载中"
  duration: 0   // loading 不自动消失，由业务方控制关闭
```

### 12.7 深色页面适配

```
Toast
  toastType: text
  rowCount: single
  message: "非wifi网络，注意流量消耗"
  // 页面为深色时，背景色自动切换为 #FFFFFF26（15% 白）
```

---

## 13. 变体矩阵（完整）

### 13.1 文字型（toastType=text）

| rowCount | 有标题 | 气泡高度 | 字符上限 | 停滞时间 |
|----------|--------|---------|---------|---------|
| `single` | ❌ | 44pt | 14 | 2s |
| `double` | ❌ | 64pt | 28（两行） | 3–3.5s |
| `double-with-title` | ✅ | 70pt | 标题 1 行，正文 2 行 | 3–3.5s |

### 13.2 图标文字型（toastType=icon-text）

| iconLayout | rowCount | iconState | 气泡尺寸 | 图标尺寸 | 字符上限 | 推荐 |
|------------|----------|-----------|---------|---------|---------|------|
| `vertical` | `single` | success | 96×96pt | 36×36pt | ≤ 5 | ✅ |
| `vertical` | `single` | failure | 96×96pt | 36×36pt | ≤ 5 | ✅ |
| `vertical` | `single` | warning | 96×96pt | 36×36pt | ≤ 5 | ✅ |
| `vertical` | `single` | loading | 96×96pt | 36×36pt | ≤ 5 | ✅ |
| `vertical` | `single` | custom | 96×96pt | 36×36pt | ≤ 5 | ✅ |
| `vertical` | `double` | success/failure/warning/custom | 236×114pt | 36×36pt | ≤ 28 | ✅ |
| `vertical` | `double-with-title` | success/failure/warning/custom | 236×144pt | 36×36pt | 标题 1 行，正文 2 行 | ✅ |
| `horizontal` | `single` | success/failure/warning/loading/custom | 高 44pt | 18×18pt | ≤ 12 | ⚠️ |

---

## 14. 与其他组件的关系

| 关联组件 | 关系说明 |
|----------|----------|
| `dialog.md` | 信息较多、需要用户决策时，使用弹窗而非轻提示 |
| `snackbar.md` | 底部横幅，含操作按钮；轻提示无按钮，两者互补 |
| `notification-banner.md` | 通知横幅，持久展示；轻提示自动消失，场景不同 |
| `loading`（刷新和加载规范） | 加载中状态的旋转动效参考「刷新和加载」规范 |
