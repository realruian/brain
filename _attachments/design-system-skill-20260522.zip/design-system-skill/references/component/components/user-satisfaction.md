# user-satisfaction 满意度评分

> **组件分类**：Component（组件级）
> **定义**：满意度评分组件用于采集用户对服务/体验的满意程度，共包含**星星**、**表情**、**数字**三大类型，6 种大样式，9 种具体样式。支持**只读型**（展示已有结果）和**可交互型**（用户主动打分）两种模式。图片资源优先调用 CDN URL 实现。
> **Style 依赖**：
> - Reference 层：`color-reference.md` · `font-reference.md` · `spacing-reference.md` · `radius-reference.md`
> - Semantic 层：`color-semantic.md` · `font-semantic.md` · `spacing-semantic.md` · `radius-semantic.md` · `stroke-semantic.md`
> - Component 层：`component-spacing.md`（组件内部间距 `cs-*`）· `component-radius.md`（组件内部圆角 `cr-*`）

> ⚠️ **核心约束**：
> - **星星评分**：3星制（卡片类非满意度打分）/ 5星制（卡片类非满意/满意度打分）；图标使用 CDN 切图，支持半屏/全屏两种宽度
> - **表情评分**：3分制（344px 宽）或 5分制（670px 宽），适用于卡片类满意度打分题；图标使用 CDN 切图，`object-fit: cover`
> - **数字评分**：NPS 0–10 分（11个圆形按钮）或费力度 1–7 分（7个矩形按钮）；布局为 `space-between` 横排
> - 选中态：数字/星星组件用 `#FFFADB` 背景 + `#FFDD00` 描边 + `#FF7700` 文字；表情组件切换为点亮切图 + 文字统一 `#111111`（不使用情绪色）
> - 未选中态：NPS/CES简洁版背景 `#F5F5F5`（`bg-page`），CES详细版背景 `#F7F7F7`（`bg-surface`）；数字未选中文字 `#555555`，表情/星星 `#999999`；**禁止使用透明度降低**
> - 每个选项最小触摸热区 ≥ **44×44pt**（@1x）

---

## 0. 组件分类总览

user-satisfaction 按**量表类型**分为 **3 大类**，共 **9 种具体样式**：

| 大类 | 大样式 | 具体样式 | 适用场景 | 宽度布局 |
|------|--------|---------|---------|---------|
| **星星** | 3星制 | 半屏宽度 | 卡片类 非满意度类 打分题 | 344px，3单元等宽 |
| **星星** | 3星制 | 全屏宽度 | 卡片类 非满意度类 打分题 | 670px，3单元等宽 |
| **星星** | 5星制 | 半屏宽度 | 卡片类 非满意/满意度类 打分题 | 344px，5单元等宽 |
| **星星** | 5星制 | 全屏宽度 | 卡片类 非满意/满意度类 打分题 | 670px，5单元等宽 |
| **表情** | 3/5分制 | 1–3分（三档） | 卡片类 满意度类 打分题 | 344px，3单元等宽 |
| **表情** | 3/5分制 | 1–5分（五档） | 卡片类 满意度类 打分题 | 670px，5单元等宽 |
| **数字** | NPS 0–10分 | 含两端标注行 | 卡片类 NPS 打分题 | 670px，11个圆形按钮+底部标注行 |
| **数字** | 费力度 1–7分 | 简洁版（横排+标注行） | 卡片类 费力度 打分题 | 670px，7个矩形按钮（48px高）+底部标注行 |
| **数字** | 费力度 1–7分 | 详细版（按钮内嵌竖排标注） | 卡片类 费力度 打分题 | 670px，7个矩形按钮（124px高，内含数字+标注文字） |

---

## 0. 图标 / 间距 / Ownership 约束

- **icon-route（默认）**：满意度评分图标按正文既定资源策略执行，不得随意替换 icon route。
- **fixed-asset 例外**：评分图标优先走 CDN 图片，SVG 仅作兜底，不得强制改成 iconfont；输出可记录 `icon-route=fixed-asset`。
- **spacing-owner（归属）**：组件内部星星/表情/数字量表的排布与间距归本组件；页面外层留白与容器占位归宿主。
- **宿主裁决（优先级）**：冲突遵循 `宿主 > 组合场景 > 本组件`，子组件只拥有自身内部样式。
- **不可跳步**：先回 `references/INDEX.md` 完成区域路由与宿主锁定，再用 `component-quickref.md` 做宿主级收敛；本文件仅承接组件内 ownership 细则，不承担前置路由改判；不得凭语义猜测。


## 1. 交互模式（mode）

| mode | 名称 | 说明 | 典型场景 |
|------|------|------|----------|
| `readonly` | 只读型 | 仅展示已有评分结果，不可交互 | 历史评分查看、订单评价记录 |
| `interactive` | 可交互型 | 用户可点击选择分值，有选中反馈 | 服务结束后满意度调研、NPS 问卷 |

---

## 2. 量表类型（scaleType）

| scaleType | 名称 | 说明 | 分值范围 | 典型场景 |
|-----------|------|------|---------|---------|
| `star` | 星星评分 | 3星制或5星制，图标+文字 | 1~3 或 1~5，支持半星 | 卡片类非满意度打分 |
| `emoji` | 表情评分 | 3档或5档表情图标+文字标签 | 1~3 或 1~5，整数 | 卡片类满意度打分 |
| `nps` | NPS数字量表 | 0–10 共11个圆形数字按钮，`space-between` 横排 | 0~10，整数 | 净推荐值调研 |
| `ces` | 费力度数字量表 | 1–7 共7个矩形数字按钮，`space-between` 横排 | 1~7，整数 | 服务费力度评估 |

---

## 3. 切图资源（CDN URL）

> 图片优先调用以下 CDN URL（`<img>` 标签），CDN 不可达时通过 `onError` 降级显示 SVG 或 Emoji Unicode，禁止两者同时渲染。

### 3.1 星星切图

| 状态 | 说明 | CDN URL |
|------|------|---------|
| 满星 | 选中/已评星 | `https://p0.meituan.net/ingee/024047bc03da9aa1266c6f61ccfe0ec91912.png` |
| 半星 | 半颗星 | `https://p0.meituan.net/ingee/39858aed7d9227a961aab3636d91eaf81946.png` |
| 空星 | 未选中 | `https://p0.meituan.net/ingee/751b40f4b90c4d788e6565d5f2e2062e1633.png` |

### 3.2 表情切图（5档）

| 档位 | 标签 | 点亮态（选中） | 未点亮态（未选中） |
|------|------|-------------|----------------|
| 1 | 非常不满意 | `https://p0.meituan.net/ingee/2a1d9641ee642c9c88b1ecebb67e8b737251.png` | `https://p0.meituan.net/ingee/9d67b96f88633bfff17ef39aaa67aca36552.png` |
| 2 | 不满意 | `https://p0.meituan.net/ingee/b4a272553500ed6e6874bac39e11dd857695.png` | `https://p0.meituan.net/ingee/61094e87f0be0e713aa3b656b966c61e5618.png` |
| 3 | 一般 | `https://p0.meituan.net/ingee/987db183bd9fb261fac4d40672f677f38949.png` | `https://p0.meituan.net/ingee/8823a90ccba6d9bfd18ae3a4d1d629a96539.png` |
| 4 | 满意 | `https://p0.meituan.net/ingee/9c0a3d0958189b3632bbed657ccbb6bd8458.png` | `https://p0.meituan.net/ingee/495372b44c2761b7d86539225f88e57b5842.png` |
| 5 | 非常满意 | `https://p0.meituan.net/ingee/752286df0be055bc0ddb2a31ffc351019371.png` | `https://p0.meituan.net/ingee/6a3c0d315aa50ccefeb35933fff559a67417.png` |

> **三档映射**：档位 2（不满意）→ 三档档1；档位 3（一般）→ 三档档2；档位 5（非常满意）→ 三档档3（满意）。

---

## 4. 颜色语义

### 4.1 星星评分颜色

| 状态 | 背景 | 描边 | 文字色 | 说明 |
|------|------|------|-------|------|
| 未选中 | 无（透明） | 无 | `#999999`（`text-hint`） | 空星切图 + 灰色文字；**星星类型无按钮背景色** |
| 选中（交互/只读） | 无（透明） | 无 | `#111111`（`text-primary`） | 满星切图，文字变黑 |
| 禁用 | 无（透明） | 无 | `#C2C2C2`（`text-disabled`） | 图标整体 `opacity: 0.4` |

### 4.2 表情评分颜色

**文字颜色规则：**

| 状态 | 文字色 | 说明 |
|------|-------|------|
| 未选中（default） | `#999999` | 所有档位统一灰色 |
| 选中（interactive selected） | `#111111`（`text-primary`） | 所有档位统一黑色，**不使用情绪色** |
| 只读选中（readonly） | `#111111`（`text-primary`） | 所有档位统一黑色 |
| 禁用（disabled） | `#C2C2C2` | 所有档位统一浅灰 |

**三档（emojiCount=3）图标映射：**

| 档位 | 标签 | 未选中文字色 | 选中文字色 | 图标状态 |
|------|------|------------|----------|---------|
| 1 | 不满意 | `#999999` | `#111111` | 切换为点亮切图 |
| 2 | 一般 | `#999999` | `#111111` | 切换为点亮切图 |
| 3 | 满意 | `#999999` | `#111111` | 切换为点亮切图 |

**五档（emojiCount=5）图标映射：**

| 档位 | 标签 | 未选中文字色 | 选中文字色 | 图标状态 |
|------|------|------------|----------|---------|
| 1 | 非常不满意 | `#999999` | `#111111` | 切换为点亮切图 |
| 2 | 不满意 | `#999999` | `#111111` | 切换为点亮切图 |
| 3 | 一般 | `#999999` | `#111111` | 切换为点亮切图 |
| 4 | 满意 | `#999999` | `#111111` | 切换为点亮切图 |
| 5 | 非常满意 | `#999999` | `#111111` | 切换为点亮切图 |

> **未选中态**：使用未点亮切图，文字 `#999999`，禁止使用透明度降低。
> **选中态**：切换为对应点亮切图，文字统一 `#111111`，**不显示情绪色（红/橙/绿）**。
> **三档切图来源**：三档档1"不满意"对应五档的档位2切图；档2"一般"对应五档档位3切图；档3"满意"对应五档档位5切图。

### 4.3 数字评分颜色（NPS & 费力度）

| 状态 | 背景色 | 描边 | 文字色 | 字重 | 适用范围 |
|------|-------|------|-------|------|--------|
| 未选中 | `#F5F5F5`（`bg-page`） | 无 | `#555555`（`text-secondary`） | 400 | NPS / CES简洁版 |
| 未选中 | `#F7F7F7`（`bg-surface`） | 无 | `#111111`（`text-primary`） | 500 | CES详细版（数字常态就加粗） |
| 选中（交互态） | `#FFFADB` | `1px solid #FFDD00`（`yellow-default`） | `#FF7700`（`orange-default`） | 500 | 全类型 |
| 只读选中 | `#FFFADB` | `1px solid #FFDD00` | `#FF7700` | 500 | 全类型 |
| 标注文字 | — | — | `#999999` | 400 | NPS / CES简洁版标注行 |
| CES详细版内嵌标注（未选中） | — | — | `#999999` | 400 | 按钮内部标注文字，未选中态 |
| CES详细版内嵌标注（选中） | — | — | `#FF7700`（与数字一致） | 400 | 按钮内部标注文字，选中态与数字颜色保持一致 |

---

## 5. 尺寸规格（@2x，单位 px）

### 5.1 星星评分尺寸

| 属性 | 3星制·半屏 @2x | 3星制·全屏 @2x | 5星制·半屏 @2x | 5星制·全屏 @2x | @1x 说明 |
|------|-------------|-------------|-------------|-------------|---------|
| 组件容器宽 | **344px** | **670px** | **344px** | **670px** | 半屏≈172pt / 全屏=335pt |
| 组件容器高 | **104px** | **108px** | **92px** | **108px** | 52pt / 54pt / 46pt |
| 单元宽（`flex:1`） | **114.67px** | **223.33px** | **68.8px** | **134px** | 等宽分配 |
| 图标容器尺寸 | **68×68px** | **72×72px** | **48×48px** | **72×72px** | 34pt/36pt/24pt |
| 图标与文字间距 | **4px** | **4px** | **12px** | **4px** | `row-gap` |
| 文字标签字号 | **24px** | **24px** | **24px** | **24px** | 12pt |
| 文字标签行高 | **32px** | **32px** | **32px** | **32px** | 16pt |
| 文字标签色（未选中） | `#999999` | `#999999` | `#999999` | `#999999` | — |
| 文字标签色（只读选中） | `#111111` | `#111111` | `#111111` | `#111111` | `text-primary` |
| 5星制无文字项 | — | — | `opacity: 0` | `opacity: 0` | 中间项文字隐藏 |

> **5星制半屏特殊说明**：单元内 `row-gap: 12px`，中间项（instance-1/2/3）文字 `opacity: 0` 隐藏，仅两端显示文字。

### 5.2 表情评分尺寸

| 属性 | 三档（1–3分） @2x | 五档（1–5分） @2x | @1x |
|------|---------------|---------------|-----|
| 组件容器宽 | **344px** | **670px** | 172pt / 335pt |
| 组件容器高 | **100px** | **112px** | 50pt / 56pt |
| 单元宽（`flex:1`） | **114.67px** | **134px** | 等宽分配 |
| 图标容器尺寸 | **60×60px** | **66×66px**（外框 66×76px） | 30pt / 33pt |
| 图标与文字间距 | **8px** | **4px** | `row-gap` |
| 文字标签字号 | **24px** | **24px** | 12pt |
| 文字标签行高 | **32px** | **32px** | 16pt |
| 文字标签色（未选中） | `#999999` | `#999999` | — |
| 五档外框 padding | — | `padding: 5px 0` | 图标容器上下各5px |

> **五档图标说明**：外框 `frame`（66×76px）内含图标实体 `rectangle`（66×66px），上下 padding 5px，`object-fit: cover`。

### 5.3 数字 NPS 尺寸（0–10分，11个按钮）

> **代码来源**：KM 代码块7「NPS·简洁描述」。该 ComponentSet 含多行变体（default + 各档选中），每行均包含按钮行 + 底部标注行，无单独「无标注」变体。

| 属性 | @2x（px） | @1x（pt） | 说明 |
|------|---------|---------|------|
| 组件容器宽 | **670px** | 335pt | `left: 60px`，全内容区 |
| 按钮行高度 | **48px** | 24pt | `flex-row`，`space-between` |
| 单个按钮尺寸 | **48×48px** | 24×24pt | 圆形，`radius-full`（`border-radius: 9999px`）；**禁止使用 `flex: 1`**，必须固定 `width: 48px; height: 48px; flex-shrink: 0`，否则按钮在弹性容器中会被拉伸为椭圆 |
| 按钮内边距（`cs-5`） | `padding: 10px` | 5pt | 四向各 10px |
| 按钮排列方式 | `justify-content: space-between` | — | 11个按钮均匀分布 |
| 按钮未选中背景（`bg-page`） | `#F5F5F5` | — | — |
| 按钮选中背景 | `#FFFADB` | — | + `border: 1px solid #FFDD00` |
| 数字字号 | **24px** | 12pt | `font-weight: 400`→未选中，`500`→选中 |
| 数字文字色（未选中，`text-secondary`） | `#555555` | — | — |
| 数字文字色（选中，`orange-default`） | `#FF7700` | — | weight: 500 |
| 标注行高度 | **32px** | 16pt | 宽 670px，`space-between` |
| 标注文字字号 | **24px** | 12pt | `#999999`，weight: 400 |
| 按钮行与标注行间距（`cs-6`） | **12px** | 6pt | `row-gap: 12px` |
| 整体容器高 | **92px** | 46pt | 按钮行 48px + gap 12px + 标注行 32px = 92px |
| ComponentSet 高度 | **252px** | 126pt | — |

> **标注行**：宽 670px，`justify-content: space-between`，左端"非常不满意"（120px宽）、右端"非常满意"（96px宽），颜色 `#999999`。

### 5.4 数字费力度尺寸（1–7分，7个按钮）

费力度有**两种变体**，对应 KM 中两个不同代码块：

#### 5.4.1 简洁版（代码块8）—— 横排按钮 + 底部标注行

| 属性 | @2x（px） | @1x（pt） | 说明 |
|------|---------|---------|------|
| 组件容器宽 | **670px** | 335pt | `left: 60px` |
| 按钮行高度 | **48px** | 24pt | `flex-row`，`space-between` |
| 单个按钮尺寸 | **84×48px** | 42×24pt | **矩形**，`cr-8`（`border-radius: 16px`） |
| 按钮内边距（`cs-5`） | `padding: 10px` | 5pt | — |
| 按钮排列方式 | `justify-content: space-between` | — | 7个按钮均匀分布 |
| 按钮未选中背景（`bg-page`） | `#F5F5F5` | — | — |
| 按钮选中背景 | `#FFFADB` | — | + `border: 1px solid #FFDD00` |
| 数字字号 | **24px** | 12pt | weight: 400（未选中）/ 500（选中） |
| 数字文字色（未选中，`text-secondary`） | `#555555` | — | — |
| 数字文字色（选中，`orange-default`） | `#FF7700` | — | weight: 500 |
| 标注行高度 | **32px** | 16pt | 宽 670px，`space-between` |
| 标注文字色 | `#999999` | — | weight: 400 |
| 标注文字宽度 | 左96px·中48px·右96px | — | "非常简单"·"一般"·"非常复杂" |
| 按钮行与标注间距（`cs-6`） | **12px** | 6pt | `row-gap: 12px` |
| 整体容器高 | **92px** | 46pt | 按钮行 48px + gap 12px + 标注行 32px = 92px |
| ComponentSet 高度 | **252px** | 126pt | — |

#### 5.4.2 详细版（代码块9）—— 按钮内嵌竖排标注

> 每个按钮内**上方数字 + 下方标注文字**竖排排列，标注文字直接内嵌在按钮内部，无独立标注行。

| 属性 | @2x（px） | @1x（pt） | 说明 |
|------|---------|---------|------|
| 组件容器宽 | **670px** | 335pt | `left: 60px` |
| 单个按钮尺寸 | **84×124px** | 42×62pt | **矩形竖排**，`cr-8`（`border-radius: 16px`） |
| 按钮内边距（`cs-5`） | `padding: 10px` | 5pt | — |
| 按钮行排列方式（容器级） | `justify-content: space-between` | — | 7个按钮横向均匀分布 |
| 按钮内排列方式（按钮级） | `flex-direction: column` | — | 每个按钮内部数字+标注文字竖排 |
| 按钮未选中背景 | `#F7F7F7` | — | 注意：非 `#F5F5F5`，为浅灰背景（`bg-surface`） |
| 按钮选中背景 | `#FFFADB` | — | + `border: 1px solid #FFDD00` |
| 数字字号（`text-1`） | **26px** | 13pt | `#111111`，weight: 500 |
| 数字行高 | **36px** | 18pt | 数字元素需置于固定高度 `height: 36px` 的容器内，与标注容器（64px）一同保证各按钮垂直方向对齐一致 |
| 标注文字字号（`text`） | **24px** | 12pt | `#999999`（未选中）/ `#FF7700`（选中），weight: 400 |
| 标注文字行高 | **32px** | 16pt | — |
| 标注文字容器高 | **64px** | 32pt | 可容纳两行（最多2行文字）；**必须为标注容器设置固定高度 `height: 64px`**，否则不同行数的标注文字会导致各按钮内数字垂直错位 |
| 数字与标注间距（`cs-2`） | **4px** | 2pt | `row-gap: 4px`（按钮内） |
| ComponentSet 高度 | **284px** | 142pt | 顶部 80px + 按钮行 124px + 间距 |

---

## 6. 组件集（ComponentSet）规格

设计稿中各类型均包含 4 个状态变体（1 个 default + 3/4个选中态）。

### 6.1 星星·3星制·半屏版（窄版，344px）

```
[ComponentSet]  790×264px，border-radius: 40px，border: 3px dashed #111111
  ├── [Row-0: default]     top:80px,  left:223px, width:344px, height:104px — 所有文字 #999999
  ├── [Row-1: 档1选中]     top:264px, left:223px, width:344px, height:104px — 第1个instance文字 #111111
  ├── [Row-2: 档2选中]     top:448px, left:223px, width:344px, height:104px — 第2个instance文字 #111111
  └── [Row-3: 档3选中]     top:632px, left:223px, width:344px, height:104px — 第3个instance文字 #111111
```

变体行间距：`264 - 80 = 184px`（@2x），即 **92pt**。

### 6.2 星星·3星制·全屏版（670px）

```
[ComponentSet]  790×268px，border-radius: 40px，border: 3px dashed #111111
  ├── [Row-0: default]     top:80px,  left:60px, width:670px, height:108px — 所有文字 #999999
  ├── [Row-1: 档1选中]     top:268px, left:60px, width:670px, height:108px — 第1个instance文字 #111111
  ├── [Row-2: 档2选中]     top:456px, left:60px, width:670px, height:108px — 第2个instance文字 #111111
  └── [Row-3: 档3选中]     top:644px, left:60px, width:670px, height:108px — 第3个instance文字 #111111
```

变体行间距：`268 - 80 = 188px`（@2x），即 **94pt**。

### 6.3 星星·5星制·半屏版（344px）

```
[ComponentSet]  790×252px，border-radius: 40px，border: 3px dashed #111111
  ├── [Row-0: default]   top:80px，left:223px, width:344px, height:92px — 所有文字 #999999（中间项 opacity:0）
  ├── [Row-1~5: 各档选中] top:172/264/356/448/540px，对应第N个instance文字色显示
```

ComponentSet 高度：252px；变体行间距：92px。

### 6.4 星星·5星制·全屏版（670px）

```
[ComponentSet]  790×268px，border-radius: 40px，border: 3px dashed #111111
  ├── [Row-0: default]   top:80px,  left:60px, width:670px, height:108px — 所有文字 #999999
  ├── [Row-1~5: 各档选中] top每次+188px，对应第N个instance文字色 #111111
```

### 6.5 NPS 数字量表（0–10分）

> 对应 KM 代码块7。每行变体均含按钮行 + 底部标注行（height:92px），无单独「无标注」变体。

```
[ComponentSet]  790×252px，border-radius: 40px，border: 3px dashed #111111
  ├── [Row-0: default]   top:80px，left:60px, width:670px, height:92px
  │     ├── [frame 按钮行] 670×48px，space-between — 11个 #F5F5F5 圆形按钮（radius-full）
  │     └── [frame-1 标注行] 670×32px，space-between — 左"非常不满意"120px·右"非常满意"96px，#999999
  ├── [Row-1: 某值选中]   top:252px，height:92px — 对应按钮 #FFFADB+border:#FFDD00，文字 #FF7700/500
  └── [Row-2: 另一值选中] top:444px，height:92px — 同上，展示不同选中值
```

ComponentSet 高度：252px；变体行间距：192px（80px间距 + 92px行高）。

### 6.6 费力度数字量表（1–7分）

费力度有两个独立代码块（简洁版 / 详细版）：

**简洁版**（代码块8）——横排按钮 + 底部标注行：

```
[ComponentSet]  790×252px，border-radius: 40px，border: 3px dashed #111111
  ├── [Row-0: default]   top:80px，left:60px, width:670px, height:92px
  │     ├── [frame 按钮行] 670×48px，space-between — 7个 #F5F5F5 矩形按钮（84×48px，cr-8）
  │     └── [frame-1 标注行] 670×32px，space-between — 左"非常简单"96px·中"一般"48px·右"非常复杂"96px，#999999
  ├── [Row-1: 某值选中]   top:252px，height:92px — 对应按钮 #FFFADB+border:#FFDD00，文字 #FF7700/500
  └── [Row-2: 另一值选中] top:444px，height:92px
```

**详细版**（代码块9）——按钮内嵌竖排标注：

```
[ComponentSet]  790×284px，border-radius: 40px，border: 3px dashed #111111
  ├── [Row-0: default]   top:80px，left:60px, width:670px, height:124px
  │     └── [7个按钮] 84×124px，cr-8，bg:#F7F7F7，flex-column，center/center，row-gap:4px
  │           ├── [.text-1 数字] 26px/36px，#111111，weight:500
  │           └── [.text 标注]   24px/32px，#999999，weight:400，高度64px（可2行）
  └── [Row-1: 某值选中]   top:284px，height:124px — 对应按钮 #FFFADB+border:#FFDD00，数字 #FF7700/500，标注文字 #FF7700（与数字一致）
```

---

## 7. 结构规格（组件树）

### 7.1 星星评分·3星制·半屏（344px）

```
[SatisfactionScore]  flex-row，width:344px，height:104px，column-gap:0
  ├── [星星单元 1] 114.67×104px — flex-column，center/center，row-gap:4px，column-gap:4px，flex-grow:1
  │     ├── [图标帧] 68×68px，flex-shrink:0 — <img> 空星/满星切图，object-fit:cover
  │     └── [标签] "不满意" — 72×32px，font-size:24px/lh:32px/w:400，#999999→#111111
  ├── [星星单元 2] 同上
  │     ├── [图标帧] 68×68px
  │     └── [标签] "一般" — 48×32px（文字较短）
  └── [星星单元 3] 同上
        ├── [图标帧] 68×68px
        └── [标签] "满意" — 72×32px
```

### 7.2 星星评分·3星制·全屏（670px）

```
[SatisfactionScore]  flex-row，width:670px，height:108px，column-gap:0
  ├── [星星单元 1] 223.33×108px — flex-column，center/center，row-gap:4px，column-gap:4px，flex-grow:1
  │     ├── [图标帧] 72×72px，flex-shrink:0
  │     └── [标签] "不满意" — 72×32px，#999999→#111111
  ├── [星星单元 2] 同上，[标签] "一般" — 48×32px
  └── [星星单元 3] 同上，[标签] "满意" — 72×32px
```

### 7.3 星星评分·5星制·半屏（344px）

```
[SatisfactionScore]  flex-row，width:344px，height:92px，column-gap:0
  ├── [星星单元 1] 68.8×92px — row-gap:12px，column-gap:12px，flex-grow:1
  │     ├── [图标帧] 48×48px
  │     └── [标签] "很差" — 72×32px，#999999（显示）
  ├── [星星单元 2] 同上，[标签] 72×32px，opacity:0（隐藏）
  ├── [星星单元 3] 同上，[标签] 48×32px，opacity:0（隐藏）
  ├── [星星单元 4] 同上，[标签] 48×32px，opacity:0（隐藏）
  └── [星星单元 5] 同上，[标签] "很好" — 72×32px，#999999（显示）
```

> 5星制半屏版中间3项文字 `opacity:0`，仅首尾显示标签。

### 7.4 星星评分·5星制·全屏（670px）

```
[SatisfactionScore]  flex-row，width:670px，height:108px，column-gap:0
  ├── [星星单元 1~5] 134×108px — row-gap:4px，column-gap:4px，flex-grow:1、flex-column、center/center
  │     ├── [图标帧] 72×72px，flex-shrink:0
  │     └── [标签] 全部显示，#999999（未选中）→#111111（选中）
  │           星星单元1: "很差" — 72px
  │           星星单元2: "较差" — 48px
  │           星星单元3: "一般" — 48px
  │           星星单元4: "较好" — 48px
  │           星星单元5: "很好" — 72px
```

### 7.5 表情评分·三档（1–3分，344px）

```
[SatisfactionScore]  flex-row，width:344px，height:100px，column-gap:0
  ├── [表情单元 1] 114.67×100px — row-gap:8px，column-gap:0，flex-grow:1、flex-column、center/center
  │     ├── [图标容器] 60×60px，flex-shrink:0
  │     │     └── [切图] position:absolute，60×60px，object-fit:cover
  │     └── [标签] "不满意" — 72×32px，#999999（未选中）→#111111（选中）
  ├── [表情单元 2] 同上，[标签] "一般" — 48×32px
  └── [表情单元 3] 同上，[标签] "满意" — 72×32px
```

### 7.6 表情评分·五档（1–5分，670px）

```
[SatisfactionScore]  flex-row，width:670px，height:112px，column-gap:0
  ├── [表情单元 1~5] 134×112px — row-gap:4px，column-gap:0，flex-grow:1、flex-column、center/center
  │     ├── [外框 frame] 66×76px，flex-shrink:0，padding:5px 0，flex-column，center/center
  │     │     └── [切图 rectangle] 66×66px，position:absolute，object-fit:cover
  │     └── [标签] 各档文字，宽度不一：
  │           表情单元1: "非常不满意" — 120px
  │           表情单元2: "不满意" — 72px
  │           表情单元3: "一般" — 48px
  │           表情单元4: "满意" — 48px
  │           表情单元5: "非常满意" — 96px
```

### 7.7 数字 NPS（0–10分）

> 对应 KM 代码块7，每个变体均包含按钮行 + 标注行，无单独「无标注」变体。

```
[SatisfactionScore]  flex-column，width:670px，height:92px，row-gap:12px（cs-6）
  ├── [frame 按钮行] flex-row，width:670px，height:48px，justify-content:space-between
  │     ├── [按钮 0~9] width:48px，height:48px，flex-shrink:0，radius-full，padding:10px（cs-5），bg:#F5F5F5（bg-page）
  │     │             ⚠️ 禁止 flex:1，按钮宽高必须固定，否则在 space-between 布局中会被拉伸为椭圆
  │     │     → 选中：bg:#FFFADB，border:1px solid #FFDD00，文字 #FF7700（orange-default）/500
  │     └── [按钮 10] 同上
  └── [frame-1 标注行] flex-row，width:670px，height:32px，justify-content:space-between
        ├── [左标注] "非常不满意" — 120px，#999999
        └── [右标注] "非常满意" — 96px，#999999
```

### 7.8 数字费力度（1–7分）

**简洁版**（代码块8）——横排按钮 + 底部标注行：

```
[SatisfactionScore 简洁版]  flex-column，width:670px，height:92px，row-gap:12px（cs-6）
  ├── [frame 按钮行] flex-row，width:670px，height:48px，justify-content:space-between
  │     ├── [按钮 1~6] 84×48px，cr-8，padding:10px（cs-5），bg:#F5F5F5（bg-page）
  │     │     → 选中：bg:#FFFADB，border:1px solid #FFDD00，文字 #FF7700（orange-default）/500
  │     └── [按钮 7] 同上
  └── [frame-1 标注行] flex-row，width:670px，height:32px，justify-content:space-between
        ├── [左标注] "非常简单" — 96px，#999999
        ├── [中标注] "一般" — 48px，#999999
        └── [右标注] "非常复杂" — 96px，#999999
```

**详细版**（代码块9）——按钮内嵌竖排标注（⚠️ 与简洁版结构完全不同）：

```
[SatisfactionScore 详细版]  flex-row，width:670px，height:124px，justify-content:space-between
  └── [按钮 1~7] 84×124px，cr-8，bg:#F7F7F7（bg-surface），flex-column，center/center，row-gap:4px（cs-2）
        ├── [.text-1 数字容器] height:36px，display:flex，align-items:center，justify-content:center，flex-shrink:0
        │     └── [数字文字] font-size:26px，line-height:36px，#111111，weight:500（默认态）
        │           → 选中：bg:#FFFADB，border:1px solid #FFDD00，数字色 #FF7700（orange-default）
        │     ⚠️ 必须为数字设置固定高度容器（height:36px），配合标注容器固定高度，确保各按钮数字行垂直对齐
        └── [.text 标注文字容器] height:64px，display:flex，align-items:center，justify-content:center
              └── [标注文字] font-size:24px，line-height:32px，#999999（未选中）→#FF7700（选中），weight:400
                            text-align:center，可容纳最多2行文字
              ⚠️ 必须为标注设置固定高度容器（height:64px），否则不同行数标注文字会导致各按钮数字垂直错位
```

> ⚠️ **详细版关键差异**：
> - 按钮高度 **124px**（非48px）
> - 按钮背景 `#F7F7F7`（`bg-surface`），非 `#F5F5F5`（`bg-page`）
> - 无独立标注行，标注文字内嵌于每个按钮内部
> - 数字字号 **26px**（非24px），weight: 500（常态即加粗）

---

## 8. 标签文字宽度对照

### 8.1 星星 3星制 / 表情三档（共用同一套标签）

| 标签 | 宽度 @2x |
|------|---------|
| "不满意" | 72px |
| "一般" | 48px |
| "满意" | 72px |

### 8.2 星星 5星制标签

| 位置 | 标签 | 宽度 @2x | 备注 |
|------|------|---------|------|
| 单元1 | "很差" | 72px | 半屏/全屏均显示 |
| 单元2 | "较差" | 48px | 半屏 opacity:0，全屏显示 |
| 单元3 | "一般" | 48px | 半屏 opacity:0，全屏显示 |
| 单元4 | "较好" | 48px | 半屏 opacity:0，全屏显示 |
| 单元5 | "很好" | 72px | 半屏/全屏均显示 |

### 8.3 表情五档标签

| 标签 | 宽度 @2x |
|------|---------|
| "非常不满意" | 120px |
| "不满意" | 72px |
| "一般" | 48px |
| "满意" | 48px |
| "非常满意" | 96px |

### 8.4 NPS 标注文字

| 位置 | 文字 | 宽度 @2x |
|------|------|---------|
| 左端 | "非常不满意" | 120px |
| 右端 | "非常满意" | 96px |

### 8.5 费力度标注文字

| 位置 | 文字 | 宽度 @2x |
|------|------|---------|
| 左端 | "非常简单" | 96px |
| 中端 | "一般" | 48px |
| 右端 | "非常复杂" | 96px |

---

## 9. 状态（state）

### 9.1 只读型状态

| state | 说明 | 视觉表现 |
|-------|------|----------|
| `default` | 展示历史评分 | 选中项切换为选中切图/高亮色，其余为未选中态 |
| `loading` | 评分加载中 | 骨架屏占位（`skeleton`） |

### 9.2 可交互型状态

| state | 说明 | 视觉表现 |
|-------|------|----------|
| `default` | 未选择任何分值 | 所有选项使用未选中样式 |
| `selected` | 已选择某分值 | 选中项切图/背景/文字切换为高亮态 |
| `disabled` | 禁用 | 所有选项不响应点击，视觉置灰：数字按钮背景 `bg-disabled`（`#F0F0F0`），文字 `text-disabled`（`#C2C2C2`）；星星/表情图标整体 `opacity: 0.4` |

---

## 10. Token 引用

### 10.1 颜色 Token

| 用途 | Token 名称 | 实测色值 | 语义层来源 |
|------|-----------|---------|-----------|
| 数字/星星选中背景 | `yellow-bg`（Y1） | `#FFFADB` | 品牌黄浅色背景，`color-semantic.md` §四 Brand Yellow |
| 数字/星星选中描边 | `brand-yellow` | `#FFDD00` | `color-semantic.md` |
| 数字/星星选中文字 | `orange-default` | `#FF7700` | `color-semantic.md`（品牌橙） |
| 数字/星星未选中背景（NPS/CES简洁版） | `bg-page` | `#F5F5F5` | `color-semantic.md` |
| CES详细版按钮未选中背景 | `bg-surface` | `#F7F7F7` | `color-semantic.md` |
| 数字未选中文字 | `text-secondary` | `#555555` | `color-semantic.md` §二 Text |
| 表情/星星未选中文字 | `text-hint` | `#999999` | `color-semantic.md` §二 Text；亦用于标注行、CES详细版未选中内嵌标注 |
| 只读选中文字 | `text-primary` | `#111111` | `color-semantic.md` §二 Text |
| 表情选中文字（交互/只读） | `text-primary` | `#111111` | `color-semantic.md` §二 Text；**不使用情绪色** |
| 标注文字 | `text-hint` | `#999999` | NPS/CES简洁版底部标注行，同 `text-hint` |
| 禁用按钮背景 | `bg-disabled` | `#F0F0F0` | `color-semantic.md` |
| 禁用文字 | `text-disabled` | `#C2C2C2` | `color-semantic.md` §二 Text |

### 10.2 字体 Token

| 用途 | 字号 @2x | @1x | 字重 | 行高 @2x | 备注 |
|------|---------|-----|------|---------|------|
| 星星/表情标签（未选中） | 24px | 12pt | 400 | 32px | — |
| 星星/表情标签（选中） | 24px | 12pt | 500（推荐） | 32px | — |
| 数字按钮（未选中，NPS/CES简洁版） | 24px | 12pt | 400 | 32px | — |
| 数字按钮（选中，NPS/CES简洁版） | 24px | 12pt | 500 | 32px | — |
| 数字按钮（CES详细版数字，常态） | 26px | 13pt | 500 | 36px | `.text-1`，默认即加粗 |
| 数字按钮（CES详细版数字，选中） | 26px | 13pt | 500 | 36px | 色变 `#FF7700` |
| 标注文字（标注行/按钮内嵌） | 24px | 12pt | 400 | 32px | — |

### 10.3 间距 Token

> 所有组件内部间距从 `component-spacing.md`（`cs-*`）引用，不使用裸 pt 数值。
> **Style 三层引用链**：`spacing-reference.md`（原始值）→ `spacing-semantic.md`（语义化）→ `component-spacing.md`（组件专用 `cs-*`，本组件直接引用此层）

| 用途 | Token（`cs-*`） | 值 @2x | @1x | 说明 |
|------|--------------|-------|-----|------|
| 星星/表情图标与文字（3星/全屏/五档） | `cs-2` | 4px | 2pt | `row-gap` |
| 星星5星制半屏图标与文字 | `cs-6` | 12px | 6pt | `row-gap` |
| 表情三档图标与文字 | `cs-4` | 8px | 4pt | `row-gap` |
| 数字按钮行与标注行间距（NPS/CES简洁版） | `cs-6` | 12px | 6pt | `row-gap` |
| 数字按钮内边距（四向，NPS/CES简洁版） | `cs-5` | 10px | 5pt | `padding` |
| CES详细版按钮内边距（四向） | `cs-5` | 10px | 5pt | `padding` |
| CES详细版按钮内数字与标注文字间距 | `cs-2` | 4px | 2pt | `row-gap`（按钮内竖排） |
| 表情五档图标外框上下内边距 | ≈`cs-2`~`cs-3` | 5px | 2.5pt | `padding: 5px 0`；设计稿实测 5px，介于 `cs-2`(4px) 与 `cs-3`(6px) 之间，以实测为准 |
| 全屏版页面边距 | — | 60px | 30pt | `left: 60px`（页面级，用 `spacing-semantic.md`）|
| 单元内水平 gap（小） | `cs-2` | 4px | 2pt | `column-gap` |
| 单元内水平 gap（大，5星半屏） | `cs-6` | 12px | 6pt | `column-gap` |

### 10.4 圆角 Token

> 组件内圆角从 `component-radius.md`（`cr-*`）或 `radius-semantic.md`（`radius-full`）引用，不使用裸 pt 数值。
> **Style 三层引用链**：`radius-reference.md`（原始值）→ `radius-semantic.md`（`radius-full` 等语义化）→ `component-radius.md`（`cr-8` 等组件专用，本组件直接引用此层）

| 用途 | Token | 值 @2x | 说明 |
|------|-------|-------|------|
| NPS 数字按钮（完全圆形） | `radius-full` | `border-radius: 9999px` | 宽高各48px，自动呈圆形 |
| 费力度数字按钮（矩形圆角） | `cr-8` | 16px（8pt×2） | 中等圆角，不可改为胶囊形 |
| ComponentSet 外框 | — | `border-radius: 40px` | 设计稿展示框，非组件规范圆角 |

---

## 11. 变体矩阵（完整 MECE）

### 11.1 星星评分变体

| scaleType | starCount | width | state | 说明 |
|-----------|-----------|-------|-------|------|
| `star` | 3 | 半屏 | `default` | 三个空星 + 灰色文字 |
| `star` | 3 | 半屏 | `selected` | 选中N项，对应满星 + 文字 #111111 |
| `star` | 3 | 全屏 | `default` | 同上，全屏宽度 |
| `star` | 3 | 全屏 | `selected` | — |
| `star` | 5 | 半屏 | `default` | 五个空星，中间三项文字隐藏 |
| `star` | 5 | 半屏 | `selected` | 选中N项满星 |
| `star` | 5 | 全屏 | `default` | 五个空星 + 全部文字显示 |
| `star` | 5 | 全屏 | `selected` | 选中N项满星 |

### 11.2 表情评分变体

| emojiCount | state | 选中档位 | 图标 | 文字色 |
|------------|-------|---------|------|------|
| 3 | `default` | 无 | 未点亮切图 | `#999999` |
| 3 | `selected` 档1 | 不满意 | 点亮切图（档位2） | `#111111` |
| 3 | `selected` 档2 | 一般 | 点亮切图（档位3） | `#111111` |
| 3 | `selected` 档3 | 满意 | 点亮切图（档位5） | `#111111` |
| 5 | `default` | 无 | 未点亮切图 | `#999999` |
| 5 | `selected` 档1 | 非常不满意 | 点亮切图（档位1） | `#111111` |
| 5 | `selected` 档2 | 不满意 | 点亮切图（档位2） | `#111111` |
| 5 | `selected` 档3 | 一般 | 点亮切图（档位3） | `#111111` |
| 5 | `selected` 档4 | 满意 | 点亮切图（档位4） | `#111111` |
| 5 | `selected` 档5 | 非常满意 | 点亮切图（档位5） | `#111111` |

### 11.3 数字评分变体

> NPS 始终含底部标注行（无单独「无标注」变体）；CES 有两个独立变体：横排+底部标注行（`ces-plain`）和按钮内嵌竖排标注（`ces-detailed`）。

| scaleType | data-variant | state | 说明 |
|-----------|-------------|-------|------|
| `nps` | `nps-annotated` | `default` | 11个 `#F5F5F5` 圆形按钮 + 底部两端标注行 |
| `nps` | `nps-annotated` | `selected` | 选中项 `#FFFADB`+border，文字 `#FF7700`/500 |
| `ces` | `ces-plain` | `default` | 7个 `#F5F5F5` 矩形按钮（48px高）+ 底部三端标注行 |
| `ces` | `ces-plain` | `selected` | 选中项 `#FFFADB`+border，文字 `#FF7700`/500 |
| `ces` | `ces-detailed` | `default` | 7个 `#F7F7F7` 矩形按钮（124px高），内嵌数字+标注文字竖排 |
| `ces` | `ces-detailed` | `selected` | 选中按钮 `#FFFADB`+border，数字色 `#FF7700`/500，标注文字色 `#FF7700` |

---

## 12. 交互规则

### 12.1 点击交互

| 操作 | 行为 |
|------|------|
| 点击星星/表情/数字按钮 | 选中对应分值，切换为选中样式 |
| 点击已选中的同一项 | 取消选中（回到未评分状态），若业务不允许取消则忽略 |
| 滑动 | 各类型不支持滑动选择 |

### 12.2 动画

| 动作 | 效果 |
|------|------|
| 数字/星星选中 | 背景色渐变过渡，时长 150ms，`ease-out` |
| 表情选中 | 图标切换为点亮切图，文字颜色变化，时长 150ms |
| 取消选中 | 渐变回未选中态，时长 100ms |

### 12.3 最小触摸热区

| 类型 | 视觉尺寸 @2x | 视觉尺寸 @1x | 触摸热区要求 |
|------|------------|------------|------------|
| NPS 圆形按钮 | 48×48px | 24×24pt | 需扩展至 ≥44pt |
| CES简洁版矩形按钮 | 84×48px | 42×24pt | 高度需扩展至 ≥44pt |
| CES详细版矩形按钮 | 84×124px | 42×62pt | 高度 62pt 远超过 44pt，安全✅ |
| 星星·3星半屏单元 | 114.67×104px | 57×52pt | 满足 ≥44pt |
| 星星·5星半屏单元 | 68.8×92px | 34×46pt | 宽度需扩展至 ≥44pt |
| 表情三档单元 | 114.67×100px | 57×50pt | 满足 ≥44pt |
| 表情五档单元 | 134×112px | 67×56pt | 满足 ≥44pt |

---

## 13. Props API（供 AI 生码参考）

```typescript
export type SatisfactionScoreProps = {
  /**
   * 量表类型
   * @default "emoji"
   */
  scaleType?: "star" | "emoji" | "nps" | "ces";

  /**
   * 交互模式
   * @default "interactive"
   */
  mode?: "readonly" | "interactive";

  /**
   * 当前分值（只读型为展示值；可交互型为受控值）
   * star-3: 1~3（支持0.5半星）；star-5: 1~5（支持0.5半星）
   * emoji-3: 1~3；emoji-5: 1~5
   * nps: 0~10；ces: 1~7
   */
  value?: number;

  /**
   * 可交互型默认值（非受控）
   */
  defaultValue?: number;

  /**
   * 星星档位（scaleType=star 时有效）
   * @default 5
   */
  starCount?: 3 | 5;

  /**
   * 表情档位（scaleType=emoji 时有效）
   * @default 5
   */
  emojiCount?: 3 | 5;

  /**
   * 布局宽度（star/emoji 类型有效）
   * @default "fullWidth"
   */
  width?: "halfWidth" | "fullWidth";

  /**
   * CES 费力度量表变体（scaleType=ces 时有效）
   * - "plain"    横排7个矩形按钮（48px高）+ 底部标注行（默认）
   * - "detailed" 每个按钮内嵌上方数字 + 下方标注文字竖排（124px高，无独立标注行）
   * @default "plain"
   */
  cesVariant?: "plain" | "detailed";

  /**
   * 量表左侧标注文字
   * - nps：左端标注（始终显示）@default "非常不满意"
   * - ces plain：左端标注 @default "非常简单"
   * - ces detailed：第1个按钮内的标注文字（可覆盖）
   */
  minLabel?: string;

  /**
   * 量表右侧标注文字
   * - nps：右端标注（始终显示）@default "非常满意"
   * - ces plain：右端标注 @default "非常复杂"
   * - ces detailed：第7个按钮内的标注文字（可覆盖）
   */
  maxLabel?: string;

  /**
   * 量表中间标注文字（ces plain 时有效，ces detailed 无独立中间标注）
   * @default "一般"
   */
  midLabel?: string;

  /**
   * 表情/星星标签数组
   * @default star-3: ["不满意", "一般", "满意"]
   * @default star-5: ["很差", "", "", "", "很好"]（中间项为空，opacity:0）
   * @default emoji-3: ["不满意", "一般", "满意"]
   * @default emoji-5: ["非常不满意", "不满意", "一般", "满意", "非常满意"]
   */
  labels?: string[];

  /**
   * 是否禁用（interactive 模式下有效）
   * @default false
   */
  disabled?: boolean;

  /**
   * 分值变更回调
   */
  onChange?: (value: number) => void;
};
```

---

## 14. data-attribute 规范

| 属性 | 值 | 说明 |
|------|----|------|
| `data-slot` | `"satisfaction-score"` | 组件根容器 |
| `data-slot` | `"satisfaction-score-items"` | 按钮/表情/星星容器区 |
| `data-slot` | `"satisfaction-score-item"` | 单个选项单元 |
| `data-slot` | `"satisfaction-score-label"` | 文字标签 |
| `data-slot` | `"satisfaction-score-annotation"` | 量表标注文字行 |
| `data-scale-type` | `"star"` / `"emoji"` / `"nps"` / `"ces"` | 量表类型 |
| `data-variant` | `"star-3-half"` / `"star-3-full"` / `"star-5-half"` / `"star-5-full"` | 星星评分具体变体（类型-档位-宽度） |
| `data-variant` | `"emoji-3"` / `"emoji-5"` | 表情评分具体变体 |
| `data-variant` | `"nps-annotated"` / `"ces-plain"` / `"ces-detailed"` | 数字评分具体变体（NPS 始终含标注行；CES 有横排+底部标注行版 和 按钮内嵌竖排标注版） |
| `data-mode` | `"readonly"` / `"interactive"` | 交互模式 |
| `data-count` | `"3"` / `"5"` / `"11"` / `"7"` | 选项数量 |
| `data-width` | `"halfWidth"` / `"fullWidth"` | 布局宽度（star/emoji） |
| `data-state` | `"default"` / `"selected"` / `"disabled"` | 组件整体状态 |
| `data-value` | `"3"` | 当前分值（字符串） |

---

## 15. 无障碍（Accessibility）

- **只读型**：
  - 根容器 `role="img"`，`aria-label="满意度评分 3 分（满分 5 分）"`
  - 各选项 `aria-hidden="true"`

- **可交互型**：
  - 根容器 `role="radiogroup"`，`aria-label="请对本次服务进行评分"`
  - 每个选项 `role="radio"`，`aria-label="N 分"`，选中时 `aria-checked="true"`
  - 禁用时 `aria-disabled="true"`
  - 键盘：`ArrowLeft` / `ArrowRight` 移动，`Enter` / `Space` 确认

---

## 16. 使用约束（AI 生成时的硬性规则）

1. **图片优先 CDN URL**：星星和表情图标必须优先使用 §3 中的 CDN URL（`<img>` 标签），CDN 不可达时通过 `onError` 降级 SVG/Emoji，禁止两者同时渲染
2. **5星制半屏**：中间三项（第2/3/4项）文字必须 `opacity: 0`，不可删除DOM节点
3. **NPS 选项固定 11 个（0–10）**，费力度固定 7 个（1–7），不可增减
   - **NPS 始终含底部标注行**，无需也不支持 `showAnnotation` 开关
4. **数字选中态配色**：`#FFFADB` 背景 + `#FFDD00` 描边 + `#FF7700` 文字，不可自定义
5. **表情未选中禁止降低透明度**：使用未点亮切图 + `#999999` 文字
6. **不含提交按钮**：本组件不包含提交/确认按钮，提交逻辑由外层表单控制
7. **最小触摸热区**：≥ 44pt，视觉尺寸不足时需扩展热区（NPS按钮、5星半屏单元）
8. **NPS/费力度按钮排列**：必须用 `justify-content: space-between`，不可用固定 gap
9. **三档/五档表情图标**：使用 `position: absolute` + `object-fit: cover` 渲染切图
10. **NPS 圆形按钮尺寸固定**：`width: 48px; height: 48px; flex-shrink: 0`，**禁止使用 `flex: 1`**；在 `space-between` 弹性容器中，`flex: 1` 会导致按钮宽度被撑开而变形为椭圆
11. **CES 详细版按钮内垂直对齐**：数字和标注文字须分别放置在独立固定高度容器中（数字容器 `height: 36px`，标注容器 `height: 64px`），不可让文字直接决定行高；若各按钮标注行数不一（1行/2行），不用固定容器则数字行位置会上下错位
12. **组件容器宽度**：在卡片等外层容器内嵌时，应使用 `width: 100%; max-width: 670px`（全屏版）或 `max-width: 344px`（半屏版），避免因外层 padding 导致组件溢出边界；避免直接写死 `width: 670px`

---

## 17. 常见组合示例

### 17.1 NPS 调研（含两端标注，可交互）

> NPS 始终含标注行，无需 `showAnnotation` 参数。

```
SatisfactionScore
  scaleType: "nps"
  mode: "interactive"
  minLabel: "非常不满意"
  maxLabel: "非常满意"
  onChange: (v) => setScore(v)
```

### 17.2 快速满意度反馈（三档表情，可交互）

```
SatisfactionScore
  scaleType: "emoji"
  emojiCount: 3
  mode: "interactive"
  labels: ["不满意", "一般", "满意"]
  onChange: (v) => setScore(v)
```

### 17.3 细粒度满意度（五档表情，可交互）

```
SatisfactionScore
  scaleType: "emoji"
  emojiCount: 5
  mode: "interactive"
  labels: ["非常不满意", "不满意", "一般", "满意", "非常满意"]
  onChange: (v) => setScore(v)
```

### 17.4 星星评分（3星，全屏，可交互）

```
SatisfactionScore
  scaleType: "star"
  starCount: 3
  width: "fullWidth"
  mode: "interactive"
  labels: ["不满意", "一般", "满意"]
  onChange: (v) => setScore(v)
```

### 17.5 CES 费力度评分—简洁版（横排按钮+底部标注，可交互）

```
SatisfactionScore
  scaleType: "ces"
  cesVariant: "plain"
  mode: "interactive"
  minLabel: "非常简单"
  midLabel: "一般"
  maxLabel: "非常复杂"
  onChange: (v) => setScore(v)
```

### 17.5b CES 费力度评分—详细版（按钮内嵌竖排标注，可交互）

```
SatisfactionScore
  scaleType: "ces"
  cesVariant: "detailed"
  mode: "interactive"
  onChange: (v) => setScore(v)
```

### 17.6 结果回显（只读，表情五档）

```
SatisfactionScore
  scaleType: "emoji"
  emojiCount: 5
  mode: "readonly"
  value: 4
  labels: ["非常不满意", "不满意", "一般", "满意", "非常满意"]
```

---

## 18. 与其他组件的关系

| 关联组件 | 关系说明 |
|----------|----------|
| `rating.md` | Rating 用于商品/内容质量星级评分（1–5星，展示型居多）；Satisfaction-Score 用于满意度调研问卷（多种量表类型）；两者场景不同，禁止混用 |
| `form` | 调研问卷场景中，Satisfaction-Score 作为表单字段嵌入，需配合表单提交逻辑 |
| `dialog` / `half-screen-dialog` | 满意度调研通常在弹窗或半屏浮层内触发 |
| `button` | 外层提交按钮由页面/表单层提供，本组件不包含 |
| `progress` | 多题调研问卷中，顶部进度条展示当前题目进度 |
