# Text Edit Menu 文本复制气泡

> **组件分类**：Component（组件级）
> **定义**：文本复制气泡是用户**长按文本**后弹出的操作气泡，包含对文本的快捷操作（如复制、粘贴、全选等）。气泡浮于文本上方或下方，包含尖角指向被选文本。根据操作项内容分为**图标文本型**（图标+文字）和**文本型**（纯文字）。当操作数超过显示上限时，通过左右箭头进行**省略展示**。
> **Style 依赖**：`color-semantic.md` · `font-semantic.md` · `spacing-semantic.md` · `component-spacing.md` · `radius-semantic.md`

> ⚠️ **核心约束**：
> - 气泡背景固定为**深色（#000000CC，80%不透明黑）**，无浅色版本
> - **图标文本型**最多完整展示 **5 个**操作；**文本型**最多完整展示 **5 个**操作
> - 超过 5 个时均需使用**省略展示**模式，配合左右箭头翻页
> - 尖角固定为**8×3pt**，三角形，颜色与气泡背景一致（`#000000CC`）
> - 气泡尖角分为**在上**（气泡在文本上方）和**在下**（气泡在文本下方）两种位置

---

## 0. 图标 / 间距 / Ownership 约束

- **icon-route（默认）**：Text Edit Menu 内操作项图标默认回 `component/atoms/icon.md`，并遵循正文指定 class / weight。
- **fixed-asset 例外**：尖角、close icon、URL 切图及 CSS/SVG 降级位点属于 fixed-asset 或显式例外，必须按正文路由，禁止通用规则覆盖。
- **spacing-owner（归属）**：文本编辑气泡内部项间距、翻页箭头与容器内对齐归本组件；页面外层浮层留白归宿主。
- **宿主裁决（优先级）**：冲突遵循 `宿主 > 组合场景 > 本组件通用规则`，子组件不得反向改写气泡排布。
- **不可跳步**：先回 `references/INDEX.md` 完成区域路由与宿主锁定，再用 `component-quickref.md` 做宿主级收敛；本文件仅承接组件内 ownership 细则，不承担前置路由改判；不得凭语义猜测。


## 1. 类型（type）

| type | 名称 | 操作项组成 | 整体高度（@2x） | 适用场景 |
|------|------|-----------|--------------|----------|
| `icon-text` | 图标文本型 | 图标（20×20pt）+ 文字（12pt / 24×16pt） | **70pt**（含尖角） | 需要图标辅助理解操作含义时，视觉更丰富 |
| `text` | 文本型 | 纯文字（14pt / 28×20pt） | **46pt**（含尖角） | 系统原生操作（如复制/粘贴），文字即可清晰表意 |

---

## 2. 展示模式（displayMode）

| displayMode | 名称 | 说明 | 触发条件 |
|-------------|------|------|----------|
| `full` | 全部展示 | 所有操作项直接展示，无翻页箭头 | 操作数 ≤ 5（图标文本型/文本型） |
| `overflow` | 省略展示 | 左右两侧各有一个翻页箭头（`向左`/`向右`），操作项分页展示 | 操作数 > 5 时激活 |

> **省略展示结构**：左右翻页箭头（各 14×14pt）夹在操作项两侧，翻页箭头**可点击**切换页面；处于边界页时（首页左箭头 / 末页右箭头）降低透明度（`opacity: 0.3`）并禁用点击（`pointer-events: none`）。

---

## 3. 尖角位置（arrowPosition）

| arrowPosition | 名称 | 尖角所在区域 | 气泡与文本的位置关系 |
|--------------|------|-----------|-------------------|
| `top` | 尖角在上 | 气泡顶部（"顶部区域"） | 气泡在被选文本**下方** |
| `bottom` | 尖角在下 | 气泡底部（"底部区域"） | 气泡在被选文本**上方** |

> **规则**：默认气泡弹出在被选文本**上方**（`arrowPosition=bottom`），屏幕上方空间不足时翻转至下方（`arrowPosition=top`）。

---

## 4. 操作数量（itemCount）

### 4.1 图标文本型（icon-text）

| displayMode | itemCount | 操作区宽度（@2x） | 整体高度（@2x） |
|-------------|-----------|----------------|--------------|
| `full` | 2 | **104pt** | 70pt |
| `full` | 3 | **156pt** | 70pt |
| `full` | 4 | **208pt** | 70pt |
| `full` | 5 | **260pt** | 70pt |
| `overflow` | >5 | **344pt**（固定含翻页箭头） | 70pt |

> 宽度推导：操作区 = 左内边距 14pt + 操作项组 + 右内边距 14pt；操作项组 = `itemCount × 24pt + (itemCount-1) × 28pt gap`
> 简化：每项 24pt 宽 + 项间 gap 28pt；5项宽度：`14+24×5+28×4+14=260pt`

### 4.2 文本型（text）

| displayMode | itemCount | 操作区宽度（@2x） | 整体高度（@2x） |
|-------------|-----------|----------------|--------------|
| `full` | 1 | **56pt** | 46pt |
| `full` | 2 | **112pt** | 46pt |
| `full` | 3 | **168pt** | 46pt |
| `full` | 4 | **224pt** | 46pt |
| `full` | 5 | **280pt** | 46pt |
| `overflow` | >5 | **336pt**（固定含翻页箭头） | 46pt |

> 宽度推导：操作区 = 左内边距 14pt + 文字项（42pt 含分割线）×N + 右内边距 14pt；每项文字区 28×20pt + 分割线 14pt 间距

---

## 5. 尺寸规格（@2x / @1x 对照）

> **说明**：设计稿为 @2x（750px 基准），@1x = px÷2 = pt

### 5.1 图标文本型操作区

| 属性 | 值（@2x） | @1x | 说明 |
|------|---------|-----|------|
| 操作区高度 | **128px** | 64pt | 不含尖角 |
| 操作区圆角 | **16px** | 8pt | `radius-s` |
| 操作区背景 | `#000000CC` | — | 80%不透明黑，`mask-heavy` |
| 左右内边距 | **28px** | 14pt | padding-left / right |
| 上内边距 | **24px** | 12pt | padding-top |
| 下内边距 | **20px** | 10pt | padding-bottom |
| 操作项间距 | **56px** | 28pt | gap 之间 |
| 操作项整体 | **48×84px** | 24×42pt | 图标+文字组合尺寸（flex-column） |
| 图标尺寸 | **40×40px** | 20×20pt | 功能图标 |
| 图标与文字间距 | **12px** | 6pt | flex-column row-gap |
| 文字区域 | **48×32px** | 24×16pt | 文字宽×高 |

### 5.2 文本型操作区

| 属性 | 值（@2x） | @1x | 说明 |
|------|---------|-----|------|
| 操作区高度 | **80px** | 40pt | 不含尖角 |
| 操作区圆角 | **16px** | 8pt | `radius-s` |
| 操作区背景 | `#000000CC` | — | 80%不透明黑，`mask-heavy` |
| 左右内边距 | **28px** | 14pt | padding-left / right |
| 上下内边距 | **20px** | 10pt | padding-top / bottom |
| 文字项内间距 | **28px** | 14pt | gap（含分割线） |
| 文字区域 | **56×40px** | 28×20pt | 文字宽×高 |
| 分割线宽度 | **2px** | 1pt | 竖向分割线，宽 1pt × 高 13pt |

### 5.3 尖角

| 属性 | 值（@2x） | @1x | 说明 |
|------|---------|-----|------|
| 尖角宽度 | **32px** | 16pt | 三角形底边宽度 |
| 尖角高度 | **12px** | 6pt | 三角形高度 |
| 尖角颜色 | `#000000CC` | — | 与气泡背景一致 |
| 水平对齐 | 与操作区**居中** | — | 默认居中，可按需偏移 |

### 5.4 翻页箭头（省略展示模式）

| 属性 | 值（@2x） | @1x | 说明 |
|------|---------|-----|------|
| 箭头图标尺寸 | **28×28px** | 14×14pt | 代码实测 `.instance` `width: 28px; height: 28px` |
| 箭头与内容间距 | **28px** | 14pt | 同气泡 `column-gap`，箭头作为 flex 子项参与排列 |
| 左箭头 | `向左 / 返回` | — | 当前页为首页时 `opacity: 0.3`，不可点击 |
| 右箭头 | `向右` | — | 当前页为末页时 `opacity: 0.3`，不可点击 |

> **overflow 模式气泡宽度固定**：总宽 **672px（@2x） / 336pt（@1x）**，翻页时气泡宽度**不变**
> 宽度以**首屏（page 0）内容**自然撑开后锁定，之后各页内容在相同宽度内从左到右排列
>
> **首屏宽度验证（@2x，flexbox column-gap: 28px）**：
> `左箭头(28)` + `gap(28)` + `[含分割线文字项 84px × 4]` + `gap×4(28×4=112)` + `[末项 56px]` + `gap(28)` + `右箭头(28)` + `padding×2(56)` = **672px**
> 展示 5 个操作项（4 项含分割线 + 最末 1 项无分割线）

### 5.5 代码实测：文本型（text）组件集（@2x）

> 数据来源 1：full 模式组件集（`componentset` 839×1463px）
> 数据来源 2：overflow 模式组件集（`componentset` **839×691px**，含 arrowPosition=bottom @ top=138px 和 arrowPosition=top @ top=462px 两个变体）

**full 模式气泡宽度验证**

| displayMode | itemCount | 气泡宽度（@2x） | 气泡宽度（@1x） | 气泡容器高度（@2x） | 总高（@2x，含尖角） |
|-------------|-----------|--------------|--------------|----------------|----------------|
| `full` | 1 | **112px** | 56pt | 80px | 92px |
| `full` | 2 | **224px** | 112pt | 80px | 92px |
| `full` | 3 | **336px** | 168pt | 80px | 92px |
| `full` | 4 | **448px** | 224pt | 80px | 92px |
| `full` | 5 | **560px** | 280pt | 80px | 92px |
| `overflow` | >5 | **672px** | 336pt | 80px | 92px |

**气泡容器关键样式（代码实测，overflow 模式 .frame / .frame-13）**

```css
/* 气泡主容器（.frame / .frame-13）—— full 和 overflow 通用 */
width: 672px;                        /* overflow 模式固定宽，@1x = 336pt */
height: 80px;                        /* @1x = 40pt，不含尖角 */
border-radius: 16px;                 /* @1x = 8pt，radius-s */
border-radius: 16px;
background: rgba(0, 0, 0, 0.8);     /* #000000CC，mask-heavy */
 padding: 20px 28px 20px 28px;
display: flex;
flex-direction: row;
justify-content: center;
align-items: center;
column-gap: 28px;                   /* 子项间距（含箭头↔内容），@1x = 14pt */

/* 尖角容器（.frame-11 / .frame-12）—— 尖角所在行 */
align-self: stretch;
width: 672px;
height: 12px;                        /* 尖角高度，@1x = 6pt */
/* 注：.frame-11（尖角在下，位于气泡 flex-column 的第二行） */
/* 注：.frame-12（尖角在上，位于气泡 flex-column 的第一行） */

/* 文字项分组容器（.frame-1 ~ .frame-9，含分割线的文字项） */
width: 84px;   height: 40px;        /* 文字(56px) + gap(28px) + 分割线(2px) ≈ 84px 含 gap */
display: flex;
flex-direction: row;
justify-content: center;
align-items: center;
column-gap: 28px;                   /* 文字与下一项之间，已含于父级 gap */

/* 文字主体（.instance .frame-2 .text） */
width: 56px;   height: 40px;        /* @1x = 28×20pt */
white-space: nowrap;
font-family: "PingFang SC";
font-size: 28px;                    /* @1x = 14pt */
line-height: 40px;                  /* @1x = 20pt */
font-weight: 400;                   /* Regular */
color: #FFFFFF;

/* 分割线（.pen-1 ~ .pen-4，仅前4项有，末项无） */
width: 2px;    height: 26px;        /* @1x = 1×13pt */

/* 末项（.frame-9 / .frame-18，无分割线） */
width: 56px;   /* 无 .pen，仅文字主体 */

/* 翻页箭头（.instance / .instance-7 / .instance-11 / .instance-18） */
width: 28px;   height: 28px;        /* @1x = 14×14pt */
flex-shrink: 0;
```

**overflow 模式气泡内部布局（代码实测，@2x）**

```
气泡容器（.frame / .frame-13，672px 宽，padding: 20px 28px，column-gap: 28px）
├── [左翻页箭头]  .instance / .instance-11  — 28×28px，flex-shrink:0
├── [文字项+分割线] .frame-1~4 / .frame-14~17 × 4
│     各项内部：display:flex; row; column-gap:28px
│     ├── 文字主体  .instance-2~5  56×40px
│     └── 分割线    .pen-1~4       2×26px
├── [末项-无分割线] .frame-9 / .frame-18  56×40px（仅文字，无 .pen）
└── [右翻页箭头]  .instance-7 / .instance-18  — 28×28px，flex-shrink:0

宽度验证（flexbox，column-gap: 28px，7个子项）：
  flex items：左箭头(28) + 含分割线项×4(84 each) + 末项(56) + 右箭头(28)
            = 28 + 336 + 56 + 28 = 448px
  gaps：(7 - 1) × 28 = 168px
  padding：28 × 2 = 56px
  总宽：448 + 168 + 56 = 672px ✓

两个 arrowPosition 变体（组件集坐标）：
  arrowPosition=bottom（气泡在文本上方）：.component  @ top:138px — 尖角容器 .frame-11 在气泡下方
  arrowPosition=top   （气泡在文本下方）：.component-1 @ top:462px — 尖角容器 .frame-12 在气泡上方
```

### 5.6 代码实测：图标文本型（icon-text）组件集（@2x）

> 数据来源：full 模式组件集（`componentset` 839×1665px）

**full 模式气泡宽度验证**

| displayMode | itemCount | 气泡宽度（@2x） | 气泡宽度（@1x） | 气泡容器高度（@2x） | 总高（@2x，含尖角） |
|-------------|-----------|--------------|--------------|----------------|----------------|
| `full` | 2 | **208px** | 104pt | 128px | 140px |
| `full` | 3 | **312px** | 156pt | 128px | 140px |
| `full` | 4 | **416px** | 208pt | 128px | 140px |
| `full` | 5 | **520px** | 260pt | 128px | 140px |

**气泡容器关键样式（代码实测）**

```css
/* 气泡主容器（.frame） */
height: 128px;                       /* @1x = 64pt，不含尖角 */
border-radius: 16px;                 /* @1x = 8pt，radius-s */
background: rgba(0, 0, 0, 0.8);     /* #000000CC，mask-heavy */
padding: 24px 28px 20px 28px;       /* 上 12pt / 左右 14pt / 下 10pt */
column-gap: 56px;                   /* 操作项间距，@1x = 28pt */

/* 尖角（arrow） */
/* 尖角高度 = 总高 140px - 容器高 128px = 12px（@1x = 6pt） */

/* 操作项整体（.instance） */
width: 48px;   height: 84px;        /* @1x = 24×42pt */
flex-direction: column;
row-gap: 12px;                      /* 图标与文字间距，@1x = 6pt */

/* 图标（.instance-1） */
width: 40px;   height: 40px;        /* @1x = 20×20pt */

/* 文字（.text） */
width: 48px;   height: 32px;        /* @1x = 24×16pt */
font-family: "PingFang SC";
font-size: 24px;                    /* @1x = 12pt */
line-height: 32px;                  /* @1x = 16pt */
font-weight: 400;                   /* Regular */
color: #FFFFFF;
```

**full 模式宽度推导（flexbox，column-gap: 56px）**

```
以 5 项为例（520px）:
  flex items: 操作项宽度(48) × 5 = 240px
  gaps: (5-1) × 56 = 224px
  padding: 28 × 2 = 56px
  总宽: 240 + 224 + 56 = 520px ✓

以 2 项为例（208px）:
  flex items: 48 × 2 = 96px
  gaps: 1 × 56 = 56px
  padding: 56px
  总宽: 96 + 56 + 56 = 208px ✓
```

---

## 6. Token 引用

### 6.1 颜色 Token

| 用途 | Token 名称 | 值 | 语义层来源 |
|------|-----------|-----|-----------|
| 气泡背景 / 尖角颜色 | `mask-heavy` | `#000000CC`（80%黑） | `color-semantic.md` §六 Mask |
| 操作文字色 | `white` | `#FFFFFF` | `color-semantic.md` §一 |
| 操作图标色 | `white` | `#FFFFFF` | `color-semantic.md` §一 |
| 分割线色 | `divider-secondary-dark` | `#FFFFFF26`（White-Opacity-15） | `color-semantic.md` §五 Divider |
| 翻页箭头色 | `white` | `#FFFFFF` | `color-semantic.md` §一 |

### 6.2 字体 Token

| 用途 | Token 名称 | 字号 @2x | 行高 @2x | 字重 |
|------|-----------|---------|---------|------|
| 图标文本型文字 | `caption-l-24-regular` | 12pt | 16pt | 400（Regular） |
| 文本型操作文字 | `body-s-28-regular` | 14pt | 20pt | 400（Regular） |

> **注**：图标文本型文字宽度固定 24pt，单行展示；文本型文字区域固定 28×20pt。
> **代码实测（@2x）**：`font-size: 28px; line-height: 40px; font-weight: 400; font-family: "PingFang SC"; color: #FFFFFF`

### 6.3 间距 Token

| 用途 | Token 名称 | 值（@2x） | @1x | Token 来源 |
|------|-----------|---------|-----|----------|
| 操作区左右内边距 | `cs-14` | 28px | 14pt | `component-spacing.md` |
| 图标文本型上内边距 | `spacing-l` | 24px | 12pt | `spacing-semantic.md` |
| 图标文本型下内边距 | `spacing-m` | 20px | 10pt | `spacing-semantic.md` |
| 文本型上下内边距 | `spacing-m` | 20px | 10pt | `spacing-semantic.md` |
| 图标文本型项间距 | `spacing-4xl` | 56px | 28pt | `spacing-semantic.md` |
| 文本型项间距 | `cs-14` | 28px | 14pt | `component-spacing.md` |
| 图标与文字间距 | `spacing-xs` | 12px | 6pt | `spacing-semantic.md` |

### 6.4 圆角 Token

| 用途 | Token 名称 | 值（@2x） | @1x | Token 来源 |
|------|-----------|---------|-----|----------|
| 操作区圆角 | `radius-s` | 16px | 8pt | `radius-semantic.md` |

---

## 7. 结构规格

### 7.1 图标文本型组件树

```
[TextEditMenu 根容器]                — flex-column，居中对齐
  ├── [顶部区域]（arrowPosition=top 时存在）
  │     └── [尖角] 16×6pt，三角形，向上，居中
  ├── [操作区] `radius-s`（8pt），`mask-heavy`，padding: `spacing-l` `cs-14` `spacing-m` `cs-14`，gap: `spacing-4xl`
  │     ├── [左翻页箭头]（省略模式专有）14×14pt
  │     ├── [操作项 1] 24×42pt，flex-column，gap: `spacing-xs`（6pt）
  │     │     ├── [图标] 20×20pt
  │     │     └── [文字] 24×16pt，12pt，white
  │     ├── [操作项 2] 同上
  │     ├── ... （最多5项同时展示）
  │     └── [右翻页箭头]（省略模式专有）14×14pt
  └── [底部区域]（arrowPosition=bottom 时存在）
        └── [尖角] 16×6pt，三角形，向下，居中
```

### 7.2 文本型组件树

```
[TextEditMenu 根容器 / .component / .component-1]  — flex-column，居中对齐
  ├── [顶部尖角容器 / .frame-12]（arrowPosition=top 时展示）
  │     └── [尖角] 16×6pt，三角形，向上，居中，@2x 32×12px
  ├── [操作区 / .frame / .frame-13]
│     — radius-s(8pt)，`mask-heavy`，padding: `spacing-m` `cs-14`
│     — display:flex; row; align-items:center; column-gap: `cs-14`
  │     ├── [左翻页箭头 / .instance / .instance-11]（省略模式专有）
  │     │     — 28×28px，flex-shrink:0，首页时 opacity:0.3、pointer-events:none
  │     ├── [含分割线文字项分组 / .frame-1~4 / .frame-14~17] ×4
  │     │     — display:flex; row; column-gap:28px
  │     │     ├── [文字 / .text]  56×40px，28px/Regular/#FFFFFF
  │     │     └── [分割线 / .pen]  2×26px，白色透明
  │     ├── [末项-无分割线 / .frame-9 / .frame-18] ×1
  │     │     — 56×40px，仅文字，无 .pen
  │     └── [右翻页箭头 / .instance-7 / .instance-18]（省略模式专有）
  │           — 28×28px，flex-shrink:0，末页时 opacity:0.3、pointer-events:none
  └── [底部尖角容器 / .frame-11]（arrowPosition=bottom 时展示）
        └── [尖角] 16×6pt，三角形，向下，居中，@2x 32×12px
```

### 7.3 分割线规则（文本型）

- 每个文字项右侧有分割线（竖线，宽 **1pt** × 高 **13pt**，代码实测 `.pen` `width: 2px; height: 26px` @2x）
- **最后一个**操作项无分割线（组件中用 `.frame-9` / `.frame-18` 表示末项，仅含 `.text`，无 `.pen`）
- 省略模式时，左右翻页箭头之间的操作项分割线保持不变
- 翻页箭头作为普通 flex 子项，与内容项共享 `column-gap: 28px`（不需额外 margin）
- 气泡宽度**始终不随翻页变化**：以首屏内容自然撑宽后锁定，第二屏内容在相同宽度内从左对齐排列

---

## 8. 交互规则

### 8.1 触发与消失

| 行为 | 说明 |
|------|------|
| **触发** | 用户**长按**文本区域，文本被选中后自动弹出 |
| **消失** | 用户点击某个操作项执行操作后消失；点击气泡外区域消失 |
| **位置** | 默认弹出在被选文本**上方**；上方空间不足时自动翻转至下方 |
| **居中** | 气泡水平居中对齐于被选文本，但需与屏幕左右边缘保持安全距离 |

### 8.2 省略展示翻页逻辑

- 超过 5 个操作项时启用省略模式，左右箭头控制翻页
- 每次翻页显示不同的操作项子集（每次展示最多5项）
- 翻到最左页（page 0）时，左箭头 `opacity: 0.3` 且 `pointer-events: none`（不可点击）
- 翻到最右页时，右箭头 `opacity: 0.3` 且 `pointer-events: none`
- 翻页切换效果：通过 `opacity` 淡入淡出（推荐 0.2s ease），气泡宽度不变
- 支持触摸左右滑动（`threshold ≥ 40px`）和鼠标拖拽切换页

### 8.3 位置自适应

- 气泡与屏幕左右边缘最小距离 ≥ **8pt**（设计稿 16px @2x）
- 气泡靠近屏幕边缘时整体平移，尖角保持指向被选文本方向的中心

---

## 9. Props API（供 AI 生码参考）

```typescript
export type TextEditMenuProps = {
  /**
   * 菜单类型
   * @default "icon-text"
   */
  type: "icon-text" | "text";

  /**
   * 尖角位置（上/下）
   * @default "bottom"
   */
  arrowPosition?: "top" | "bottom";

  /**
   * 操作项列表（1~5 项直接展示；超过 5 项自动启用省略模式）
   */
  items: TextEditMenuItem[];

  /**
   * 点击操作项的回调
   */
  onItemPress?: (item: TextEditMenuItem, index: number) => void;

  /**
   * 当前页索引（省略模式下，用于翻页状态）
   * @default 0
   */
  pageIndex?: number;

  /**
   * 翻页回调（省略模式下翻页时触发）
   */
  onPageChange?: (pageIndex: number) => void;
};

export type TextEditMenuItem = {
  /**
   * 图标节点（仅 type="icon-text" 时有效，40×40pt 大小）
   */
  icon?: React.ReactNode;

  /**
   * 操作文字（必填）
   */
  label: string;

  /**
   * 唯一标识
   */
  key: string;

  /**
   * 是否禁用
   */
  disabled?: boolean;
};
```

---

## 10. data-attribute 规范

| 属性 | 值 | 说明 |
|------|----|------|
| `data-slot` | `"text-edit-menu"` | 组件根容器 |
| `data-slot` | `"text-edit-menu-arrow"` | 尖角 |
| `data-slot` | `"text-edit-menu-content"` | 操作区 |
| `data-slot` | `"text-edit-menu-item"` | 单个操作项 |
| `data-slot` | `"text-edit-menu-icon"` | 操作项图标（图标文本型） |
| `data-slot` | `"text-edit-menu-label"` | 操作项文字 |
| `data-slot` | `"text-edit-menu-divider"` | 分割线（文本型） |
| `data-slot` | `"text-edit-menu-prev"` | 左翻页箭头（省略模式） |
| `data-slot` | `"text-edit-menu-next"` | 右翻页箭头（省略模式） |
| `data-type` | `"icon-text"` / `"text"` | 菜单类型 |
| `data-variant` | `"icon-text-full"` / `"icon-text-overflow"` / `"text-full"` / `"text-overflow"` | 组件变体（type + displayMode 组合） |
| `data-arrow-position` | `"top"` / `"bottom"` | 尖角位置 |
| `data-display-mode` | `"full"` / `"overflow"` | 展示模式 |
| `data-state` | `"default"` / `"disabled"` | 操作项状态 |

---

## 11. 无障碍（Accessibility）

- 气泡根容器：`role="menu"`
- 操作项：`role="menuitem"`
- 禁用项：`aria-disabled="true"`
- 左右翻页箭头：`aria-label="上一页操作"` / `aria-label="下一页操作"`，不可用时 `aria-disabled="true"`
- 尖角：`aria-hidden="true"`（装饰性）
- 键盘交互：
  - `ArrowLeft` / `ArrowRight`：在操作项间移动焦点
  - `Enter` / `Space`：执行当前操作
  - `Escape`：关闭气泡

---

## 12. 变体矩阵（完整 MECE）

### 12.1 图标文本型（icon-text）

| type | displayMode | itemCount | arrowPosition | 操作区宽度（@2x） | 整体高度（@2x） |
|------|-------------|-----------|--------------|----------------|--------------|
| `icon-text` | `full` | 2 | `top` | 104pt | 70pt |
| `icon-text` | `full` | 2 | `bottom` | 104pt | 70pt |
| `icon-text` | `full` | 3 | `top` | 156pt | 70pt |
| `icon-text` | `full` | 3 | `bottom` | 156pt | 70pt |
| `icon-text` | `full` | 4 | `top` | 208pt | 70pt |
| `icon-text` | `full` | 4 | `bottom` | 208pt | 70pt |
| `icon-text` | `full` | 5 | `top` | 260pt | 70pt |
| `icon-text` | `full` | 5 | `bottom` | 260pt | 70pt |
| `icon-text` | `overflow` | >5 | `top` | 344pt | 70pt |
| `icon-text` | `overflow` | >5 | `bottom` | 344pt | 70pt |

### 12.2 文本型（text）

| type | displayMode | itemCount | arrowPosition | 操作区宽度（@2x） | 整体高度（@2x） |
|------|-------------|-----------|--------------|----------------|--------------|
| `text` | `full` | 1 | `top` | 56pt | 46pt |
| `text` | `full` | 1 | `bottom` | 56pt | 46pt |
| `text` | `full` | 2 | `top` | 112pt | 46pt |
| `text` | `full` | 2 | `bottom` | 112pt | 46pt |
| `text` | `full` | 3 | `top` | 168pt | 46pt |
| `text` | `full` | 3 | `bottom` | 168pt | 46pt |
| `text` | `full` | 4 | `top` | 224pt | 46pt |
| `text` | `full` | 4 | `bottom` | 224pt | 46pt |
| `text` | `full` | 5 | `top` | 280pt | 46pt |
| `text` | `full` | 5 | `bottom` | 280pt | 46pt |
| `text` | `overflow` | >5 | `top` | 336pt | 46pt |
| `text` | `overflow` | >5 | `bottom` | 336pt | 46pt |

---

## 13. 使用约束

### 13.1 与 Popover 的区别

| 维度 | Text Edit Menu | Popover 气泡浮层 |
|------|---------------|----------------|
| **触发方式** | 用户**长按文本**自动弹出（系统行为） | 用户**点击/长按按钮**触发 |
| **内容类型** | 文本编辑操作（复制/粘贴/全选等） | 菜单式功能操作列表 |
| **布局方向** | **横向**排列（操作项水平展开） | **纵向**排列（操作项垂直堆叠） |
| **图标** | 可选（图标文本型 / 纯文字型） | 必须有图标 |
| **背景主题** | 仅深色（无浅色版本） | 浅色 / 深色两种 |

### 13.2 使用建议

- **系统原生文本操作**（复制/粘贴/全选/查找）→ 使用 `text`（文本型）
- **富文本编辑操作**（加粗/斜体/链接等需要图标区分的操作）→ 使用 `icon-text`（图标文本型）
- **操作项数量建议 ≤ 5**；超过时可考虑是否合并或降低频率低的操作
- **不推荐**将非文本操作放入 TextEditMenu，应使用 Popover 替代

### 13.3 常见组合示例

```
// 场景 1：原生文本选择（复制/粘贴/全选/查词典）
<TextEditMenu
  type="text"
  arrowPosition="bottom"
  items={[
    { key: "copy", label: "复制" },
    { key: "paste", label: "粘贴" },
    { key: "select-all", label: "全选" },
    { key: "lookup", label: "查词典" },
  ]}
/>

// 场景 2：富文本编辑（加粗/斜体/链接/颜色，超过5项省略模式）
<TextEditMenu
  type="icon-text"
  arrowPosition="bottom"
  items={[
    { key: "bold", label: "加粗", icon: <BoldIcon /> },
    { key: "italic", label: "斜体", icon: <ItalicIcon /> },
    { key: "link", label: "链接", icon: <LinkIcon /> },
    { key: "color", label: "颜色", icon: <ColorIcon /> },
    { key: "clear", label: "清除", icon: <ClearIcon /> },
    { key: "comment", label: "评论", icon: <CommentIcon /> },
  ]}
  // 自动进入省略模式（6项 > 5）
/>
```

---

## 14. 与其他组件的关系

| 关联组件 | 关系说明 |
|----------|----------|
| `popover` | 同为浮层气泡，TextEditMenu 针对文本操作（横向布局），Popover 针对功能操作（纵向布局） |
| `tooltip` | 同为系统触发的浮层，TextEditMenu 面向操作，Tooltip 面向引导说明 |
| `navigation` | 长按文本时导航栏通常不受影响 |
