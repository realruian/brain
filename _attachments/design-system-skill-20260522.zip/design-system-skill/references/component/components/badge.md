# Badge 徽标 - 组件规范

> **组件分类**：Component（组件级）
> **定义**：徽标用于对元素进行标注，提示用户有新消息、待办项或营销利益点，常叠加于图标、头像、列表等宿主元素的右上角或右下角。

---

## 0. 图标 / 间距 / Ownership 约束

- **icon-route（默认）**：本组件内功能图标默认回 `component/atoms/icon.md`，并沿用本文件已声明的 iconfont class / weight。
- **fixed-asset 例外**：若正文已指定 `assets/*.svg`、官方 SVG、PNG/CDN 切图、URL 尖角资源或固定插画，该位点必须走固定资产，不得强行回 iconfont；输出时可标注 `icon-route=fixed-asset`。
- **spacing-owner（归属）**：组件内部 slot、行内/容器内 gap、padding、对齐归本组件；页面边距、吸顶/吸底占位、列表外层留白归宿主。
- **宿主裁决（优先级）**：冲突遵循 `宿主 > 组合场景 > 本组件通用规则`，子组件仅拥有自身内部样式，不反向改宿主排布。
- **不可跳步**：先回 `references/INDEX.md` 完成区域路由与宿主锁定，再用 `component-quickref.md` 做宿主级收敛；本文件仅承接组件内 ownership 细则，不承担前置路由改判；不得凭语义猜测。

## 1. 组件类型（type）

| type | 名称 | 用途 | 变体数 |
|------|------|------|--------|
| `dot` | 红点 | 弱提示，无数字，仅表示"有更新" | 2 |
| `number` | 数字徽标 | 显示具体数量（1~99+），功能型提醒 | 18 |
| `text` | 文字徽标 | 显示自定义文字，运营/营销场景 | 6 |

---

## 2. 尺寸规格（size）

### 2.1 红点（type=dot）

| size | 名称 | 直径 | 圆角 Token |
|------|------|------|-----------|
| `standard` | 标准 | 6pt | `radius-full` |
| `large` | 大号 | 8pt | `radius-full` |

### 2.2 数字徽标（type=number）

| size | 名称 | 高度 | 单数(1位)宽 | 双数(2位)宽 | 上限(99+)宽 | 水平内边距 | 圆角（无尖角） | 圆角（有尖角，tip=true） |
|------|------|------|-----------|-----------|-----------|----------|--------------|----------------------|
| `small` | 小号 | 12pt | 12pt | 20pt | 26.5pt | `cs-5`（单数）/ `cs-4`（双/99+） | `cr-6` | `cr-6 cr-6 cr-6 cr-1` |
| `standard` | 标准 | 14pt | 14pt | 20pt | 26.5pt | `cs-4.5`（单数）/ `cs-4`（双/99+） | `cr-7` | `cr-7 cr-7 cr-7 cr-1` |
| `large` | 大号 | 16pt | 16pt | 21.5pt | 28pt | `cs-3.5`（单数）/ `cs-4`（双/99+） | `cr-8` | `cr-8 cr-8 cr-8 cr-1` |

> **圆角换算说明（来源：2倍图÷2，Token 来源：`component-radius.md`）**
> - `small`（2x: 12px）= 6pt = `cr-6`
> - `standard`（2x: 14px）= 7pt = `cr-7`
> - `large`（2x: 16px）= 8pt = `cr-8`
> - 有尖角时左下角固定为 1pt（2x: 2px）= `cr-1`
> - `99+` 变体圆角实现为 `radius-full`（`border-radius: 9999px`，确保完全胶囊形）

### 2.3 数字徽标详细像素规格（2倍图实测值）

| size | tip | 字数类型 | 2x尺寸(w×h) | 2x圆角 | 2x水平padding | 2x字号 | 2x行高 | 描边层类型 |
|------|-----|---------|------------|--------|-------------|--------|--------|----------|
| `small` | `false` | 单数(1位) | 24×24px | 12px（`cr-6`×2） | 10px（`cs-5`×2） | 20px | 28px | RECTANGLE（2px white border） |
| `small` | `false` | 双数(2位) | 40×24px | 12px（`cr-6`×2） | 8px（`cs-4`×2） | 20px | 28px | RECTANGLE（2px white border） |
| `small` | `false` | 上限(99+) | 53×24px | `radius-full` | 8px（`cs-4`×2） | 20px | 28px | RECTANGLE（2px white border） |
| `small` | `true` | 单数(1位) | 24×24px | 12px 12px 12px 2px（`cr-6 cr-6 cr-6 cr-1`×2） | 8px（`cs-4`×2） | 20px | 28px | RECTANGLE（2px white border） |
| `small` | `true` | 双数(2位) | 40×24px | 12px 12px 12px 2px（`cr-6 cr-6 cr-6 cr-1`×2） | 8px（`cs-4`×2） | 20px | 28px | RECTANGLE（2px white border） |
| `small` | `true` | 上限(99+) | 53×24px | 12px 12px 12px 2px（`cr-6 cr-6 cr-6 cr-1`×2） | 8px（`cs-4`×2） | 20px | 28px | RECTANGLE（2px white border） |
| `standard` | `false` | 单数(1位) | 28×28px | 14px（`cr-7`×2） | 9px（`cs-4.5`×2） | 20px | 28px | RECTANGLE（2px white border） |
| `standard` | `false` | 双数(2位) | 40×28px | 14px（`cr-7`×2） | 8px（`cs-4`×2） | 20px | 28px | RECTANGLE（2px white border） |
| `standard` | `false` | 上限(99+) | 53×28px | `radius-full` | 8px（`cs-4`×2） | 20px | 28px | RECTANGLE（2px white border） |
| `standard` | `true` | 单数(1位) | 28×28px | 14px 14px 14px 2px（`cr-7 cr-7 cr-7 cr-1`×2） | 8px（`cs-4`×2） | 20px | 28px | RECTANGLE（2px white border） |
| `standard` | `true` | 双数(2位) | 40×28px | 14px 14px 14px 2px（`cr-7 cr-7 cr-7 cr-1`×2） | 8px（`cs-4`×2） | 20px | 28px | RECTANGLE（2px white border） |
| `standard` | `true` | 上限(99+) | 53×28px | 14px 14px 14px 2px（`cr-7 cr-7 cr-7 cr-1`×2） | 8px（`cs-4`×2） | 20px | 28px | RECTANGLE（2px white border） |
| `large` | `false` | 单数(1位) | 32×32px | 16px（`cr-8`×2） | 7px（`cs-3.5`×2） | 22px | 32px | RECTANGLE（2px white border） |
| `large` | `false` | 双数(2位) | 43×32px | `radius-full` | 8px（`cs-4`×2） | 22px | 32px | RECTANGLE（2px white border） |
| `large` | `false` | 上限(99+) | 56×32px | `radius-full` | 8px（`cs-4`×2） | 22px | 32px | RECTANGLE（2px white border） |
| `large` | `true` | 单数(1位) | 32×32px | 16px 16px 16px 2px（`cr-8 cr-8 cr-8 cr-1`×2） | 9px（`cs-4.5`×2） | 22px | 32px | RECTANGLE（2px white border） |
| `large` | `true` | 双数(2位) | 43×32px | 16px 16px 16px 2px（`cr-8 cr-8 cr-8 cr-1`×2） | 8px（`cs-4`×2） | 22px | 32px | RECTANGLE（2px white border） |
| `large` | `true` | 上限(99+) | 56×32px | 16px 16px 16px 2px（`cr-8 cr-8 cr-8 cr-1`×2） | 8px（`cs-4`×2） | 22px | 32px | RECTANGLE（2px white border） |

### 2.4 文字徽标（type=text）

| size | 名称 | 高度 | 宽度（约） | 水平内边距 | 字体 Token / 字号 | 2x字号 / 行高 | 圆角（无尖角） | 圆角（有尖角） |
|------|------|------|-----------|----------|-----------|-------------|--------------|--------------|
| `small` | 小号 | 12pt | 26pt | `cs-4` | 18px / 9pt | 18px / 24px | `cr-6` | `cr-6 cr-6 cr-6 cr-1` |
| `standard` | 标准 | 14pt | 28pt | `cs-4` | `caption-s-20-medium` | 20px / 28px | `cr-7` | `cr-7 cr-7 cr-7 cr-1` |
| `large` | 大号 | 16pt | 32pt | `cs-5` | `caption-l-22-medium` | 22px / 32px | `cr-8` | `cr-8 cr-8 cr-8 cr-1` |

> **文字徽标圆角说明（来源：2倍图÷2，Token 来源：`component-radius.md`）**
> - `small`（2x: 12px）= 6pt = `cr-6`；有尖角时 `cr-6 cr-6 cr-6 cr-1`
> - `standard`（2x: 14px）= 7pt = `cr-7`；有尖角时 `cr-7 cr-7 cr-7 cr-1`
> - `large`（2x: 16px）= 8pt = `cr-8`；有尖角时 `cr-8 cr-8 cr-8 cr-1`
> - `large` tip=false 的描边层圆角使用 `radius-full`（胶囊形），容器本身保持 `cr-8`

### 2.5 文字徽标详细像素规格（2倍图实测值）

| size | tip | 2x尺寸(w×h) | 2x容器圆角 | 2x描边层圆角 | 2x水平padding | 2x字号 | 2x行高 | 描边层类型 |
|------|-----|------------|----------|------------|-------------|--------|--------|----------|
| `small` | `false` | 52×24px | 12px（`cr-6`×2） | 12px（`cr-6`×2） | 8px（`cs-4`×2） | 18px | 24px | RECTANGLE（2px white border） |
| `small` | `true` | 52×24px | 12px 12px 12px 2px（`cr-6 cr-6 cr-6 cr-1`×2） | 12px 12px 12px 2px（`cr-6 cr-6 cr-6 cr-1`×2） | 8px（`cs-4`×2） | 18px | 24px | RECTANGLE（2px white border） |
| `standard` | `false` | 56×28px | 14px（`cr-7`×2） | 14px（`cr-7`×2） | 8px（`cs-4`×2） | 20px | 28px | RECTANGLE（2px white border） |
| `standard` | `true` | 56×28px | 14px 14px 14px 2px（`cr-7 cr-7 cr-7 cr-1`×2） | 14px 14px 14px 2px（`cr-7 cr-7 cr-7 cr-1`×2） | 8px（`cs-4`×2） | 20px | 28px | RECTANGLE（2px white border） |
| `large` | `false` | 64×32px | 16px（`cr-8`×2） | `radius-full` | 10px（`cs-5`×2） | 22px | 32px | RECTANGLE（2px white border） |
| `large` | `true` | 64×32px | 16px 16px 16px 2px（`cr-8 cr-8 cr-8 cr-1`×2） | 16px 16px 16px 2px（`cr-8 cr-8 cr-8 cr-1`×2） | 10px（`cs-5`×2） | 22px | 32px | RECTANGLE（2px white border） |

---

## 3. 状态与变体

### 3.1 尖角（tip）

| tip | 说明 | 圆角实现 |
|-----|------|---------|
| `false`（默认） | 无尖角，标准圆角胶囊 | `border-radius: R` |
| `true` | 左下尖角，贴合宿主元素右上角时使用 | `border-radius: R R R 2px` |

### 3.2 完整变体矩阵

**数字徽标（18 个变体）**

| size | 字数类型 | tip | 尺寸(w×h) | Figma objectId |
|------|---------|-----|-----------|----------------|
| `small` | 单数(1位) | `false` | 12×12pt | `84441:44068` |
| `small` | 双数(2位) | `false` | 20×12pt | `84441:44062` |
| `small` | 上限(99+) | `false` | 26.5×12pt | `84441:44074` |
| `small` | 单数(1位) | `true` | 12×12pt | `84441:44080` |
| `small` | 双数(2位) | `true` | 20×12pt | `84441:44086` |
| `small` | 上限(99+) | `true` | 26.5×12pt | `84441:44092` |
| `standard` | 单数(1位) | `false` | 14×14pt | `80438:43037` |
| `standard` | 双数(2位) | `false` | 20×14pt | `80438:43310` |
| `standard` | 上限(99+) | `false` | 26.5×14pt | `80438:42865` |
| `standard` | 单数(1位) | `true` | 14×14pt | `80438:42880` |
| `standard` | 双数(2位) | `true` | 20×14pt | `80438:42875` |
| `standard` | 上限(99+) | `true` | 26.5×14pt | `80438:42971` |
| `large` | 单数(1位) | `false` | 16×16pt | `80438:42870` |
| `large` | 双数(2位) | `false` | 21.5×16pt | `80438:43403` |
| `large` | 上限(99+) | `false` | 28×16pt | `80438:43150` |
| `large` | 单数(1位) | `true` | 16×16pt | `80438:42890` |
| `large` | 双数(2位) | `true` | 21.5×16pt | `80438:42924` |
| `large` | 上限(99+) | `true` | 28×16pt | `80438:42885` |

**文字徽标（6 个变体）**

| size | tip | 尺寸(w×h) | Figma objectId |
|------|-----|-----------|----------------|
| `small` | `false` | 26×12pt | `80438:42956` |
| `small` | `true` | 26×12pt | `80438:42929` |
| `standard` | `false` | 28×14pt | `80438:42951` |
| `standard` | `true` | 28×14pt | `80438:42855` |
| `large` | `false` | 32×16pt | `80438:42914` |
| `large` | `true` | 32×16pt | `80438:42919` |

---

## 4. 布局结构

```
Badge
├── [type=dot]
│   └── ELLIPSE 圆（直径 6/8pt，background: red-default，radius-full）
│
├── [type=number]
│   └── FRAME 容器
│       ├── display: flex / flex-direction: column
│       ├── justify-content: center / align-items: center
│       ├── background: red-default
│       ├── padding: 0 [水平内边距]（左右相等）
│       ├── TEXT 数字内容（color: white，font-weight: 500）
│       └── 描边覆盖层（position: absolute，inset: 0）
│           └── 所有变体            → RECTANGLE（border: 2px solid white，与容器同圆角）
│
└── [type=text]
    └── FRAME 容器
        ├── display: flex / flex-direction: column
        ├── justify-content: center / align-items: center
        ├── background: red-default
        ├── padding: 0 `cs-4`（small/standard）/ 0 `cs-5`（large）
        ├── TEXT 文字内容（color: white，font-weight: 500）
        └── 描边覆盖层（position: absolute，inset: 0）
            └── 所有变体        → RECTANGLE（border: 2px solid white，与容器同圆角；`large tip=false` 描边层圆角为 `radius-full`）
```

**描边层实现规则**：
- 描边为**外描边**，不占用容器内部空间，不影响容器尺寸
- 描边层使用 `position: absolute` 绝对定位，四边向外偏移描边宽度（`top/left/right/bottom: -2px`，2x），与容器边缘保持一致的外扩距离
- 2倍图下描边宽度均为 `2px`（换算1x = **1pt**），颜色为 `white`
- **所有 `text` 变体**（含 `small tip=true`）：均使用 RECTANGLE + `border: 2px solid white`，描边层圆角与容器保持视觉一致
- **`text` large + tip=false**：描边层圆角为 `radius-full`（`9999px`，胶囊），容器圆角保持 `cr-8`
- `box-sizing: border-box`；描边层通过 `top/left/right/bottom: -2px` 实现外扩，容器本身不设任何 border
- **圆角补偿规则**：覆盖层四边向外偏移 2px，圆角值须在容器圆角基础上 **+2px**，确保外描边圆角与容器圆角视觉吻合（如容器 `border-radius: 12px` → 覆盖层 `border-radius: 14px`；尖角左下角 `2px` → 覆盖层左下角 `4px`；`radius-full` 保持 `9999px` 不变）

---

## 5. Props API

```typescript
export type BadgeProps = {
  /**
   * 徽标类型
   * @default "number"
   */
  type?: "dot" | "number" | "text";

  /**
   * 尺寸档位（dot 仅支持 standard/large）
   * @default "standard"
   */
  size?: "small" | "standard" | "large";

  /**
   * 显示数字（type=number 时有效，>99 自动展示"99+"）
   */
  count?: number;

  /**
   * 最大显示数（超出则展示"maxCount+"）
   * @default 99
   */
  maxCount?: number;

  /**
   * 是否显示左下尖角（贴合宿主元素角落时使用）
   * @default false
   */
  tip?: boolean;

  /**
   * 徽标文字内容（type=text 时有效，推荐 2~4 字）
   */
  children?: string;
};
```

---

## 6. data-attribute 规范

| 属性 | 值 | 说明 |
|------|----|------|
| `data-slot` | `"badge"` | 全局稳定标识，供父组件 CSS 定向选中 |
| `data-type` | `"dot"` / `"number"` / `"text"` | 徽标类型 |
| `data-size` | `"small"` / `"standard"` / `"large"` | 尺寸档位 |
| `data-tip` | `"true"` / `"false"` | 是否有左下尖角 |

---

## 7. Token 引用

### 7.1 颜色 Token

| 用途 | Token 名称 | 实测值（2x） | 语义层来源 |
|------|-----------|------------|-----------|
| 徽标背景（红色品牌色） | `red-default` | `#FF2D19` | `color-semantic.md` §七 Functional Color |
| 数字/文字颜色 | `white` | `#FFFFFF` | `color-semantic.md` §一 Neutral Color |
| 外描边（1pt，白色） | `white` | `#FFFFFF`，2px（2x）/ 1pt（1x） | `color-semantic.md` §一 Neutral Color |

### 7.2 圆角 Token

| 用途 | Token 名称 | 实测值（1x） | 有尖角时左下角 | 语义层来源 |
|------|-----------|------------|--------------|-----------|
| 红点全圆 | `radius-full` | 全圆 | — | `component-radius.md` |
| `small` 徽标圆角 | `cr-6` | 6pt（2x: 12px） | `cr-1`（1pt / 2x: 2px） | `component-radius.md` |
| `standard` 徽标圆角 | `cr-7` | 7pt（2x: 14px） | `cr-1`（1pt / 2x: 2px） | `component-radius.md` |
| `large` 徽标圆角 | `cr-8` | 8pt（2x: 16px） | `cr-1`（1pt / 2x: 2px） | `component-radius.md` |
| `text` `large` tip=false 描边层 | `radius-full` | `border-radius: 9999px` | — | `component-radius.md`（描边层胶囊形，容器本身仍为 `cr-8`） |
| `99+` 数字变体（胶囊） | `radius-full` | `border-radius: 9999px` | — | `component-radius.md`（确保完全胶囊形） |

### 7.3 字体 Token

| type / size | Token 名称 | 2x 字号 | 1x 字号 | 2x 行高 | 1x 行高 | 字重 | 字族 | 语义层来源 |
|-------------|-----------|--------|--------|--------|--------|------|------|-----------|
| `number` small | `caption-s-20-medium` | 20px | 10pt | 28px | 14pt | 500 | PingFang SC | `font-semantic.md` §一 Caption |
| `number` standard | `caption-s-20-medium` | 20px | 10pt | 28px | 14pt | 500 | PingFang SC | `font-semantic.md` §一 Caption |
| `number` large | `caption-l-22-medium` | 22px | 11pt | 32px | 16pt | 500 | PingFang SC | `font-semantic.md` §一 Caption |
| `text` small | — | 18px | 9pt | 24px | 12pt | 500 | PingFang SC | — |
| `text` standard | `caption-s-20-medium` | 20px | 10pt | 28px | 14pt | 500 | PingFang SC | `font-semantic.md` §一 Caption |
| `text` large | `caption-l-22-medium` | 22px | 11pt | 32px | 16pt | 500 | PingFang SC | `font-semantic.md` §一 Caption |

---

## 8. 无障碍（Accessibility）

- 徽标本身为装饰性元素，添加 `aria-hidden="true"` 隐藏
- 宿主元素（图标/按钮）通过 `aria-label` 将数量语义传达给辅助技术，如 `aria-label="消息，9条未读"`
- 不使用原生 `<span>` 以外的语义标签（避免 screen reader 读出多余信息）

---

## 9. 使用约束（AI 生成时的硬性规则）

1. **禁止直接写 hex 颜色**：颜色必须使用 §7.1 中的 Token 名称（背景 `red-default`，文字/描边 `white`）
2. **禁止自定义尺寸**：只能从 §2 表格中选取 size，不能自定义 `width`/`height`
3. **数字超过 maxCount 时**：自动截断显示为 `"99+"` 形式，不允许展示 3 位及以上数字
4. **营销型徽标（text）限制**：同屏最多展示 2 个，不得与功能型（number）同时滥用
5. **尖角使用场景**：仅当徽标需精准贴合宿主元素角落（如头像右上角）时开启 `tip=true`
6. **红点不承载数量信息**：需要显示数字时必须改用 `type="number"`
7. **描边实现方式**：白色描边为**外描边**，通过独立绝对定位覆盖层（RECTANGLE）实现，覆盖层设 `top/left/right/bottom: -2px`（2x）使描边完全在容器外侧；容器本身不设 `border`，`overflow: visible` 确保描边不被裁切
8. **所有数字徽标均有描边**：`type=number` 所有变体（含单数 tip=false）均使用 RECTANGLE 覆盖层，`border: 2px solid white`（2x）/ `1pt solid white`（1x）
9. **99+ 圆角写法**：`type=number` 99+ 变体圆角使用 `radius-full`（`border-radius: 9999px`，来源 `component-radius.md`）；`type=text` large tip=false 的描边层也使用 `radius-full`，确保跨平台完全胶囊形渲染
10. **文字徽标描边统一规则**：所有 `type=text` 变体（含 `small tip=true`）覆盖层均为 RECTANGLE（`border: 2px solid white`），描边层圆角与数字徽标规则一致（容器圆角 +2px；`radius-full` 保持不变）
11. **文字徽标 large 水平 padding**：large 尺寸 padding 为 `cs-5`（2x: 10px，来源 `component-spacing.md`），比 small/standard 的 `cs-4` 大一档
12. **描边默认开启规则（number / text）**：`type=number` 和 `type=text` 的描边**默认开启**。当徽标搭配**黑色线性图标**或**黑色文字**使用时，可不使用描边（省略描边覆盖层）。若用户明确指定使用或不使用描边，须**优先遵循用户指令**，不受默认规则约束。

---

## 10. 使用场景速查

| 场景 | type | size | tip | 说明 |
|------|------|------|-----|------|
| 功能图标（Tab/导航图标）弱提示 | `dot` | `standard` | — | 仅表示有更新 |
| 功能图标 消息数字提醒（1~99条） | `number` | `standard` | `false` | 通用场景 |
| 消息超过 99 条 | `number` | `standard` | `false` | 自动显示"99+" |
| 头像/列表 新消息，贴合角落 | `number` | `large` | `true` | 左下尖角贴合 |
| 更显眼的动态提示（大红点） | `dot` | `large` | — | 配合大元素使用 |
| 金刚图标旁 营销利益点 | `text` | `standard` | `true` | 尖角贴合图标 |
| 运营图标 功能更新 | `text` | `standard` | `false` | 不贴合时无尖角 |
| 密集列表 小徽标 | `text` | `small` | `false` | 空间紧凑场景 |

---

## 11. AI 决策树

```
用户说 "badge" / "徽标" / "未读数" / "消息提醒"
  ├── 只需一个小红点？→ type="dot"
  │     ├── 一般场景 → size="standard"（6×6pt）
  │     └── 更显眼   → size="large"（8×8pt）
  │
  ├── 需要显示数字？→ type="number"
  │     ├── 配合小图标 → size="small"（高12pt）
  │     ├── 通用场景   → size="standard"（高14pt）← 默认
  │     ├── 配合大元素 → size="large"（高16pt）
  │     ├── 数量 >99  → 自动显示"99+"
  │     └── 贴合宿主角落？→ tip=true
  │
  └── 需要显示文字？→ type="text"
        ├── 密集场景 → size="small"（高12pt）
        ├── 通用     → size="standard"（高14pt）← 默认
        ├── 大图/醒目 → size="large"（高16pt）
        └── 贴合宿主角落？→ tip=true

描边决策（number / text）：
  用户明确指定描边？
    ├── 是 → 遵循用户指令（使用或不使用）
    └── 否（默认）
          ├── 搭配黑色线性图标 或 黑色文字？→ 可不使用描边
          └── 其他场景                    → 默认开启描边（white 外描边）

颜色速查（均使用 Token，禁止写 hex）：
  背景色   → red-default
  文字色   → white
  外描边   → 2px solid white → 叠加宿主元素时保证可识别
```

---

## 12. 与其他组件的关系

| 关联组件 | 关系说明 |
|----------|----------|
| `bottom-navigation` | Tab 图标右上角常叠加数字徽标或红点 |
| `list` | 列表项头像/图标右上角可叠加徽标 |
| `icon` | 功能图标（如消息/购物车）右上角叠加徽标 |

---

## 13. 完整设计稿参考

- **印迹设计稿**：https://ingee.meituan.com/#/artboard/1414193/pos_t
- **imageId**：1414193
- **画布尺寸**：6705 × 15809
- **COMPONENT_SET objectId**：
  - 红点：`80438:38673`
  - 数字徽标：`80438:38608`
  - 文字徽标：`80438:38578`
