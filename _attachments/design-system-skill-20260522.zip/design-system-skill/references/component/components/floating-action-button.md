# Floating Action Button 悬浮按钮

> **组件分类**：Component（组件级）
> **定义**：悬浮按钮是悬浮在页面侧边位置，通常作为页面中不跟随页面上下滑动的重要常驻功能的快捷入口。
> **Style 依赖**：`color-semantic.md` · `font-semantic.md` · `component-spacing.md` · `component-radius.md` · `stroke-semantic.md`
---

## 0. 图标 / 间距 / Ownership 约束

- **icon-route（默认）**：本组件内功能图标默认回 `component/atoms/icon.md`，并沿用本文件已声明的 iconfont class / weight。
- **fixed-asset 例外**：若正文已指定 `assets/*.svg`、官方 SVG、PNG/CDN 切图、URL 尖角资源或固定插画，该位点必须走固定资产，不得强行回 iconfont；输出时可标注 `icon-route=fixed-asset`。
- **spacing-owner（归属）**：组件内部 slot、行内/容器内 gap、padding、对齐归本组件；页面边距、吸顶/吸底占位、列表外层留白归宿主。
- **宿主裁决（优先级）**：冲突遵循 `宿主 > 组合场景 > 本组件通用规则`，子组件仅拥有自身内部样式，不反向改宿主排布。
- **不可跳步**：先回 `references/INDEX.md` 完成区域路由与宿主锁定，再用 `component-quickref.md` 做宿主级收敛；本文件仅承接组件内 ownership 细则，不承担前置路由改判；不得凭语义猜测。

## 1. 组件大类（category）

| category     | 名称      | 说明                      |
| ------------ | ------- | ----------------------- |
| `functional` | 功能型悬浮按钮 | 承载具体功能入口，固定 **48pt** 尺寸 |

> 营销型悬浮按钮因业务差异较大，大小仅供参考，本规范主要覆盖功能型。

---

## 2. 样式类型（styleType）

功能型悬浮按钮根据内容分为 3 种样式：

| styleType    | 名称     | 选用条件                       | 典型示例           |
| ------------ | ------ | -------------------------- | -------------- |
| `icon`       | 图标型    | 图标语义清晰，或在页面中符合用户认知习惯（如购物车） | 购物车、客服         |
| `icon-text`  | 图标+文字型 | 图标语义不明显或新上线图标，需文字辅助降低认知成本  | "抢票"、"帮助"、"对比" |
| `icon-group` | 图标组合型  | 需呈现多个重要功能时，最多 **2个**       | 客服+返回顶部        |

> **图标组合型约束**：数量不超过 2 个，过多会导致用户注意力分散或误操作。
> **双按钮一致性**：图标组合型双按钮情况下，文字展示形式需保持一致（都有文字或都没有文字）。

---

## 3. 规格（固定值，不可调整）

### 3.1 通用规格

| 属性    | 值                          | 说明          |
| ----- | -------------------------- | ----------- |
| 容器形状  | **正圆形**                    | 宽高均为 48pt，`radius-full`（`component-radius.md`），不可修改 |
| 容器尺寸  | **48×48pt**                | 固定不可调整      |
| 组合型间距 | **18pt**（`cs-18`）          | 两个图标按钮之间的间距 |
| 按钮阴影  | **中阴影**（`shadow-raised`）   | 固定不可调整      |

### 3.2 图标+文字型（`icon-text`）内部布局规格

| 属性           | 值                               | 说明                       |
| ------------ | ------------------------------- | ------------------------ |
| 容器宽度         | **48pt**                        | 固定不可调整                   |
| 图标大小         | **20pt**                        | 按钮内部图标尺寸                 |
| 文字字号         | **10号**（`caption-s-10-regular`） | 图标下方文字，字重常规体（`regular`）  |
| 文字行高         | **14pt**（`caption-s-10-regular` 内置行高） | 对应 10 号字的行高，不可单独修改 |
| 布局方向         | **纵向**，图标在上、文字在下               | 两者水平居中对齐                 |
| 图标与文字间距      | **0pt**                         | 图标和文字紧贴，无间距              |
| 图标距容器上边距     | **`cs-8`**                      | 图标顶部到容器顶部                |
| 文字距容器下边距     | **`cs-6`**                      | 文字底部到容器底部                |
| 文字建议长度       | **2 个字以内**                      | 不可换行                     |

---

## 4. 徽标（badge，可选）

悬浮按钮支持在右上角展示徽标，类型为数字类徽标：

| 徽标类型       | 显示规则                        |
| ---------- | --------------------------- |
| 数字（1-9）    | 显示具体数字，徽标大小 **16×16pt**（估算） |
| 双位数（10-99） | 显示具体数字                      |
| 超出（99+）    | 显示 "99+"                    |

徽标偏移：距按钮右上角 **4pt** 内缩位置展示。

---

## 5. 位置说明

### 5.1 默认位置

- **优先放置在页面右下角**
- 如遮挡关键信息（如加购、结算按钮等），可改放**左侧**

### 5.2 全面屏适配

| 场景       | 底部间距                     |
| -------- | ------------------------ |
| 有底部按钮    | 功能型悬浮按钮在按钮上方，间距 **24pt**（`cs-24`） |
| 无底部按钮    | 直接距屏幕底部安全区 **24pt**（`cs-24`）      |
| 有营销型悬浮按钮 | 功能型在营销型上方排列              |

### 5.3 非全面屏适配

| 场景    | 底部间距           |
| ----- | -------------- |
| 无底部按钮 | 距屏幕底部 **60pt** |

### 5.4 临时入口（如"返回顶部"）位置规则

- 默认状态无悬浮按钮时：页面上滑超过 1 屏后，临时入口（返回顶部）出现
- 默认状态已有悬浮按钮时：新增临时入口依次排列在**末位**，原有常驻悬浮按钮上移

---

## 6. 交互行为

### 6.1 触发（出现）

| 触发方式      | 说明                |
| --------- | ----------------- |
| 常规功能按钮    | 页面加载后常驻展示         |
| 返回顶部（仅适用） | 用户滑动页面超过 1 屏内容时出现 |

### 6.2 出现动效

- 悬浮在页面侧边位置，置于页面顶层

### 6.3 点击操作

| 按钮类型        | 行为            |
| ----------- | ------------- |
| 常规功能入口（如客服） | 点击后跳转至对应界面    |
| 返回顶部        | 点击后页面自动上滑到最顶端 |

### 6.4 隐藏（可选）

| 隐藏时机        | 说明                     |
| ----------- | ---------------------- |
| 向上滑动页面时（可选） | 触发悬浮按钮隐藏动效；如不隐藏，固定在原位置 |
| 停止滑动时（可选）   | 悬浮按钮可收起至屏幕边缘           |

### 6.5 消失（仅适用于返回顶部）

- 手动滑动至页面最顶部，或点击返回顶部后，按钮消失

---

## 7. Token 引用

### 7.1 颜色 Token

| 用途       | Token 名称            | 语义层来源                                |
| -------- | ------------------- | ------------------------------------ |
| 按钮背景（白色） | `white`             | `color-semantic.md` §一 Neutral Color |
| 图标颜色     | `text-primary`      | `color-semantic.md` §二 Text Color    |
| 文字颜色     | `text-primary`      | `color-semantic.md` §二 Text Color    |
| 徽标背景     | `red-default` | `color-semantic.md` §七 Functional Color   |
| 徽标文字     | `text-on-brand`     | `color-semantic.md` §七 Brand Color    |

### 7.2 字体 Token

| 用途         | Token 名称               | 语义层来源                         |
| ---------- | ---------------------- | ----------------------------- |
| 图标+文字型——文字 | `caption-s-10-regular` | `font-semantic.md` §一 Caption |

### 7.3 阴影 Token

| 用途   | Token 名称        | 说明       |
| ---- | --------------- | -------- |
| 按钮阴影 | `shadow-raised` | 中阴影，不可调整 |

### 7.4 间距 Token

| 用途                          | Token 名称      | 值    | 语义层来源                   |
| --------------------------- | ------------- | ---- | ----------------------- |
| 组合型按钮间距                     | `cs-18`       | 18pt | `component-spacing.md`  |
| 全面屏底部间距（有底部按钮 / 无底部按钮）      | `cs-24`       | 24pt | `component-spacing.md`  |
| 图标距容器上边距（`icon-text`）       | `cs-8`        | 8pt  | `component-spacing.md`  |
| 文字距容器下边距（`icon-text`）       | `cs-6`        | 6pt  | `component-spacing.md`  |

---

## 8. Props API（供 AI 生码参考）

```typescript
export type FloatingActionButtonProps = {
  /**
   * 样式类型
   * @default "icon"
   */
  styleType?: "icon" | "icon-text" | "icon-group";

  /**
   * 图标（单图标型）
   */
  icon?: React.ReactNode;

  /**
   * 文字（仅 icon-text 有效，建议 2 个字以内）
   */
  label?: string;

  /**
   * 图标组合（仅 icon-group 有效，最多 2 个）
   */
  icons?: Array<{
    icon: React.ReactNode;
    label?: string;
    onClick?: () => void;
  }>;

  /**
   * 徽标数字（0 不显示，超过 99 显示 99+）
   */
  badgeCount?: number;

  /**
   * 位置
   * @default "right"
   */
  position?: "right" | "left";

  /**
   * 是否允许向上滑动时隐藏
   * @default false
   */
  hideOnScrollUp?: boolean;

  /**
   * 是否允许停止滑动时收起至边缘
   * @default false
   */
  collapseOnStop?: boolean;

  /**
   * 点击回调（单图标型）
   */
  onClick?: () => void;
};
```

---

## 9. data-attribute 规范

| 属性                | 值                                         | 说明      |
| ----------------- | ----------------------------------------- | ------- |
| `data-slot`       | `"floating-action-button"`                       | 悬浮按钮根容器 |
| `data-style-type` | `"icon"` / `"icon-text"` / `"icon-group"` | 样式类型    |
| `data-position`   | `"right"` / `"left"`                      | 放置位置    |
| `data-has-badge`  | `"true"` / `"false"`                      | 是否有徽标   |

---

## 10. 无障碍（Accessibility）

- 按钮使用 `role="button"` 或 `<button>` 元素
- 必须设置 `aria-label` 描述按钮功能（如"返回顶部"、"联系客服"）
- 图标+文字型：`aria-label` 与可见文字保持一致
- 图标组合型：每个图标单独设置 `aria-label`
- 支持键盘 `Tab` 键聚焦，`Enter`/`Space` 键触发

---

## 11. 使用约束（AI 生成时的硬性规则）

1. **尺寸与形状固定**：所有悬浮按钮整体尺寸固定为 **48×48pt 正圆形**（`radius-full`），不可修改、不可拉伸为椭圆或矩形
2. **图标大小固定**：图标型（`icon`）和图标组合型（`icon-group`）图标为 **24pt**；图标+文字型（`icon-text`）图标为 **20pt**，不可修改
3. **阴影固定**：使用 `shadow-raised`，不可移除或更换
4. **组合型上限**：图标组合型最多 **2 个**；超出时应拆分或使用其他组件
5. **文字限制**：图标+文字型的文字建议 **2 个字以内**，不可换行；图标距容器上边距 `cs-8`，文字距容器下边距 `cs-6`，图标与文字间距为 0pt（紧贴无间距）
6. **双按钮文字一致性**：图标组合型双按钮必须同时有文字或同时无文字
7. **无蒙层**：悬浮按钮不使用蒙层
8. **不替代 Tab Bar**：悬浮按钮只用于快捷功能入口，不替代底部导航
9. **返回顶部按钮**：仅在用户滑动超过 1 屏后出现，不可常驻
10. **禁止直接写 hex 颜色**：颜色必须使用 §7.1 中的语义 Token
11. **无描边**：悬浮按钮容器不使用任何描边（`border`），不可添加 `border`、`outline` 或 `box-shadow` 描边效果
12. **图标规范**：图标优先使用 iconfont **line-medium** 风格；图标尺寸与粗细由组件规格固定，**不可调整**；图标颜色默认为 `text-primary`（`#111111`），若用户未指定颜色则必须使用 `text-primary`，用户明确指定颜色时方可更改

---

## 12. 常见组合示例

### 12.1 单图标（客服入口）

```tsx
<FloatingActionButton
  styleType="icon"
  icon={<span className="font icon-iconfont-customer-line-medium" aria-hidden />}  {/* 客服图标 */
  position="right"
  onClick={() => navigateTo('/service')}
/>
```

### 12.2 图标+文字（新功能引导）

```tsx
<FloatingActionButton
  styleType="icon-text"
  icon={<span className="font icon-iconfont-shopping-line-medium" aria-hidden />}  {/* 购物袋/票务图标 */
  label="抢票"
  position="right"
  onClick={() => navigateTo('/ticket')}
/>
```

### 12.3 图标组合（客服+返回顶部）

```tsx
<FloatingActionButton
  styleType="icon-group"
  icons={[
    { icon: <span className="font icon-iconfont-customer-line-medium" aria-hidden />, label: "客服", onClick: openService },
    { icon: <span className="font icon-iconfont-backtop-line-medium" aria-hidden />, label: "顶部", onClick: scrollToTop }
  ]}
  position="right"
/>
```

### 12.4 带徽标（消息通知）

```tsx
<FloatingActionButton
  styleType="icon"
  icon={<span className="font icon-iconfont-notice-line-medium" aria-hidden />}  {/* 消息/通知图标 */}
  badgeCount={9}
  position="right"
/>
```

---

## 13. 与其他组件的关系

| 关联组件                 | 关系说明                       |
| -------------------- | -------------------------- |
| `button`             | 底部 CTA 按钮，跟随页面布局，与悬浮按钮不同层级 |
| `tab-bar`            | 底部导航，悬浮按钮不能替代 Tab Bar 功能   |
| `badge`              | 悬浮按钮右上角徽标复用 Badge 组件规范     |
| `half-screen-dialog` | 可作为触发半页弹窗的入口按钮             |
| `toast`              | 悬浮按钮点击后可触发 Toast 轻提示       |
