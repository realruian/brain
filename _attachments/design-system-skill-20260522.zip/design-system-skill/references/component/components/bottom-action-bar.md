# Bottom Action Bar 底部操作栏 - 组件规范

> **组件分类**：Component（组件级）
> **定义**：底部操作栏固定在页面底部，为当前页面提供主操作入口（如加入购物车、立即购买、去结算等）。与底部导航栏（Bottom Navigation）功能完全不同：导航栏承载一级信息架构，操作栏承载页面级 CTA 行为。
> **Style 依赖**：`color-semantic.md` · `font-semantic.md` · `spacing-semantic.md` · `component-spacing.md` · `radius-semantic.md` · `component-radius.md` · `stroke-semantic.md`

---

<!-- COMP-NAV-START -->

## 🗺️ Bottom Action Bar — variant / 章节速查

> 共 15 种主 variant；胶囊非等分不是新 variant，而是通过 `capsuleLayout="asymmetric"` 组合配置实现。按场景快速选型，再用 `offset` 跳到对应节。

| variant | 名称 | 适用场景 | 详细规格行 |
|------|------|------|------|
| `single` | 单按钮全宽 | 只有 1 个主 CTA | L380 |
| `double` | 双按钮并排 | 副操作 + 主 CTA（等宽） | L393 |
| `triple` | 三按钮并排 | 3 个等宽操作 | L407 |
| `stack` | 双排堆叠 | 主标题行 + 副说明行 | L425 |
| `asymmetric` | 非等分双按钮 | 左小右大的不等宽布局 | L441 |
| `icon-action` | 图标入口+主按钮 | 左侧 1‒4 个图标入口 + 右侧主 CTA | L457 |
| `icon-double` | 图标入口+双按钮 | 左侧 1‒4 个图标入口 + 右侧副/主 CTA | L277 |
| `icon-action-double` | 增强型图标入口+双主按钮 | 左侧增强图标 + 右侧两个主 CTA | L519 |
| `icon-action-split` | 增强型图标入口+副主按钮 | 左侧增强图标 + 右侧副/主 CTA 各一 | L544 |
| `icon-action-triple` | 增强型图标入口+双副主 | 左侧增强图标 + 右侧副/副/主 三按钮 | L565 |
| `price-split` | 价格展示区+副主按钮 | 左侧价格 + 右侧副/主 CTA | L590 |
| `capsule-combo` | 胶囊组合按钮 | 胶囊式多选 + 主 CTA | L611 |
| `icon-capsule-combo` | 图标入口+胶囊组合 | 增强图标 + 胶囊组合 | L683 |
| `double-icon-capsule-combo` | 双图标+胶囊组合 | 2个增强图标 + 胶囊组合 | L771 |
| `triple-icon-capsule-combo` | 三图标+胶囊组合 | 3个增强图标 + 胶囊组合 | L820 |

> 非等分胶囊写法：保持 `variant="capsule-combo"` 或 `variant="icon-capsule-combo"`，再配 `capsuleLayout="asymmetric"`。
| `— 其他章节 —` | Props / Token / 约束 / 决策树 | — |  |

**其他关键章节直达：**

- **Props API**：跳转 → L875
- **Token 引用**：跳转 → L1021
- **使用约束**：跳转 → L1160
- **AI 决策树**：跳转 → L1238
- **常见组合示例**：跳转 → L1306

<!-- COMP-NAV-END -->

## 0. 图标 / 间距 / Ownership 约束

- **icon-route（默认）**：Bottom Action Bar 内功能图标默认回 `component/atoms/icon.md`，并遵循正文 iconfont class / weight。
- **fixed-asset 例外**：正文若指定官方 SVG、`assets/*.svg`、PNG/CDN 等固定资源，必须走 fixed-asset，不得强行回 iconfont。
- **spacing-owner（Bar 自持）**：左右分区、icon-entry 间距、按钮组分配与条内对齐归 Bottom Action Bar。
- **宿主裁决（优先级）**：`button` 仅拥有自身内部 slot 与文字/图标规则；与底部安全区关系由 Bottom Action Bar 按 `system.md` 统一裁决。
- **不可跳步**：先回 `references/INDEX.md` 完成区域路由与宿主锁定，再用 `component-quickref.md` 做宿主级收敛；本文件仅承接组件内 ownership 细则，不承担前置路由改判；不得凭语义猜测。


## 1. 组件变体（variant）

| variant | 名称 | 说明 |
|---------|------|------|
| `single` | 单按钮全宽 | 单个主操作按钮，横贯全宽；容器高 48pt |
| `double` | 双按钮并排 | 左副右主，2等分；容器高 48pt |
| `triple` | 三按钮并排 | 左1副+左2副+右主，3等分；容器高 48pt |
| `stack` | 双排堆叠 | 上行主操作全宽 + 下行副操作全宽，垂直堆叠；容器高 96pt |
| `asymmetric` | 非等分双按钮 | 左固定宽副按钮（`flex-shrink: 0`）+ 右弹性主按钮（`flex-grow: 1`）；容器高 48pt |
| `icon-action` | 图标入口+主按钮 | 左侧 1~4 个图标入口（图标+标签，各 50pt）+ 右侧弹性主按钮；容器高 48pt |
| `icon-double` | 图标入口+双按钮 | 左侧 1~4 个图标入口（图标+标签，各 50pt）+ 右侧 1 个副按钮 + 1 个主按钮并排；容器高 48pt |
| `icon-action-double` | 增强型图标入口+双主按钮 | 左侧 2 个增强型图标入口（大图标 44pt + 大标签 20pt）+ 右侧 2 个主按钮并排；容器高 96pt |
| `icon-action-split` | 增强型图标入口+副主按钮 | 左侧 1 个增强型图标入口（大图标 44pt + 大标签 20pt）+ 右侧 1 个副按钮 + 1 个主按钮并排；容器高 96pt（@2x） |
| `icon-action-triple` | 增强型图标入口+双副主按钮 | 左侧 1 个增强型图标入口（大图标 44pt + 大标签 20pt）+ 右侧 2 个副按钮 + 1 个主按钮（共三按钮）并排；容器高 96pt（@2x） |
| `price-split` | 价格展示区+副主按钮 | 左侧价格/说明展示区（小图标 36pt + 次级文字 28pt，灰色）+ 右侧副按钮 + 主按钮并排；容器高 96pt（@2x），左右 padding 对称 24pt |
| `capsule-combo` | 胶囊组合按钮 | 左半（次操作，深灰渐变）+ 右半（主操作，黄色渐变）无间隙拼合成一个完整胶囊；两半等宽（各 `flex-grow: 1`）；容器高 96pt（@2x） |
| `icon-capsule-combo` | 增强型图标入口+胶囊组合 | 左侧 1 个增强型图标入口（大图标 44pt + 大标签 20pt，`flex-shrink:0`）+ 右侧胶囊组合（左半深灰次操作 + 右半黄色主操作，两半各 `flex-grow:1`）；容器高 96pt（@2x），左 padding 12pt，右 padding 24pt |
| `double-icon-capsule-combo` | 双增强型图标入口+胶囊组合 | 左侧 **2 个**增强型图标入口（各 100pt，总 200pt，`flex-shrink:0`）+ 右侧胶囊组合（左半深灰次操作 + 右半黄色主操作，两半各 `flex-grow:1`）；容器高 96pt（@2x），左 padding 12pt，右 padding 24pt；右侧胶囊宽约 502pt（较 `icon-capsule-combo` 缩短 100pt） |
| `triple-icon-capsule-combo` | 三增强型图标入口+胶囊组合（结算底部工具栏） | 左侧 **3 个**增强型图标入口（各 100pt，总 300pt，`flex-shrink:0`）+ 右侧胶囊组合（左半深灰次操作 + 右半黄色主操作，两半各 `flex-grow:1`）；容器高 96pt（@2x），左 padding 12pt，右 padding 24pt；右侧胶囊宽约 402pt；**典型场景为购物车结算页或通用结算页**，左侧三个入口通常为客服/优惠/购物车等高频功能，右侧胶囊为"去结算"等主操作 |

---

## 2. 按钮样式类型（buttonType）

| buttonType | 名称 | 视觉特征 | 适用位置 |
|------------|------|---------|---------|
| `primary` | 主操作 | `gradient-yellow` 渐变背景 + `text-primary` 文字 | 最右侧主按钮 / single / stack 上行 |
| `secondary` | 副操作 | 透明背景 + `stroke-strong` 描边 + `text-primary` 文字 | 左侧副按钮 / stack 下行 |
| `capsule-left` | 胶囊左半（次操作） | `gradient-dark`（深灰渐变 `#525252 → #272727`）背景 + `text-warm-yellow`（`#FFF6B8`）文字；`border-radius: 40px 0 0 40px`，右侧无圆角，与右半无缝拼合。**到餐（DPT5）例外**：左半底色改用 `dpt5-g-yo`，文字色改用 `white` | 仅 `capsule-combo` 变体左半 |
| `capsule-right` | 胶囊右半（主操作） | `gradient-yellow` 背景 + `text-primary`（`#111111`）文字；`border-radius: 0 40px 40px 0`，左侧无圆角，与左半无缝拼合。**到餐（DPT5）例外**：右半底色改用 `dpt5-g-or` | 仅 `capsule-combo` 变体右半 |

> **图标可选**：主操作按钮和副操作按钮均可选配左侧图标（17pt）。
> **价格可选**：主操作按钮可选配价格区域（使用 `MT New Digital Display` 数字字体）。
> **胶囊组合特殊性**：`capsule-left` 与 `capsule-right` 必须成对使用，不可单独出现。两半之间无间隙、无描边，在视觉上构成一个整体胶囊；颜色对比（深灰 vs 黄色）代替形态差异（描边 vs 填充）来区分主次权重。

**图标入口（icon-entry）**

`icon-action` 变体专属，左侧区域由若干图标入口组成，每个入口为独立的图标+标签垂直排列单元：

| iconEntry 区域 | 名称 | 视觉特征 | 说明 |
|--------------|------|---------|------|
| `icon-entry` | 图标入口 | 图标（22pt）+ 标签（`caption-s-10-regular`，`text-primary`）垂直排列 | 常用于客服、收藏、分享等次要功能；每个入口固定宽 50pt；最多 4 个 |

### 2.1 图标粗细规范

| 项目 | 规范 | 说明 |
|------|------|------|
| 默认粗细 | **中黑体（Medium）** | 按钮内图标线条粗细默认使用 Medium 字重（中黑体）风格 |
| 可自定义 | 允许按业务需求调整 | 可根据品牌风格选择 Regular（细）、Medium（中黑体）、Bold（粗） |
| 一致性要求 | **同一业务保持相同粗细** | 同一 App / 同一业务线内所有底部操作栏图标必须统一粗细，不可混用不同字重的图标风格 |

> **图标粗细业务规则**：图标粗细与品牌调性一致。电商/外卖类业务通常使用 Medium；资讯/阅读类业务可使用 Regular；需要强调力度感的场景可用 Bold。同一业务线的不同页面（商品详情、订单确认、购物车等）必须保持图标粗细一致，切勿因页面不同而出现粗细混乱。

---

## 2.5 样式选择指南

> 根据**按钮数量**、**排列方向**、**左侧功能入口数量**和**文案长度**选择合适的变体。

### 独立按钮（无图标入口）

| 布局类型 | 选用条件 | 左侧功能 无 | 左侧功能 1个 | 左侧功能 2个 | 左侧功能 3个 | 左侧功能 4个 |
|---------|---------|-----------|------------|------------|------------|------------|
| **左右等分 · 1个操作** | 单一主操作，文案 ≤8字 | `single` | `icon-action`（1图标） | `icon-action`（2图标） | `icon-action`（3图标） | `icon-action`（4图标） |
| **左右等分 · 2个操作** | 主+副操作，文案均 ≤8字 | `double` | `icon-double`（1图标） | `icon-double`（2图标） | — | — |
| **左右等分 · 3个操作** | 主+2副，文案均 ≤6字 | `triple` | `icon-double`（1图标） | — | — | — |
| **左右不等分** | 主操作文案较长（>8字）时；副操作文案短，左侧固定宽 | `asymmetric` | — | — | — | — |
| **上下排列** | 主操作和副操作文案都较长（均超过8字）时 | `stack` | — | — | — | — |

> **左侧功能**指图标入口区域（icon-entry），每个图标入口固定 50pt 宽。左侧功能越多，右侧主按钮可用宽度越小；超过 2 个图标入口时，副按钮+主按钮的双按钮布局（`icon-double`）空间过窄，不建议使用。

### 胶囊组合按钮

| 布局类型 | 选用条件 | 说明 |
|---------|---------|------|
| **胶囊组合 · 等分双操作** | 主次操作视觉权重需同等突出；两个操作**均为强引导**（如"立即购买"与"订阅购买"同等重要）；需要通过颜色而非形态（描边 vs 填充）来区分主次；@2x 设计稿场景 | `capsule-combo`：左深灰次操作 + 右黄色主操作，无间隙拼合，各 `flex-grow: 1` |
| **增强型图标入口+胶囊组合** | 在胶囊组合双操作的基础上，还需要左侧额外提供一个可点击的功能快捷入口（如"客服"）；功能入口与两个操作在视觉上明确分区；@2x 设计稿场景 | `icon-capsule-combo`：左侧 1 个增强型图标入口（`flex-shrink:0`，100pt）+ 右侧等分胶囊组合（`flex-grow:1`，602pt），左 padding 12pt，两区 gap 12pt |
| **双增强型图标入口+胶囊组合** | 在单图标入口胶囊组合的基础上，左侧需要同时提供 **2 个**可点击的功能快捷入口（如"客服"+"收藏"）；@2x 设计稿场景 | `double-icon-capsule-combo`：左侧 2 个增强型图标入口（各 100pt，总 200pt，`flex-shrink:0`）+ 右侧等分胶囊组合（`flex-grow:1`，502pt），左 padding 12pt，两区 gap 12pt |
| **三增强型图标入口+胶囊组合**（结算底部工具栏） | **购物车结算页或通用结算页**的标准布局：左侧需要同时提供 **3 个**高频功能快捷入口（结算场景典型配置：客服/优惠券/购物车，或客服/收藏/分享等）；右侧胶囊提供次操作（如"查看详情"/"编辑"）+ 主操作（如"去结算"/"立即付款"）；@2x 设计稿场景 | `triple-icon-capsule-combo`：左侧 3 个增强型图标入口（各 100pt，总 300pt，`flex-shrink:0`）+ 右侧等分胶囊组合（`flex-grow:1`，402pt），左 padding 12pt，两区 gap 12pt |

> **胶囊组合 vs 独立双按钮选择依据**：
> - `double`（独立双按钮）：次操作为**辅助性**行为（如"加购"），主次权重差异显著，通过描边 vs 填充区分
> - `capsule-combo`（胶囊组合）：次操作也是**强引导**行为（如"加购"与"立购"同等重要），两操作在视觉上地位相近，使用颜色对比（深灰 vs 黄）而非形态对比来区分方向性

### 选择规则总结

```
按钮操作数量？
  ├── 1个主操作
  │   ├── 文案 ≤8字，无左侧功能入口 → variant="single"
  │   ├── 文案 ≤8字，有 1~4 个左侧功能入口 → variant="icon-action"
  │   └── 文案 >8字（长文案） → variant="asymmetric"（副按钮短文案）或 variant="stack"（副按钮也是长文案）
  │
  ├── 2个操作（主+副）
  │   ├── 文案均 ≤8字，无左侧功能入口，主次权重差异明显 → variant="double"
  │   ├── 文案均 ≤8字，有 1~2 个左侧功能入口 → variant="icon-double"
  │   ├── 文案较长 → variant="stack"（上主下副，各自全宽）
  │   └── 两操作视觉权重相当、均需强引导（@2x） → variant="capsule-combo"
  │
  └── 3个操作（主+副1+副2）
      ├── 文案均较短（≤6字）→ variant="triple"
      └── 文案较长 → 拆分为 2 个操作 + 跳转入口（重新评估信息架构）

文案长度判断基准（@1x，15pt 'PingFang SC', 'Noto Sans SC', 'Source Han Sans SC', 'Microsoft YaHei', 'WenQuanYi Micro Hei', sans-serif Medium）：
  - ≤4字：约 60pt，所有变体均适用
  - 5~8字：约 75~120pt，适用 double / triple / icon-action
  - >8字：约 >120pt，建议使用 asymmetric / stack
```

---

## 3. 尺寸规格

### 3.1 容器（Bar）

| 区域 | 值 | Token / 说明 |
|------|-----|-------------|
| 容器背景 | `white` | 白色底 |
| 顶部描边 | 0.5pt，`divider-secondary` | `rgba(0,0,0,0.06)` 极轻分割线 |
| 顶部 padding | 8pt（`spacing-s`） | 按钮顶部距容器顶部 |
| 左右 padding | 12pt（`cs-12`） | 按钮距容器左右边缘 |
| 按钮列间距（横排） | 8pt（`spacing-s`） | single/double/triple 中各按钮间距 |
| 按钮行间距（堆叠） | 8pt（`spacing-s`） | stack 上下两行按钮间距 |
| 容器基准宽度 | 375pt | @1x 设计稿宽度，实际屏宽等分适配 |

**各变体容器高度：**

| variant | 容器高度 | 计算说明 |
|---------|---------|---------|
| `single` | 48pt | 按钮 40pt + 顶部 padding 8pt |
| `double` | 48pt | 按钮 40pt + 顶部 padding 8pt |
| `triple` | 48pt | 按钮 40pt + 顶部 padding 8pt |
| `stack` | 96pt | 按钮 40pt × 2 + 顶部 padding 8pt + 行间距 8pt |
| `asymmetric` | 48pt | 按钮 40pt + 顶部 padding 8pt |
| `icon-action` | 48pt | 图标入口区 38pt（22pt 图标 + 2pt gap + 14pt 标签行）+ 顶部 padding 8pt |
| `icon-action-double` | 96pt（@2x） | 增强型图标入口 76pt + 顶部 padding 16pt（@2x 设计稿） |
| `icon-action-split` | 96pt（@2x） | 大型按钮 80pt + 顶部 padding 16pt（@2x 设计稿） |
| `icon-action-triple` | 96pt（@2x） | 大型按钮 80pt + 顶部 padding 16pt（@2x 设计稿） |
| `price-split` | 96pt（@2x） | 大型按钮 80pt + 顶部 padding 16pt（@2x 设计稿，左右 padding 对称 24pt） |
| `capsule-combo` | 96pt（@2x） | 胶囊组合按钮 80pt + 顶部 padding 16pt（@2x 设计稿，左右 padding 对称 24pt） |
| `icon-capsule-combo` | 96pt（@2x） | 增强型图标入口 76pt + 胶囊组合 80pt + 顶部 padding 16pt（@2x 设计稿，左 padding 12pt，右 padding 24pt） |
| `double-icon-capsule-combo` | 96pt（@2x） | 双增强型图标入口区 76pt + 胶囊组合 80pt + 顶部 padding 16pt（@2x 设计稿，左 padding 12pt，右 padding 24pt；与 `icon-capsule-combo` 等高，仅左侧图标入口数量不同） |
| `triple-icon-capsule-combo` | 96pt（@2x） | 三增强型图标入口区 76pt + 胶囊组合 80pt + 顶部 padding 16pt（@2x 设计稿，左 padding 12pt，右 padding 24pt；与 `double-icon-capsule-combo` 等高，左侧图标入口增加为 3 个） |

> 容器底部与 Home Indicator 组件相接，不含 Home Indicator 本身高度。

### 3.2 按钮（Button）

| 区域 | 值 | Token / 说明 |
|------|-----|-------------|
| 按钮高度 | 40pt | `size=xl`（Button 组件规范） |
| 按钮圆角 | `radius-full` | 胶囊形，`border-radius: 9999px` |
| 按钮上下内边距 | 9.5pt（`cs-9.5`） | 顶部和底部各 9.5pt |
| 按钮左右内边距 | 20pt（`cs-20`） | 左右各 20pt |
| 图标与文字 gap | 2pt（`cs-2`） | 图标和主文字之间的横向间距 |
| 图标尺寸 | 17×17pt | flex-shrink: 0 |
| 单按钮宽度（single） | 351pt | 375pt - 左右 padding 12pt×2 |
| 双按钮单个宽度（double） | 171.5pt | （351pt - 列间距 8pt）÷ 2 |
| 三按钮单个宽度（triple） | 111.67pt | （351pt - 列间距 8pt×2）÷ 3 |
| 堆叠每行按钮宽度（stack） | 351pt | 同 single，全宽 |
| 非等分副按钮宽度（asymmetric） | 112pt | 固定宽，`flex-shrink: 0` |
| 非等分主按钮宽度（asymmetric） | 弹性 | `flex-grow: 1`，撑满剩余空间（约 231pt） |
| 图标入口+主按钮（icon-action） | 主按钮弹性 | 左侧每个图标入口固定 50pt（最多 4 个），主按钮 `flex-grow: 1` |
| 增强型图标入口+双主按钮（icon-action-double） | 双按钮并排 | 左侧 2 个增强型图标入口各 100pt，右侧 2 个主按钮各 243pt（@2x 750pt 宽度） |
| 增强型图标入口+双副主按钮（icon-action-triple） | 三按钮并排 | 左侧 1 个增强型图标入口 100pt，右侧 3 个按钮各 `flex-grow:1`（约 190pt），总宽 602pt（@2x） |
| 价格展示区+副主按钮（price-split） | 左价格信息+右双按钮 | 左侧价格展示区 100pt（`flex-shrink:0`），右侧副按钮 + 主按钮各 243pt（`flex-grow:1`），总宽 502pt（@2x） |
| 胶囊组合按钮（capsule-combo） | 等分双半 | 左右两半各 `flex-grow: 1`（各约 351pt），总宽 702pt，无间隙拼合（@2x 750pt 宽度） |
| 增强型图标入口+胶囊组合（icon-capsule-combo） | 左图标入口固定+右胶囊弹性 | 左侧图标入口 100pt（`flex-shrink:0`），右侧胶囊组合 602pt（`flex-grow:1`）；胶囊内两半各 `flex-grow:1`（各约 301pt），无间隙拼合；容器左 padding 12pt，图标区与胶囊区 gap 12pt |
| 双增强型图标入口+胶囊组合（double-icon-capsule-combo） | 左双图标入口固定+右胶囊弹性 | 左侧 2 个图标入口各 100pt（总 200pt，`flex-shrink:0`），右侧胶囊组合 502pt（`flex-grow:1`）；胶囊内两半各 `flex-grow:1`（各约 251pt，`min-width:195px`），无间隙拼合；容器左 padding 12pt，两图标入口横排排列，图标区与胶囊区 gap 12pt |
| 三增强型图标入口+胶囊组合（triple-icon-capsule-combo） | 左三图标入口固定+右胶囊弹性 | 左侧 3 个图标入口各 100pt（总 300pt，`flex-shrink:0`），右侧胶囊组合 402pt（`flex-grow:1`）；胶囊内两半各 `flex-grow:1`（各约 201pt，`min-width:195px`），无间隙拼合；容器左 padding 12pt，三图标入口横排排列，图标区与胶囊区 gap 12pt |

### 3.3 增强型图标入口（enhanced-icon-entry，icon-action-double 变体专属）

| 区域 | 值 | Token / 说明 |
|------|-----|-------------|
| 每个增强型图标入口宽度 | 100pt | `flex-shrink: 0`，固定宽 |
| 增强型图标入口区域高度 | 76pt | 图标 44pt + gap 8pt + 标签 32pt（@2x 尺寸） |
| 增强型图标尺寸 | 44×44pt | `flex-shrink: 0`，@2x 对应 22pt @1x |
| 增强型图标与标签 gap | 8pt（@2x） | 垂直间距，`padding-top: 8px` |
| 增强型标签文字 | 20pt 'PingFang SC', 'Noto Sans SC', 'Source Han Sans SC', 'Microsoft YaHei', 'WenQuanYi Micro Hei', sans-serif Regular | @2x 对应 10pt @1x，但视觉强度更高 |
| 增强型标签颜色 | `text-primary` | `#111111` |
| 增强型图标入口区左 padding | 12pt（`cs-12`） | 图标入口区距容器左边缘 |
| 增强型图标入口与按钮区间距 | 12pt | `column-gap: 12px` |

> **icon-action-double 容器参数特殊性**：该变体为 @2x 设计稿规格，容器高度 96pt，左侧为 2 个垂直堆叠的增强型图标入口，右侧为 2 个并排的大型主按钮（字体 30pt）。适用于需要突出多个功能入口且提供多个购买选项的场景（如"立即购买" vs "订阅购买"等）。

### 3.3.5 增强型图标入口（单个，icon-action-split / icon-action-triple / icon-capsule-combo 变体共用）

| 区域 | 值 | Token / 说明 |
|------|-----|-------------|
| 单个增强型图标入口宽度 | 100pt | `flex-shrink: 0`，固定宽 |
| 单个增强型图标入口高度 | 76pt | 图标 44pt + gap + 标签（含内边距），@2x 尺寸 |
| 增强型图标尺寸 | 44×44pt | `flex-shrink: 0` |
| 增强型标签文字 | 20pt 'PingFang SC', 'Noto Sans SC', 'Source Han Sans SC', 'Microsoft YaHei', 'WenQuanYi Micro Hei', sans-serif Regular | @2x 对应 10pt @1x |
| 增强型标签颜色 | `text-primary` | `#111111` |
| 图标入口与按钮区间距 | 12pt | `column-gap: 12px` |

**各变体标签 padding-top 差异：**

| 变体 | 标签容器高度 | `padding-top` | 说明 |
|------|------------|--------------|------|
| `icon-action-split` | 32pt | `8px` | 图标 44pt + padding-top 8pt + 标签行高 24pt（`line-height: 28px` 含内边距） |
| `icon-action-triple` | 28pt | `4px` | 图标 44pt + padding-top 4pt + 标签行高 24pt |
| `icon-capsule-combo` | 32pt | `4px` | 图标 44pt + padding-top 4pt + 标签行高 28pt（`height: 32px; line-height: 28px`） |
| `double-icon-capsule-combo` | 32pt | `4px` | 与 `icon-capsule-combo` 图标入口规格完全相同；2 个入口横排排列（`flex-direction: row`），各 100pt，间距 0pt，总宽 200pt |
| `triple-icon-capsule-combo` | 32pt | `4px` | 与 `icon-capsule-combo` 图标入口规格完全相同；3 个入口横排排列（`flex-direction: row`），各 100pt，间距 0pt，总宽 300pt |

> **icon-action-split 容器参数特殊性**：该变体为 @2x 设计稿规格，容器高度 96pt，左侧为 1 个单独的增强型图标入口，右侧为 1 个副按钮（描边）+ 1 个主按钮（渐变）并排。适用于需要强调单一功能入口但同时提供两个选择的场景（如"添加购物车" vs "立即购买"）。
>
> **icon-capsule-combo 图标入口特殊性**：与 `icon-action-split` 结构相同，但标签容器内边距为 `padding-top: 4px`（而非 8px），标签 `height: 32px`，`line-height: 28px`；配合右侧胶囊组合使用，图标入口可点击，作为功能快捷入口（如"客服"）。
>
> **double-icon-capsule-combo 图标入口特殊性**：2 个图标入口规格与 `icon-capsule-combo` 完全相同（各 100pt，`padding-top: 4px`），但两个入口横排排列（`flex-direction: row`），组成 200pt 宽的图标入口区（`flex-shrink:0`）。右侧胶囊总宽因此从 602pt 缩短为 502pt，两半各约 251pt（`min-width: 195px`）。
>
> **triple-icon-capsule-combo 图标入口特殊性**：3 个图标入口规格与 `icon-capsule-combo` 完全相同（各 100pt，`padding-top: 4px`），三个入口横排排列（`flex-direction: row`），组成 300pt 宽的图标入口区（`flex-shrink:0`）。右侧胶囊总宽因此从 502pt 进一步缩短为 402pt，两半各约 201pt（`min-width: 195px`，接近最小允许值）。⚠️ 由于右侧胶囊宽度已接近极限，**不支持 `asymmetric` 非等分配置**；若需非等分，请改用 `double-icon-capsule-combo`（右侧胶囊 502pt，左半固定 248pt，右半约 254pt，空间仍较紧）或 `icon-capsule-combo asymmetric`（右侧胶囊 602pt，左半固定 248pt，右半约 354pt）。

### 3.4 副+主按钮并排（icon-action-split 变体专属）

| 区域 | 值 | Token / 说明 |
|------|-----|-------------|
| 右侧按钮区宽高 | 602×80pt | 两个按钮并排，总宽 602pt |
| 单按钮宽度 | 293pt | 各按钮占 293pt（包含内边距） |
| 两按钮间距 | 16pt | `column-gap: 16px` |
| 副按钮风格 | 描边型 | `border-bold` + `stroke-strong`（即 1pt `#CCCCCC`），`radius-full` |
| 主按钮风格 | 渐变型 | `gradient-yellow`（即 `linear-gradient(135deg, rgba(255, 231, 77, 1) 0%, rgba(255, 221, 0, 1) 100%)`），`radius-full` |
| 副按钮文字 | 30pt 'PingFang SC', 'Noto Sans SC', 'Source Han Sans SC', 'Microsoft YaHei', 'WenQuanYi Micro Hei', sans-serif Medium | 相同规格 |
| 主按钮文字 | 30pt 'PingFang SC', 'Noto Sans SC', 'Source Han Sans SC', 'Microsoft YaHei', 'WenQuanYi Micro Hei', sans-serif Medium | 相同规格 |
| 副按钮字色 | `text-primary` | `#111111` |
| 主按钮字色 | `text-primary` | `#111111` |
| 按钮内图标 | 34×34pt | 可选，双按钮均支持 |
| 按钮内价格 | visibility: hidden | 可选但在当前设计中隐藏 |

> **icon-action-split 按钮规格说明**：右侧两按钮为等宽并排设计，副按钮（左）采用描边风格便于视觉区分，主按钮（右）采用渐变黄风格强调主操作。两按钮高度统一 80pt，内边距 `19px 40px`（对应 @2x 的内部布局）。

### 3.5 图标入口（icon-entry，icon-action 与 icon-double 变体共用）

| 区域 | 值 | Token / 说明 |
|------|-----|-------------|
| 每个图标入口宽度 | 50pt | `flex-shrink: 0`，固定宽 |
| 图标入口区域高度 | 38pt | 图标 22pt + gap 2pt + 标签 14pt |
| 图标尺寸 | 22×22pt | `flex-shrink: 0` |
| 图标与标签 gap | 2pt（`cs-2`） | `padding-top: cs-2` |
| 标签文字 | `caption-s-10-regular` | 'PingFang SC', 'Noto Sans SC', 'Source Han Sans SC', 'Microsoft YaHei', 'WenQuanYi Micro Hei', sans-serif，10pt，Regular |
| 标签颜色 | `text-primary` | `#111111` |
| 容器左 padding | 6pt（`cs-6`） | 图标入口区距容器左边缘（替换标准 12pt） |
| 容器右 padding | 12pt（`cs-12`） | 主按钮距容器右边缘（保持标准 12pt） |
| 图标入口列间距 | 0pt | 紧贴排列，宽度自身已包含内间距 |
| 图标入口与按钮区间距 | 6pt（`cs-6`） | `column-gap: 12px` @2x（icon-action 为主按钮，icon-double 为副+主并排区） |

> **icon-action / icon-double 容器参数特殊性**：左 padding 为 6pt（非标准 12pt），右 padding 保持标准 12pt，图标入口区与按钮区 gap 为 6pt；左右不对称，编码时需注意单独设置而非使用统一 padding 值。
>
> **icon-double 组合规则**：左侧图标入口区沿用本节；右侧按钮区沿用 `double` 变体的双按钮并排规则（左副右主、等宽、按钮高 40pt）。它是独立 variant，❌ 不要误写成 `icon-action-split`，也不要把它当成 `double` + `iconEntries` 的自由拼接。

### 3.6 双副+主按钮三等分（icon-action-triple 变体专属）

| 区域 | 值 | Token / 说明 |
|------|-----|-------------|
| 右侧按钮区宽高 | 602×80pt | 三个按钮并排，总宽 602pt |
| 单按钮宽度 | `flex-grow: 1`（初始值约 190pt） | 三按钮等分右侧空间，`justify-content: start` |
| 三按钮间距 | 16pt | `column-gap: 16px` |
| 副按钮1风格 | 描边型 | `border-bold` + `stroke-strong`（即 1pt `#CCCCCC`），`radius-full` |
| 副按钮2风格 | 描边型 | `border-bold` + `stroke-strong`（即 1pt `#CCCCCC`），`radius-full` |
| 主按钮风格 | 渐变型 | `gradient-yellow`（即 `linear-gradient(135deg, rgba(255,231,77,1) 0%, rgba(255,221,0,1) 100%)`），`radius-full` |
| 所有按钮高度 | 80pt | 统一高度，`radius: 40px`（`radius-full`） |
| 所有按钮内边距 | `19px 40px` | 上下 19pt，左右 40pt |
| 所有按钮文字 | 30pt 'PingFang SC', 'Noto Sans SC', 'Source Han Sans SC', 'Microsoft YaHei', 'WenQuanYi Micro Hei', sans-serif Medium | @2x 对应 15pt @1x |
| 所有按钮字色 | `text-primary` | `#111111` |
| 按钮内图标 | 34×34pt | 可选，三个按钮均支持 |
| 按钮内价格 | visibility: hidden | 可选但在当前设计中隐藏 |
| 左侧图标入口与按钮区间距 | 12pt | `column-gap: 12px` |

> **icon-action-triple 按钮规格说明**：右侧三按钮均采用 `flex-grow: 1` 等分排列（`justify-content: start`），其中左1、左2为副按钮（描边），最右侧为主按钮（渐变）。与 `icon-action-split` 的主要区别在于：`icon-action-triple` 提供 2 个副操作选项而非 1 个，三按钮总宽均分 602pt（含两个 16pt 间距后每按钮约 190pt）。

### 3.7 左侧价格展示区（price-info，price-split 变体专属）

| 区域 | 值 | Token / 说明 |
|------|-----|-------------|
| 价格展示区宽度 | 100pt | `flex-shrink: 0`，固定宽 |
| 价格展示区高度 | 40pt | 与容器内部可用区等高 |
| 布局方向 | 横排 | `flex-direction: row`，图标与文字并排 |
| 内部对齐 | `justify-content: center`，`align-items: center` | 整体居中对齐 |
| 图标尺寸 | 36×36pt | `flex-shrink: 0`，小于增强型图标的 44pt |
| 图标与文字间距 | 8pt | `column-gap: 8px` |
| 文字宽高 | 56×40pt | 固定尺寸 |
| 文字颜色 | `text-tertiary` | `#888888`，三级辅助色（`color-semantic.md` §二 → `.Grey-3`） |
| 文字大小 | 28pt 'PingFang SC', 'Noto Sans SC', 'Source Han Sans SC', 'Microsoft YaHei', 'WenQuanYi Micro Hei', sans-serif Regular | @2x 对应 14pt @1x |
| 容器左 padding | 24pt | 与右侧 padding 对称（区别于图标入口变体的 12pt） |
| 容器右 padding | 24pt | 对称设计，`justify-content: space-between` 将两区域推向两端 |
| 容器整体对齐 | `justify-content: space-between` | 左右内容各自靠边，中间留白 |

> **price-split 左侧区域特殊性**：左侧为**价格/说明展示区**，而非可点击的图标入口。图标尺寸较小（36pt vs 44pt），文字使用三级辅助色 `text-tertiary`（`#888888`，`.Grey-3`），通常用于显示优惠提示、积分说明、配送费等辅助信息。该区域不接受点击交互（无 `onPress`）。容器使用对称 padding（左右各 24pt），整体布局采用 `space-between` 而非单向 gap。

### 3.8 胶囊组合按钮（capsule-combo 变体专属）

`capsule-combo` 支持两种宽度布局配置，通过 `capsuleLayout` 属性区分：

#### 3.8.1 等分配置（`capsuleLayout="symmetric"`，默认）

| 区域 | 值 | Token / 说明 |
|------|-----|-------------|
| 整体胶囊区域宽高 | 702×80pt | 总宽 702pt（容器 750pt - 左 24pt - 右 24pt），高 80pt |
| 左半（次操作）宽度 | `flex-grow: 1`（约 351pt） | 与右半等宽 |
| 右半（主操作）宽度 | `flex-grow: 1`（约 351pt） | 与左半等宽 |
| 两半间隙 | 0pt | 无间距、无描边，紧密拼合 |
| 左半圆角 | `40px 0 0 40px` | 仅左侧为圆角（`radius-full` 单侧），右侧平切 |
| 右半圆角 | `0 40px 40px 0` | 仅右侧为圆角（`radius-full` 单侧），左侧平切 |
| 左半背景 | `gradient-dark` | `linear-gradient(135deg, rgba(82,82,82,1) 0%, rgba(39,39,39,1) 100%)` |
| 右半背景 | `gradient-yellow` | `linear-gradient(135deg, rgba(255,231,77,1) 0%, rgba(255,221,0,1) 100%)` |
| 左半主文字颜色 | `text-warm-yellow` | `#FFF6B8`（暖黄色，与深灰背景形成对比） |
| 右半主文字颜色 | `text-primary` | `#111111` |
| 两半主文字大小 | 30pt 'PingFang SC', 'Noto Sans SC', 'Source Han Sans SC', 'Microsoft YaHei', 'WenQuanYi Micro Hei', sans-serif Medium | @2x 设计稿规格，@1x 对应 15pt（`subtitle-s-15-medium`） |
| 两半高度 | 80pt | 统一高度，与 @2x 其他变体一致 |
| 两半内布局方向 | `flex-direction: column` | 主文字行 + 可选副文字行，垂直排列 |
| 两半主文字行高 | 44px | `height: 44px; line-height: 44px` |
| 两半副文字行（可选） | 28px | `height: 28px; line-height: 28px`，`font-size: 20px`，`font-weight: 400`，颜色同主文字但透明度可降低；默认 `visibility: hidden` |
| 行间距（主文字与副文字） | -2px | `margin-top: -2px`（`>*:not(:first-child)`），两行紧凑叠放 |
| 价格子区域（可选） | `visibility: hidden` 可切换 | 内含 ¥符号（22pt MT New Digital Display）+ 数字（32pt MT New Digital Display），颜色同主文字；默认隐藏 |
| 容器左 padding | 24pt（`cs-24`） | 对称设计 |
| 容器右 padding | 24pt（`cs-24`） | 对称设计 |
| 容器顶部 padding | 16pt | @2x 设计稿 |

#### 3.8.2 非等分配置（`capsuleLayout="asymmetric"`）

| 区域 | 值 | Token / 说明 |
|------|-----|-------------|
| 整体胶囊区域宽高 | 702×80pt | 总宽 702pt（容器 750pt - 左 24pt - 右 24pt），高 80pt |
| 左半（次操作）宽度 | `flex-shrink: 0`，固定 248pt | `min-width: 248pt`，不随容器缩放，约占总宽 35% |
| 右半（主操作）宽度 | `flex-grow: 1`（约 454pt） | 弹性占满剩余空间，约占总宽 65% |
| 两半间隙 | 0pt | 无间距、无描边，紧密拼合 |
| 左半圆角 | `40px 0 0 40px` | 仅左侧为圆角（`radius-full` 单侧），右侧平切 |
| 右半圆角 | `0 40px 40px 0` | 仅右侧为圆角（`radius-full` 单侧），左侧平切 |
| 左半背景 | `gradient-dark` | `linear-gradient(135deg, rgba(82,82,82,1) 0%, rgba(39,39,39,1) 100%)` |
| 右半背景 | `gradient-yellow` | `linear-gradient(135deg, rgba(255,231,77,1) 0%, rgba(255,221,0,1) 100%)` |
| 左半主文字颜色 | `text-warm-yellow` | `#FFF6B8`（暖黄色，与深灰背景形成对比） |
| 右半主文字颜色 | `text-primary` | `#111111` |
| 两半主文字大小 | 30pt 'PingFang SC', 'Noto Sans SC', 'Source Han Sans SC', 'Microsoft YaHei', 'WenQuanYi Micro Hei', sans-serif Medium | @2x 设计稿规格，@1x 对应 15pt（`subtitle-s-15-medium`） |
| 两半高度 | 80pt | 统一高度 |
| 两半内布局方向 | `flex-direction: column` | 主文字行 + 可选副文字行，垂直排列 |
| 右半内部 padding | `19px 0px`（上下各 19pt） | 通过 padding 实现内容居中（区别于左半使用 `justify-content: center`） |
| 两半主文字行高 | 44px | `height: 44px; line-height: 44px` |
| 两半副文字行（可选） | 28px | `height: 28px; line-height: 28px`，`font-size: 20px`，`font-weight: 400`；默认 `visibility: hidden` |
| 左半副文字行颜色 | `text-warm-yellow` | `#FFF6B8`，与主文字一致 |
| 右半副文字行颜色 | `rgba(0,0,0,0.67)` | 深色半透明，与黄底配合；区别于左半的暖黄色 |
| 行间距（主文字与副文字） | -2px | `margin-top: -2px`（`>*:not(:first-child)`），两行紧凑叠放 |
| 价格子区域（可选） | `visibility: hidden` 可切换 | 内含 ¥符号（22pt MT New Digital Display）+ 数字（32pt MT New Digital Display），颜色同主文字；默认隐藏 |
| 容器左 padding | 24pt（`cs-24`） | 对称设计 |
| 容器右 padding | 24pt（`cs-24`） | 对称设计 |
| 容器顶部 padding | 16pt | @2x 设计稿 |

> **配置选择依据**：
> - `symmetric`（等分）：两操作的业务权重**完全相等**，视觉上需要同等强调（如"加入购物车"与"立即购买"在业务漏斗中同等重要）；两按钮在屏幕上各占一半，体现对等感
> - `asymmetric`（非等分）：次操作（左半）也是强引导，但**主操作的优先级略高**，需要给主操作更大的点击面积；或左侧次操作文字较短而不需要太多横向空间时使用。左半固定 248pt，右半约 454pt

> **capsule-combo 圆角特殊性**：左半仅左侧两角为圆（`border-radius: 40px 0 0 40px`），右半仅右侧两角为圆（`border-radius: 0 40px 40px 0`）。两半合并后整体外轮廓才是完整的胶囊形（`border-radius: 40px`），编码时**不可**对整体包裹元素设置 `border-radius`，而须分别对两个子元素设置半圆角。
>
> **左半文字颜色特殊性**：左半背景为深灰，主文字使用暖黄色 `#FFF6B8`（`text-warm-yellow`），而非标准的 `text-primary`（`#111111`）。若设计稿中颜色有变动，需重新确认语义 Token 映射。
>
> **非等分右半副文字颜色特殊性**：`asymmetric` 配置下，右半副文字行颜色为 `rgba(0,0,0,0.67)`（深色半透明），而非 `text-warm-yellow`，因为右半背景为黄色渐变（`gradient-yellow`），需要深色文字保证可读性。

---

## 4. 字体规格（@1x 基准尺寸）

| 区域 | 字体 Token | 说明 |
|------|-----------|------|
| 按钮主文字 | `subtitle-s-15-medium` | 'PingFang SC', 'Noto Sans SC', 'Source Han Sans SC', 'Microsoft YaHei', 'WenQuanYi Micro Hei', sans-serif，15pt，Medium，`text-primary` |
| 价格大号数字 | — | MT New Digital Display，16pt，Medium，`text-primary` |
| 价格单位（¥ 符号） | — | MT New Digital Display，11pt，Medium，`text-primary` |

> **价格字体说明**：价格数字使用 `MT New Digital Display` 专用数字字体，非系统字体。如无法加载，fallback 为 `'PingFang SC', 'Noto Sans SC', 'Source Han Sans SC', 'Microsoft YaHei', 'WenQuanYi Micro Hei', sans-serif`。

---

## 5. 详细布局结构

### 5.1 单按钮全宽（variant=single）

```
底部操作栏容器（375×48pt）
├── 顶部描边（375×0.5pt，divider-secondary）
└── 主操作按钮（351×40pt，margin: cs-9.5 cs-20，radius-full，gradient-yellow）
    ├── [可选] 图标（17×17pt，flex-shrink:0）
    ├── 主文字（subtitle-s-15-medium，text-primary）
    └── [可选] 价格区域（flex-row，visibility 由业务控制）
        ├── ¥符号（MT New Digital Display，11pt）
        └── 数字（MT New Digital Display，16pt）
```

### 5.2 双按钮并排（variant=double）

```
底部操作栏容器（375×48pt）
├── 顶部描边（375×0.5pt，divider-secondary）
├── 副操作按钮（171.5×40pt，margin-top: spacing-s，radius-full，border: border-bold stroke-strong）
│   ├── [可选] 图标（17×17pt）
│   └── 副操作文字（subtitle-s-15-medium，text-primary）
└── 主操作按钮（171.5×40pt，margin-top: spacing-s，radius-full，gradient-yellow）
    ├── [可选] 图标（17×17pt）
    ├── 主文字（subtitle-s-15-medium，text-primary）
    └── [可选] 价格区域（同单按钮）
```

### 5.3 三按钮并排（variant=triple）

```
底部操作栏容器（375×48pt）
├── 顶部描边（375×0.5pt，divider-secondary）
├── 副操作按钮1（111.67×40pt，margin-top: spacing-s，radius-full，border: border-bold stroke-strong）
│   ├── [可选] 图标（17×17pt）
│   └── 副操作文字（subtitle-s-15-medium，text-primary）
├── 副操作按钮2（111.67×40pt，margin-top: spacing-s，radius-full，border: border-bold stroke-strong）
│   ├── [可选] 图标（17×17pt）
│   └── 副操作文字（subtitle-s-15-medium，text-primary）
└── 主操作按钮（111.67×40pt，margin-top: spacing-s，radius-full，gradient-yellow）
    ├── [可选] 图标（17×17pt）
    └── 主文字（subtitle-s-15-medium，text-primary）
```

> **triple 说明**：三按钮均使用 `flex: 1` 等分，列间距均为 `spacing-s`（8pt）。通常左1副、左2副为不同的次要操作（如"收藏"、"加购"），最右侧为主操作（如"立即购买"）。

### 5.4 双排堆叠（variant=stack）

```
底部操作栏容器（375×96pt）
├── 顶部描边（375×0.5pt，divider-secondary）
├── 主操作按钮（351×40pt，margin-top: spacing-s，radius-full，gradient-yellow）← 第1行
│   ├── [可选] 图标（17×17pt）
│   ├── 主文字（subtitle-s-15-medium，text-primary）
│   └── [可选] 价格区域（MT New Digital Display）
└── 副操作按钮（351×40pt，margin-top: spacing-s，radius-full，border: border-bold stroke-strong）← 第2行
    ├── [可选] 图标（17×17pt）
    └── 副操作文字（subtitle-s-15-medium，text-primary）
```

> **stack 说明**：两行按钮均全宽（351pt），上行为主操作（渐变），下行为副操作（描边）。适用于主副操作均需要足够点击面积、横排空间不足以容纳的场景（如长文字操作标签）。

### 5.5 非等分双按钮（variant=asymmetric）

```
底部操作栏容器（375×48pt）
├── 顶部描边（375×0.5pt，divider-secondary）
├── 副操作按钮（112×40pt，flex-shrink:0，radius-full，border: border-bold stroke-strong）
│   ├── [可选] 图标（17×17pt）
│   └── 副操作文字（subtitle-s-15-medium，text-primary）
└── 主操作按钮（flex-grow:1 ≈231pt×40pt，radius-full，gradient-yellow）
    ├── [可选] 图标（17×17pt）
    ├── 主文字（subtitle-s-15-medium，text-primary）
    └── [可选] 价格区域（MT New Digital Display）
```

> **asymmetric 说明**：副按钮宽度固定 112pt（`flex-shrink: 0`），主按钮弹性占满剩余宽度（`flex-grow: 1`）。适用于副操作文字较短、主操作需要更大点击目标的场景（如“购物车” + “立即购买”）。

### 5.6 图标入口+主按钮—−1个图标入口（variant=icon-action）

```
底部操作栏容器（375×48pt），paddingLeft:6pt  paddingRight:12pt
├── 顶部描边（375×0.5pt，divider-secondary）
├── 图标入口区（共 50×38pt，flex-direction:row，gap:0pt）
│   └── 图标入口（50×38pt，flex-direction:column，align-items:center）
│       ├── 图标（22×22pt，flex-shrink:0）
│       └── 标签（caption-s-10-regular，text-primary，paddingTop:cs-2）
└── 主操作按钮（flex-grow:1×40pt，radius-full，gradient-yellow）
    ├── [可选] 图标（17×17pt）
    ├── 主文字（subtitle-s-15-medium，text-primary）
    └── [可选] 价格区域（MT New Digital Display）
```

### 5.7 图标入口+主按钮—−2个图标入口（variant=icon-action）

```
底部操作栏容器（375×48pt），paddingLeft:6pt  paddingRight:12pt
├── 顶部描边（375×0.5pt，divider-secondary）
├── 图标入口区（共 100×38pt，flex-direction:row，gap:0pt）
│   ├── 图标入口（50×38pt）：图标（22pt）+ 标签（caption-s-10-regular）
│   └── 图标入口（50×38pt）：图标（22pt）+ 标签（caption-s-10-regular）
└── 主操作按钮（flex-grow:1×40pt，radius-full，gradient-yellow）
    ├── [可选] 图标（17×17pt）
    ├── 主文字（subtitle-s-15-medium，text-primary）
    └── [可选] 价格区域（MT New Digital Display）
```

### 5.8 图标入口+主按钮—−3个图标入口（variant=icon-action）

```
底部操作栏容器（375×48pt），paddingLeft:6pt  paddingRight:12pt
├── 顶部描边（375×0.5pt，divider-secondary）
├── 图标入口区（共 150×38pt，flex-direction:row，gap:0pt）
│   ├── 图标入口（50×38pt）：图标（22pt）+ 标签（caption-s-10-regular）
│   ├── 图标入口（50×38pt）：图标（22pt）+ 标签（caption-s-10-regular）
│   └── 图标入口（50×38pt）：图标（22pt）+ 标签（caption-s-10-regular）
└── 主操作按钮（flex-grow:1×40pt，radius-full，gradient-yellow）
    ├── [可选] 图标（17×17pt）
    ├── 主文字（subtitle-s-15-medium，text-primary）
    └── [可选] 价格区域（MT New Digital Display）
```

### 5.9 图标入口+主按钮—−4个图标入口（variant=icon-action）

```
底部操作栏容器（375×48pt），paddingLeft:6pt  paddingRight:12pt
├── 顶部描边（375×0.5pt，divider-secondary）
├── 图标入口区（共 200×38pt，flex-direction:row，gap:0pt）
│   ├── 图标入口（50×38pt）：图标（22pt）+ 标签（caption-s-10-regular）
│   ├── 图标入口（50×38pt）：图标（22pt）+ 标签（caption-s-10-regular）
│   ├── 图标入口（50×38pt）：图标（22pt）+ 标签（caption-s-10-regular）
│   └── 图标入口（50×38pt）：图标（22pt）+ 标签（caption-s-10-regular）
└── 主操作按钮（flex-grow:1×40pt，radius-full，gradient-yellow）
    ├── [可选] 图标（17×17pt）
    ├── 主文字（subtitle-s-15-medium，text-primary）
    └── [可选] 价格区域（MT New Digital Display）
```

> **icon-action 内容说明**：图标入口区与主按钮之间间距为 6pt（column-gap）。随着图标入口数量增加，主按钮可用宽度减小，但 flex-grow:1 始终保证按钮占满剩余空间（含 4 个入口时主按钮宽度分配剩余 ≈ 145pt）。

### 5.10 增强型图标入口+双主按钮（variant=icon-action-double，@2x 设计稿规格）

```
底部操作栏容器（750×96pt @2x），paddingTop:16px paddingRight:24px paddingBottom:0px paddingLeft:12px
├── 顶部描边（750×0.5pt，divider-secondary `rgba(0,0,0,0.06)`，对应 border-default）
├── 左侧图标入口区（frame-37，200×76pt）
│   ├── 增强型图标入口1（frame-38，100×76pt，flex-direction:column，align-items:center）
│   │   ├── 图标（44×44pt，flex-shrink:0）
│   │   └── 标签（100×32pt，20pt 'PingFang SC', 'Noto Sans SC', 'Source Han Sans SC', 'Microsoft YaHei', 'WenQuanYi Micro Hei', sans-serif Regular，text-primary，padding-top:8pt）
│   └── 增强型图标入口2（frame-40，100×76pt，flex-direction:column，align-items:center）
│       ├── 图标（44×44pt，flex-shrink:0）
│       └── 标签（100×32pt，20pt 'PingFang SC', 'Noto Sans SC', 'Source Han Sans SC', 'Microsoft YaHei', 'WenQuanYi Micro Hei', sans-serif Regular，text-primary，padding-top:8pt）
└── 右侧主按钮区（frame-42，502×80pt，column-gap:16pt）
    ├── 主操作按钮1（instance-54，243×80pt，radius-full，gradient-yellow）
    │   ├── 图标（34×34pt，flex-shrink:0）
    │   ├── 主文字（90×44pt，30pt 'PingFang SC', 'Noto Sans SC', 'Source Han Sans SC', 'Microsoft YaHei', 'WenQuanYi Micro Hei', sans-serif Medium，text-primary）
    │   └── [可选] 价格区域（visibility: hidden）
    └── 主操作按钮2（instance-57，243×80pt，radius-full，gradient-yellow）
        ├── 图标（34×34pt，flex-shrink:0）
        ├── 主文字（90×44pt，30pt 'PingFang SC', 'Noto Sans SC', 'Source Han Sans SC', 'Microsoft YaHei', 'WenQuanYi Micro Hei', sans-serif Medium，text-primary）
        └── [可选] 价格区域（visibility: hidden）
```

> **icon-action-double 说明**：该变体设计用于 @2x 设计稿（750×1624pt 手机页面）。左侧为 2 个垂直堆叠的增强型图标入口（各 100pt 宽），图标 44×44pt、标签 20pt，间距 8pt。右侧为 2 个并排的大型主按钮（各 243pt 宽），按钮字体 30pt，两按钮间距 16pt。适用于需要强调多个功能快捷方式（如"客服"、"收藏"）并提供多个购买选项的场景。

### 5.11 增强型图标入口+副主按钮（variant=icon-action-split，@2x 设计稿规格）

```
底部操作栏容器（750×96pt @2x），paddingTop:16px paddingRight:24px paddingBottom:0px paddingLeft:12px
├── 顶部描边（750×0.5pt，divider-secondary `rgba(0,0,0,0.06)`，对应 border-default）
├── 左侧图标入口区（frame-45，100×76pt）
│   ├── 图标（44×44pt，flex-shrink:0）
│   └── 标签（100×32pt，20pt 'PingFang SC', 'Noto Sans SC', 'Source Han Sans SC', 'Microsoft YaHei', 'WenQuanYi Micro Hei', sans-serif Regular，text-primary，padding-top:8pt）
└── 右侧副+主按钮区（frame-47，602×80pt，column-gap:16pt，justify-content:end）
    ├── 副操作按钮（instance-61，293×80pt，radius-full，border: 1px solid #CCCCCC）
    │   ├── 图标（34×34pt，flex-shrink:0）
    │   ├── 主文字（90×44pt，30pt 'PingFang SC', 'Noto Sans SC', 'Source Han Sans SC', 'Microsoft YaHei', 'WenQuanYi Micro Hei', sans-serif Medium，text-primary）
    │   └── [可选] 价格区域（visibility: hidden）
    └── 主操作按钮（instance-64，293×80pt，radius-full，gradient-yellow）
        ├── 图标（34×34pt，flex-shrink:0）
        ├── 主文字（90×44pt，30pt 'PingFang SC', 'Noto Sans SC', 'Source Han Sans SC', 'Microsoft YaHei', 'WenQuanYi Micro Hei', sans-serif Medium，text-primary）
        └── [可选] 价格区域（visibility: hidden）
```

> **icon-action-split 说明**：该变体设计用于 @2x 设计稿（750×1624pt 手机页面）。左侧为 1 个单独的增强型图标入口（100pt 宽），图标 44×44pt、标签 20pt。右侧为 1 个副按钮（描边，293pt）+ 1 个主按钮（渐变，293pt）并排排列。按钮高度 80pt，字体 30pt，两按钮间距 16pt。适用于需要突出单一功能入口（如"购物车"）同时提供两个不同操作选项（如"加购" vs "立即购买"）的场景。

### 5.12 增强型图标入口+双副主按钮（variant=icon-action-triple，@2x 设计稿规格）

```
底部操作栏容器（750×96pt @2x），paddingTop:16px paddingRight:24px paddingBottom:0px paddingLeft:12px
├── 顶部描边（750×0.5pt，divider-secondary `rgba(0,0,0,0.06)`，对应 border-default）
├── 左侧图标入口区（frame-50，100×76pt，flex-shrink:0）
│   ├── 图标（44×44pt，flex-shrink:0）
│   └── 标签（100×28pt，20pt 'PingFang SC', 'Noto Sans SC', 'Source Han Sans SC', 'Microsoft YaHei', 'WenQuanYi Micro Hei', sans-serif Regular，text-primary，padding-top:4pt）
└── 右侧三按钮区（frame-52，602×80pt，column-gap:16pt，justify-content:start）
    ├── 副操作按钮1（instance-68，flex-grow:1≈190×80pt，radius-full，border: 1px solid #CCCCCC）
    │   ├── 图标（34×34pt，flex-shrink:0）
    │   ├── 主文字（113×44pt，30pt 'PingFang SC', 'Noto Sans SC', 'Source Han Sans SC', 'Microsoft YaHei', 'WenQuanYi Micro Hei', sans-serif Medium，text-primary）
    │   └── [可选] 价格区域（visibility: hidden）
    ├── 副操作按钮2（instance-71，flex-grow:1≈190×80pt，radius-full，border: 1px solid #CCCCCC）
    │   ├── 图标（34×34pt，flex-shrink:0）
    │   ├── 主文字（118×44pt，30pt 'PingFang SC', 'Noto Sans SC', 'Source Han Sans SC', 'Microsoft YaHei', 'WenQuanYi Micro Hei', sans-serif Medium，text-primary）
    │   └── [可选] 价格区域（visibility: hidden）
    └── 主操作按钮（instance-74，flex-grow:1≈190×80pt，radius-full，gradient-yellow）
        ├── 图标（34×34pt，flex-shrink:0）
        ├── 主文字（90×44pt，30pt 'PingFang SC', 'Noto Sans SC', 'Source Han Sans SC', 'Microsoft YaHei', 'WenQuanYi Micro Hei', sans-serif Medium，text-primary）
        └── [可选] 价格区域（visibility: hidden）
```

> **icon-action-triple 说明**：该变体设计用于 @2x 设计稿（750×1624pt 手机页面）。左侧为 1 个单独的增强型图标入口（100pt 宽，`flex-shrink:0`），图标 44×44pt、标签 20pt。右侧三按钮区（602pt，`flex-grow:1`）采用 `justify-content: start` 均匀分配，三个按钮均为 `flex-grow:1`（初始宽 190pt），间距 16pt。左1、左2为副按钮（描边），最右侧为主按钮（渐变）。适用于需要提供单一快捷功能入口且同时提供三种不同操作选项的场景（如"客服"入口 + "查看规格" + "加购" + "立即购买"）。

### 5.13 价格展示区+副主按钮（variant=price-split，@2x 设计稿规格）

```
底部操作栏容器（750×96pt @2x），paddingTop:16px paddingRight:24px paddingBottom:0px paddingLeft:24px，justify-content:space-between
├── 顶部描边（750×0.5pt，divider-secondary `rgba(0,0,0,0.06)`，对应 border-default）
├── 左侧价格展示区（frame-56，100×40pt，flex-shrink:0，flex-direction:row，justify-content:center，align-items:center，column-gap:8pt）
│   ├── 图标（36×36pt，flex-shrink:0）
│   └── 说明/价格文字（56×40pt，28pt 'PingFang SC', 'Noto Sans SC', 'Source Han Sans SC', 'Microsoft YaHei', 'WenQuanYi Micro Hei', sans-serif Regular，text-tertiary `#888888`）
└── 右侧副+主按钮区（frame-57，502×80pt，column-gap:16pt，justify-content:end）
    ├── 副操作按钮（instance-78，flex-grow:1≈243×80pt，radius-full，border: 1px solid #CCCCCC）
    │   ├── 图标（34×34pt，flex-shrink:0）
    │   ├── 主文字（90×44pt，30pt 'PingFang SC', 'Noto Sans SC', 'Source Han Sans SC', 'Microsoft YaHei', 'WenQuanYi Micro Hei', sans-serif Medium，text-primary `#111111`）
    │   └── [可选] 价格区域（visibility: hidden）
    └── 主操作按钮（instance-81，flex-grow:1≈243×80pt，radius-full，gradient-yellow）
        ├── 图标（34×34pt，flex-shrink:0）
        ├── 主文字（90×44pt，30pt 'PingFang SC', 'Noto Sans SC', 'Source Han Sans SC', 'Microsoft YaHei', 'WenQuanYi Micro Hei', sans-serif Medium，text-primary `#111111`）
        └── [可选] 价格区域（visibility: hidden）
```

> **price-split 说明**：该变体设计用于 @2x 设计稿（750×1624pt 手机页面）。左侧为纯展示型价格/说明区（100pt 宽，`flex-shrink:0`），内含 36pt 小图标和 28pt 灰色文字（`text-tertiary`，`#888888`），不可点击。右侧为副按钮（描边，`flex-grow:1`）+ 主按钮（渐变，`flex-grow:1`），间距 16pt。容器整体采用 `justify-content: space-between` 将左右两区推向两端，左右 padding 对称均为 24pt。适用于需要同时展示优惠信息/配送说明且提供双按钮操作的场景。

### 5.14 胶囊组合按钮（variant=capsule-combo，@2x 设计稿规格）

```
底部操作栏容器（750×96pt @2x），paddingTop:16px paddingRight:24px paddingBottom:0px paddingLeft:24px
├── 顶部描边（750×0.5pt，divider-secondary `rgba(0,0,0,0.06)`，对应 border-default）
└── 胶囊组合区（instance，702×80pt，flex-direction:row，gap:0pt）
    └── 胶囊内容（frame，702×80pt，flex-direction:row，justify-content:start，align-items:start）
        ├── 左半—次操作（frame-1，flex-grow:1≈351×80pt，min-width:195pt）
        │   ├── border-radius: 40px 0 0 40px
        │   ├── background: gradient-dark（linear-gradient(135deg, #525252 0%, #272727 100%)）
        │   ├── flex-direction: column，justify-content: center，align-items: center
        │   ├── 主文字行（frame-2，150×44pt）
        │   │   ├── 主标签文字（150×44pt，30pt 'PingFang SC', 'Noto Sans SC', 'Source Han Sans SC', 'Microsoft YaHei', 'WenQuanYi Micro Hei', sans-serif Medium，text-warm-yellow `#FFF6B8`，text-align:center）
        │   │   └── [可选] 价格子区域（visibility: hidden）
        │   │       ├── ¥符号（14×32pt，22pt MT New Digital Display，text-warm-yellow）
        │   │       └── 数字（82×44pt，32pt MT New Digital Display，text-warm-yellow）
        │   └── [可选] 副文字行（frame-4，140×28pt，visibility: hidden）
        │       ├── 说明文字（100×28pt，20pt 'PingFang SC', 'Noto Sans SC', 'Source Han Sans SC', 'Microsoft YaHei', 'WenQuanYi Micro Hei', sans-serif Regular，text-warm-yellow，text-align:center）
        │       └── 附加说明（33×28pt，20pt 'PingFang SC', 'Noto Sans SC', 'Source Han Sans SC', 'Microsoft YaHei', 'WenQuanYi Micro Hei', sans-serif Regular，text-warm-yellow，text-align:center）
        └── 右半—主操作（frame-5，flex-grow:1≈351×80pt，min-width:195pt）
            ├── border-radius: 0 40px 40px 0
            ├── background: gradient-yellow（linear-gradient(135deg, rgba(255,231,77,1) 0%, rgba(255,221,0,1) 100%)）
            ├── flex-direction: column，justify-content: center，align-items: center
            ├── 主文字行（frame-6，120×44pt）
            │   ├── 主标签文字（120×44pt，30pt 'PingFang SC', 'Noto Sans SC', 'Source Han Sans SC', 'Microsoft YaHei', 'WenQuanYi Micro Hei', sans-serif Medium，text-primary `#111111`，text-align:center）
            │   └── [可选] 价格子区域（visibility: hidden）
            │       ├── ¥符号（14×32pt，22pt MT New Digital Display，text-primary）
            │       └── 数字（82×44pt，32pt MT New Digital Display，text-primary）
            └── [可选] 副文字行（frame-8，100×28pt，visibility: hidden）
                └── 说明文字（100×28pt，20pt 'PingFang SC', 'Noto Sans SC', 'Source Han Sans SC', 'Microsoft YaHei', 'WenQuanYi Micro Hei', sans-serif Regular，rgba(0,0,0,0.67)，text-align:center）
```

> **capsule-combo 等分（symmetric）说明**：该配置用于 @2x 设计稿（750×1624pt 手机页面）。两半无间隙并排拼合为视觉上的单一胶囊体，各占约 351pt（等宽）。左半（次操作）使用深灰渐变背景搭配暖黄文字（`#FFF6B8`）；右半（主操作）使用黄色渐变背景搭配深黑文字（`#111111`）。两半均支持可选价格子区域和可选副文字行（默认隐藏）。适用于两个操作权重相近、均需强视觉引导的场景。

### 5.15 胶囊组合按钮—非等分（variant=capsule-combo, capsuleLayout=asymmetric，@2x 设计稿规格）

```
底部操作栏容器（750×96pt @2x），paddingTop:16px paddingRight:24px paddingBottom:0px paddingLeft:24px
├── 顶部描边（750×0.5pt，divider-secondary `rgba(0,0,0,0.06)`，对应 border-default）
└── 胶囊组合区（instance，702×80pt，flex-direction:row，gap:0pt）
    └── 胶囊内容（frame，702×80pt，flex-direction:row，justify-content:start，align-items:start）
        ├── 左半—次操作（frame-9，flex-shrink:0，248×80pt，min-width:248pt）
        │   ├── border-radius: 40px 0 0 40px
        │   ├── background: gradient-dark（linear-gradient(135deg, #525252 0%, #272727 100%)）
        │   ├── flex-direction: column，justify-content: center，align-items: center
        │   ├── 主文字行（frame-10，150×44pt，column-gap:4px）
        │   │   ├── 主标签文字（150×44pt，30pt 'PingFang SC', 'Noto Sans SC', 'Source Han Sans SC', 'Microsoft YaHei', 'WenQuanYi Micro Hei', sans-serif Medium，text-warm-yellow `#FFF6B8`，text-align:center）
        │   │   └── [可选] 价格子区域（instance-4，78×44pt，visibility: hidden）
        │   │       ├── ¥符号（text--2，14×32pt，22pt MT New Digital Display，text-warm-yellow）
        │   │       └── 数字帧（frame-11，82×44pt）
        │   │           ├── 整数部分（text-74，35×44pt，32pt MT New Digital Display，text-warm-yellow）
        │   │           └── 小数部分（text-90，27×44pt，32pt MT New Digital Display，text-warm-yellow）
        │   └── [可选] 副文字行（frame-12，140×28pt，visibility: hidden，column-gap:4px）
        │       ├── 说明文字（text-5，100×28pt，20pt 'PingFang SC', 'Noto Sans SC', 'Source Han Sans SC', 'Microsoft YaHei', 'WenQuanYi Micro Hei', sans-serif Regular，text-warm-yellow，text-align:center）
        │       └── 附加说明（text-11，33×28pt，20pt 'PingFang SC', 'Noto Sans SC', 'Source Han Sans SC', 'Microsoft YaHei', 'WenQuanYi Micro Hei', sans-serif Regular，text-warm-yellow，text-align:center）
        └── 右半—主操作（frame-13，flex-grow:1≈454×80pt，padding:19px 0px 19px 0px）
            ├── border-radius: 0 40px 40px 0
            ├── background: gradient-yellow（linear-gradient(135deg, rgba(255,231,77,1) 0%, rgba(255,221,0,1) 100%)）
            ├── flex-direction: column，justify-content: center，align-items: center
            ├── 主文字行（frame-14，120×44pt，column-gap:4px）
            │   ├── 主标签文字（text-6，120×44pt，30pt 'PingFang SC', 'Noto Sans SC', 'Source Han Sans SC', 'Microsoft YaHei', 'WenQuanYi Micro Hei', sans-serif Medium，text-primary `#111111`，text-align:center）
            │   └── [可选] 价格子区域（instance-5，78×44pt，visibility: hidden）
            │       ├── ¥符号（text--3，14×32pt，22pt MT New Digital Display，text-primary）
            │       └── 数字帧（frame-15，82×44pt）
            │           ├── 整数部分（text-75，35×44pt，32pt MT New Digital Display，text-primary）
            │           └── 小数部分（text-91，27×44pt，32pt MT New Digital Display，text-primary）
            └── [可选] 副文字行（frame-16，100×28pt，visibility: hidden，column-gap:4px）
                └── 说明文字（text-7，100×28pt，20pt 'PingFang SC', 'Noto Sans SC', 'Source Han Sans SC', 'Microsoft YaHei', 'WenQuanYi Micro Hei', sans-serif Regular，rgba(0,0,0,0.67)，text-align:center）
```

> **capsule-combo 非等分（asymmetric）说明**：该配置用于 @2x 设计稿。左半固定宽 248pt（`flex-shrink: 0`），右半弹性占满剩余约 454pt（`flex-grow: 1`）。两半总宽同为 702pt，无间隙拼合。右半通过 `padding: 19px 0px` 而非 `justify-content: center` 实现内容垂直居中（与等分配置的居中方式不同）。右半副文字行颜色为 `rgba(0,0,0,0.67)`（深色半透明），适应黄色背景；左半副文字行颜色仍为 `text-warm-yellow`（`#FFF6B8`），适应深灰背景。适用于主操作需要更大点击面积或次操作文字较短的场景。

### 5.16 增强型图标入口+胶囊组合（variant=icon-capsule-combo，@2x 设计稿规格）

```
底部操作栏容器（750×96pt @2x），paddingTop:16px paddingRight:24px paddingBottom:0px paddingLeft:12px，column-gap:12px
├── 顶部描边（750×0.5pt，divider-secondary `rgba(0,0,0,0.06)`，对应 border-default）
├── 左侧图标入口区（frame-17，100×76pt，flex-shrink:0，flex-direction:column，align-items:center）
│   ├── 图标（instance-6，44×44pt，flex-shrink:0）
│   └── 标签容器（frame-18，100×32pt，flex-direction:column，justify-content:start，align-items:start，padding-top:4pt）
│       └── 标签文字（text-8，100×28pt，20pt 'PingFang SC', 'Noto Sans SC', 'Source Han Sans SC', 'Microsoft YaHei', 'WenQuanYi Micro Hei', sans-serif Regular，text-primary `#111111`，text-align:center，line-height:28px）
└── 右侧胶囊组合区（instance-7，flex-grow:1 即 602×80pt）
    └── 胶囊内容（frame-19，602×80pt，flex-direction:row，justify-content:start，align-items:start，gap:0pt）
        ├── 左半—次操作（frame-20，flex-grow:1≈301×80pt，min-width:195pt）
        │   ├── border-radius: 40px 0 0 40px
        │   ├── background: gradient-dark（linear-gradient(135deg, rgba(82,82,82,1) 0%, rgba(39,39,39,1) 100%)）
        │   ├── flex-direction: column，justify-content: center，align-items: center
        │   ├── >*:not(:first-child) { margin-top: -2px }
        │   ├── 主文字行（frame-21，150×44pt，column-gap:4px）
        │   │   ├── 主标签文字（text-9，150×44pt，30pt 'PingFang SC', 'Noto Sans SC', 'Source Han Sans SC', 'Microsoft YaHei', 'WenQuanYi Micro Hei', sans-serif Medium，text-warm-yellow `#FFF6B8`，text-align:center）
        │   │   └── [可选] 价格子区域（instance-8，78×44pt，visibility: hidden）
        │   │       ├── ¥符号（text--4，14×32pt，22pt MT New Digital Display，text-warm-yellow）
        │   │       └── 数字帧（frame-22，82×44pt）
        │   │           ├── 整数部分（text-76，35×44pt，32pt MT New Digital Display，text-warm-yellow）
        │   │           └── 小数部分（text-92，27×44pt，32pt MT New Digital Display，text-warm-yellow）
        │   └── [可选] 副文字行（frame-23，140×28pt，visibility: hidden，column-gap:4px）
        │       ├── 说明文字（text-12，100×28pt，20pt 'PingFang SC', 'Noto Sans SC', 'Source Han Sans SC', 'Microsoft YaHei', 'WenQuanYi Micro Hei', sans-serif Regular，text-warm-yellow，text-align:center）
        │       └── 附加说明（text-13，33×28pt，20pt 'PingFang SC', 'Noto Sans SC', 'Source Han Sans SC', 'Microsoft YaHei', 'WenQuanYi Micro Hei', sans-serif Regular，text-warm-yellow，text-align:center）
        └── 右半—主操作（frame-24，flex-grow:1≈301×80pt，min-width:195pt）
            ├── border-radius: 0 40px 40px 0
            ├── background: gradient-yellow（linear-gradient(135deg, rgba(255,231,77,1) 0%, rgba(255,221,0,1) 100%)）
            ├── flex-direction: column，justify-content: center，align-items: center
            ├── >*:not(:first-child) { margin-top: -2px }
            ├── 主文字行（frame-25，120×44pt，column-gap:4px）
            │   ├── 主标签文字（text-14，120×44pt，30pt 'PingFang SC', 'Noto Sans SC', 'Source Han Sans SC', 'Microsoft YaHei', 'WenQuanYi Micro Hei', sans-serif Medium，text-primary `#111111`，text-align:center）
            │   └── [可选] 价格子区域（instance-9，78×44pt，visibility: hidden）
            │       ├── ¥符号（text--5，14×32pt，22pt MT New Digital Display，text-primary）
            │       └── 数字帧（frame-26，82×44pt）
            │           ├── 整数部分（text-77，35×44pt，32pt MT New Digital Display，text-primary）
            │           └── 小数部分（text-93，27×44pt，32pt MT New Digital Display，text-primary）
            └── [可选] 副文字行（frame-27，100×28pt，visibility: hidden，column-gap:4px）
                └── 说明文字（text-15，100×28pt，20pt 'PingFang SC', 'Noto Sans SC', 'Source Han Sans SC', 'Microsoft YaHei', 'WenQuanYi Micro Hei', sans-serif Regular，rgba(0,0,0,0.67)，text-align:center）
```

> **icon-capsule-combo 等分（symmetric）说明**：该配置设计用于 @2x 设计稿（750×1624pt 手机页面）。左侧为 1 个可点击的增强型图标入口（100pt，`flex-shrink:0`），图标 44×44pt，标签 20pt，标签 `padding-top: 4px`（区别于 `icon-action-split` 的 8px）。右侧胶囊组合区（602pt，`flex-grow:1`）内两半各 `flex-grow:1`（等宽约 301pt，初始 `width: 301px`，`min-width: 195px`），无间隙拼合；左半深灰渐变+暖黄文字（次操作），右半黄色渐变+深黑文字（主操作）；两半均通过 `justify-content: center` 实现内容居中，通过 `margin-top: -2px` 使主副文字行紧凑叠放。容器左 padding 12pt（非对称，区别于 `capsule-combo` 的 24pt），图标入口与胶囊区 gap 12pt。适用于需要额外功能快捷入口（如"客服"）同时提供两个同等强引导操作且主次权重相近的场景。若主操作需要更大点击面积，可使用 `capsuleLayout="asymmetric"` 非等分配置（见 §5.17）。

### 5.17 增强型图标入口+胶囊组合—非等分（variant=icon-capsule-combo, capsuleLayout=asymmetric，@2x 设计稿规格）

```
底部操作栏容器（750×96pt @2x），paddingTop:16px paddingRight:24px paddingBottom:0px paddingLeft:12px，column-gap:12px
├── 顶部描边（750×0.5pt，divider-secondary `rgba(0,0,0,0.06)`，对应 border-default）
├── 左侧图标入口区（frame-28，100×76pt，flex-shrink:0，flex-direction:column，align-items:center）
│   ├── 图标（instance-10，44×44pt，flex-shrink:0）
│   └── 标签容器（frame-29，100×32pt，flex-direction:column，justify-content:start，align-items:start，padding-top:4pt）
│       └── 标签文字（text-16，100×28pt，20pt 'PingFang SC', 'Noto Sans SC', 'Source Han Sans SC', 'Microsoft YaHei', 'WenQuanYi Micro Hei', sans-serif Regular，text-primary `#111111`，text-align:center，line-height:28px）
└── 右侧胶囊组合区（instance-11，flex-grow:1 即 602×80pt）
    └── 胶囊内容（602×80pt，flex-direction:row，justify-content:start，align-items:start，gap:0pt）
        ├── 左半—次操作（frame-30，flex-shrink:0，248×80pt，min-width:248pt）
        │   ├── border-radius: 40px 0 0 40px
        │   ├── background: gradient-dark（linear-gradient(135deg, rgba(82,82,82,1) 0%, rgba(39,39,39,1) 100%)）
        │   ├── flex-direction: column，justify-content: center，align-items: center
        │   ├── >*:not(:first-child) { margin-top: -2px }
        │   ├── 主文字行（frame-31，150×44pt，column-gap:4px）
        │   │   ├── 主标签文字（text-17，150×44pt，30pt 'PingFang SC', 'Noto Sans SC', 'Source Han Sans SC', 'Microsoft YaHei', 'WenQuanYi Micro Hei', sans-serif Medium，text-warm-yellow `#FFF6B8`，text-align:center）
        │   │   └── [可选] 价格子区域（instance-12，78×44pt，visibility: hidden）
        │   │       ├── ¥符号（text--6，14×32pt，22pt MT New Digital Display，text-warm-yellow）
        │   │       └── 数字帧（frame-32，82×44pt）
        │   │           ├── 整数部分（text-78，35×44pt，32pt MT New Digital Display，text-warm-yellow）
        │   │           └── 小数部分（text-94，27×44pt，32pt MT New Digital Display，text-warm-yellow）
        │   └── [可选] 副文字行（frame-33，140×28pt，visibility: hidden，column-gap:4px）
        │       ├── 说明文字（text-18，100×28pt，20pt 'PingFang SC', 'Noto Sans SC', 'Source Han Sans SC', 'Microsoft YaHei', 'WenQuanYi Micro Hei', sans-serif Regular，text-warm-yellow，text-align:center）
        │       └── 附加说明（text-19，33×28pt，20pt 'PingFang SC', 'Noto Sans SC', 'Source Han Sans SC', 'Microsoft YaHei', 'WenQuanYi Micro Hei', sans-serif Regular，text-warm-yellow，text-align:center）
        └── 右半—主操作（frame-34，flex-grow:1≈354×80pt，padding:19px 0px 19px 0px）
            ├── border-radius: 0 40px 40px 0
            ├── background: gradient-yellow（linear-gradient(135deg, rgba(255,231,77,1) 0%, rgba(255,221,0,1) 100%)）
            ├── flex-direction: column，justify-content: center，align-items: center
            ├── >*:not(:first-child) { margin-top: -2px }
            ├── 主文字行（frame-35，120×44pt，column-gap:4px）
            │   ├── 主标签文字（text-20，120×44pt，30pt 'PingFang SC', 'Noto Sans SC', 'Source Han Sans SC', 'Microsoft YaHei', 'WenQuanYi Micro Hei', sans-serif Medium，text-primary `#111111`，text-align:center）
            │   └── [可选] 价格子区域（instance-13，78×44pt，visibility: hidden）
            │       ├── ¥符号（text--7，14×32pt，22pt MT New Digital Display，text-primary）
            │       └── 数字帧（frame-36，82×44pt）
            │           ├── 整数部分（text-79，35×44pt，32pt MT New Digital Display，text-primary）
            │           └── 小数部分（text-95，27×44pt，32pt MT New Digital Display，text-primary）
            └── [可选] 副文字行（frame-37，100×28pt，visibility: hidden，column-gap:4px）
                └── 说明文字（text-21，100×28pt，20pt 'PingFang SC', 'Noto Sans SC', 'Source Han Sans SC', 'Microsoft YaHei', 'WenQuanYi Micro Hei', sans-serif Regular，rgba(0,0,0,0.67)，text-align:center）
```

> **icon-capsule-combo 非等分（asymmetric）说明**：该配置设计用于 @2x 设计稿。与等分配置的区别在于右侧胶囊内部布局：左半为**固定宽 248pt**（`flex-shrink:0`，`min-width:248px`），右半为**弹性宽约 354pt**（`flex-grow:1`）。两半总宽仍为 602pt，无间隙拼合。右半通过 `padding: 19px 0px` 而非 `justify-content: center` 实现内容垂直居中（与等分配置的居中方式不同）。右半副文字颜色为 `rgba(0,0,0,0.67)`（深色半透明），适应黄色背景；左半副文字颜色仍为 `text-warm-yellow`（`#FFF6B8`），适应深灰背景。容器和图标入口与等分配置完全相同（左 padding 12pt，gap 12pt，图标入口 `padding-top:4pt`）。适用于主操作需要更大点击面积、或次操作文字较短（如"预约"）时，使右侧主操作（如"立即购买"）获得更宽的按压区域。

### 5.19 双增强型图标入口+胶囊组合（variant=double-icon-capsule-combo，@2x 设计稿规格）

```
底部操作栏容器（750×96pt @2x），paddingTop:16px paddingRight:24px paddingBottom:0px paddingLeft:12px，column-gap:12px
├── 顶部描边（750×0.5pt，divider-secondary `rgba(0,0,0,0.06)`，对应 border-default）
├── 左侧双图标入口区（frame-38，200×76pt，flex-shrink:0，flex-direction:row，align-items:start，gap:0pt）
│   ├── 图标入口1（frame-39，100×76pt，flex-shrink:0，flex-direction:column，align-items:center）
│   │   ├── 图标（instance-14，44×44pt，flex-shrink:0）
│   │   └── 标签容器（frame-40，100×32pt，flex-direction:column，justify-content:start，align-items:start，padding-top:4pt）
│   │       └── 标签文字（text-22，100×28pt，20pt 'PingFang SC', 'Noto Sans SC', 'Source Han Sans SC', 'Microsoft YaHei', 'WenQuanYi Micro Hei', sans-serif Regular，text-primary `#111111`，text-align:center，line-height:28px）
│   └── 图标入口2（frame-41，100×76pt，flex-shrink:0，flex-direction:column，align-items:center）
│       ├── 图标（instance-15，44×44pt，flex-shrink:0）
│       └── 标签容器（frame-42，100×32pt，flex-direction:column，justify-content:start，align-items:start，padding-top:4pt）
│           └── 标签文字（text-23，100×28pt，20pt 'PingFang SC', 'Noto Sans SC', 'Source Han Sans SC', 'Microsoft YaHei', 'WenQuanYi Micro Hei', sans-serif Regular，text-primary `#111111`，text-align:center，line-height:28px）
└── 右侧胶囊组合区（instance-16，flex-grow:1 即 502×80pt）
    └── 胶囊内容（frame-43，502×80pt，flex-direction:row，justify-content:start，align-items:start，gap:0pt）
        ├── 左半—次操作（frame-44，flex-grow:1≈251×80pt，min-width:195pt）
        │   ├── border-radius: 40px 0 0 40px
        │   ├── background: gradient-dark（linear-gradient(135deg, rgba(82,82,82,1) 0%, rgba(39,39,39,1) 100%)）
        │   ├── flex-direction: column，justify-content: center，align-items: center
        │   ├── >*:not(:first-child) { margin-top: -2px }
        │   ├── 主文字行（frame-45，150×44pt，column-gap:4px）
        │   │   ├── 主标签文字（text-24，150×44pt，30pt 'PingFang SC', 'Noto Sans SC', 'Source Han Sans SC', 'Microsoft YaHei', 'WenQuanYi Micro Hei', sans-serif Medium，text-warm-yellow `#FFF6B8`，text-align:center）
        │   │   └── [可选] 价格子区域（instance-17，78×44pt，visibility: hidden）
        │   │       ├── ¥符号（text--8，14×32pt，22pt MT New Digital Display，text-warm-yellow）
        │   │       └── 数字帧（frame-46，82×44pt）
        │   │           ├── 整数部分（text-80，35×44pt，32pt MT New Digital Display，text-warm-yellow）
        │   │           └── 小数部分（text-96，27×44pt，32pt MT New Digital Display，text-warm-yellow）
        │   └── [可选] 副文字行（frame-47，137×28pt，visibility: hidden，column-gap:4px）
        │       ├── 说明文字（text-25，100×28pt，20pt 'PingFang SC', 'Noto Sans SC', 'Source Han Sans SC', 'Microsoft YaHei', 'WenQuanYi Micro Hei', sans-serif Regular，text-warm-yellow，text-align:center）
        │       └── 附加说明（text-26，33×28pt，20pt 'PingFang SC', 'Noto Sans SC', 'Source Han Sans SC', 'Microsoft YaHei', 'WenQuanYi Micro Hei', sans-serif Regular，text-warm-yellow，text-align:center）
        └── 右半—主操作（frame-48，flex-grow:1≈251×80pt，min-width:195pt）
            ├── border-radius: 0 40px 40px 0
            ├── background: gradient-yellow（linear-gradient(135deg, rgba(255,231,77,1) 0%, rgba(255,221,0,1) 100%)）
            ├── flex-direction: column，justify-content: center，align-items: center
            ├── >*:not(:first-child) { margin-top: -2px }
            ├── 主文字行（frame-49，120×44pt，column-gap:4px）
            │   ├── 主标签文字（text-27，120×44pt，30pt 'PingFang SC', 'Noto Sans SC', 'Source Han Sans SC', 'Microsoft YaHei', 'WenQuanYi Micro Hei', sans-serif Medium，text-primary `#111111`，text-align:center）
            │   └── [可选] 价格子区域（instance-18，78×44pt，visibility: hidden）
            │       ├── ¥符号（text--9，14×32pt，22pt MT New Digital Display，text-primary）
            │       └── 数字帧（frame-50，82×44pt）
            │           ├── 整数部分（text-81，35×44pt，32pt MT New Digital Display，text-primary）
            │           └── 小数部分（text-97，27×44pt，32pt MT New Digital Display，text-primary）
            └── [可选] 副文字行（frame-51，100×28pt，visibility: hidden，column-gap:4px）
                └── 说明文字（text-28，100×28pt，20pt 'PingFang SC', 'Noto Sans SC', 'Source Han Sans SC', 'Microsoft YaHei', 'WenQuanYi Micro Hei', sans-serif Regular，rgba(0,0,0,0.67)，text-align:center）
```

> **double-icon-capsule-combo 说明**：该配置设计用于 @2x 设计稿（750×1624pt 手机页面）。左侧为 **2 个**可点击的增强型图标入口（各 100pt，总宽 200pt，`flex-shrink:0`），两入口横排排列（`flex-direction: row`，`gap: 0pt`）；每个入口图标 44×44pt，标签 20pt，`padding-top: 4px`（与 `icon-capsule-combo` 一致）。右侧胶囊组合区（`flex-grow:1`，约 502pt）内两半各 `flex-grow:1`（等宽约 251pt，`min-width: 195px`），无间隙拼合；左半深灰渐变+暖黄文字（次操作），右半黄色渐变+深黑文字（主操作）；两半均通过 `justify-content: center` + `margin-top: -2px` 实现内容居中和紧凑叠放。容器左 padding 12pt，双图标入口区与胶囊区 gap 12pt。适用于需要同时提供 **2 个功能快捷入口**（如"客服"+"收藏"）并配合双强操作胶囊的场景。与 `icon-capsule-combo` 的主要区别：图标入口数量为 2 个，右侧胶囊总宽从 602pt 缩短为 502pt，两半各约 251pt（而非 301pt）。

### 5.20 三增强型图标入口+胶囊组合（variant=triple-icon-capsule-combo，@2x 设计稿规格）

```
底部操作栏容器（750×96pt @2x），paddingTop:16px paddingRight:24px paddingBottom:0px paddingLeft:12px，column-gap:12px
├── 顶部描边（750×0.5pt，divider-secondary `rgba(0,0,0,0.06)`，对应 border-default）
├── 左侧三图标入口区（frame-52，300×76pt，flex-shrink:0，flex-direction:row，align-items:start，gap:0pt）
│   ├── 图标入口1（frame-53，100×76pt，flex-shrink:0，flex-direction:column，align-items:center）
│   │   ├── 图标（instance-19，44×44pt，flex-shrink:0）
│   │   └── 标签容器（frame-54，100×32pt，flex-direction:column，justify-content:start，align-items:start，padding-top:4pt）
│   │       └── 标签文字（text-29，100×28pt，20pt 'PingFang SC', 'Noto Sans SC', 'Source Han Sans SC', 'Microsoft YaHei', 'WenQuanYi Micro Hei', sans-serif Regular，text-primary `#111111`，text-align:center，line-height:28px）
│   ├── 图标入口2（frame-55，100×76pt，flex-shrink:0，flex-direction:column，align-items:center）
│   │   ├── 图标（instance-20，44×44pt，flex-shrink:0）
│   │   └── 标签容器（frame-56，100×32pt，flex-direction:column，justify-content:start，align-items:start，padding-top:4pt）
│   │       └── 标签文字（text-30，100×28pt，20pt 'PingFang SC', 'Noto Sans SC', 'Source Han Sans SC', 'Microsoft YaHei', 'WenQuanYi Micro Hei', sans-serif Regular，text-primary `#111111`，text-align:center，line-height:28px）
│   └── 图标入口3（frame-57，100×76pt，flex-shrink:0，flex-direction:column，align-items:center）
│       ├── 图标（instance-21，44×44pt，flex-shrink:0）
│       └── 标签容器（frame-58，100×32pt，flex-direction:column，justify-content:start，align-items:start，padding-top:4pt）
│           └── 标签文字（text-31，100×28pt，20pt 'PingFang SC', 'Noto Sans SC', 'Source Han Sans SC', 'Microsoft YaHei', 'WenQuanYi Micro Hei', sans-serif Regular，text-primary `#111111`，text-align:center，line-height:28px）
└── 右侧胶囊组合区（instance-22，flex-grow:1 即 402×80pt）
    └── 胶囊内容（frame-59，402×80pt，flex-direction:row，justify-content:start，align-items:start，gap:0pt）
        ├── 左半—次操作（frame-60，flex-grow:1≈201×80pt，min-width:195pt）
        │   ├── border-radius: 40px 0 0 40px
        │   ├── background: gradient-dark（linear-gradient(135deg, rgba(82,82,82,1) 0%, rgba(39,39,39,1) 100%)）
        │   ├── flex-direction: column，justify-content: center，align-items: center
        │   ├── >*:not(:first-child) { margin-top: -2px }
        │   ├── 主文字行（frame-61，150×44pt，column-gap:4px）
        │   │   ├── 主标签文字（text-32，150×44pt，30pt 'PingFang SC', 'Noto Sans SC', 'Source Han Sans SC', 'Microsoft YaHei', 'WenQuanYi Micro Hei', sans-serif Medium，text-warm-yellow `#FFF6B8`，text-align:center）
        │   │   └── [可选] 价格子区域（instance-23，78×44pt，visibility: hidden）
        │   │       ├── ¥符号（text--10，14×32pt，22pt MT New Digital Display，text-warm-yellow）
        │   │       └── 数字帧（frame-62，82×44pt）
        │   │           ├── 整数部分（text-82，35×44pt，32pt MT New Digital Display，text-warm-yellow）
        │   │           └── 小数部分（text-98，27×44pt，32pt MT New Digital Display，text-warm-yellow）
        │   └── [可选] 副文字行（frame-63，140×28pt，visibility: hidden，column-gap:4px）
        │       ├── 说明文字（text-33，100×28pt，20pt 'PingFang SC', 'Noto Sans SC', 'Source Han Sans SC', 'Microsoft YaHei', 'WenQuanYi Micro Hei', sans-serif Regular，text-warm-yellow，text-align:center）
        │       └── 附加说明（text-34，33×28pt，20pt 'PingFang SC', 'Noto Sans SC', 'Source Han Sans SC', 'Microsoft YaHei', 'WenQuanYi Micro Hei', sans-serif Regular，text-warm-yellow，text-align:center）
        └── 右半—主操作（frame-64，flex-grow:1≈201×80pt，min-width:195pt）
            ├── border-radius: 0 40px 40px 0
            ├── background: gradient-yellow（linear-gradient(135deg, rgba(255,231,77,1) 0%, rgba(255,221,0,1) 100%)）
            ├── flex-direction: column，justify-content: center，align-items: center
            ├── >*:not(:first-child) { margin-top: -2px }
            ├── 主文字行（frame-65，120×44pt，column-gap:4px）
            │   ├── 主标签文字（text-35，120×44pt，30pt 'PingFang SC', 'Noto Sans SC', 'Source Han Sans SC', 'Microsoft YaHei', 'WenQuanYi Micro Hei', sans-serif Medium，text-primary `#111111`，text-align:center）
            │   └── [可选] 价格子区域（instance-24，78×44pt，visibility: hidden）
            │       ├── ¥符号（text--11，14×32pt，22pt MT New Digital Display，text-primary）
            │       └── 数字帧（frame-66，82×44pt）
            │           ├── 整数部分（text-83，35×44pt，32pt MT New Digital Display，text-primary）
            │           └── 小数部分（text-99，27×44pt，32pt MT New Digital Display，text-primary）
            └── [可选] 副文字行（frame-67，100×28pt，visibility: hidden，column-gap:4px）
                └── 说明文字（text-36，100×28pt，20pt 'PingFang SC', 'Noto Sans SC', 'Source Han Sans SC', 'Microsoft YaHei', 'WenQuanYi Micro Hei', sans-serif Regular，rgba(0,0,0,0.67)，text-align:center）
```

> **triple-icon-capsule-combo 说明**：该配置设计用于 @2x 设计稿（750×1624pt 手机页面）。左侧为 **3 个**可点击的增强型图标入口（各 100pt，总宽 300pt，`flex-shrink:0`），三入口横排排列（`flex-direction: row`，`gap: 0pt`）；每个入口图标 44×44pt，标签 20pt，`padding-top: 4px`（与 `icon-capsule-combo` 一致）。右侧胶囊组合区（`flex-grow:1`，约 402pt）内两半各 `flex-grow:1`（等宽约 201pt，`min-width: 195px`，接近最小允许值），无间隙拼合；左半深灰渐变+暖黄文字（次操作），右半黄色渐变+深黑文字（主操作）；两半均通过 `justify-content: center` + `margin-top: -2px` 实现内容居中和紧凑叠放。容器左 padding 12pt，三图标入口区与胶囊区 gap 12pt。适用于需要同时提供 **3 个功能快捷入口**（如"客服"+"收藏"+"分享"）并配合双强操作胶囊的场景。⚠️ 由于右侧胶囊已压缩至约 402pt（两半各 201pt），已接近 `min-width: 195px` 的最小约束，**不支持 `asymmetric` 非等分配置**。节点名称与 `.component-5` CSS 设计稿完全对应：`frame-52`（三图标入口区）→ `frame-53/55/57`（单个入口）→ `instance-22`（胶囊组合区）。

---

## 6. Props API

```typescript
export type BottomActionBarProps = {
  /**
   * 变体类型
   * - "single"：单按钮全宽（容器 48pt）
   * - "double"：左副右主，2等分（容器 48pt）
   * - "triple"：左1副+左2副+右主，3等分（容器 48pt）
   * - "stack"：上主下副，各全宽垂直堆叠（容器 96pt）
   * - "asymmetric"：左固定宽副+右弹性主（容器 48pt）
   * - "icon-action"：左图标入口1~4个+右主按钮（容器 48pt）
   * - "icon-double"：左图标入口1~4个+右副主按钮并排（容器 48pt）
   * - "icon-action-double"：左增强型图标入口2个+右主按钮2个（@2x 设计稿，容器 96pt）
   * - "icon-action-split"：左增强型图标入口1个+右副主按钮各1个（@2x 设计稿，容器 96pt）
   * - "icon-action-triple"：左增强型图标入口1个+右双副按钮+主按钮共三按钮并排（@2x 设计稿，容器 96pt）
   * - "price-split"：左侧价格/说明展示区（不可点击）+右副主按钮各1个（@2x 设计稿，容器 96pt，对称 padding 24pt）
   * - "capsule-combo"：左半（次操作，深灰渐变）+ 右半（主操作，黄色渐变）无间隙拼合成胶囊（@2x 设计稿，容器 96pt）
   * - "icon-capsule-combo"：左侧 1 个增强型图标入口（可点击，`flex-shrink:0`）+ 右侧胶囊组合（左深灰+右黄色）（@2x 设计稿，容器 96pt，左 padding 12pt）；可通过 `capsuleLayout` 配置等分或非等分
   * - "double-icon-capsule-combo"：左侧 2 个增强型图标入口（各 100pt，总 200pt，横排，`flex-shrink:0`）+ 右侧等分胶囊组合（左深灰+右黄色，各 `flex-grow:1`，约 251pt）（@2x 设计稿，容器 96pt，左 padding 12pt）
   * - "triple-icon-capsule-combo"：左侧 3 个增强型图标入口（各 100pt，总 300pt，横排，`flex-shrink:0`）+ 右侧等分胶囊组合（左深灰+右黄色，各 `flex-grow:1`，约 201pt，接近 min-width 极限）（@2x 设计稿，容器 96pt，左 padding 12pt）；不支持 `capsuleLayout="asymmetric"`
   * @default "single"
   */
  variant?: "single" | "double" | "triple" | "stack" | "asymmetric" | "icon-action" | "icon-double" | "icon-action-double" | "icon-action-split" | "icon-action-triple" | "price-split" | "capsule-combo" | "icon-capsule-combo" | "double-icon-capsule-combo" | "triple-icon-capsule-combo";

  /**
   * 胶囊组合布局配置（variant="capsule-combo" 或 variant="icon-capsule-combo" 时有效）
   * - "symmetric"：两半等宽（各 flex-grow:1）；capsule-combo 约 351pt，icon-capsule-combo 约 301pt；适用于两操作权重完全相等的场景
   * - "asymmetric"：左半固定宽 248pt（flex-shrink:0），右半弹性（flex-grow:1）；capsule-combo 约 454pt，icon-capsule-combo 约 354pt；适用于主操作需要更大点击面积的场景
   * @default "symmetric"
   *
   * ⚠️ variant="double-icon-capsule-combo" 时：
   * 仅支持 "symmetric"（两半各 flex-grow:1，约 251pt），不支持 "asymmetric"。
   * 右侧胶囊总宽仅 502pt，若强制使用 asymmetric 左半固定 248pt 将导致右半约 254pt 极度受限，
   * 请改用 variant="icon-capsule-combo" + capsuleLayout="asymmetric" 以获得更宽的右半空间（约 354pt）。
   *
   * ⚠️ variant="triple-icon-capsule-combo" 时：
   * 仅支持 "symmetric"（两半各 flex-grow:1，约 201pt），不支持 "asymmetric"。
   * 右侧胶囊总宽仅 402pt，两半已接近 min-width:195px 极限，不可缩减任一半的宽度。
   * 若需要非等分胶囊，请降级至 double-icon-capsule-combo（右侧 502pt）或 icon-capsule-combo asymmetric（右侧 354pt）。
   */
  capsuleLayout?: "symmetric" | "asymmetric";

  /**
   * 主操作按钮配置
   * - 大多数变体只需一个 primaryAction
   * - icon-action-double 变体可支持 primaryActions 数组（最多 2 个，分别对应右侧两个按钮）
   */
  primaryAction?: {
    /** 按钮文字 */
    label: string;
    /** 可选：左侧图标 */
    icon?: React.ReactNode;
    /** 可选：价格信息（主按钮专属） */
    price?: {
      /** 价格数值（如 "99"） */
      amount: string;
      /** 货币符号，默认 "¥" */
      currency?: string;
    };
    /** 点击回调 */
    onPress: () => void;
  };

  /**
   * 主操作按钮列表（仅 variant="icon-action-double" 时有效，最多 2 个）
   * 对应右侧并排的两个主按钮
   */
  primaryActions?: Array<{
    /** 按钮文字 */
    label: string;
    /** 可选：左侧图标 */
    icon?: React.ReactNode;
    /** 点击回调 */
    onPress: () => void;
  }>;

  /**
   * 副操作按钮1配置（variant="double" / "triple" / "stack" / "asymmetric" / "icon-double" / "icon-action-split" 时有效）
   */
  secondaryAction?: {
    label: string;
    icon?: React.ReactNode;
    onPress: () => void;
  };

  /**
   * 副操作按钮2配置（variant="triple" / "icon-action-triple" 时有效，位于左1副，最左侧位置）
   * - "triple"：三按钮中居左的副按钮（@1x 设计稿）
   * - "icon-action-triple"：右侧三按钮中最左侧的第一个副按钮（@2x 设计稿）
   */
  secondaryAction2?: {
    label: string;
    icon?: React.ReactNode;
    onPress: () => void;
  };

  /**
   * 图标入口列表（多变体支持，各变体说明如下）
   * - variant="icon-action" / "icon-double"：最多 4 项，每入口宽 50pt
   * - variant="icon-action-split" / "icon-action-triple" / "icon-capsule-combo"：固定 1 项，入口宽 100pt（增强型）
   * - variant="icon-action-double"：固定 2 项，各入口宽 100pt（增强型），两入口竖排
   * - variant="double-icon-capsule-combo"：固定 2 项，各入口宽 100pt（增强型），两入口**横排**，总宽 200pt
   * - variant="triple-icon-capsule-combo"：固定 3 项，各入口宽 100pt（增强型），三入口**横排**，总宽 300pt
   */
  iconEntries?: Array<{
    /** 图标组件 */
    icon: React.ReactNode;
    /** 图标下方标签文字 */
    label: string;
    /** 点击回调 */
    onPress: () => void;
  }>; // icon-action 类最多 4 项；icon-capsule-combo 类固定 1 项；double-icon-capsule-combo / icon-action-double 固定 2 项；triple-icon-capsule-combo 固定 3 项

  /**
   * 左侧价格/说明展示区配置（仅 variant="price-split" 时有效）
   * 该区域为纯展示区，不可点击，图标使用 36pt，文字使用 text-secondary 灰色
   */
  priceInfo?: {
    /** 展示区图标（36×36pt，flex-shrink:0） */
    icon?: React.ReactNode;
    /** 说明/价格文字（如"立减12元"、"免费配送"等，28pt 灰色） */
    label: string;
  };

  /**
   * 是否包含 Home Indicator（iPhoneX 及以上）
   * @default true
   */
  showHomeIndicator?: boolean;
};
```

---

## 7. data-attribute 规范

| 属性 | 值 | 说明 |
|------|----|------|
| `data-slot` | `"bottom-action-bar"` | 全局稳定标识 |
| `data-variant` | `"single"` / `"double"` / `"triple"` / `"stack"` / `"asymmetric"` / `"icon-action"` / `"icon-action-double"` / `"icon-action-split"` / `"icon-action-triple"` / `"price-split"` / `"capsule-combo"` / `"icon-capsule-combo"` / `"double-icon-capsule-combo"` / `"triple-icon-capsule-combo"` | 变体类型 |
| `data-icon-count` | `"1"` / `"2"` / `"3"` / `"4"` | 图标入口数量（`icon-action` 变体带此属性；`double-icon-capsule-combo` 固定值为 `"2"`，不可省略；`triple-icon-capsule-combo` 固定值为 `"3"`，不可省略） |
| `data-capsule-layout` | `"symmetric"` / `"asymmetric"` | 胶囊布局配置（`capsule-combo` 和 `icon-capsule-combo` 变体均带此属性；默认 `"symmetric"` 等分，`"asymmetric"` 为左半固定 248pt 右半弹性；`double-icon-capsule-combo` 和 `triple-icon-capsule-combo` 仅支持 `"symmetric"`，不带此属性或固定值 `"symmetric"`） |

---

## 8. Token 引用

### 8.1 颜色 Token

| 用途 | Token 名称 | 语义层来源 |
|------|-----------|-----------|
| 容器背景 | `white` | `color-semantic.md` §三 Background Color |
| 顶部描边颜色 | `divider-secondary` | `color-semantic.md` §五 Divider Color |
| 主按钮渐变背景 | `gradient-yellow` | `color-semantic.md` §八 Gradient Color |
| 主按钮/副按钮文字 | `text-primary` | `color-semantic.md` §二 Text Color，映射 `.Grey-1`（`#111111`） |
| 副按钮描边颜色 | `stroke-strong` | `color-semantic.md` §四 Stroke Color，映射 `.Grey-6`（`#CCCCCC`） |
| price-split 左侧文字颜色 | `text-tertiary` | `color-semantic.md` §二 Text Color，映射 `.Grey-3`（`#888888`）；仅 `price-split` 左侧展示区使用 |
| capsule-combo 左半背景 | `gradient-dark` | `color-semantic.md` §八 Gradient Color；深灰渐变 `linear-gradient(135deg, rgba(82,82,82,1) 0%, rgba(39,39,39,1) 100%)`；仅 `capsule-combo` 左半使用 |
| capsule-combo 左半文字颜色 | `text-warm-yellow` | `color-semantic.md` §二 Text Color；暖黄色 `#FFF6B8`；仅 `capsule-combo` 左半使用，与深灰背景搭配 |

### 8.2 描边宽度 Token

| 用途 | Token 名称 | 语义层来源 |
|------|-----------|-----------|
| 顶部分割线宽度 | `border-default` | `stroke-semantic.md` §一 Border，0.5pt，对应 `divider-secondary` 颜色 |
| 副按钮描边宽度 | `border-bold` | `stroke-semantic.md` §一 Border，1pt |

### 8.3 圆角 Token

| 用途 | Token 名称 | 语义层来源 |
|------|-----------|-----------|
| 主按钮圆角（胶囊形） | `radius-full` | `component-radius.md` |
| 副按钮圆角（胶囊形） | `radius-full` | `component-radius.md` |

### 8.4 间距 Token

| 用途 | Token 名称 | 值 | 语义层来源 |
|------|-----------|-----|----------|
| 容器顶部 padding | `spacing-s` | 8pt | `spacing-semantic.md` |
| 容器左右 padding | `cs-12` | 12pt | `component-spacing.md` |
| 双按钮列间距 | `spacing-s` | 8pt | `spacing-semantic.md` |
| 按钮上下内边距 | `cs-9.5` | 9.5pt | `component-spacing.md` |
| 按钮左右内边距 | `cs-20` | 20pt | `component-spacing.md` |
| 图标与文字 gap | `cs-2` | 2pt | `component-spacing.md` |
| icon-action 左 padding | `cs-6` | 6pt | `component-spacing.md`（替代标准 cs-12） |
| icon-action 图标区与主按钮 gap | `cs-6` | 6pt | `component-spacing.md` |
| icon-action 图标与标签 gap | `cs-2` | 2pt | `component-spacing.md` |
| icon-action-double 容器顶部 padding | — | 16pt | @2x 设计稿，不同于标准 8pt |
| icon-action-double 容器左 padding | `cs-12` | 12pt | 标准左 padding |
| icon-action-double 容器右 padding | — | 24pt | @2x 设计稿，不同于标准 12pt |
| icon-action-double 图标入口间距（垂直） | — | 8pt | 两个增强型图标入口之间的行间距 |
| icon-action-double 右侧按钮间距 | — | 16pt | `column-gap: 16px`，两按钮之间的列间距 |
| icon-action-double 增强型图标与标签 gap | — | 8pt | 增强型图标下方标签的间距 |
| icon-action-split 容器顶部 padding | — | 16pt | @2x 设计稿，不同于标准 8pt |
| icon-action-split 容器左 padding | `cs-12` | 12pt | 标准左 padding |
| icon-action-split 容器右 padding | — | 24pt | @2x 设计稿，不同于标准 12pt |
| icon-action-split 左侧图标与按钮区间距 | — | 12pt | `column-gap: 12px` |
| icon-action-split 右侧按钮间距 | — | 16pt | `column-gap: 16px`，副主按钮间距 |
| icon-action-triple 容器顶部 padding | — | 16pt | @2x 设计稿，不同于标准 8pt |
| icon-action-triple 容器左 padding | `cs-12` | 12pt | 标准左 padding |
| icon-action-triple 容器右 padding | — | 24pt | @2x 设计稿，不同于标准 12pt |
| icon-action-triple 左侧图标与按钮区间距 | — | 12pt | `column-gap: 12px` |
| icon-action-triple 右侧三按钮间距 | — | 16pt | `column-gap: 16px`，三按钮之间的列间距（两处） |
| price-split 容器顶部 padding | `spacing-xl` | 16pt | @2x 设计稿，不同于标准 8pt（`spacing-s`） |
| price-split 容器左 padding | `cs-24` | 24pt | 对称设计，不同于图标入口变体的 `cs-12`（12pt） |
| price-split 容器右 padding | `cs-24` | 24pt | 对称设计，`justify-content: space-between` 配合使用 |
| price-split 价格区图标与文字间距 | `spacing-s` | 8pt | `column-gap: 8px`，左侧展示区内部间距 |
| price-split 右侧按钮间距 | `spacing-xl` | 16pt | `column-gap: 16px`，副主按钮间距 |
| capsule-combo 容器顶部 padding | — | 16pt | @2x 设计稿，不同于标准 8pt |
| capsule-combo 容器左 padding | `cs-24` | 24pt | 对称设计，与 price-split 相同 |
| capsule-combo 容器右 padding | `cs-24` | 24pt | 对称设计 |
| capsule-combo 两半间隙 | — | 0pt | 无间隙拼合，不使用 column-gap |
| capsule-combo 主/副文字行间距 | — | -2px | `margin-top: -2px`（`>*:not(:first-child)`），紧凑叠放 |
| icon-capsule-combo 容器顶部 padding | — | 16pt | @2x 设计稿，不同于标准 8pt |
| icon-capsule-combo 容器左 padding | `cs-12` | 12pt | 非对称，区别于 `capsule-combo` 的 24pt |
| icon-capsule-combo 容器右 padding | — | 24pt | @2x 设计稿 |
| icon-capsule-combo 图标区与胶囊区 gap | — | 12pt | `column-gap: 12px` |
| icon-capsule-combo 胶囊两半间隙 | — | 0pt | 无间隙拼合，不使用 column-gap |
| icon-capsule-combo 主/副文字行间距 | — | -2px | `margin-top: -2px`（`>*:not(:first-child)`），紧凑叠放 |
| icon-capsule-combo asymmetric 左半固定宽 | — | 248pt | `flex-shrink:0`，`min-width:248px`；与 `capsule-combo asymmetric` 左半相同 |
| icon-capsule-combo asymmetric 右半弹性宽 | — | 约 354pt | `flex-grow:1`（右侧胶囊 602pt − 左半 248pt = 354pt） |
| icon-capsule-combo asymmetric 右半内边距 | — | 19px 0px | `padding: 19px 0px`，替代 `justify-content: center` 实现垂直居中 |
| double-icon-capsule-combo 容器顶部 padding | `spacing-xl` | 16pt | @2x 设计稿，与 `icon-capsule-combo` 一致（同 `price-split` 顶部 padding）|
| double-icon-capsule-combo 容器左 padding | `cs-12` | 12pt | 非对称，与 `icon-capsule-combo` 一致，区别于 `capsule-combo` 的 24pt |
| double-icon-capsule-combo 容器右 padding | — | 24pt | @2x 设计稿 |
| double-icon-capsule-combo 图标入口区与胶囊区 gap | — | 12pt | `column-gap: 12px`，与 `icon-capsule-combo` 一致 |
| double-icon-capsule-combo 两图标入口间距 | — | 0pt | 两入口横排，`gap: 0pt`，紧密排列，总宽 200pt |
| double-icon-capsule-combo 胶囊两半间隙 | — | 0pt | 无间隙拼合，不使用 column-gap |
| double-icon-capsule-combo 主/副文字行间距 | — | -2px | `margin-top: -2px`（`>*:not(:first-child)`），紧凑叠放 |
| double-icon-capsule-combo 两半初始宽度 | — | 约 251pt | 各 `flex-grow:1`，初始 `width: 251px`，`min-width: 195px`（右侧胶囊 502pt ÷ 2） |
| triple-icon-capsule-combo 容器顶部 padding | `spacing-xl` | 16pt | @2x 设计稿，与 `icon-capsule-combo` 及 `double-icon-capsule-combo` 一致 |
| triple-icon-capsule-combo 容器左 padding | `cs-12` | 12pt | 非对称，与 `icon-capsule-combo` 系列一致，区别于 `capsule-combo` 的 24pt |
| triple-icon-capsule-combo 容器右 padding | — | 24pt | @2x 设计稿 |
| triple-icon-capsule-combo 图标入口区与胶囊区 gap | — | 12pt | `column-gap: 12px`，与 `icon-capsule-combo` 系列一致 |
| triple-icon-capsule-combo 三图标入口间距 | — | 0pt | 三入口横排，`gap: 0pt`，紧密排列，总宽 300pt |
| triple-icon-capsule-combo 胶囊两半间隙 | — | 0pt | 无间隙拼合，不使用 column-gap |
| triple-icon-capsule-combo 主/副文字行间距 | — | -2px | `margin-top: -2px`（`>*:not(:first-child)`），紧凑叠放 |
| triple-icon-capsule-combo 两半初始宽度 | — | 约 201pt | 各 `flex-grow:1`，初始 `width: 201px`，`min-width: 195px`（右侧胶囊 402pt ÷ 2；接近最小约束，不可进一步缩减） |

### 8.5 字体 Token

> **@2x 说明**：`icon-action-double`、`icon-action-split`、`icon-action-triple`、`price-split` 均为 @2x 设计稿规格（750pt 宽），其字体尺寸在设计稿中为 @1x 值的 2 倍。Token 名称统一引用 `font-semantic.md` 中对应的 @1x 语义 Token，渲染时由系统自动按设备像素比缩放。

| 用途 | Token 名称 | 语义层来源 |
|------|-----------|-----------|
| 按钮主文字 | `subtitle-s-15-medium` | `font-semantic.md` §一 Subtitle，@1x 15pt 'PingFang SC', 'Noto Sans SC', 'Source Han Sans SC', 'Microsoft YaHei', 'WenQuanYi Micro Hei', sans-serif Medium |
| 图标入口标签 | `caption-s-10-regular` | `font-semantic.md` §一 Caption，@1x 10pt 'PingFang SC', 'Noto Sans SC', 'Source Han Sans SC', 'Microsoft YaHei', 'WenQuanYi Micro Hei', sans-serif Regular |
| 价格数字/单位 | `price-16-medium` / `price-11-medium` | `font-semantic.md` §三 Price Font；数字 16pt、单位（¥）符 11pt，均使用 MT New Digital Display |
| icon-action-double 增强型标签 | `caption-s-10-regular` | `font-semantic.md` §一 Caption；@2x 设计稿实测 20pt，对应 @1x 10pt 'PingFang SC', 'Noto Sans SC', 'Source Han Sans SC', 'Microsoft YaHei', 'WenQuanYi Micro Hei', sans-serif Regular |
| icon-action-double 主按钮文字 | `subtitle-s-15-medium` | `font-semantic.md` §一 Subtitle；@2x 设计稿实测 30pt，对应 @1x 15pt 'PingFang SC', 'Noto Sans SC', 'Source Han Sans SC', 'Microsoft YaHei', 'WenQuanYi Micro Hei', sans-serif Medium |
| icon-action-split 增强型标签 | `caption-s-10-regular` | `font-semantic.md` §一 Caption；@2x 设计稿实测 20pt，对应 @1x 10pt 'PingFang SC', 'Noto Sans SC', 'Source Han Sans SC', 'Microsoft YaHei', 'WenQuanYi Micro Hei', sans-serif Regular |
| icon-action-split 副+主按钮文字 | `subtitle-s-15-medium` | `font-semantic.md` §一 Subtitle；@2x 设计稿实测 30pt，对应 @1x 15pt 'PingFang SC', 'Noto Sans SC', 'Source Han Sans SC', 'Microsoft YaHei', 'WenQuanYi Micro Hei', sans-serif Medium |
| icon-action-triple 增强型标签 | `caption-s-10-regular` | `font-semantic.md` §一 Caption；@2x 设计稿实测 20pt，对应 @1x 10pt 'PingFang SC', 'Noto Sans SC', 'Source Han Sans SC', 'Microsoft YaHei', 'WenQuanYi Micro Hei', sans-serif Regular |
| icon-action-triple 三按钮文字 | `subtitle-s-15-medium` | `font-semantic.md` §一 Subtitle；@2x 设计稿实测 30pt，对应 @1x 15pt 'PingFang SC', 'Noto Sans SC', 'Source Han Sans SC', 'Microsoft YaHei', 'WenQuanYi Micro Hei', sans-serif Medium；副按钮与主按钮规格相同 |
| price-split 价格/说明文字 | `body-l-14-regular` | `font-semantic.md` §一 Body；@2x 设计稿实测 28pt，对应 @1x 14pt 'PingFang SC', 'Noto Sans SC', 'Source Han Sans SC', 'Microsoft YaHei', 'WenQuanYi Micro Hei', sans-serif Regular；颜色 `text-tertiary`（`#888888`），区别于其他变体的 `text-primary` |
| price-split 副+主按钮文字 | `subtitle-s-15-medium` | `font-semantic.md` §一 Subtitle；@2x 设计稿实测 30pt，对应 @1x 15pt 'PingFang SC', 'Noto Sans SC', 'Source Han Sans SC', 'Microsoft YaHei', 'WenQuanYi Micro Hei', sans-serif Medium |
| capsule-combo 两半主按钮文字 | `subtitle-s-15-medium` | `font-semantic.md` §一 Subtitle；@2x 设计稿实测 30pt，对应 @1x 15pt 'PingFang SC', 'Noto Sans SC', 'Source Han Sans SC', 'Microsoft YaHei', 'WenQuanYi Micro Hei', sans-serif Medium；左半颜色 `text-warm-yellow`，右半颜色 `text-primary` |
| capsule-combo 副文字行（可选） | — | @2x 设计稿 20pt 'PingFang SC', 'Noto Sans SC', 'Source Han Sans SC', 'Microsoft YaHei', 'WenQuanYi Micro Hei', sans-serif Regular，对应 @1x 10pt；默认 `visibility: hidden`，需手动开启 |
| capsule-combo 价格数字（可选） | `price-16-medium` / `price-11-medium` | `font-semantic.md` §三 Price Font；@2x 设计稿 ¥符号 22pt + 数字 32pt，MT New Digital Display Medium；默认 `visibility: hidden` |

---

## 9. 屏幕适配规范

```
纵向高度适配：
  ├── iPhoneX 及以上（刘海屏）：操作栏直接与 Home Indicator 组件相连，间距 0
  └── iPhoneSE 及其他非刘海屏 / Android：底部增加 8pt 间距

横向宽度适配：
  └── 按钮宽度随屏宽等比适配（flex: 1 均分，左右 padding 固定 12pt）
```

---

## 10. 无障碍（Accessibility）

- 操作栏容器使用 `role="toolbar"`，`aria-label="页面操作"`
- 主操作按钮：`role="button"`，`aria-label` 描述完整操作含义（如"立即购买，¥99"）
- 副操作按钮：`role="button"`，`aria-label` 描述操作含义
- 按钮禁用时添加 `aria-disabled="true"` 并变更视觉样式

---

## 11. 使用约束（AI 生成时的硬性规则）

1. **禁止直接写 hex 颜色**：颜色必须使用 §8.1 中的 Token 名称
2. **容器高度固定**：不可自定义容器高度；@1x 变体（`single`/`double`/`triple`/`asymmetric`/`icon-action`/`icon-double`）始终为 **48pt**，@2x 变体（`stack`/`icon-action-double`/`icon-action-split`/`icon-action-triple`/`price-split`）始终为 **96pt**，均不含 Home Indicator
3. **按钮高度固定**：@1x 变体按钮高度始终为 40pt，@2x 变体按钮高度始终为 80pt，不可自定义
4. **圆角固定**：按钮统一使用 `radius-full` 胶囊形，不可自定义圆角数值
5. **双按钮权重**：左侧必须为副操作（描边型），右侧必须为主操作（渐变型），不可互换
6. **价格字体**：价格数字使用 `MT New Digital Display`，不可用 `'PingFang SC', 'Noto Sans SC', 'Source Han Sans SC', 'Microsoft YaHei', 'WenQuanYi Micro Hei', sans-serif` 或系统字体替代
7. **此组件禁止用于导航**：本组件仅用于页面级 CTA，不承载信息架构导航功能
8. **icon-action / icon-double 图标入口数量上限**：`iconEntries` 最多 4 项（4个图标区占用 200pt），超出 4 项将导致按钮区过窄
9. **icon-action / icon-double 容器 padding 不对称**：左 padding 为 6pt（`cs-6`），右 padding 为 12pt（`cs-12`），不可使用统一的 padding 简写
10. **asymmetric 副按钮宽度固定**：副按钮宽度始终为 112pt，不可根据文字长度自动伸缩
11. **icon-double 双按钮权重**：右侧按钮并排区内左副右主，不可交换顺序
12. **icon-action-double 容器尺寸固定**：容器宽 750pt 高 96pt（@2x 设计稿），不可修改
13. **icon-action-double 图标入口固定为 2 个**：`iconEntries` 长度必须为 2，不支持 1 个或 3~4 个
14. **icon-action-double 主按钮固定为 2 个**：`primaryActions` 长度必须为 2，不支持 1 个或 3 个以上
15. **icon-action-double 图标尺寸固定**：左侧图标 44×44pt，右侧按钮内图标 34×34pt，不可自定义
16. **icon-action-double 字体规格固定**：左侧标签 20pt，右侧按钮文字 30pt，不可自定义
17. **icon-action-split 容器尺寸固定**：容器宽 750pt 高 96pt（@2x 设计稿），不可修改
18. **icon-action-split 左侧图标入口固定为 1 个**：`iconEntries` 长度必须为 1，不支持 2 个或以上
19. **icon-action-split 副+主按钮权重固定**：左侧为副按钮（描边），右侧为主按钮（渐变），不可互换
20. **icon-action-split 按钮尺寸固定**：各按钮宽度 293pt，高度 80pt，内边距 `19px 40px`，不可自定义
21. **icon-action-split 字体规格固定**：左侧标签 20pt，右侧按钮文字 30pt，不可自定义
22. **icon-action-triple 容器尺寸固定**：容器宽 750pt 高 96pt（@2x 设计稿），不可修改
23. **icon-action-triple 左侧图标入口固定为 1 个**：`iconEntries` 长度必须为 1，不支持 0 个或 2 个以上
24. **icon-action-triple 右侧按钮固定为三个（2副1主）**：`secondaryAction2` + `secondaryAction` + `primaryAction` 均必须提供，不可减少为两个
25. **icon-action-triple 三按钮权重顺序固定**：从左至右依次为副1（描边）→ 副2（描边）→ 主（渐变），不可调换顺序
26. **icon-action-triple 字体规格固定**：左侧标签 20pt，右侧三按钮文字均为 30pt，不可自定义
27. **price-split 容器尺寸固定**：容器宽 750pt 高 96pt（@2x 设计稿），padding 对称 24pt，不可修改
28. **price-split 左侧展示区不可点击**：`priceInfo` 区域为纯展示，不支持 `onPress`/`onClick` 等交互事件，不可将其用作功能入口
29. **price-split 左侧展示区文字颜色固定**：必须使用 `text-tertiary`（`#888888`，`.Grey-3`），不可改为 `text-primary` 或 `text-secondary` 或其他颜色，以区分展示信息与操作按钮
30. **price-split 左侧图标尺寸固定**：图标必须为 36×36pt，不可使用增强型图标的 44pt 规格
31. **price-split 右侧按钮配置固定**：必须同时提供 `secondaryAction` + `primaryAction`（副+主各一），不可省略任一按钮
32. **price-split 与 icon-action-split 禁止混用**：两者均为"左侧区域+右侧双按钮"布局，但前者左侧为展示区（灰色文字），后者为可点击的图标入口（黑色文字），语义不同，不可互换
33. **capsule-combo 容器尺寸固定**：容器宽 750pt 高 96pt（@2x 设计稿），padding 对称 24pt，不可修改
34. **capsule-combo 两半不可拆分使用**：左半（`capsule-left`）与右半（`capsule-right`）必须成对出现，不可单独使用任一半
35. **capsule-combo 两半之间严格无间隙**：两半 `column-gap` 为 0，不可添加任何间距；若需间隙请改用 `double` 变体
36. **capsule-combo 圆角分配固定**：左半只设 `border-radius: 40px 0 0 40px`，右半只设 `border-radius: 0 40px 40px 0`；不可在外层包裹元素上设置 `border-radius`，不可将整体圆角分配方式改为其他值
37. **capsule-combo 左半文字颜色固定**：左半必须使用 `text-warm-yellow`（`#FFF6B8`），不可改为 `text-primary`（`#111111`）或其他颜色
38. **capsule-combo 左半背景固定**：左半必须使用 `gradient-dark`（深灰渐变），不可改为 `gradient-yellow` 或纯色
39. **capsule-combo 右半背景固定**：右半必须使用 `gradient-yellow`，与左半形成深浅对比，不可与左半互换背景
40. **capsule-combo 不支持描边**：两半均无描边，不可为任一半添加 border，视觉区分完全通过背景颜色对比实现
41. **capsule-combo 两半权重不可互换**：左侧为次操作（深灰），右侧为主操作（黄色），不可调换顺序
42. **capsule-combo 与 double 禁止混淆**：`capsule-combo` 两操作在视觉上权重相近（均为强引导），不含描边副按钮；`double` 主次权重差异明显（左副按钮描边，右主按钮渐变），不可互换
43. **capsule-combo 默认为等分配置**：未指定 `capsuleLayout` 时默认使用 `symmetric`（等分，两半各 `flex-grow:1`），不可省略逻辑但应知道默认行为
44. **capsule-combo asymmetric 左半宽度固定不可修改**：`asymmetric` 配置下左半宽度固定为 248pt（`flex-shrink: 0`），不可改为其他固定值或改为 `flex-grow` 弹性布局
45. **capsule-combo 不同配置下右半副文字颜色不同**：`symmetric` 配置右半副文字颜色与等分配置一致（`text-warm-yellow` 的深色对应版本），`asymmetric` 配置右半副文字必须使用 `rgba(0,0,0,0.67)`（深色半透明），不可与左半混用暖黄色
46. **icon-capsule-combo 容器尺寸固定**：容器宽 750pt 高 96pt（@2x 设计稿），左 padding 12pt，右 padding 24pt，不可修改；与 `capsule-combo`（左右各 24pt）的 padding 不同，不可互用
47. **icon-capsule-combo 左侧图标入口固定为 1 个**：`iconEntries` 长度必须为 1，不支持 0 个或 2 个以上；图标入口**可点击**（区别于 `price-split` 的纯展示区），必须提供 `onPress` 回调
48. **icon-capsule-combo 图标入口标签 padding-top 固定为 4px**：不可改为 8px（`icon-action-split` 规格），不可省略 padding-top，否则标签行会紧贴图标
49. **icon-capsule-combo 默认右侧胶囊两半等分**：默认（`capsuleLayout="symmetric"`）两半均为 `flex-grow:1`，初始 `width: 301px`，`min-width: 195px`；如需非等分请显式设置 `capsuleLayout="asymmetric"`
50. **icon-capsule-combo symmetric 两半内容居中方式**：等分配置下两半均通过 `justify-content: center` 实现内容居中；asymmetric 配置下右半通过 `padding: 19px 0px` 实现居中（与 `capsule-combo asymmetric` 右半相同）；不可在 symmetric 配置中使用 padding 居中方式
51. **icon-capsule-combo 与 icon-action-split 禁止混淆**：两者均为"1个图标入口+右侧双操作"布局，但 `icon-action-split` 右侧为独立副按钮（描边）+主按钮（渐变），`icon-capsule-combo` 右侧为胶囊组合（无间隙拼合），不可互换
52. **icon-capsule-combo 支持 capsuleLayout 属性**：右侧胶囊可通过 `capsuleLayout="symmetric"`（默认，各 `flex-grow:1`，约 301pt）或 `capsuleLayout="asymmetric"`（左半固定 248pt，右半弹性约 354pt）配置；与 `capsule-combo` 的区别仅在于右半弹性宽度不同（354pt vs 454pt）
53. **icon-capsule-combo asymmetric 左半宽度固定不可修改**：`asymmetric` 配置下左半宽度固定为 248pt（`flex-shrink: 0`，`min-width: 248px`），不可改为其他固定值或改为 `flex-grow` 弹性布局
54. **icon-capsule-combo asymmetric 右半副文字颜色必须为深色半透明**：`asymmetric` 配置下右半副文字颜色必须使用 `rgba(0,0,0,0.67)`，不可使用 `text-warm-yellow`（`#FFF6B8`）；left半副文字颜色仍为 `text-warm-yellow`，不可与右半混用
55. **icon-capsule-combo asymmetric 右半居中方式与 symmetric 不同**：`asymmetric` 配置下右半通过 `padding: 19px 0px` 实现内容垂直居中，不可改为 `justify-content: center`（两者渲染结果在该宽度下有视觉差异）
56. **icon-capsule-combo 与 capsule-combo asymmetric 的右半宽度不同**：`icon-capsule-combo asymmetric` 右半弹性宽约 354pt（右侧胶囊总宽 602pt − 左半 248pt），`capsule-combo asymmetric` 右半弹性宽约 454pt（总胶囊宽 702pt − 左半 248pt）；不可互换使用
57. **double-icon-capsule-combo 容器尺寸固定**：容器宽 750pt 高 96pt（@2x 设计稿），左 padding 12pt，右 padding 24pt，不可修改；与 `icon-capsule-combo`（相同 padding）一致，与 `capsule-combo`（左右各 24pt）不同
58. **double-icon-capsule-combo 左侧图标入口固定为 2 个横排**：`iconEntries` 长度必须为 2，不支持 1 个或 3 个以上；2 个入口**横排**排列（`flex-direction: row`，`gap: 0pt`），与 `icon-action-double` 的**竖排**（2 入口上下排列）严格不同，不可混淆
59. **double-icon-capsule-combo 图标入口标签 padding-top 固定为 4px**：与 `icon-capsule-combo` 相同，不可改为 8px（`icon-action-split` 规格），不可改为 0px
60. **double-icon-capsule-combo 右侧胶囊两半严格等分**：两半均为 `flex-grow:1`，初始 `width: 251px`，`min-width: 195px`；不支持 `capsuleLayout="asymmetric"` 非等分配置（非等分需使用 `icon-capsule-combo` 变体加 `capsuleLayout="asymmetric"`）
61. **double-icon-capsule-combo 两半内容居中方式固定**：两半均通过 `justify-content: center` 实现内容居中，不可使用 `padding` 替代；与 `capsule-combo asymmetric` 的右半居中方式不同
62. **double-icon-capsule-combo 与 icon-capsule-combo 胶囊宽度不同**：`double-icon-capsule-combo` 右侧胶囊总宽约 502pt（两图标入口 200pt 后剩余），`icon-capsule-combo` 右侧胶囊总宽约 602pt（单图标入口 100pt 后剩余）；两半宽度因此不同（约 251pt vs 301pt），不可互换
63. **double-icon-capsule-combo 与 icon-action-double 禁止混淆**：两者均为"2个增强型图标入口+右侧操作区"布局，但 `icon-action-double` 图标入口**竖排**+右侧为 2 个独立主按钮（渐变），`double-icon-capsule-combo` 图标入口**横排**+右侧为等分胶囊组合（左深灰次操作+右黄色主操作），不可互换
64. **triple-icon-capsule-combo 容器尺寸固定**：容器宽 750pt 高 96pt（@2x 设计稿），左 padding 12pt，右 padding 24pt，不可修改；与 `icon-capsule-combo`、`double-icon-capsule-combo` 的 padding 相同
65. **triple-icon-capsule-combo 左侧图标入口固定为 3 个横排**：`iconEntries` 长度必须为 3，不支持 2 个或 4 个以上；3 个入口**横排**排列（`flex-direction: row`，`gap: 0pt`），与 `icon-action-double` 的**竖排**严格不同，不可混淆
66. **triple-icon-capsule-combo 图标入口标签 padding-top 固定为 4px**：与 `icon-capsule-combo` 和 `double-icon-capsule-combo` 相同，不可改为 8px（`icon-action-split` 规格），不可改为 0px
67. **triple-icon-capsule-combo 右侧胶囊两半严格等分**：两半均为 `flex-grow:1`，初始 `width: 201px`，`min-width: 195px`；不支持 `capsuleLayout="asymmetric"` 非等分配置（右侧胶囊仅 402pt，两半已接近最小约束，任何固定宽配置都会使另一半过窄）
68. **triple-icon-capsule-combo 两半内容居中方式固定**：两半均通过 `justify-content: center` 实现内容居中，不可使用 `padding` 替代
69. **triple-icon-capsule-combo 与 double-icon-capsule-combo 胶囊宽度不同**：`triple-icon-capsule-combo` 右侧胶囊总宽约 402pt（三图标入口 300pt 后剩余），`double-icon-capsule-combo` 右侧胶囊总宽约 502pt（两图标入口 200pt 后剩余）；两半宽度因此不同（约 201pt vs 251pt），不可互换
70. **triple-icon-capsule-combo 是图标入口+胶囊组合系列的上限**：3 个横排入口（300pt）已占据容器 40% 宽度，右侧胶囊两半已趋近最小可用宽度（201pt ≈ min-width 195pt）。若业务需要 4 个图标入口，建议拆分页面信息架构（将部分功能提升至 NavBar 或其他区域），而非继续扩展图标入口数量
71. **triple-icon-capsule-combo 胶囊文案长度约束**：右侧胶囊两半各约 201pt，接近最小可用宽度。文案长度应控制在 **4字以内**（`subtitle-s-15-medium` 字号下约 60pt @1x，@2x 对应 120pt），超出 5字将导致文字溢出或截断；典型文案组合：次操作"查看详情"（4字）+ 主操作"去结算"（3字），或"加购"（2字）+ "立即付款"（4字）
72. **triple-icon-capsule-combo 的首选使用场景为结算类页面**：该变体是购物车结算页和通用结算页的标准底部工具栏布局。结算场景的典型图标入口配置为「客服」+「优惠券」+「购物车」（可按业务调整）；次操作胶囊通常为"查看详情"/"编辑购物车"，主操作胶囊通常为"去结算"/"立即付款"。非结算场景（如商品详情页）若确需 3 个图标入口，亦可使用，但需注意右侧胶囊文案长度约束（第 71 条）
73. **triple-icon-capsule-combo 图标入口内容不可超出结算流程语义**：结算场景中，第三个图标入口（"购物车"）应提供跳回购物车列表的导航功能，不可将三个入口全部配置为非关键功能（如三个均为"分享"/"礼物"/"特效"），以避免结算流程关键入口缺失；非结算场景不受此约束

---

## 12. AI 决策树

```
用户说"底部操作栏" / "底部按钮" / "加入购物车按钮" / "去结算" / "立即购买" / "购物车页结算栏" / "结算工具栏" / "checkout bar" / "购物车底部"
  │
  ├── 只有一个主操作？
  │   └── → variant="single"（单个 gradient-yellow 全宽胶囊按钮）
  │
  ├── 一个主操作 + 一个副操作？
  │   ├── 两按钮等分、文字均较短？ → variant="double"（左副右主，2等分）
  │   ├── 主操作需明显大于副操作？ → variant="asymmetric"（左固定宽副+右弹性主）
  │   └── 文字较长或需要大点击区域？ → variant="stack"（上主下副，各全宽堆叠，容器 96pt）
  │
  ├── 一个主操作 + 两个副操作？
  │   └── → variant="triple"（左1副+左2副+右主，3等分）
  │
  ├── 主操作 + 左侧图标功能入口（仅一个主按钮）？
  │   ├── @1x 设计稿（375pt 宽）？ → variant="icon-action"，iconEntries 长度 1~4
  │   ├── @2x 设计稿（750pt 宽）且需 2 个大图标入口 + 2 个主按钮？ → variant="icon-action-double"，iconEntries 长度 2，primaryActions 长度 2
  │   ├── @2x 设计稿（750pt 宽）且需 1 个大图标入口 + 1 副 1 主按钮？ → variant="icon-action-split"，iconEntries 长度 1，secondaryAction + primaryAction
  │   └── @2x 设计稿（750pt 宽）且需 1 个大图标入口 + 2 副 1 主（共三按钮）？ → variant="icon-action-triple"，iconEntries 长度 1，secondaryAction2 + secondaryAction + primaryAction
  │
  ├── 主+副两个按钮 + 左侧图标功能入口？
  │   └── → variant="icon-double"，iconEntries 长度 1~4，右侧副+主按钮并排等分剩余宽度
  │
  ├── 左侧需要展示价格/优惠/说明（纯展示，不可点击，灰色文字）+ 右侧副+主按钮？
  │   └── → variant="price-split"，priceInfo={icon, label}，secondaryAction + primaryAction
  │
  ├── 两个操作视觉权重相近（均需强引导，如"加购"与"立购"在业务上同等重要），且不需要图标入口（@2x 设计稿）？
  │   └── → variant="capsule-combo"，secondaryAction（左半深灰） + primaryAction（右半黄色），两半无间隙拼合
  │       ├── 两操作权重完全相等，需等分空间？→ capsuleLayout="symmetric"（默认，各 flex-grow:1，约 351pt）
  │       └── 主操作优先级略高，需要更大点击面积，或左侧次操作文字较短？→ capsuleLayout="asymmetric"（左半固定 248pt，右半 flex-grow:1 约 454pt）
  │
  ├── 两个操作视觉权重相近（均需强引导），且需要左侧额外提供 1 个可点击的功能快捷入口（@2x 设计稿）？
  │   └── → variant="icon-capsule-combo"，iconEntries 长度 1（可点击，如"客服"）+ secondaryAction（左半深灰）+ primaryAction（右半黄色）
  │       → 容器左 padding 12pt，图标区与胶囊区 gap 12pt
  │       ├── 两操作权重完全相等，需等分空间？→ capsuleLayout="symmetric"（默认，各 flex-grow:1，约 301pt，justify-content:center 居中）
  │       └── 主操作优先级略高，需要更大点击面积，或左侧次操作文字较短？→ capsuleLayout="asymmetric"（左半固定 248pt，右半 flex-grow:1 约 354pt，padding:19px 0px 居中）
  │
  ├── 两个操作视觉权重相近（均需强引导），且需要左侧同时提供 2 个可点击的功能快捷入口（@2x 设计稿）？
  │   └── → variant="double-icon-capsule-combo"，iconEntries 长度 2（横排，如"客服"+"收藏"）+ secondaryAction（左半深灰）+ primaryAction（右半黄色）
  │       → 容器左 padding 12pt，2 个图标入口横排各 100pt（总 200pt，flex-shrink:0），图标区与胶囊区 gap 12pt
  │       → 与 icon-capsule-combo 的核心区别：图标区由 1 个（100pt）扩展为 2 个横排（200pt），右侧胶囊总宽从约 602pt 压缩为约 502pt
  │       ├── 两操作权重完全相等，需等分空间？→ capsuleLayout="symmetric"（默认，各 flex-grow:1，约 251pt，justify-content:center 居中）
  │       └── ⚠️ 不支持 asymmetric 布局（右侧胶囊 502pt 空间有限，固定 248pt 左半将导致右半过窄，不建议使用）
  │
  └── 两个操作视觉权重相近（均需强引导），且需要左侧同时提供 3 个可点击的功能快捷入口（@2x 设计稿）？
      │   **（这是"结算底部工具栏"的标准变体，适用于购物车结算页或通用结算页）**
      └── → variant="triple-icon-capsule-combo"，iconEntries 长度 3（横排）+ secondaryAction（左半深灰）+ primaryAction（右半黄色）
          → 结算场景典型配置：iconEntries 为客服/优惠券/购物车；secondaryAction 为"查看详情"/"编辑购物车"；primaryAction 为"去结算"/"立即付款"
          → 非结算场景亦可用：iconEntries 为客服/收藏/分享；secondaryAction 为次操作；primaryAction 为主操作
          → 容器左 padding 12pt，3 个图标入口横排各 100pt（总 300pt，flex-shrink:0），图标区与胶囊区 gap 12pt
          → 与 double-icon-capsule-combo 的核心区别：图标区由 2 个（200pt）扩展为 3 个横排（300pt），右侧胶囊总宽从约 502pt 进一步压缩为约 402pt
          ├── 两操作权重完全相等？→ capsuleLayout="symmetric"（唯一支持，各 flex-grow:1，约 201pt，接近 min-width 极限）
          └── ⚠️ 严禁 asymmetric 布局（右侧胶囊仅 402pt，两半已接近 min-width:195px，任何固定宽分配都会使另一半过窄）
              → 若需要非等分胶囊，改用 double-icon-capsule-combo（右侧 502pt）或 icon-capsule-combo asymmetric（右侧 354pt）
          ⚠️ triple-icon-capsule-combo 是图标入口+胶囊系列的上限，4 个及以上入口需重新评估信息架构

含价格？
  └── 在主按钮内追加价格区域（MT New Digital Display 数字字体）
      （single / double / stack / asymmetric / icon-action 的主按钮均支持）
      （icon-action-double 的多按钮场景需在 primaryActions 中分别处理）

⚠️ 用户说"底部导航" / "tabbar" → 请使用 bottom-navigation.md，不是本组件
```

---

## 13. 常见组合示例

### 13.1 商品详情页 — 双按钮（加入购物车 + 立即购买）

```
BottomActionBar
  variant: double
  secondaryAction: { label: "加入购物车", icon: <CartIcon /> }
  primaryAction: { label: "立即购买" }
```

### 13.2 订单确认页 — 单按钮（去结算）

```
BottomActionBar
  variant: single
  primaryAction:
    label: "去结算"
    price: { amount: "99", currency: "¥" }
```

### 13.3 活动页 — 单按钮（立即抢购）

```
BottomActionBar
  variant: single
  primaryAction: { label: "立即抢购", icon: <FlashIcon /> }
```

### 13.4 商品详情页 — 三按钮（收藏 + 加购 + 立即购买）

```
BottomActionBar
  variant: triple
  secondaryAction2: { label: "收藏", icon: <HeartIcon /> }
  secondaryAction:  { label: "加入购物车", icon: <CartIcon /> }
  primaryAction:    { label: "立即购买" }
```

### 13.5 预约/报名页 — 双排堆叠（立即报名 + 咨询客服）

```
BottomActionBar
  variant: stack
  primaryAction:   { label: "立即报名", icon: <CalendarIcon /> }
  secondaryAction: { label: "咨询客服", icon: <ServiceIcon /> }
```

### 13.6 商品详情页 — 非等分双按钮（小购物车 + 立即购买大）

```
BottomActionBar
  variant: asymmetric
  secondaryAction: { label: "购物车", icon: <CartIcon /> }
  primaryAction:   { label: "立即购买", price: { amount: "168" } }
```

### 13.7 商品详情页 — 图标入口+主按钮（1图标）

```
BottomActionBar
  variant: icon-action
  iconEntries: [{ icon: <ServiceIcon />, label: "客服" }]
  primaryAction: { label: "立即购买" }
```

### 13.8 商品详情页 — 图标入口+主按钮（2图标）

```
BottomActionBar
  variant: icon-action
  iconEntries: [
    { icon: <ServiceIcon />, label: "客服" },
    { icon: <HeartIcon />,   label: "收藏" }
  ]
  primaryAction: { label: "立即购买" }
```

### 13.9 商品详情页 — 图标入口+主按钮（3图标）

```
BottomActionBar
  variant: icon-action
  iconEntries: [
    { icon: <ServiceIcon />, label: "客服" },
    { icon: <HeartIcon />,   label: "收藏" },
    { icon: <ShareIcon />,   label: "分享" }
  ]
  primaryAction: { label: "立即购买" }
```

### 13.10 商品详情页 — 图标入口+主按钮（4图标）

```
BottomActionBar
  variant: icon-action
  iconEntries: [
    { icon: <ServiceIcon />, label: "客服" },
    { icon: <HeartIcon />,   label: "收藏" },
    { icon: <ShareIcon />,   label: "分享" },
    { icon: <CartIcon />,    label: "购物车" }
  ]
  primaryAction: { label: "立即购买" }
```

### 13.11 商品详情页 — 图标入口+双按钮（2图标）

```
BottomActionBar
  variant: icon-double
  iconEntries: [
    { icon: <ServiceIcon />, label: "客服" },
    { icon: <HeartIcon />,   label: "收藏" }
  ]
  secondaryAction: { label: "加入购物车", icon: <CartIcon /> }
  primaryAction:   { label: "立即购买" }
```

### 13.12 商品详情页 — 增强型图标入口+双主按钮（@2x 设计稿，750×1624pt）

```
BottomActionBar
  variant: icon-action-double
  iconEntries: [
    { icon: <ServiceIcon />, label: "客服咨询" },
    { icon: <HeartIcon />,   label: "收藏商品" }
  ]
  primaryActions: [
    { label: "立即购买", icon: <BuyIcon />, onPress: handleBuy },
    { label: "订阅购买", icon: <SubscribeIcon />, onPress: handleSubscribe }
  ]
```

> **icon-action-double 典型场景**：
> - 商品详情页需要提供多个快捷功能（客服、收藏等）同时提供多种购买选项（一次性购买 vs 订阅购买）
> - 运营活动页需要同时强调多个功能入口（领券、客服）和多个下单渠道
> - 实时性强的抢购场景，需要两个并排的主按钮提供不同的下单规则

### 13.13 商品详情页 — 增强型图标入口+副主按钮（@2x 设计稿，750×1624pt）

```
BottomActionBar
  variant: icon-action-split
  iconEntries: [
    { icon: <CartIcon />, label: "购物车" }
  ]
  secondaryAction: { label: "加入购物车" }
  primaryAction:   { label: "立即购买" }
```

> **icon-action-split 典型场景**：
> - 商品详情页需要突出单一快捷功能（购物车、客服等）同时提供两个不同的购买选项（加购 vs 立即购买）
> - 订阅类商品需要区分"加入购物车"和"立即订购"两种行为
> - 限时抢购场景，区分"加购待付"和"立即支付"两个明确的操作选项

### 13.14 商品详情页 — 增强型图标入口+双副主按钮（@2x 设计稿，750×1624pt）

```
BottomActionBar
  variant: icon-action-triple
  iconEntries: [
    { icon: <ServiceIcon />, label: "客服" }
  ]
  secondaryAction2: { label: "查看规格", icon: <SpecIcon /> }
  secondaryAction:  { label: "加入购物车", icon: <CartIcon /> }
  primaryAction:    { label: "立即购买" }
```

> **icon-action-triple 典型场景**：
> - 商品详情页需要提供单一快捷功能入口（如"客服"）并同时展示三种操作选项（如"查看规格" + "加购" + "立即购买"）
> - 酒店/旅游类商品需要区分"查看详情"、"加入心愿单"和"立即预订"三个行为
> - 复杂规格商品场景，需要"查看规格"副按钮辅助用户决策，再引导到"加购"或"立即购买"

### 13.15 商品详情页 — 价格展示区+副主按钮（@2x 设计稿，750×1624pt）

```
BottomActionBar
  variant: price-split
  priceInfo: { icon: <CouponIcon />, label: "立减12元" }
  secondaryAction: { label: "加入购物车", icon: <CartIcon /> }
  primaryAction:   { label: "立即购买" }
```

> **price-split 典型场景**：
> - 商品详情页左侧展示当前可用优惠金额（如"立减12元"），右侧提供"加购"和"立即购买"双操作
> - 外卖/到家业务展示配送费或到手价说明（如"免配送费"），引导用户在两种结算方式间选择
> - 闪购/团购类场景展示已优惠金额或剩余优惠名额说明，引导用户尽快完成购买决策
> - 注意：若左侧信息需要可点击跳转（如点击查看优惠详情），应改用 `icon-action-split` 变体而非 `price-split`

### 13.16 商品详情页 — 胶囊组合（加入购物车 + 立即购买，等权重）

```
BottomActionBar
  variant: capsule-combo
  secondaryAction: { label: "加入购物车" }   // 左半，gradient-dark 深灰背景，text-warm-yellow 文字
  primaryAction:   { label: "立即购买" }      // 右半，gradient-yellow 黄色背景，text-primary 文字
```

> **capsule-combo 典型场景**：
> - 两个购买路径同等重要、均需强引导时（如"加入购物车"与"立即购买"在业务漏斗中都是核心转化路径）
> - 需要用颜色对比区分两操作方向性，但不希望用描边副按钮降低左侧按钮的视觉重量
> - @2x 设计稿场景（750pt 宽度）；注意：@1x 场景（375pt 宽度）若两操作权重相当，仍推荐 `double` 变体
> - 常见于闪购/秒杀/会员订购等需要同时强调"收藏/预约"与"立即购买"的场景

### 13.17 商品详情页 — 增强型图标入口+胶囊组合（@2x 设计稿，750×1624pt）

```
BottomActionBar
  variant: icon-capsule-combo
  iconEntries: [
    { icon: <ServiceIcon />, label: "客服", onPress: handleService }
  ]
  secondaryAction: { label: "加入购物车" }   // 左半，gradient-dark 深灰背景，text-warm-yellow 文字
  primaryAction:   { label: "立即购买" }      // 右半，gradient-yellow 黄色背景，text-primary 文字
```

> **icon-capsule-combo 典型场景**：
> - 商品详情页需要同时提供客服快捷入口（可点击），以及"加入购物车"和"立即购买"两个同等强引导操作
> - 与 `icon-action-split` 的区别：`icon-action-split` 右侧是描边副按钮+渐变主按钮（主次权重有差异），`icon-capsule-combo` 右侧是胶囊组合（两操作视觉权重相近，均为强引导）
> - 与 `capsule-combo` 的区别：`capsule-combo` 无图标功能入口，`icon-capsule-combo` 在左侧增加了 1 个可点击的功能入口；右侧胶囊宽度因此缩短（602pt vs 702pt），两半各约 301pt（而非 351pt）
> - 适用于高频次功能入口（如"客服"）与双强操作需要共存的场景（如会员订购类商品详情页）

### 13.18 商品详情页 — 增强型图标入口+胶囊组合（非等分，@2x 设计稿，750×1624pt）

```
BottomActionBar
  variant: icon-capsule-combo
  capsuleLayout: asymmetric
  iconEntries: [
    { icon: <ServiceIcon />, label: "客服", onPress: handleService }
  ]
  secondaryAction: { label: "预约" }         // 左半（固定 248pt），gradient-dark 深灰背景，text-warm-yellow 文字
  primaryAction:   { label: "立即购买" }      // 右半（弹性约 354pt），gradient-yellow 黄色背景，text-primary 文字
```

> **icon-capsule-combo asymmetric 典型场景**：
> - 与等分配置（13.17）的适用逻辑相同，区别在于次操作文字较短（如"预约"）或主操作在业务上优先级略高时，使右侧主操作获得更宽的按压区域（约 354pt vs 301pt）
> - 与 `capsule-combo asymmetric` 的区别：多了左侧 1 个可点击的图标入口（100pt），因此右侧胶囊总宽从 702pt 压缩为 602pt，左半固定 248pt 不变，右半弹性宽从约 454pt 缩短为约 354pt
> - 右半内容通过 `padding: 19px 0px` 实现垂直居中（区别于等分配置的 `justify-content: center`），右半副文字行颜色使用 `rgba(0,0,0,0.67)`（深色半透明），适应黄色背景
> - 适用于"预约+立即购买"、"加购（短文案）+立即订购"等主操作需要占据更宽空间的场景

### 13.19 商品详情页 — 双增强型图标入口+胶囊组合（客服+收藏 × 加购+立购，@2x 设计稿，750×1624pt）

```
BottomActionBar
  variant: double-icon-capsule-combo
  capsuleLayout: symmetric                    // 默认，两半各 flex-grow:1，约 251pt
  iconEntries: [
    { icon: <ServiceIcon />,  label: "客服",  onPress: handleService  },  // 第1个图标入口（100pt）
    { icon: <FavoriteIcon />, label: "收藏",  onPress: handleFavorite }   // 第2个图标入口（100pt），横排紧邻
  ]
  secondaryAction: { label: "加入购物车" }    // 左半（约 251pt），gradient-dark 深灰背景，text-warm-yellow 文字
  primaryAction:   { label: "立即购买" }      // 右半（约 251pt），gradient-yellow 黄色背景，text-primary 文字
```

> **double-icon-capsule-combo 典型场景**：
> - 在会员订购类商品详情页，运营需要同时提供"客服"和"收藏"两个功能快捷入口，并且加入购物车与立即购买同等重要时
> - 限时抢购/秒杀场景，两个强引导操作（加购 + 立购）需要等权重呈现，同时提供"客服"和"提醒"两个高频功能入口
> - 与 `icon-capsule-combo`（13.17）的区别：左侧图标入口从 1 个（100pt）扩展为 2 个横排（200pt），右侧胶囊总宽从约 602pt 压缩为约 502pt，两半各约 251pt（而非 301pt）
> - 与 `icon-action-double`（13.12）的区别：`icon-action-double` 左侧 2 个图标入口**竖排**、右侧为 2 个独立主按钮（均渐变黄），`double-icon-capsule-combo` 左侧 2 个图标入口**横排**、右侧为等分胶囊（左深灰次操作 + 右黄色主操作）；场景用途完全不同，不可混淆
> - 注意：右侧胶囊约 502pt 宽度下仅支持等分布局（`capsuleLayout="symmetric"`，两半各约 251pt）；若次操作文字极短（如"预约"）需要主操作更宽，应改用 `icon-capsule-combo asymmetric`（右侧胶囊 602pt，左半 248pt，右半约 354pt）
> - 布局约束：双图标入口横排总宽 200pt（`flex-shrink:0`），图标区与胶囊区 `gap: 12pt`，容器左 padding 12pt，右 padding 24pt；图标入口各含 44pt 图标 + 20pt 标签，`padding-top: 4px`

### 13.20 商品详情页 — 三增强型图标入口+胶囊组合（客服+收藏+分享 × 加购+立购，@2x 设计稿，750×1624pt）

```
BottomActionBar
  variant: triple-icon-capsule-combo
  capsuleLayout: symmetric                    // 唯一支持的布局，两半各 flex-grow:1，约 201pt
  iconEntries: [
    { icon: <ServiceIcon />,  label: "客服",  onPress: handleService  },  // 第1个图标入口（100pt）
    { icon: <FavoriteIcon />, label: "收藏",  onPress: handleFavorite },  // 第2个图标入口（100pt），横排紧邻
    { icon: <ShareIcon />,    label: "分享",  onPress: handleShare    }   // 第3个图标入口（100pt），横排紧邻
  ]
  secondaryAction: { label: "加入购物车" }    // 左半（约 201pt），gradient-dark 深灰背景，text-warm-yellow 文字
  primaryAction:   { label: "立即购买" }      // 右半（约 201pt），gradient-yellow 黄色背景，text-primary 文字
```

> **triple-icon-capsule-combo 典型场景**：
> - **【首选场景】购物车结算页**：左侧三个入口为"客服"+"优惠券"+"购物车"（高频功能），右侧胶囊为"查看详情"（次操作，深灰）+ "去结算"（主操作，黄色）；这是该变体最典型的业务场景
> - **【首选场景】通用结算页**：左侧三个入口为"客服"+"收藏"+"分享"，右侧胶囊为"加入购物车"（次操作）+ "立即付款"（主操作）
> - 社交电商或内容电商类商品详情页，运营需要同时提供"客服"、"收藏"和"分享"三个高频功能快捷入口，并且加入购物车与立即购买同等重要时
> - 直播间购买场景，三个入口可为"客服"、"分享"和"礼物"，右侧胶囊提供"加购"和"订购"双强引导操作
> - 与 `double-icon-capsule-combo`（13.19）的区别：左侧图标入口从 2 个横排（200pt）扩展为 3 个横排（300pt），右侧胶囊总宽从约 502pt 进一步压缩为约 402pt，两半各约 201pt（接近 `min-width: 195px` 极限）
> - ⚠️ **唯一支持等分布局**：`capsuleLayout` 只能为 `"symmetric"`，不支持 `"asymmetric"` 非等分配置。右侧胶囊仅 402pt，两半已接近最小可用宽度（201pt），任何固定宽配置都会使另一半过窄，影响文字展示
> - ⚠️ **图标入口系列上限**：`triple-icon-capsule-combo` 是 icon+capsule 系列中图标入口数量的最大值（3 个）。若业务需要 4 个图标入口，应将部分功能迁移至 NavBar 或二级操作区，而非在此基础上继续扩展
> - 布局约束：三图标入口横排总宽 300pt（`flex-shrink:0`），图标区与胶囊区 `gap: 12pt`，容器左 padding 12pt，右 padding 24pt；每个图标入口含 44pt 图标 + 20pt 标签，`padding-top: 4px`；节点对应 CSS：`frame-52`（三图标入口区）→ `frame-53/55/57`（单个入口）→ `instance-22`（胶囊组合区）

### 13.21 购物车结算页 — 结算底部工具栏（客服+优惠券+购物车 × 查看详情+去结算，@2x 设计稿，750×1624pt）

```
BottomActionBar
  variant: triple-icon-capsule-combo
  capsuleLayout: symmetric                     // 唯一支持的布局，两半各 flex-grow:1，约 201pt
  iconEntries: [
    { icon: <ServiceIcon />,  label: "客服",   onPress: handleService  },  // 第1个图标入口（100pt）
    { icon: <CouponIcon />,   label: "优惠券", onPress: handleCoupon   },  // 第2个图标入口（100pt），横排紧邻
    { icon: <CartIcon />,     label: "购物车", onPress: handleCart     }   // 第3个图标入口（100pt），横排紧邻
  ]
  secondaryAction: { label: "查看详情" }       // 左半（约 201pt），gradient-dark 深灰背景，text-warm-yellow 文字
  primaryAction:   { label: "去结算" }          // 右半（约 201pt），gradient-yellow 黄色背景，text-primary 文字
```

> **购物车结算页结算工具栏说明**：
> - 这是 `triple-icon-capsule-combo` 变体在**购物车结算**场景下的标准配置：左侧 3 个高频功能入口（客服咨询、优惠券领取、返回购物车），右侧胶囊双操作（"查看详情"次操作 + "去结算"主操作）
> - `iconEntries[2]` 的"购物车"入口通常跳回购物车列表，便于用户修改商品；若为独立结算页可替换为"购物车数量角标"式入口
> - 可替换为**通用结算场景**：`secondaryAction` 为"加入购物车"，`primaryAction` 为"立即付款"，图标入口按业务需求调整（如客服/收藏/分享）
> - ⚠️ 右侧胶囊两半各约 201pt，已接近 `min-width: 195px` 极限，文案长度需控制在 **4字以内**（如"去结算"4字，"查看详情"4字），超出将导致文字截断

### 13.22 通用结算页 — 结算底部工具栏（客服+收藏+分享 × 加入购物车+立即付款，@2x 设计稿，750×1624pt）

```
BottomActionBar
  variant: triple-icon-capsule-combo
  capsuleLayout: symmetric                     // 唯一支持的布局，两半各 flex-grow:1，约 201pt
  iconEntries: [
    { icon: <ServiceIcon />,  label: "客服",  onPress: handleService  },  // 第1个图标入口（100pt）
    { icon: <FavoriteIcon />, label: "收藏",  onPress: handleFavorite },  // 第2个图标入口（100pt），横排紧邻
    { icon: <ShareIcon />,    label: "分享",  onPress: handleShare    }   // 第3个图标入口（100pt），横排紧邻
  ]
  secondaryAction: { label: "加购物车" }       // 左半（约 201pt），gradient-dark 深灰背景，text-warm-yellow 文字
  primaryAction:   { label: "立即付款" }        // 右半（约 201pt），gradient-yellow 黄色背景，text-primary 文字
```

> **通用结算场景说明**：
> - 适用于从商品详情页直接进入结算流程（非经由购物车），需要保留"客服"、"收藏"、"分享"三个功能入口
> - `secondaryAction` 的"加购物车"可引导用户将当前商品加入购物车后继续浏览（保存购买意向），`primaryAction` 的"立即付款"直接进入付款流程
> - ⚠️ 文案长度约束同上（4字以内）；"加购物车" 5字已达上限，若显示不全可缩短为 "加入购物车" → "加购" (2字)
> - 与 §13.21（购物车结算）的区别：图标入口功能不同（无"购物车"跳转入口），胶囊操作语义不同（"加购物车" vs "查看详情"）

---

## 14. 与其他组件的关系

| 关联组件 | 关系说明 |
|----------|----------|
| `bottom-navigation` | 功能不同：导航栏承载信息架构，操作栏承载页面 CTA；两者不可互换 |
| `button` | 操作栏内部按钮为 Button 组件 `size=xl` 的封装应用 |
| `home-indicator` | 操作栏正下方衔接，刘海屏间距 0pt |
