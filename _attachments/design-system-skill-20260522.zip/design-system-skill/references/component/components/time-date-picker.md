# Time/Date Picker 时间/日期选择器

> **组件分类**：Component（组件级）
> **定义**：时间/日期选择器是底部弹出的半页弹窗（Half-screen Dialog）形态，供用户选择日期或时间。分为**平铺式**（日历/列表）和**滚轮式**两大类，根据场景和用户操作习惯选用。
> **Style 依赖**：`color-semantic.md` · `font-semantic.md` · `spacing-semantic.md` · `component-spacing.md` · `radius-semantic.md` · `component-radius.md` · `stroke-semantic.md`

> ⚠️ **核心约束**：
> - 时间/日期选择器承载于**半页弹窗**容器内，本规范专注内容区组件，容器样式遵循 `half-screen-dialog.md`
> - **滚轮式**适用于"直接选择（无需浏览决策）"或"目标与当前跨度较大"的场景
> - **平铺式**分为**平铺日历式**（天为最小单位，选单个/一组日期）和**平铺列表式**（2 个层级选项，选时段/时刻）
> - 所有变体底部均有一个主操作按钮（`gradient-yellow` 渐变，全圆角）

---

## 0. 图标 / 间距 / Ownership 约束

- **icon-route（默认）**：本组件内功能图标默认回 `component/atoms/icon.md`，并沿用本文件已声明的 iconfont class / weight。
- **fixed-asset 例外**：若正文已指定 `assets/*.svg`、官方 SVG、PNG/CDN 切图、URL 尖角资源或固定插画，该位点必须走固定资产，不得强行回 iconfont；输出时可标注 `icon-route=fixed-asset`。
- **spacing-owner（归属）**：组件内部 slot、行内/容器内 gap、padding、对齐归本组件；页面边距、吸顶/吸底占位、列表外层留白归宿主。
- **宿主裁决（优先级）**：冲突遵循 `宿主 > 组合场景 > 本组件通用规则`，子组件仅拥有自身内部样式，不反向改宿主排布。
- **不可跳步**：先回 `references/INDEX.md` 完成区域路由与宿主锁定，再用 `component-quickref.md` 做宿主级收敛；本文件仅承接组件内 ownership 细则，不承担前置路由改判；不得凭语义猜测。

## 1. 选择器类型（pickerType）

| pickerType | 名称 | 适用场景 |
|-----------|------|----------|
| `calendar` | 平铺日历式 | 以**天**为最小单位，选择单个日期或一段连续日期（如入住/离店日期选择） |
| `list` | 平铺列表式 | 具有 **2 个层级**的选项，用户选择时段/时刻（如预约时间段） |
| `wheel` | 滚轮式 | 用户直接选择（无需浏览决策），或目标与当前跨度较大时使用（如出生年份） |

> **选型原则**：
> - 操作习惯上"浏览决策"型 → `calendar` 或 `list`
> - "直接目标"型或跨度大 → `wheel`
> - 时间间隔建议视业务情况设定：若几分钟差异不影响用户，可采用较大间隔（如5/10分钟）

---

## 2. 标题样式（titleType）

三种类型均支持以下标题样式，在右侧属性面板切换：

| titleType | 名称 | 说明 |
|-----------|------|------|
| `single` | 单行标题 | 默认，居中展示，标题文字 17pt（500 Medium），行高 24pt |
| `double` | 双行标题 | 第一行与单行标题相同；第二行默认 14pt 常规（Regular），字数较多时可调整为 12pt 常规 |
| `custom` | 自定义标题 | 按业务需求自定义内容（如图片类型标题，关闭按钮样式需单独说明） |

> **标题容器**：`background: #FFFFFF`，上下内边距 `cs-30`（15pt），左右 `cs-10`（5pt），`gap: cs-10`（5pt，标题文字与关闭按钮间）。
> **关闭按钮**：右侧图标按钮（`关闭or取消`，18×18pt），图标色 `#999999`。

---

## 3. 滚轮式（wheel）规格

### 3.1 变体（columns）

滚轮式以**列数**为主要变体维度：

| columns | 名称 | 选项格宽度 | 典型场景 |
|---------|------|-----------|----------|
| `1` | 1列 | 343pt（全宽内容区） | 单维度选择（如年份） |
| `2` | 2列 | 171.5pt × 2 | 二维选择（如时/分） |
| `3` | 3列（默认） | 114pt × 3 | 三维选择（如年/月/日） |
| `4` | 4列 | 85.5pt × 4 | 四维选择（如年/月/日/时） |
| `5` | 5列 | 68.5pt × 5 | 五维选择（如年/月/日/时/分） |

### 3.2 滚轮式尺寸规格（@2x / @1x 对照）

> **说明**：设计稿为 @2x（750px 基准，@1x ÷2 = pt）

| 属性 | 值（@2x） | @1x 换算 | 说明 |
|------|---------|--------|------|
| 容器宽度 | **750px** | 375pt | 全屏宽，底部弹窗宽度 |
| 容器高度 | **768px** | 384pt | 含标题 + 内容 + 按钮区 |
| 顶部圆角 | **40px** | 20pt | `radius-xl`（左上+右上） |
| 标题区高度 | **108px** | 54pt | 固定高度，含 15pt 上下 padding |
| 内容区高度 | **496px** | 248pt | 5行选项（每行 48pt） |
| 底部按钮区 | **96px** | 48pt | 含按钮（40pt，margin-top 8pt） |
| Home Indicator 占位 | **68px** | 34pt | 底部安全区 padding |
| **总高度（含安全区）** | **768+68=836px** | **418pt** | 实际展示高度 |

### 3.3 选项行规格

| 属性 | 值（@2x） | @1x | 说明 |
|------|---------|-----|------|
| 行高 | **96px** | 48pt | 选项单行高度（含 5pt 上下 padding） |
| 内容区每行可见数 | **5行** | — | 建议纵向保持 5 个选项高度 |
| 高亮区（选中行）高度 | **80px** | 40pt | 当前选中项高亮背景 |
| 高亮区颜色 | **#F7F7F7** | — | `surface-secondary`（灰色背景） |
| 高亮区圆角 | **16px** | 8pt | `radius-s` |
| 选项文字 | **30px / 44px** | 15pt/22pt | PingFang SC Medium，行高 22pt |
| 选项内边距 | `padding: cs-10 0`（上下各 5pt） | — | 上下各 5pt |

### 3.4 底部按钮规格

| 属性 | 值（@2x） | @1x | 说明 |
|------|---------|-----|------|
| 按钮宽度 | **686px** | 343pt | 左右各 16pt margin |
| 按钮高度 | **80px** | 40pt | 对应 Button `size=l` |
| 按钮背景 | `gradient-yellow` | — | `linear-gradient(97deg, #FFE74D 0%, #FFDD00 100%)` |
| 按钮圆角 | **40px** | 20pt | `radius-full`（全圆角） |
| 按钮文字 | **"主操作"** | — | 15pt，PingFang SC 500，`text-primary`（`#111111`） |

---

## 4. 平铺日历式（calendar）规格

### 4.1 日期格单元（DateCell）

| 属性 | 值（@2x） | @1x | 说明 |
|------|---------|-----|------|
| 单元格宽度 | 按 7 等分 | ≈ 53.5pt | 7天平均分配，内容居中 |
| 常规型单格高度 | **100px** | 50pt | 基础日期单格 |
| 复杂型单格高度 | **140px** | 70pt | 含辅助信息（如价格/节假日），高度增加 20pt |
| 选中圆角 | **24px** | 12pt | 选中日期圆角（两端） |
| 中间段圆角 | **0px** | 0pt | 连续选择中间日期无圆角 |
| 最左/最右特殊圆角 | **19px** | ≈9.5pt | 每行最左/最右项圆角，需单独调整 |

> **颜色说明**：
> - 周末高亮色默认使用 `R3 #FF2D19`；如无需高亮周末，可调整为 `text-primary (#111111)`
> - 辅助信息分两类：**常规提示信息**（如节假日、"休"/"班"）与**操作反馈信息**（如"入住"）；冲突时操作反馈高优展示

### 4.2 日历行数

| 推荐行数 | 最少行数 | 说明 |
|----------|----------|------|
| 6行 | 5行 | 如需更多行，应符合半页弹窗最大高度约束 |

### 4.3 星期标题行

| 属性 | 值（@2x） | Token |
|------|---------|-------|
| 标题文字色（默认）| `text-secondary`（`#555555`） | `color-semantic.md` §二 |
| 周末文字色 | `R3 #FF2D19` | `color-semantic.md` §三 Brand |
| 字号 | 12pt | `caption-l-22` ≈ |

---

## 5. 平铺列表式（list）规格

### 5.1 一级选项列宽

一级选项支持 **2 档固定宽度**：

| 宽度类型 | 值（@2x） | @1x | 适用场景 |
|----------|---------|-----|----------|
| 标准宽 | **224px** | 112pt | 短字段（如"上午"/"下午"） |
| 宽型 | **240px** | 120pt | 略长字段 |

> 建议根据实际字段长短选择；一级选项列宽**固定**，内容居中展示。

### 5.2 二级选项区

- 二级选项跟随一级展示，纵向滚动
- 单行高度与滚轮选项高度一致（48pt @1x）
- 选择器高度建议展示 **6 个选项**；选项不足 6 个时建议使用空白占位
- 实际需求需更多行时，应符合半页弹窗最大高度约束

---

## 6. Token 引用

### 6.1 颜色 Token

| 用途 | Token 名称 | 值 | 语义层来源 |
|------|-----------|-----|-----------|
| 容器背景 | `bg-page` / `white` | `#FFFFFF` | `color-semantic.md` §一 |
| 内容区高亮（选中行） | `surface-secondary` | `#F7F7F7` | `color-semantic.md` §一 Surface |
| 主操作按钮背景 | `gradient-yellow` | `linear-gradient(97deg, #FFE74D 0%, #FFDD00 100%)` | `color-semantic.md` §八 Gradient |
| 主文字色 | `text-primary` | `#111111` | `color-semantic.md` §二 |
| 次级文字色 | `text-secondary` | `#555555` | `color-semantic.md` §二 |
| 禁用/灰色图标 | `icon-tertiary` | `#999999` | `color-semantic.md` §三 |
| 深色蒙层（蒙层背景） | `bg-overlay-dark` | `#000000CC`（80%） | `color-semantic.md` §六 |
| 周末/强调色（日历） | `brand-red` / `R3` | `#FF2D19` | `color-semantic.md` §三 Brand |
| 选中边框（日历选中首尾） | `brand-yellow` | `#FFDD00` | `color-semantic.md` §三 Brand |

### 6.2 字体 Token

| 用途 | Token 名称 | 字号 @2x | 行高 @2x | 字重 |
|------|-----------|---------|---------|------|
| 标题文字 | `subtitle-l-34-medium` | 34px | 48px | 500（Medium） |
| 双行标题第二行（默认） | `body-l-28-regular` | 28px | 40px | 400（Regular） |
| 双行标题第二行（长文） | `body-s-24-regular` | 24px | 32px | 400（Regular） |
| 滚轮选项 | `body-l-30-medium` | 30px | 44px | 500（Medium） |
| 主操作按钮 | `subtitle-s-30-semibold` | 30px | 44px | 600（Semibold） |

### 6.3 间距 Token

| 用途 | Token 名称 | 值（@2x） | @1x |
|------|-----------|---------|-----|
| 标题区上下内边距 | `cs-30` | 30px | 15pt |
| 按钮区上外边距 | `spacing-s` | 16px | 8pt |
| 容器左右外边距（按钮） | `spacing-xl` | 32px | 16pt |
| 选项内上下内边距 | `cs-10` | 10px | 5pt |

### 6.4 圆角 Token

| 用途 | Token 名称 | 值（@2x） | @1x |
|------|-----------|---------|-----|
| 容器顶部圆角（弹窗） | `radius-2xl` | 40px | 20pt |
| 选中高亮区圆角 | `radius-s` | 16px | 8pt |
| 主操作按钮圆角 | `radius-full` | 40px（全圆角） | 20pt |
| 证件型上传卡片圆角 | `radius-m` | 12px | 6pt |

---

## 7. 结构规格

### 7.1 组件树（滚轮式）

```
[滚轮式选择器]                    — 375×384pt，顶部圆角 20pt，白色背景
  ├── [标题区]                   — 375×54pt，白色背景，上下 padding 15pt
  │     ├── [标题文字]           — 居中，17pt/24pt，Medium（#111111）
  │     └── [关闭/取消按钮]      — 右侧，18×18pt，灰色图标
  ├── [内容区]                   — 375×248pt，flex-column，底部 padding `spacing-s`（8pt）
  │     ├── [高亮遮罩]           — 343×40pt，#F7F7F7，圆角 8pt，绝对定位居中
  │     ├── [行 1] 375×48pt      — 每行 flex-row，左右 padding `spacing-xl`（16pt）
  │     │     └── [选项 ×N]      — 等宽，上下 padding `cs-10`（5pt），gap: `cs-10`（5pt）
  │     ├── [行 2~5]             — 同行 1，共 5 行可见
  │     └── ...（共 5 个可见行）
  └── [底部按钮区]               — 375×48pt，白色背景，上内边距 `spacing-s`（8pt）
        └── [主操作按钮]         — 343×40pt，gradient-yellow，radius-full，15pt 文字
```

### 7.2 平铺式包含于半页弹窗

平铺日历式和平铺列表式内容区通过 `pickerType` 区分：
- `calendar`：7列网格，日期格 50pt（常规）或 70pt（复杂），含星期标题行
- `list`：左侧一级固定列（112/120pt）+ 右侧二级列表，纵向滚动

---

## 8. 交互规则

### 8.1 触发方式

| 场景 | 说明 |
|------|------|
| 点击输入框 / 日期区域 | 弹出对应类型的选择器（从底部以半页弹窗形式弹出） |
| 关闭 | 点击关闭按钮 / 点击蒙层区域 / 点击取消 |
| 确认 | 点击"主操作"按钮后回调选中值，关闭选择器 |

### 8.2 滚轮式交互

- 每列独立滚动，当前选中项居中高亮（`#F7F7F7` 背景）
- 滚动停止后，最近选项自动吸附至中央位置（snap 效果）
- 时间间隔可配置：建议业务侧根据精度需求设定（如5分钟、10分钟为间隔）
- 建议纵向保持 5 个选项高度的可视窗口

### 8.3 平铺日历式交互

- **单日期选择**：点击一个日期即完成选择，点击后高亮当前日期
- **区间选择**：点击起始日期 + 结束日期，两日期之间的格子呈现中间段样式（无圆角，半透明背景）
- **禁用日期**：置灰展示，不可点击（如历史日期、超出范围日期）
- 当一行的最左/最右为中间项时，应特殊调整其圆角（详见设计稿说明）

### 8.4 平铺列表式交互

- 左列（一级）点击切换，右列（二级）联动刷新
- 右列支持纵向滚动，建议展示 6 行，不足时用空白占位

---

## 9. Props API（供 AI 生码参考）

```typescript
export type TimeDatePickerProps = {
  /**
   * 选择器类型
   * @default "wheel"
   */
  pickerType: "calendar" | "list" | "wheel";

  /**
   * 标题文字（单行标题默认内容）
   */
  title?: string;

  /**
   * 标题样式
   * @default "single"
   */
  titleType?: "single" | "double" | "custom";

  /**
   * 双行标题第二行内容（仅 titleType=double 时有效）
   */
  subTitle?: string;

  /**
   * 滚轮式列数（仅 pickerType=wheel 时有效）
   * @default 3
   */
  columns?: 1 | 2 | 3 | 4 | 5;

  /**
   * 滚轮式列数据（仅 pickerType=wheel 时有效）
   * 每个 column 是一个选项数组，支持联动
   */
  columnOptions?: WheelColumnOption[][];

  /**
   * 当前选中值（受控）
   */
  value?: DateTimeValue;

  /**
   * 默认值（非受控）
   */
  defaultValue?: DateTimeValue;

  /**
   * 确认回调
   */
  onConfirm?: (value: DateTimeValue) => void;

  /**
   * 关闭回调
   */
  onClose?: () => void;

  /**
   * 日历式：禁用日期判断函数（仅 pickerType=calendar 时有效）
   */
  disabledDate?: (date: Date) => boolean;

  /**
   * 日历式：日期格类型（常规 / 复杂含辅助信息）
   * @default "normal"
   */
  calendarCellType?: "normal" | "complex";

  /**
   * 列表式：一级列宽类型（仅 pickerType=list 时有效）
   * @default "standard"
   */
  listFirstColumnWidth?: "standard" | "wide";  // standard=112pt, wide=120pt

  /**
   * 主操作按钮文字
   * @default "确定"
   */
  confirmText?: string;

  /**
   * 是否可见（控制弹出）
   */
  visible?: boolean;
};

export type WheelColumnOption = {
  label: string;
  value: string | number;
  /** 是否禁用 */
  disabled?: boolean;
};

export type DateTimeValue = Date | string | number | (string | number)[];
```

---

## 10. data-attribute 规范

| 属性 | 值 | 说明 |
|------|----|------|
| `data-slot` | `"time-date-picker"` | 选择器根容器 |
| `data-slot` | `"picker-header"` | 标题区 |
| `data-slot` | `"picker-content"` | 内容区 |
| `data-slot` | `"picker-footer"` | 底部按钮区 |
| `data-slot` | `"wheel-column"` | 滚轮单列 |
| `data-slot` | `"wheel-option"` | 滚轮单个选项 |
| `data-slot` | `"calendar-cell"` | 日历单个日期格 |
| `data-slot` | `"list-level1"` | 列表式一级列 |
| `data-slot` | `"list-level2"` | 列表式二级列 |
| `data-picker-type` | `"calendar"` / `"list"` / `"wheel"` | 选择器类型 |
| `data-columns` | `"1"` ~ `"5"` | 滚轮列数 |
| `data-state` | `"selected"` / `"disabled"` / `"default"` | 日期/选项状态 |
| `data-cell-type` | `"normal"` / `"complex"` | 日历格类型 |
| `data-range` | `"start"` / `"middle"` / `"end"` | 区间选择中的位置（日历模式） |

---

## 11. 无障碍（Accessibility）

- 底部弹窗：`role="dialog"`，`aria-modal="true"`，`aria-labelledby` 指向标题
- 关闭按钮：`aria-label="关闭"`
- 滚轮列：`role="listbox"`，每个选项 `role="option"`，选中项 `aria-selected="true"`
- 日历格：`role="gridcell"`，禁用格 `aria-disabled="true"`
- 键盘导航：
  - 滚轮：`ArrowUp` / `ArrowDown` 切换选项，`Enter` 确认
  - 日历：`ArrowLeft` / `ArrowRight` / `ArrowUp` / `ArrowDown` 移动日期，`Enter` 选择，`Escape` 关闭

---

## 12. 变体矩阵（完整 MECE）

### 12.1 滚轮式（5 变体）

| pickerType | columns | 尺寸（@2x） |
|-----------|---------|----------|
| `wheel` | `1` | 750×768px，选项宽 686px |
| `wheel` | `2` | 750×768px，选项宽 343px×2 |
| `wheel` | `3` | 750×768px，选项宽 228px×3 |
| `wheel` | `4` | 750×768px，选项宽 171px×4 |
| `wheel` | `5` | 750×768px，选项宽 137px×5 |

> 以上 5 个变体均共享 384pt 总高（含标题 54pt + 内容 248pt + 底部 48pt + Home Indicator 34pt）

### 12.2 平铺式（2大类）

| pickerType | 子类型 | 描述 |
|-----------|--------|------|
| `calendar` | `normal`（常规型） | 日期格高度 50pt，基础日期信息 |
| `calendar` | `complex`（复杂型） | 日期格高度 70pt，含价格/节假日辅助信息 |
| `list` | `standard-width`（标准宽一级） | 一级列宽 112pt |
| `list` | `wide-width`（宽型一级） | 一级列宽 120pt |

---

## 13. 使用约束

### 13.1 与 Half-screen Dialog 的关系

时间/日期选择器**必须**承载于半页弹窗（`half-screen-dialog`）容器内，需遵循以下约束：
- 最大高度：不超过半页弹窗规范中关于最大高度的说明
- 日历行数如需超过 6 行，需评估是否超出最大高度限制

### 13.2 选型建议

| 场景 | 推荐类型 |
|------|----------|
| 预约入住/离店日期 | `calendar (complex)`，展示价格、节假日 |
| 简单日期选择（如生日） | `calendar (normal)` |
| 选择时段（如上午/下午 + 具体小时） | `list`（二级联动） |
| 选择出生年/月/日 | `wheel (3列)` |
| 选择出发时间（预约发车，5分钟精度） | `wheel (2列)`，时间间隔 5 分钟 |
| 年份跨度大的选择 | `wheel (1列)` |

### 13.3 常见禁止事项

1. **禁止自定义选择器整体高度**（仅调整内容行数）
2. **滚轮列数不超过 5 列**，过多列会导致单项过窄影响可读性
3. **日历式不建议最少展示少于 5 行**，避免内容过于紧凑
4. **时间间隔不建议细于 1 分钟**，预约类场景 5~15 分钟为宜

---

## 14. 常见组合示例

### 14.1 酒店入住日期选择
```
TimeDatePicker
  pickerType: "calendar"
  calendarCellType: "complex"     // 含价格信息
  title: "选择入住日期"
  confirmText: "确定"
  value: { start: "2026-04-08", end: "2026-04-10" }
```

### 14.2 外卖预约送达时间
```
TimeDatePicker
  pickerType: "list"
  title: "预约送达时间"
  listFirstColumnWidth: "wide"    // 时段字段略长
  confirmText: "确认预约"
```

### 14.3 出生日期选择（年/月/日）
```
TimeDatePicker
  pickerType: "wheel"
  columns: 3
  title: "选择出生日期"
  confirmText: "确认"
  columnOptions: [years, months, days]
```

### 14.4 预约发车时间（时/分，5分钟间隔）
```
TimeDatePicker
  pickerType: "wheel"
  columns: 2
  title: "选择出发时间"
  confirmText: "确认时间"
  columnOptions: [hours, minutes]   // minutes 每隔 5 个为一项
```

---

## 15. 与其他组件的关系

| 关联组件 | 关系说明 |
|----------|----------|
| `half-screen-dialog` | 时间/日期选择器承载于半页弹窗内，遵循其最大高度约束 |
| `button` | 底部主操作按钮为 Button `size=l`、`variant=primary` |
| `navigation` | 选择器弹出时，页面导航区通常不受影响（弹窗覆盖层之上） |
| `form` | 表单行中的日期字段点击后触发时间/日期选择器弹出 |
