# Rating 评分评价

> **组件分类**：Component（组件级）
> **定义**：评分组件用于展示或采集用户对内容/服务的满意度评分。分为**只读型**（展示评分结果）和**可交互型**（用户主动评分）两大模式。支持**星星**和**表情**两种图标类型，可与数值文字、评价标签组合展示。
> **Style 依赖**：
> - Reference 层：`color-reference.md` · `font-reference.md` · `spacing-reference.md` · `radius-reference.md`
> - Semantic 层：`color-semantic.md` · `font-semantic.md` · `spacing-semantic.md` · `radius-semantic.md` · `stroke-semantic.md`
> - Component 层：`component-spacing.md`（组件内部间距 `cs-*`）· `component-radius.md`（组件内部圆角 `cr-*`）

> ⚠️ **核心约束**：
> - 图标数量固定为 **5 个**，不支持自定义数量
> - **只读型·星星**：`size` **固定为 `s`**（24×24px @2x），精度支持 **0.5**（半星展示），评分值范围 **0 ~ 5**，步长 0.1
> - **可交互型**：精度支持 **整档** 或 **半档**，用户点击/滑动选择；`size` 支持 `l` / `m`
> - 星星类型：激活色固定 `brand-yellow`，未激活色固定 `stroke-default`，禁止自定义
> - 评分数值文字**必须**使用价格字体 Token（`price-*`）而非普通文字 Token

---

## 0. 组件分类总览

Rating 组件按**图标类型**分为两大类（星星 / 表情），每类下再细分使用场景和变体，共 9 个变体，对应设计规范文档组件集的 5 列结构：

| 类型 | 场景（样式选择指南 第2列） | 变体（样式选择指南 第3列） | 核心规格来源 | 补充使用建议（第5列） |
|------|----------------------|----------------------|------------|-------------------|
| **星星** | 商家综合体验评价（建议平台类业务，适用于综合评价） | 无维度型 | @2x 代码实测，见 §9.1 | 星星颜色可根据品牌色调整；每颗星带独立文字标签，选中星标签变深 |
| **星星** | 商家综合体验评价（建议平台类业务，适用于综合评价） | 无总分型 | 多维度列表布局，见 §17.7 | 星星颜色可根据品牌色调整；**右侧为评价文字标签**（糟糕/不好/一般/还行/超赞），未评分 `#888888`，已评分 `#111111` weight:500；维度名建议 ≤ 3 字 |
| **星星** | 商家综合体验评价（建议平台类业务，适用于综合评价） | 综合型 | 上部无维度 + 下部多维列表，见 §17.8 | 星星颜色可根据品牌色调整；已评分右侧数值文字 `#111111` 中黑（weight:500） |
| **星星** | 列表场景评价（适用于评价列表的用户评价） | 简单型 | @2x 代码实测，见 §17.1 | 星星颜色可根据品牌色调整 |
| **表情** | 单商品快捷评价（建议自营类业务，适用于商品评价） | 二分·上下型 | @2x 代码实测，见 §17.9 | — |
| **表情** | 单商品快捷评价（建议自营类业务，适用于商品评价） | 二分·左右型 | @2x 代码实测，见 §17.10 | — |
| **表情** | 骑手类评价 | 二分·选项型 | @2x 代码实测，见 §17.11 | 选中态底色可根据品牌色调整；**圆角不可调整为胶囊形** |
| **表情** | 骑手类评价 | 三分·选项型 | @2x 代码实测，见 §17.12 | 选中态底色可根据品牌色调整；**圆角不可调整为胶囊形** |
| **表情** | 列表场景评价（适用于评价列表的用户评价） | 二分·简单型 | @2x 代码实测，见 §17.13 | 文字色可根据品牌色调整 |

> **说明**：上表完整对应设计规范页面中的组件集分类表格（共9个变体行）。第1列为两大图标类型（**星星** / **表情**），第2列为适用场景指南，第3列为细分变体，第4列为组件规格来源，第5列为补充使用建议。

---

## 0. 图标 / 间距 / Ownership 约束

- **icon-route（默认）**：评分图标按正文既定评分资源策略执行，不得随意替换 icon route。
- **fixed-asset 例外**：评分图标优先走 CDN 图片，SVG 仅作兜底；不得强行改为 iconfont，输出可标注 `icon-route=fixed-asset`。
- **spacing-owner（归属）**：评分组件内部星级/表情布局、数值与标签间距归 Rating；页面外层留白归宿主。
- **宿主裁决（优先级）**：组合场景冲突遵循 `宿主 > 组合场景 > Rating`，子组件不反向改宿主排布。
- **不可跳步**：先回 `references/INDEX.md` 完成区域路由与宿主锁定，再用 `component-quickref.md` 做宿主级收敛；本文件仅承接组件内 ownership 细则，不承担前置路由改判；不得凭语义猜测。


## 1. 交互模式（mode）

| mode | 名称 | 说明 | 典型场景 |
|------|------|------|----------|
| `readonly` | 只读型 | 仅展示评分结果，不可交互 | 列表卡片、详情页评分展示、评价列表 |
| `interactive` | 可交互型 | 用户可通过点击/滑动选择评分，有按下/选中反馈 | 订单完成后评价页、填写评价表单 |

---

## 2. 尺寸级别（size）

### 2.1 星星图标容器尺寸（@2x，单位 px）

| size | 名称 | 容器尺寸 @2x | 容器尺寸 @1x | 星星间距（@2x） | 典型场景 |
|------|------|------------|------------|---------------|----------|
| `l` | 大 | **68×68px** | 34×34pt | `spacing-2xs`（8px / 4pt） | 可交互评价页，评分主视觉区（**仅 interactive 模式**） |
| `m` | 中 | **48×48px** | 24×24pt | `spacing-3xs`（4px / 2pt） | 可交互多维度评分行（**仅 interactive 模式**） |
| `s` | 小 | **24×24px** | 12×12pt | `spacing-3xs`（4px / 2pt） | 列表卡片 / 评价列表展示评分；**只读型星星唯一可用尺寸** |

### 2.2 表情图标容器尺寸（@2x，单位 px）

| size | 名称 | 容器尺寸 @2x | 容器尺寸 @1x | 典型场景 |
|------|------|------------|------------|----------|
| `l` | 大 | **56×56px** | 28×28pt | 可交互评价页主视觉区 |
| `m` | 中 | **48×48px** | 24×24pt | 一般评价场景 |
| `s` | 小 | **32×32px** | 16×16pt | 紧凑评价场景 |

> **注**：星星图标与表情图标共用 `size` 枚举（`l` / `m` / `s`），但容器尺寸不同，通过 `iconType` 属性区分。
> **行高**：图标所在行高与容器尺寸等高，上下无额外内边距（由父级容器控制间距）。

---

## 3. 评分精度（precision）

| precision | 名称 | 说明 | 适用 mode |
|-----------|------|------|-----------|
| `full` | 整星 | 仅展示满星（0/1），值取最近整数 | `readonly` / `interactive` |
| `half` | 半星 | 支持半星展示（0/0.5/1），精度 0.5 | `readonly` / `interactive` |

> **只读型注意**：`precision=half` 时，展示值 = `Math.round(score × 2) / 2`（四舍五入到最近 0.5）；例如 4.3 → 4.5，4.2 → 4.0。

---

## 4. 星星图标形态

| 形态 | 展示条件 | 颜色 Token | 说明 |
|------|----------|-----------|------|
| 满星（full star） | 分值 ≥ 当前位置 | `brand-yellow`（`#FFDD00`） | 黄色填充星；**优先用** `https://p0.meituan.net/ingee/024047bc03da9aa1266c6f61ccfe0ec91912.png`，SVG 兜底 |
| 半星（half star） | 当前位置 - 0.5 ≤ 分值 < 当前位置 | 左半 `brand-yellow`，右半 `stroke-default` | 左右劈开，仅 `precision=half` 时出现；**优先用** `https://p0.meituan.net/ingee/39858aed7d9227a961aab3636d91eaf81946.png`，SVG 兜底 |
| 空星（empty star） | 分值 < 当前位置 - 0.5 | `stroke-default`（`#E5E5E5`） | 描边空心星；**优先用** `https://p0.meituan.net/ingee/751b40f4b90c4d788e6565d5f2e2062e1633.png`，SVG 兜底 |

---

## 5. 评分数值展示（showValue）

可与星星组合展示评分数值，支持三种位置：

| valuePosition | 说明 | 字体 Token | 示例 |
|--------------|------|-----------|------|
| `right` | 数值在星星**右侧**，与星星垂直居中对齐 | 见 §5.1 | `★★★★☆ 4.5` |
| `none` | 不显示数值 | — | 仅显示星星 |

### 5.1 数值字体规格（按尺寸匹配）

| size | valuePosition | 字体 Token | 字号 @2x | 行高 @2x | 适用 mode |
|------|--------------|-----------|---------|---------|----------|
| `l` | `right` | `price-32-bold` | 16pt | 22pt | **仅 `interactive`** |
| `m` | `right` | `price-28-bold` | 14pt | 20pt | **仅 `interactive`** |
| `s` | `right` | `price-24-medium` | 12pt | 16pt | `readonly` + `interactive` |

> **数值色**：统一使用 `text-primary`（`#111111`）。
> **数值格式**：默认展示一位小数（如 `4.5`）；业务侧可自定义格式（如 `4.5分`）。
> **只读型星星**仅使用 `size=s`，数值字体固定为 `price-24-medium`（12pt）；`l` / `m` 行仅对可交互型有效。

---

## 6. 评价标签（label）

可在星星下方或右侧显示评价文字标签，辅助描述评分含义：

| size | 标签字体 Token | 字号 @2x | 行高 @2x | 标签色 |
|------|--------------|---------|---------|--------|
| `l` | `body-l-28-regular` | **26px**（13pt） | **36px**（18pt） | `text-secondary`（`#888888`） |
| `m` | `body-s-24-regular` | 24px（12pt） | 32px（16pt） | `text-secondary` |
| `s` | `caption-l-22-regular` | 22px（11pt） | 30px（15pt） | `text-secondary` |

> **`l` 尺寸精确规格（来自 @2x 代码）**：`font-size: 26px`，`line-height: 36px`，`font-weight: 400`（未选中）/ `500`（选中当前星），字体 `PingFang SC`，标签高度 `36px`，文字居中。
> **典型标签**（可交互型）：`["非常差", "差", "一般", "好", "非常好"]`，随用户选星实时切换文字。
> **无维度型标签限制**：每颗星的标签文字**最多 3 个中文字**，**不允许折行**（`white-space: nowrap`）。标签文字居中（`text-align: center`），超出截断（`overflow: hidden` + `text-overflow: ellipsis`）。**「非常差」「非常好」为合法的 3 字标签**，实现时禁止折行。
> ⚠️ **布局约束**：无维度型 `.star-unit` 的宽度固定为 **68px**（与星星帧等宽），标签文字 `text-align: center` 在此宽度内居中。**禁止给 `.star-lbl` 设置 `min-width` 超过 68px**（会撑宽 `star-unit` 导致整行溢出）。
> **标签位置**：默认在星星**右侧**（`right`），评价页可放在星星**下方**（`bottom`）。
> **选中态标签颜色变化**：当前选中星对应标签由 `#888888`（Regular 400）变为 `#111111`（Medium 500），与 `text-primary` Token 对应。

---

## 7. 状态（state）

### 7.1 只读型状态

| state | 说明 |
|-------|------|
| `default` | 正常展示评分 |
| `loading` | 评分加载中，星星区域展示骨架占位（`skeleton`） |

### 7.2 可交互型状态

| state | 说明 | 视觉表现 |
|-------|------|----------|
| `default` | 初始/未选择状态 | 全部空星（或按 `defaultValue` 预填） |
| `hover` | 手指滑过某颗星 | 该星及左侧变为满星（黄色），右侧保持空星 |
| `selected` | 已选择某个评分 | 对应分值星星高亮，选中态稳定展示 |
| `disabled` | 禁用，不可交互 | 星星透明度降低（`text-disabled` 色），不响应点击 |

---

## 8. 变体矩阵（完整 MECE）

### 8.1 只读型（readonly）核心变体

#### 8.1.1 星星型（size 固定为 `s`）

> ⚠️ **只读型星星 `size` 固定为 `s`**（24×24px @2x），不支持 `m` / `l`。

| size | precision | showValue | valuePosition | 代表场景 |
|------|-----------|-----------|--------------|----------|
| `s` | `half` | `true` | `right` | 列表卡片 / 评价列表评分展示（最常用） |
| `s` | `full` | `true` | `right` | 评价列表用户评价行，分值色 `#FF5500` |
| `s` | `half` | `false` | `none` | 紧凑列表仅展示星星 |

#### 8.1.2 无星星只读变体（不含星星图标，独立展示分值）

> 以下变体**不渲染星星图标**，仅展示分值数字 + 评价文字，`size` 属性不适用。

| 变体名 | 布局特征 | 典型场景 | 详见 |
|--------|----------|----------|------|
| **综合展示卡** | 左侧大分值+评价文字+条数，右侧多维度分值列，竖线分隔 | 商家详情页评分汇总区 | §17.4 |
| **紧凑内联型** | 分值数字 + 评价文字水平内联，无背景 | 列表行/卡片摘要区嵌入 | §17.5 |
| **评分胶囊徽标** | 胶囊外框，左侧色块背景+白色分值，右侧评价文字 | 列表卡片评分角标 | §17.6 |

### 8.2 可交互型（interactive）核心变体

#### 8.2.1 星星类型

| size | precision | label | state | 代表场景 |
|------|-----------|-------|-------|----------|
| `l` | `full` | `on` | `default` | 评价页主评分区（初始）—— **商家综合体验 / 无维度型** |
| `l` | `full` | `on` | `selected` | 评价页选星后，选中星标签 `#111111` weight:500 |
| `l` | `half` | `off` | `default` | 精细评分（半星支持） |
| `m` | `full` | `off` | `default` | 表单内评分字段 / **无总分型**列表行 |
| `m` | `full` | `off` | `disabled` | 已提交，不可修改 |

> **商家综合体验评价（无维度型）**：来自组件集标注，适用于**平台类业务的综合体验评价**场景。采用 `size=l` + `precision=full` + `label=on`，5颗星每颗各带独立文字标签（非常差/差/一般/好/非常好），用户选中第 N 颗星后仅该颗星的标签文字高亮（`#111111`，weight:500），其余保持灰色（`#888888`，weight:400）。多个维度可垂直堆叠，每个维度为独立的 Rating 实例，行间距 98pt（@1x）。**标签文字最多 3 个中文字，不允许折行（`white-space: nowrap`），容器宽度须保证 3 字不折行（≥ 78px @2x），超出截断**。**5 星组件单行宽 484px（@2x），在页面（750px）内整体水平居中（`margin: 0 auto`），禁止居左对齐**。

> **商家综合体验评价（无总分型）**：多维度列表形式，每行一个评价维度（`size=m`），左侧维度名称（建议 ≤ 3 字），右侧展示**评价文字标签**（糟糕 / 不好 / 一般 / 还行 / 超赞），而非分值数字（未评分时标签色 `#888888`，已评分标签色 `#111111` weight:500）。整个列表容器 `750×336px`（@2x），每行 `670×48px`，行间距 24px，左右 padding 40px。**星星间距为 56px（@2x）/ 28pt，显著大于常规 4px，为该变体特定规格**。**中间星星组 `flex:1`，`justify-content:center` 居中对齐，禁止居左**。

> **商家综合体验评价（综合型）**：上部无维度型评分 + 下部多维度已评分列表的组合形式，总容器 `750×484px`（@2x），上下部件间距 32px。

#### 8.2.2 表情类型

| iconType | 场景 | 变体 | count | layout | 代表场景 |
|----------|------|------|-------|--------|----------|
| `emoji` | 单商品快捷评价 | 二分·上下型 | 2 | `vertical` | 商品快捷好/差评，表情上下排列 |
| `emoji` | 单商品快捷评价 | 二分·左右型 | 2 | `horizontal` | 商品快捷好/差评，表情左右排列 |
| `emoji` | 骑手类评价 | 二分·选项型 | 2 | `option` | 骑手服务满意/不满意，卡片按钮 |
| `emoji` | 骑手类评价 | 三分·选项型 | 3 | `option` | 骑手服务三档评价，卡片按钮 |
| `emoji` | 列表场景评价 | 二分·简单型 | 2 | `simple` | 评价列表小图标+文字紧凑展示 |

> **表情·选项型（骑手类）**：使用卡片背景（`#F7F7F7`），圆角 16px，容器 `670×76px`（@2x），表情帧 56×56px，**圆角不可调整为胶囊形**，选中态底色可根据品牌色调整。
> **表情·二分型 selected 状态**：选中某项后，**未选中项不做淡出（不使用 `opacity: 0.3` 或任何透明度降低）**，其未选中项依然正常展示（表情图标使用未点亮切图，文字 `#888888`）。

---

## 9. 尺寸规格（@2x，单位 px）

### 9.0 星星图标容器尺寸总表

| 属性 | `s` | `m` | `l` | 说明 |
|------|-----|-----|-----|------|
| 星星容器尺寸 | **24×24px**（12pt） | **48×48px**（24pt） | **68×68px**（34pt） | 来自 @2x 代码实测（包含触摸热区） |
| 表情容器尺寸 | **32×32px**（16pt） | **48×48px**（24pt） | **56×56px**（28pt） | 表情图标容器 |
| 星星间距 | **4px**（2pt） | **4px**（2pt） | **8px**（4pt） | `spacing-3xs` / `spacing-2xs` |
| 数值与图标间距（right） | **4px**（2pt） | **8px**（4pt） | **8px**（4pt） | gap |
| 标签与图标间距（right） | **4px**（2pt） | **8px**（4pt） | **8px**（4pt） | gap |
| 标签与图标间距（bottom） | — | **4px**（2pt） | **8px**（4pt） | margin-top |

### 9.1 可交互型（interactive）单项规格（来自组件集 @2x 代码）

> 以下规格直接来源于 2倍图组件集样式代码，适用于 `size=l` 可交互型评价场景（单星+文字标签组合的竖向布局）。

| 属性 | @2x（px） | @1x（pt） | 说明 |
|------|----------|----------|------|
| **组件集容器** | 910 × 276 | 455 × 138 | 整个评分组件集的外框，含虚线边框 |
| **组件集圆角** | 40px | 20pt | `border-radius: 40px` |
| **单行（component）宽** | 484px | 242pt | 5个星星单元横向排列的总宽 |
| **单行（component）高** | 116px | 58pt | 星星帧 + gap + 标签文字 |
| **单行在页面内对齐** | `width:100%; justify-content:center` | — | 页面宽 750px，父容器用 `width:100%; display:flex; justify-content:center`，❌ 禁止给包裹层写 `width:750px`（父 card 有 padding 时会溢出偏右） |
| **单个星星单元（instance）** | 68 × 116 | 34 × 58 | 宽含触摸热区，高=星星容器+间距+文字 |
| **星星帧容器（frame）** | 68 × 68 | 34 × 34 | 星星触摸热区容器（`size=l` 实测） |
| **星星与标签间距** | 12px | 6pt | instance 内部 `row-gap / column-gap: 12px` |
| **单元横向排列方式** | `justify-content: space-between` | — | 5个单元均匀分布在 484px 内 |
| **单元间隙（计算值）** | (484 - 68×5) / 4 = **30px** | **15pt** | space-between 实际间距 |
| **标签文字高** | 36px | 18pt | `height: 36px` |
| **标签字号** | 26px | 13pt | `font-size: 26px`（@2x） |
| **标签行高** | 36px | 18pt | `line-height: 36px` |
| **标签字体** | PingFang SC | — | — |
| **标签对齐** | `text-align: center` | — | 居中对齐 |

#### 9.1.1 标签文字颜色与字重（选中/未选中状态）

| 状态 | 颜色 | 字重 | Token 对应 |
|------|------|------|-----------|
| **未选中**（default / 其他星） | `#888888` | 400（Regular） | `text-secondary`（来自 @2x 代码实测） |
| **选中**（当前星） | `#111111` | 500（Medium） | `text-primary` + medium |

#### 9.1.2 组件集多行排列规格（多维度评价展示）

> **组件集使用场景**：来自页面标注，该组件集属于"**星星 · 商家综合体验评价**"类型，建议平台类业务使用，适用于综合评价，变体为**无维度型**（每颗星独立带标签，无评价维度文字）。

组件集中共有 7 行（component ~ component-6），每一行代表**同一个 5 星评价组件的一种独立评价维度实例**（多维度评价表单中的一行），各维度的当前选中状态相互独立。每行高亮一颗不同的星，用于展示"当前 hover/选中在第 N 颗星"时的视觉效果（仅该颗星对应标签变为 `#111111` weight:500）。

| 行编号 | top（@2x） | 高亮位置（行内第几颗） | 说明 |
|--------|-----------|----------------------|------|
| component（第0行） | 80px | 无高亮 | 未选中任何星的默认态 |
| component-1 | 276px | 第 1 颗（pos:0） | 选中/hover 第1星 |
| component-2 | 472px | 第 1 颗（pos:0） | 另一维度，选中第1星 |
| component-3 | 668px | 第 2 颗（pos:1） | 选中/hover 第2星 |
| component-4 | 864px | 第 2 颗（pos:1） | 另一维度，选中第2星 |
| component-5 | 1060px | 第 3 颗（pos:2） | 选中/hover 第3星 |
| component-6 | 1256px | 第 3 颗（pos:2） | 另一维度，选中第3星 |

> **规格**：行间距 = 196px（@2x）= 98pt（@1x），组件集左边距 213px（@2x）= 106.5pt，共展示了前3颗星各有2种维度实例的状态（代码截取了部分）。

---

## 10. Token 引用

### 10.1 颜色 Token

| 用途 | Token 名称 | 值 | 语义层来源 |
|------|-----------|-----|-----------|
| 激活星（满星/半星左半） | `brand-yellow` | `#FFDD00` | `color-semantic.md` §三 Brand |
| 未激活星（空星） | `stroke-default` | `#E5E5E5` | `color-semantic.md` §四 Stroke |
| 评分数值文字 | `text-primary` | `#111111` | `color-semantic.md` §二 Text |
| 评价标签文字 | `text-secondary` | `#888888` | `color-semantic.md` §二 Text |
| 禁用态星星 | `text-disabled` | `#C2C2C2` | `color-semantic.md` §二 Text |
| 可交互按压态（临时高亮） | `yellow-default` | `#FFCC00` | `color-semantic.md` §七 Functional |

### 10.2 字体 Token

| 用途 | Token 名称 | 字号 @2x | 字重 | 语义层来源 |
|------|-----------|---------|------|-----------|
| `l` right 数值 | `price-32-bold` | 16pt | 700 | `font-semantic.md` §三 Price |
| 综合展示卡·整体大分值 | `price-72-bold`（@2x 72px=36pt） | 36pt | 700 | `"MT New Digital Display"`，未评分态 `#C2C2C2` |
| 综合展示卡·维度分值 | `price-36-regular`（@2x 36px=18pt） | 18pt | 400 | `"MT New Digital Display"`，未评分时显示横杠 `—`，color `text-disabled`（`#C2C2C2`）；已评分品牌主色 |
| 综合展示卡·评价文字 | `body-m-28-medium`（@2x 28px=14pt） | 14pt | 500 | PingFang SC，**与整体分值同色**（品牌主色，未评分 `text-disabled`） |
| 综合展示卡·评价数量 | `caption-s-20-regular`（@2x 20px=10pt） | 10pt | 400 | PingFang SC，`text-disabled`（`#C2C2C2`），**`white-space: nowrap`，禁止折行，超长截断** |
| 综合展示卡·维度名称 | `caption-s-20-regular`（@2x 20px=10pt） | 10pt | 400 | PingFang SC，`text-disabled`（`#C2C2C2`），`text-align: center` |
| 紧凑内联型·分值数字 | `price-42-regular`（@2x 42px=21pt） | 21pt | 400 | `"MT New Digital Display"`，未评分 `text-disabled`（`#C2C2C2`） |
| 紧凑内联型·评价文字 | `title-l-36-medium`（@2x 36px=18pt） | 18pt | 500 | PingFang SC，**与分值数字同色**（品牌主色，未评分 `text-disabled`） |
| 评分胶囊徽标型·分值数字 | `price-42-regular`（@2x 42px=21pt） | 21pt | 400 | `"MT New Digital Display"`，color `white`（`#FFFFFF`，叠于色块上） |
| 评分胶囊徽标型·评价文字 | `title-l-36-medium`（@2x 36px=18pt） | 18pt | 500 | PingFang SC，**与左侧分值色块背景色同色**（品牌主色，未评分 `text-disabled`） |
| `m` right 数值 | `price-28-bold` | 14pt | 700 | `font-semantic.md` §三 Price |
| `s` right 数值 | `price-24-medium` | 12pt | 500 | `font-semantic.md` §三 Price |
| `l` 评价标签 | `body-l-28-regular` | **26px**（13pt） | 400 / **500**（选中时） | `font-semantic.md` §一 Body |
| `m` 评价标签 | `body-s-24-regular` | 12pt | 400 | `font-semantic.md` §一 Body |
| `s` 评价标签 | `caption-l-22-regular` | 11pt | 400 | `font-semantic.md` §一 Caption |

### 10.3 间距 Token

> **层级说明**：星星间距、图标与文字间距等**组件内部间距**均使用 `component-spacing.md` 的 `cs-*` Token；页面级/模块级间距使用 `spacing-semantic.md`。

| 用途 | Token 名称 | 层级 | 值（@2x） | @1x | 说明 |
|------|-----------|------|---------|-----|------|
| `l` 星星间距 | `cs-4` | component | 8px | 4pt | 星星之间 gap |
| `s`/`m` 星星间距 | `cs-2` | component | 4px | 2pt | 星星之间 gap |
| `m`/`l` 数值/标签与图标间距 | `cs-4` | component | 8px | 4pt | 星星与文字/标签 gap |
| `s` 数值/标签与图标间距 | `cs-2` | component | 4px | 2pt | 星星与文字/标签 gap |
| 可交互型·星星与标签间距（bottom） | `cs-6` | component | 12px | 6pt | `size=l` 星星帧与标签文字的 gap（@2x 实测 12px） |
| 无总分型·维度星星间距（特殊值） | `cs-28` | component | 56px | 28pt | `size=m` 多维度列表行内星星 gap，**显著大于常规 cs-2**，为该变体专属规格 |
| 表情·上下型·项目间距 | `cs-22` | component | 44px | 22pt | 二分上下型两个表情之间的 column-gap |
| 表情·左右型·项目间距 | `cs-16` | component | 32px | 16pt | 二分左右型两个表情之间的 column-gap |
| 紧凑内联型·分值与评价文字间距 | `cs-1.5` | component | 3px | 1.5pt | 分值数字与评价文字的水平间隔 |
| 评分胶囊徽标型·徽标内水平内边距 | `cs-9` | component | 18px | 9pt | 左侧色块徽标 padding-left/right |
| 评分胶囊徽标型·右侧文字左内边距 | `cs-6` | component | 12px | 6pt | 文字左侧内边距 |
| 评分胶囊徽标型·右侧文字右内边距 | `cs-8` | component | 16px | 8pt | 文字右侧内边距；底框宽 `width:fit-content` 随文字自适应 |

### 10.4 圆角 Token

> **层级说明**：`component-radius.md`（`cr-*`）用于组件内部细粒度圆角；`radius-semantic.md`（`radius-*`）用于页面级卡片、浮层等大圆角。

| 用途 | Token 名称 | 值（@2x） | 层级 | 说明 |
|------|-----------|---------|------|------|
| 综合展示卡卡片圆角 | `radius-xs`（8pt） | 16px | semantic | 卡片外框 `border-radius: 16px`（@2x） |
| 评分胶囊外框 | `radius-full` | `9999px` | semantic | 胶囊形，实测值 27px @2x 均属全圆角 |
| 评分胶囊左侧色块非对称圆角 | 左全圆 `radius-full` / 右小圆 `cr-4`（实测 7.5px） | `27px 7.5px 24px 27px` @2x | component | 左全圆（`radius-full` = 27px）、右侧小圆切入（`cr-4` = 7.5px @2x）；CSS 写法：`border-radius: 27px 7.5px 24px 27px` |
| 表情选项型卡片圆角 | `radius-xs`（8pt） | 16px | semantic | **不可调整为胶囊形** |

---

## 11. 结构规格

### 11.1 只读型组件树（size=s, precision=half, showValue=true, valuePosition=right）

```
[Rating 根容器]                — flex-row，align: center，gap: `cs-2`（4px/2pt）
  ├── [星星区] flex-row，gap: `cs-2`（4px/2pt）
  │     ├── [星星容器 1] 24×24px(@2x)/12pt   — 满星（`brand-yellow`）
  │     ├── [星星容器 2] 24×24px(@2x)/12pt   — 满星
  │     ├── [星星容器 3] 24×24px(@2x)/12pt   — 满星
  │     ├── [星星容器 4] 24×24px(@2x)/12pt   — 半星（左 `brand-yellow`，右 `stroke-default`）
  │     └── [星星容器 5] 24×24px(@2x)/12pt   — 空星（`stroke-default`）
  └── [数值] "3.5" — 12pt，`price-24-medium`，`text-primary`
```

### 11.2 只读型·综合展示卡组件树（来自 @2x 代码实测）

> 适用于**详情页/商家主页**的评分汇总展示区域：左侧展示整体大分值 + 评价文字 + 评价数量，右侧展示多个子维度分值。

```
[综合展示卡容器]  750×104px(@2x)，与屏幕同宽（无左右外边距），border-radius:16px，background:#FFFFFF，flex-row
  ├── [左侧区] .instance-1  317×84px，flex-row，padding: 0 24px 0 40px，column-gap:8px
  │     ├── [整体大分值]  105×84px，font:72px "MT New Digital Display" bold
  │     │     → 未评分态: 显示横杠 "—"，color #C2C2C2
  │     │     → 已评分态: color 品牌主色（如 #FF7700）
  │     └── [分值信息列] .frame  140×68px，flex-column
  │           ├── [评价文字]  140×40px，font:28px PingFang SC 500
  │           │     → 示例: "非常好"，color 与整体大分值同色（品牌主色，未评分时显示"暂无评分"，color #C2C2C2）
│           └── [评价数量行] .frame-1  136×28px，flex-row，column-gap:4px
│                 → "共" + "2458" + "条评价"，font:20px PingFang SC 400 #C2C2C2
│                 → **`white-space: nowrap`，禁止折行；超长截断（`overflow: hidden` + `text-overflow: ellipsis`）**
  ├── [分割线] .pen  2×56px
  └── [右侧维度区] .frame-2  flex-grow，padding: 0 20px，flex-row
        ├── [维度列1] .instance-2  ≈98×104px，flex-column，padding:12px 0 18px，负值叠压(-6px)
        │     ├── [维度分值]  98×52px，font:36px "MT New Digital Display"
        │     │     → 未评分态: 显示横杠 "—"，color #C2C2C2
        │     │     → 已评分态: color 品牌主色（如 #FF7700）
        │     └── [维度名称]  60×28px，font:20px PingFang SC 400 #C2C2C2，text-align:center
        ├── [维度列2]  同上
        ├── [维度列3]  同上
        └── [维度列4]  同上
```

**关键尺寸（@2x → @1x）**

| 属性 | @2x | @1x | 说明 |
|------|-----|-----|------|
| 卡片容器 | 750×104px | 375×52pt | 与屏幕同宽（无左右外边距），`border-radius: 16px`，`background:#FFFFFF` |
| 左侧区宽 | 317px | 158.5pt | `padding: 0 24px 0 40px` |
| 整体大分值字号 | 72px | 36pt | `"MT New Digital Display"` bold，未评分时显示横杠 `—`，color `#C2C2C2` |
| 评价文字字号 | 28px | 14pt | PingFang SC 500，**与整体大分值同色**（品牌主色，未评分 `#C2C2C2`） |
| 评价数量字号 | 20px | 10pt | PingFang SC 400，`#C2C2C2`，`white-space: nowrap`，超长截断 |
| 分割线 | 2×56px | 1×28pt | 竖线分隔 |
| 右侧维度列宽 | ≈98px（flex-grow:1） | ≈49pt | 4列均分右侧区域 |
| 维度分值字号 | 36px | 18pt | `"MT New Digital Display"`，`#C2C2C2` |
| 维度名称字号 | 20px | 10pt | PingFang SC 400，`#C2C2C2`，居中 |
| 维度数值与名称叠压 | `margin-top: -6px` | -3pt | 数字与文字有轻微叠压效果 |

### 11.3 可交互型组件树（size=l, precision=full, label=on）

```
[页面容器]  750px(@2x)，display: flex，justify-content: center   — 整体居中，将 484px 的评分行水平居中
  └── [Rating 根容器]  flex-row，justify-content: space-between，align: start，宽 484px(@2x)
        ├── [星星单元 1] 68×116px(@2x)  — flex-column，justify-content: center，align: center，gap: 12px
        │     ├── [星星帧] 68×68px(@2x)  — 触摸热区容器，内含 28pt 视觉星星图标
        │     └── [标签文字] "非常差" — 26px/36px(@2x)，PingFang SC，未选中:#888888 weight:400
        ├── [星星单元 2] 68×116px(@2x)  — 同上
        │     ├── [星星帧] 68×68px(@2x)
        │     └── [标签文字] "差"
        ├── [星星单元 3] 68×116px(@2x)
        │     ├── [星星帧] 68×68px(@2x)
        │     └── [标签文字] "一般"
        ├── [星星单元 4] 68×116px(@2x)
        │     ├── [星星帧] 68×68px(@2x)
        │     └── [标签文字] "好"
        └── [星星单元 5] 68×116px(@2x)
              ├── [星星帧] 68×68px(@2x)
              └── [标签文字] "非常好"

选中第 N 颗星时：
  第 N 单元标签文字 → color: #111111，font-weight: 500（text-primary + medium）
  其余单元标签文字 → color: #888888，font-weight: 400（text-secondary + regular）
```

---

## 12. 交互规则

### 12.1 可交互型 - 点击交互

| 操作 | 行为 |
|------|------|
| 点击第 N 颗星 | 选中 N 分（整星精度）；选中 N 的左半则选 N-0.5（半星精度） |
| 点击已选中的同一颗星 | 取消选中（回到未评分状态），若业务不允许取消则忽略 |
| 滑动经过星星 | 实时预览（hover 态），松手确认 |

### 12.2 可交互型 - 动画

| 动作 | 效果 |
|------|------|
| 选中星星 | 星星微弹（scale 1.0 → 1.2 → 1.0，时长 200ms，`ease-out`） |
| 取消选中 | 渐变回空星（透明度渐变，100ms） |

### 12.3 最小触摸热区

- 每颗图标触摸热区 ≥ **44×44pt**（@1x）
- `size=s` 的星星容器（12pt）和表情容器（16pt）均小于 44pt，必须扩展热区

| size | 星星容器 @2x | 表情容器 @2x | 触摸热区（@1x） | 备注 |
|------|------------|------------|--------------|------|
| `l` | **68×68px**（34pt） | **56×56px**（28pt） | 建议 ≥ 44pt | `size=l` 星星容器来自 @2x 代码实测 |
| `m` | **48×48px**（24pt） | **48×48px**（24pt） | 建议 ≥ 44pt | 接近 44pt，可直接使用 |
| `s` | **24×24px**（12pt） | **32×32px**（16pt） | 必须扩展到 ≥ 88px（44pt） | 容器小，需扩展热区 |

> **注**：所有尺寸实现时，触摸响应层应保证 ≥ 44pt，视觉呈现不变。

---

## 13. Props API（供 AI 生码参考）

```typescript
export type RatingProps = {
  /**
   * 交互模式
   * @default "readonly"
   */
  mode?: "readonly" | "interactive";

  /**
   * 当前评分值（只读型为展示值；可交互型为受控值）
   * 范围 0 ~ 5
   */
  value?: number;

  /**
   * 可交互型默认值（非受控）
   */
  defaultValue?: number;

  /**
   * 图标类型
   * @default "star"
   */
  iconType?: "star" | "emoji";

  /**
   * 图标尺寸
   * @default "s"
   */
  size?: "l" | "m" | "s";

  /**
   * 评分精度
   * @default "half"（只读）/ "full"（可交互）
   */
  precision?: "full" | "half";

  /**
   * 是否展示数值
   * @default false
   */
  showValue?: boolean;

  /**
   * 数值位置（showValue=true 时有效）
   * @default "right"
   */
  valuePosition?: "right" | "none";

  /**
   * 数值格式化函数（自定义展示）
   * @default (v) => v.toFixed(1)
   */
  formatValue?: (value: number) => string;

  /**
   * 是否展示评价标签（仅 interactive 模式有效）
   * @default false
   */
  showLabel?: boolean;

  /**
   * 评价标签数组（5项，对应 1~5 分）
   * @default ["非常差", "差", "一般", "好", "非常好"]
   */
  labels?: [string, string, string, string, string];

  /**
   * 标签位置
   * @default "right"
   */
  labelPosition?: "right" | "bottom";

  /**
   * 是否禁用（仅 interactive 模式有效）
   */
  disabled?: boolean;

  /**
   * 评分变更回调（interactive 模式下，value 改变时触发）
   */
  onChange?: (value: number) => void;
};
```

---

## 14. data-attribute 规范

| 属性 | 值 | 说明 |
|------|----|------|
| `data-slot` | `"rating"` | 组件根容器 |
| `data-slot` | `"rating-stars"` | 星星容器区 |
| `data-slot` | `"rating-star"` | 单颗星星 |
| `data-slot` | `"rating-value"` | 数值展示 |
| `data-slot` | `"rating-label"` | 评价标签 |
| `data-variant` | `"star"` | 只读型·星星（`mode=readonly` + `iconType=star`） |
| `data-variant` | `"summary-card"` | 只读型·综合展示卡 |
| `data-variant` | `"inline"` | 只读型·紧凑内联分值 |
| `data-variant` | `"pill"` | 只读型·评分胶囊徽标 |
| `data-variant` | `"no-dimension"` | 可交互型·无维度型（`size=l`，每颗星带独立标签） |
| `data-variant` | `"multi-dimension"` | 可交互型·多维度列表（`size=m`，每行一个维度） |
| `data-variant` | `"emoji"` | 可交互型·表情（上下型 / 左右型 / 选项型） |
| `data-variant` | `"emoji-simple"` | 只读型·表情·二分简单型 |
| `data-mode` | `"readonly"` / `"interactive"` | 交互模式 |
| `data-icon-type` | `"star"` / `"emoji"` | 图标类型 |
| `data-size` | `"l"` / `"m"` / `"s"` | 尺寸 |
| `data-state` | `"empty"` / `"half"` / `"full"` | 单颗星星状态 |
| `data-rating-state` | `"default"` / `"selected"` / `"disabled"` | 组件整体状态 |
| `data-value` | `"4.5"` | 当前评分值（字符串） |

---

## 15. 无障碍（Accessibility）

- **只读型**：
  - 根容器 `role="img"`，`aria-label="评分 4.5 分（满分 5 分）"`
  - 星星图标 `aria-hidden="true"`（由根容器承载语义）

- **可交互型**：
  - 根容器 `role="radiogroup"`，`aria-label="请评分"`
  - 每颗星 `role="radio"`，`aria-label="N 分"`，选中时 `aria-checked="true"`
  - 禁用时 `aria-disabled="true"`
  - 键盘交互：`ArrowLeft` / `ArrowRight` 移动选中分值，`Enter` / `Space` 确认

---

## 16. 使用约束（AI 生成时的硬性规则）

1. **星星数量固定 5 颗**，不能用于非 5 星制评分场景（非 5 星制改用 NPS 组件）
2. **评分数值必须使用 `price-*` 字体 Token**，不得使用普通文字 Token
3. **禁止自定义星星颜色**：激活色固定 `brand-yellow`，未激活色固定 `stroke-default`
4. **只读型星星（`mode=readonly` + `iconType=star`）**：**`size` 固定为 `s`（24×24px @2x），不支持 `m` / `l`**，搭配 `precision=half` + `showValue=true` + `valuePosition=right`；`m` / `l` 尺寸仅在 `mode=interactive` 时使用
5. **评价提交表单场景**：优先使用 `size=l` + `mode=interactive` + `precision=full` + `showLabel=true`
6. **最小点击区域**：`size=s` 必须扩展热区至 ≥ 44pt
7. **星星·商家综合体验评价（无维度型）**：必须使用 `iconType=star` + `size=l` + `label=on` + `precision=full`；选中态标签颜色必须是 `#111111` weight:500，未选中标签为 `#888888` weight:400；单行容器高 58pt（@1x）；**标签文字最多 3 个中文字，强制 `white-space: nowrap`，禁止折行；容器宽度须保证 3 字不折行（≥ 78px @2x），超出 `text-overflow: ellipsis` 截断**；**5 星组件整体必须在页面中水平居中（`margin: 0 auto`），禁止居左**
8. **图标资源使用优先级**：星星图标和表情图标**优先使用 CDN 图片链接**（`<img>` 标签，见 §19）；**SVG 仅作为兜底**，在 CDN 不可达时通过 `onError` 事件降级显示，禁止两者同时渲染。生成代码时须同时提供 `img` 主链接 + `svg` 兜底结构

---

## 17. 常见组合示例

### 17.1 列表卡片评分展示（最常见）

> 适用于列表卡片及评价列表内的评分展示。**星星尺寸固定为 `size=s`（24×24px @2x），不支持 `m` / `l`。** 两种精度可选：
> - **`precision: "half"`**（半星）：通用列表卡片，展示精确评分（如 4.5）
> - **`precision: "full"`**（整星）：评价列表用户评价行，分值颜色为品牌橙红 `#FF5500`（无评分时 `#888888`），整行容器 `192×32px`，星星组帧 `136×24px`，分值 `font-size 24px weight:500`

```
Rating
  mode: "readonly"
  value: 4.5
  size: "s"
  precision: "half"   // 评价列表行改用 "full"，分值色 #FF5500
  showValue: true
  valuePosition: "right"
```

### 17.2 订单评价页（用户评分）

> 适用于订单完成后的评价表单，用户主动选星。

```
Rating
  mode: "interactive"
  defaultValue: 0
  size: "l"
  precision: "full"
  showLabel: true
  labels: ["非常差", "差", "一般", "好", "非常好"]
  labelPosition: "right"
  onChange: (v) => setScore(v)
```

### 17.3 商家综合体验评价（无维度型，平台类业务）

> 来自组件集标注：建议平台类业务使用，适用于商家综合体验评价。

```
// 单个评分维度（多个维度垂直堆叠）
Rating
  mode: "interactive"
  defaultValue: 0
  size: "l"
  precision: "full"
  showLabel: true
  labels: ["非常差", "差", "一般", "好", "非常好"]
  labelPosition: "bottom"   // 每颗星正下方各有独立标签
  onChange: (v) => setScore(v)

// → @2x 尺寸（来自组件集代码）
//   单行容器: 484 × 116px（242 × 58pt），margin: 0 auto（页面宽 750px，整体水平居中）
//   单元: 68 × 116px，星星帧: 68 × 68px，内部 gap: 12px
//   标签: font-size 26px, line-height 36px, PingFang SC
//   未选中: color #888888 weight:400；选中: color #111111 weight:500
```

### 17.4 只读型·综合展示卡（详情页/商家主页汇总卡片，来自组件集 2 倍图实测）

> 左侧展示**整体大分值 + 评价定性文字 + 评价条数**，右侧展示最多 4 个**子维度分值 + 名称**，中间竖线分隔。
> 典型场景：商家详情页评分汇总区、酒旅评分展示卡。

```
RatingCard                         // 只读型综合展示卡，非标准 Rating 原子组件
  mode: "readonly"
  layout: "summary-card"           // 标识：综合展示卡变体

// 左侧区——整体综合分
scoreSection:
  overallScore: 4.8                // 整体分值（小数点 1 位），未评分时显示横杠 "—"
  scoreLabel: "非常好"              // 评价文字，颜色随分值区间变化
  reviewCount: 2458                // 评价条数

// 右侧区——子维度列表（最多 4 个维度列）
dimensions:
  - label: "口味"    score: 4.9
  - label: "环境"    score: 4.7
  - label: "服务"    score: 4.6
  - label: "性价比"  score: 4.5

// → @2x 尺寸（来自组件集 2 倍图代码）
//   卡片容器:         750 × 104px（与屏幕同宽，无左右外边距），border-radius: 16px，background: #FFFFFF
//   左侧区:           317 × 84px，padding: 0 24px 0 40px，column-gap: 8px
//   整体大分值:        105 × 84px，font: 72px "MT New Digital Display" bold
//     → 未评分态: 显示横杠 "—"，color #C2C2C2
//     → 已评分态: color 品牌主色（如 #FF7700）
//   评价文字:          140 × 40px，font: 28px PingFang SC 500
//     → color 与整体大分值同色（品牌主色，未评分时文字 "暂无评分"，color #C2C2C2）
//   评价数量行:         136 × 28px，flex-row，column-gap: 4px
//     → "共" + 数字 + "条评价"，font: 20px PingFang SC 400 #C2C2C2
//     → white-space: nowrap（禁止折行），overflow: hidden，text-overflow: ellipsis（超长截断）
//   分割线:            2 × 56px（竖线）
//   右侧维度区:         flex-grow，padding: 0 20px，4 列均分
//   单维度列:           ≈98 × 104px，padding: 12px 0 18px
//     → 维度分值: font: 36px "MT New Digital Display"，居中，52px 高
//         未评分态: 显示横杠 "—"，color #C2C2C2
//         已评分态: color 品牌主色（如 #FF7700）
//     → 维度名称: font: 20px PingFang SC 400 #C2C2C2，居中，margin-top: -6px（叠压效果）
```

### 17.5 只读型·紧凑内联分值（列表行/卡片内嵌，来自组件集 2 倍图实测）

> 分值数字与评价文字**水平内联排列**，无星星图标，适用于空间紧凑的列表行或卡片摘要区域。
> 典型场景：商家列表行评分摘要、搜索结果卡片内嵌评分。

```
RatingInline                       // 紧凑内联分值展示，无星星
  mode: "readonly"
  layout: "inline"                 // 标识：内联变体
  overallScore: 4.8                // 分值（一位小数），未评分时显示横杠 "—"，color #C2C2C2
  scoreLabel: "非常好"              // 评价文字，颜色随分值区间变化

// → @2x 尺寸（来自组件集 2 倍图代码）
//   容器:       244 × 60px，flex-row，column-gap: 3px，align-items: center
//   分值数字:    61 × 60px，font: 42px "MT New Digital Display"，line-height: 60px
//     → 未评分态: 显示横杠 "—"，color #C2C2C2
//     → 已评分态: color 品牌主色（如 #FF7700）
//   评价文字:    180 × 48px，font: 36px PingFang SC 500，line-height: 48px
//     → color 与分值数字同色（品牌主色，未评分时文字 "暂无评分"，color #C2C2C2）
//     → white-space: nowrap（强制单行，不折行）
```

**关键尺寸（@2x → @1x）**

| 属性 | @2x | @1x | 说明 |
|------|-----|-----|------|
| 容器 | 244×60px | 122×30pt | `flex-row`，`align-items: center` |
| 分值数字区宽 | 61px | 30.5pt | `"MT New Digital Display"`，`line-height: 60px` |
| 分值字号 | 42px | 21pt | 未评分时显示横杠 `—`，color `#C2C2C2`；已评分品牌主色 |
| 分值与文字间距 | 3px | 1.5pt | `column-gap: 3px` |
| 评价文字区宽 | 180px | 90pt | 最大宽度，`white-space: nowrap` |
| 评价文字字号 | 36px | 18pt | PingFang SC 500，颜色随分值变化 |
| 评价文字行高 | 48px | 24pt | `line-height: 48px` |

> ⚠️ **与综合展示卡（§17.4）的区别**：本变体**无右侧维度列**，**无评价条数**，**无分割线**，整体更紧凑（244px vs 750px），适合嵌入列表行而非独占卡片区域。

### 17.6 只读型·评分胶囊徽标（列表行/卡片内嵌，来自组件集 2 倍图实测）

> 整体呈**胶囊形**（`border-radius: 27px`），左侧为**带独立色块背景的分值徽标**（类贴纸效果，分值数字白色叠于色块上），右侧为评价文字。未评分时色块为灰色，已评分时色块变为品牌色。
> 典型场景：商家列表卡片的评分角标、搜索结果行内评分徽标。

```
RatingPill                          // 评分胶囊徽标，无星星
  mode: "readonly"
  layout: "badge-pill"             // 标识：胶囊徽标变体
  overallScore: 4.8                // 分值（一位小数），未评分时色块背景为灰 #C2C2C2，分值显示横杠 "—"（白色）
  scoreLabel: "非常好"              // 评价文字，颜色随分值区间变化

// → @2x 尺寸（来自组件集 2 倍图代码）
//   外层胶囊容器:    307 × 54px，border-radius: 27px，overflow: hidden，background: #FFFFFF
//
//   左侧徽标色块 .frame:
//     尺寸:          97 × 54px
//     圆角:          border-radius: 27px 7.5px 24px 27px（左全圆、右侧小圆切入）
//     背景:          未评分 #C2C2C2 → 已评分品牌色（如 #FF7700）
//     padding:       0 18px，column-gap: 15px
//     分值数字:      61 × 60px，font: 42px "MT New Digital Display"，color #FFFFFF，居中
//       → 未评分态: 显示横杠 "—"（白色叠于灰色块上）
//       → 已评分态: 显示实际分值（白色叠于品牌色块上）
//
//   右侧文字底框 .frame-1:
//     宽度:          width: fit-content（随评价文字内容自适应，非固定宽度，非 flex-grow）
//     高:            54px
//     padding:       3px 16px 3px 12px（文字左侧 12px、文字右侧 16px），align-items: center
//     评价文字:      font: 36px PingFang SC 500
//       → color 与左侧分值色块背景色同色（品牌主色，未评分 #C2C2C2）
//       → white-space: nowrap（强制单行）
```

**关键尺寸（@2x → @1x）**

| 属性 | @2x | @1x | 说明 |
|------|-----|-----|------|
| 外层胶囊容器 | 307×54px | 153.5×27pt | `border-radius: 27px`，`overflow: hidden` |
| 左侧徽标色块宽 | 97px | 48.5pt | 圆角 `27px 7.5px 24px 27px`，左全圆右小圆 |
| 徽标色块背景 | `#C2C2C2`（未评分） | — | 已评分时替换为品牌主色 |
| 分值数字字号 | 42px | 21pt | `"MT New Digital Display"`，color `#FFFFFF` |
| 右侧文字底框宽 | `width: fit-content`（随评价文字自适应，非固定） | — | `padding: 3px 16px 3px 12px`：文字左侧 12px、文字右侧 16px |
| 评价文字字号 | 36px | 18pt | PingFang SC 500，颜色随分值变化 |
| 评价文字行高 | 48px | 24pt | `line-height: 48px` |

> ⚠️ **与紧凑内联型（§17.5）的区别**：本变体有**独立圆角背景色块**包裹分值数字，整体是胶囊形外框（`border-radius: 27px`），视觉层级更突出；内联型无任何背景色块，两者均无星星图标。

### 17.7 星星·无总分型（商家综合体验·多维度评价，代码块2）

> 来自组件集标注：建议平台类业务使用，适用于综合评价。多维度列表形式，每行一个评价维度，右侧显示评价文字标签。

```
// 整个多维度评价列表容器 (@2x: 750×336px, padding: 0 40px)
// 每行一个维度，共5行，行间距 24px
// 单行 (@2x: 670×48px)：维度标签(78px) | 星星组(flex:1, justify-content:center, 居中对齐) | 评价文字标签(78px, text-align:right)

Rating  // 每个维度
  mode: "interactive"
  size: "m"       // 星星帧 48×48px，适配行高
  precision: "full"
  showValue: false           // 不展示分值数字
  showLabel: true            // 展示评价文字标签
  labels: ["糟糕", "不好", "一般", "还行", "超赞"]  // 1~5星对应的标签
  labelPosition: "right"     // 标签在星星右侧
  dimensionLabel: "性价比"    // 左侧维度名称（建议 ≤ 3 字）
  onChange: (v) => setScore(dimension, v)

// → @2x 尺寸（来自代码块2代码）
//   整体容器: 750 × 336px，padding: 0 40px
//   单行容器: 670 × 48px，行间距 24px（row-gap: 24px）
//   左侧维度文字: 78 × 36px，font-size 26px，#111111，weight:400
//   星星组: flex:1，justify-content:center（居中对齐），星星间距 56px（@2x）/ 28pt——该变体特有间距（常规 size=m 为 4px）
//   右侧评价文字标签: 78 × 36px，font-size 26px，text-align:right
//     → 未评分: 显示横杠 "—"，color #888888，weight:400
//     → 已评分: 标签文字（糟糕/不好/一般/还行/超赞），color #111111，weight:500
```

### 17.8 星星·综合型（商家综合体验·无维度 + 多维度组合，代码块3）

> 来自组件集标注：建议平台类业务使用，适用于综合评价。页面上方为无维度型整体评分，下方为多维度列表（已有评分），右侧分值文字为中黑。

```
// 整体容器 (@2x: 750×484px, row-gap: 32px)
// 上部: 无维度 5 星评分组 (484×116px) → 与 §17.3 参数相同
// 下部: 多维度列表 (750×336px) → 与 §17.7 参数相同，但已有评分

// 上部 - 无维度型评分
Rating
  mode: "interactive"
  size: "l"
  precision: "full"
  showLabel: true
  labels: ["非常差", "差", "一般", "好", "非常好"]
  labelPosition: "bottom"
  onChange: (v) => setOverallScore(v)

// 下部 - 多维度已评分列表（每行）
Rating
  mode: "interactive"   // 已评分状态，保持 interactive（只读型星星仅支持 size=s，展示已评分勿改为 readonly+m）
  size: "m"
  precision: "full"
  showValue: false           // 不展示分值数字
  showLabel: true            // 展示评价文字标签
  labels: ["糟糕", "不好", "一般", "还行", "超赞"]  // 1~5星对应的标签
  labelPosition: "right"     // 标签在星星右侧
  dimensionLabel: "性价比"

// → @2x 尺寸（来自代码块3代码）
//   整体外容器: 750 × 484px，row-gap: 32px
//   上部无维度: 484 × 116px（同 §17.3）
//   下部多维度: 750 × 336px，padding: 0 40px（同 §17.7）
//   已评分右侧标签文字: color #111111，weight:500
```

### 17.9 表情·二分上下型（单商品快捷评价，代码块5）

> 来自组件集标注：建议自营类业务使用，适用于商品评价。两个表情垂直排列（上下型）。

```
Rating
  mode: "interactive"
  iconType: "emoji"
  count: 2             // 二分评价：好评 / 差评
  layout: "vertical"  // 上下型
  size: "m"            // 表情帧 48×48px

// → @2x 尺寸（来自代码块5代码）
//   整体容器: 140 × 80px，column-gap: 44px
//   单项 (instance): 48 × 80px，flex-column，justify-content: center
//   表情图标帧: 48 × 48px（含 1px 边距，实际图标 46×46px）
//   标签文字: 48 × 32px，font-size 22px，line-height 32px，weight:400
//     → 未选中: color #888888，opacity: 1（不淡出，正常展示）
//     → 选中: 表情图标切换为点亮切图，文字加粗
```

### 17.10 表情·二分左右型（单商品快捷评价，代码块6）

> 来自组件集标注：建议自营类业务使用，适用于商品评价。两个表情水平排列（左右型）。

```
Rating
  mode: "interactive"
  iconType: "emoji"
  count: 2             // 二分评价：好评 / 差评
  layout: "horizontal" // 左右型
  size: "m"            // 表情帧 48×48px

// → @2x 尺寸（来自代码块6代码）
//   整体容器: 248 × 48px，column-gap: 32px
//   单项 (instance): 108 × 48px，flex-row，column-gap: 8px
//   表情图标帧: 48 × 48px（含 1px 边距，实际图标 46×46px）
//   标签文字: 52 × 36px，font-size 26px，line-height 36px，weight:400，text-align:center
//     → 未选中: color #888888，opacity: 1（不淡出，正常展示）
//     → 选中: 表情图标切换为点亮切图，文字加粗
```

### 17.11 表情·二分选项型（骑手类评价，代码块7）

> 来自组件集标注：适用于骑手类评价。两个表情按钮卡片样式，有背景色，圆角不可改为胶囊形。

```
Rating
  mode: "interactive"
  iconType: "emoji"
  count: 2             // 二分：满意 / 不满意
  layout: "option"     // 选项型（带底色卡片）
  size: "l"            // 表情帧 56×56px

// → @2x 尺寸（来自代码块7代码）
//   整体容器: 670 × 76px，column-gap: 16px
//   单项卡片: flex-grow:1（各约 327px） × 76px，border-radius: 16px，background: #F7F7F7
//   表情图标帧: 56 × 56px（含1.17px边距，实际图标约 53.67×53.67px）
//   标签文字: 52 × 36px，font-size 26px，line-height 36px，weight:400
//     → 未选中: color #888888
//   ⚠️ 圆角 border-radius: 16px 不可调整为胶囊形（50%）
```

### 17.12 表情·三分选项型（骑手类评价，代码块8）

> 来自组件集标注：适用于骑手类评价。三个表情按钮卡片样式，有背景色，圆角不可改为胶囊形。

```
Rating
  mode: "interactive"
  iconType: "emoji"
  count: 3             // 三分：不满意 / 一般 / 满意
  layout: "option"     // 选项型（带底色卡片）
  size: "l"            // 表情帧 56×56px

// → @2x 尺寸（来自代码块8代码）
//   整体容器: 670 × 76px，column-gap: 12px
//   单项卡片: flex-grow:1（各约 215.33px） × 76px，border-radius: 16px，background: #F7F7F7
//   表情图标帧: 56 × 56px（含1.17px边距，实际图标约 53.67×53.67px）
//   标签文字: 52 × 36px，font-size 26px，line-height 36px，weight:400
//     → 未选中: color #888888
//   ⚠️ 圆角 border-radius: 16px 不可调整为胶囊形（50%）
```

### 17.13 表情·二分简单型（列表场景评价，代码块9）

> 来自组件集标注：适用于评价列表的用户评价。紧凑型，小图标配文字，展示在列表行内。

```
Rating
  mode: "readonly"
  iconType: "emoji"
  count: 2             // 二分
  layout: "simple"     // 简单型（图标+文字紧凑排列）
  size: "s"            // 表情帧 32×32px

// → @2x 尺寸（来自代码块9代码）
//   整体容器: 910 × 192px（组件集外框）
//   单项容器: 84 × 32px，column-gap: 4px
//   表情图标帧: 32 × 32px（含0.67px边距，实际图标约 30.67×30.67px）
//   文字: 48 × 32px，font-size 24px，line-height 32px，weight:500
//     → 选中/好评: color #FF7700（橙色，可根据品牌色调整）
//     → 未选中: color #888888
```

---

## 18. 与其他组件的关系

| 关联组件 | 关系说明 |
|----------|----------|
| `user-satisfaction` | 用户满意度组件（NPS/表情型），满意度≠星级评分；量化精度需求不同时选择 |
| `form` | 表单行中的评分字段，使用 Rating 作为值选择器 |
| `list` | 列表行 `size=s` 评分常嵌入列表行组件的副信息区 |
| `badge` | 卡片内评分数字有时与 Badge 徽标并列展示 |
| `dialog` / `half-screen-dialog` | 评价提交场景通常在弹窗内使用 interactive 型 Rating |

---

## 19. 切图资源

> 来源：美团 CDN，切图链接长期有效。

> ⚠️ **图标渲染优先级**：**优先使用 CDN 图片链接**（`<img src="..." />`），当 CDN 链接不可用（网络异常、离线场景）时，**降级使用 SVG 内联代码**作为兜底方案。严禁同时渲染两者（避免双重显示）。实现时建议通过 `onError` 事件检测 img 加载失败后替换为 SVG。

### 19.1 星星图标

| 图标名称 | 状态 | CDN 链接（优先） | SVG 兜底 |
|---------|------|----------------|----------|
| 满星 | 激活 | `https://p0.meituan.net/ingee/024047bc03da9aa1266c6f61ccfe0ec91912.png` | 填充色 `#FFDD00`（`brand-yellow`）的五角星 SVG |
| 半星 | 激活（左半） | `https://p0.meituan.net/ingee/39858aed7d9227a961aab3636d91eaf81946.png` | 左半 `#FFDD00` / 右半 `#E5E5E5`（`stroke-default`）的劈开五角星 SVG |
| 空星 | 未激活 | `https://p0.meituan.net/ingee/751b40f4b90c4d788e6565d5f2e2062e1633.png` | 描边色 `#E5E5E5`（`stroke-default`）的空心五角星 SVG |

**实现示例（星星图标优先链接 + SVG 兜底）：**
```html
<!-- 优先 CDN img，失败时降级 SVG -->
<img
  src="https://p0.meituan.net/ingee/024047bc03da9aa1266c6f61ccfe0ec91912.png"
  width="34" height="34"
  alt="满星"
  onerror="this.style.display='none'; this.nextElementSibling.style.display='inline'"
/>
<!-- SVG 兜底（默认隐藏，img 加载失败时显示） -->
<svg style="display:none" width="34" height="34" viewBox="0 0 34 34" xmlns="http://www.w3.org/2000/svg">
  <!-- 满星：填充色 #FFDD00 -->
  <polygon points="17,3 20.9,13.1 31.6,13.1 23,19.7 26,30.4 17,24 8,30.4 11,19.7 2.4,13.1 13.1,13.1" fill="#FFDD00"/>
</svg>
```

### 19.2 表情图标

| 图标名称 | 状态 | CDN 链接（优先） |
|---------|------|----------------|
| 糟糕 | 点亮（选中） | `https://p0.meituan.net/ingee/05d9b50438a4b3acf68428ffcd11a6416058.png` |
| 糟糕 | 未点亮（未选中） | `https://p0.meituan.net/ingee/dcbc49594111f336f829af8192c6966c4717.png` |
| 不好 | 点亮（选中） | `https://p0.meituan.net/ingee/c7fe2e3069eef59fe67dcb5ece0b35136308.png` |
| 不好 | 未点亮（未选中） | `https://p0.meituan.net/ingee/860119413ce054b3a9e692ce520e8d5d4468.png` |
| 一般 | 点亮（选中） | `https://p0.meituan.net/ingee/aae2f73b7dea6138a933b5d97bcc528b5973.png` |
| 一般 | 未点亮（未选中） | `https://p0.meituan.net/ingee/89ec2b38c89b419cd3000e51ae6c14594239.png` |
| 还行 | 点亮（选中） | `https://p0.meituan.net/ingee/35211380a39129b0a9e2d72b1e0e315b6782.png` |
| 还行 | 未点亮（未选中） | `https://p0.meituan.net/ingee/5e4c2a36885cdb5caed30b0f3d7cf36f4906.png` |
| 超赞 | 点亮（选中） | `https://p0.meituan.net/ingee/363986d176dac3346a48426aedbe336e7014.png` |
| 超赞 | 未点亮（未选中） | `https://p0.meituan.net/ingee/c0f7c974166120f5adeb9826203366a85369.png` |

> **SVG 兜底说明**：表情图标 CDN 链接不可用时，降级使用对应语义的 Emoji Unicode（`😢 😟 😐 🙂 😍`）或简笔画 SVG 圆形表情作为兜底，颜色遵循点亮/未点亮状态规则（点亮：品牌色；未点亮：`#C0C0C0` 灰色）。

**实现示例（表情图标优先链接 + SVG 兜底）：**
```html
<!-- 优先 CDN img，失败时降级 SVG -->
<img
  src="https://p0.meituan.net/ingee/363986d176dac3346a48426aedbe336e7014.png"
  width="28" height="28"
  alt="超赞"
  onerror="this.style.display='none'; this.nextElementSibling.style.display='inline'"
/>
<!-- SVG 兜底（默认隐藏，img 加载失败时显示） -->
<svg style="display:none" width="28" height="28" viewBox="0 0 28 28" xmlns="http://www.w3.org/2000/svg">
  <!-- 超赞点亮兜底：彩色笑脸圆 -->
  <circle cx="14" cy="14" r="13" fill="#FFDD00" stroke="#E6C800" stroke-width="1"/>
  <circle cx="10" cy="11" r="1.5" fill="#333"/>
  <circle cx="18" cy="11" r="1.5" fill="#333"/>
  <path d="M9 17 Q14 22 19 17" stroke="#333" stroke-width="1.5" fill="none" stroke-linecap="round"/>
</svg>
```
