# Notification Banner 顶部横幅

> **组件分类**：Component（组件级）
> **定义**：顶部横幅是 App 内一种适时的信息推送，从页面顶部向下弹出、停留几秒后自动向上消失。属于强提示类组件，浮于页面所有内容层之上，不阻断用户交互。
> **Style 依赖**：`color-semantic.md` · `font-semantic.md` · `spacing-semantic.md` · `component-spacing.md` · `radius-semantic.md` · `component-radius.md` · `stroke-semantic.md`

---

## 0. 图标 / 间距 / Ownership 约束

- **icon-route（默认）**：组件自带图标按正文规则走 icon route，默认回 `component/atoms/icon.md` 并遵循既定 class / weight。
- **fixed-asset 例外**：正文若指定官方 SVG、`assets/*.svg`、PNG/CDN 或 URL 切图，该位点必须走 fixed-asset。
- **spacing-owner（归属）**：Banner 内部文本与自带图标的间距/对齐归本组件；页面外层容器留白与浮层位置归宿主组件。
- **宿主裁决（优先级）**：冲突按 `宿主 > 组合场景 > 本组件`，宿主可裁决挂载位置与外部占位。
- **不可跳步**：先回 `references/INDEX.md` 完成区域路由与宿主锁定，再用 `component-quickref.md` 做宿主级收敛；本文件仅承接组件内 ownership 细则，不承担前置路由改判；不得凭语义猜测。


## 1. 组件类型（contentType）

顶部横幅按内容语义分为四类，**必须从下表选取，不可自创类型**：

| contentType | 名称 | 说明 | 适用场景举例 |
|-------------|------|------|------------|
| `notification` | 通知类 | 通用系统/IM 通知，左侧 icon + 标题 + 正文，无富媒体价格 | IM 消息通知、平台系统通知 |
| `marketing` | 营销类 | 运营活动推送，支持品牌色定制背景/文字/按钮 | 运营活动、红包、金币权益奖励 |
| `product` | 商品类 | 商品促销信息，左侧商品图/icon + 标题 + 价格 + 标签 | 商品促销、价格展示 |
| `coupon` | 优惠券类 | 优惠金额/折扣展示，左侧大号价格字体 + 标题 + 条件 + 标签 | 金额满减、折扣信息 |

> **选型原则**：优先根据内容性质选型。有具体商品价格优先用 `product`；有优惠券金额/折扣展示优先用 `coupon`；运营活动无价格用 `marketing`；系统/IM 消息用 `notification`。

---

## 2. 变体维度

各类型支持不同维度的变体，如下表所示（MECE 穷举）：

### 2.1 通知类（`notification`）

单一固定样式，无额外子变体：

| 属性 | 约束 |
|------|------|
| 容器高度 | **60pt**（固定） |
| 左侧 icon | 必须展示 |
| 按钮 | 不展示操作按钮；右侧固定显示**时间文案 + 跳转箭头图标** |
| 时间文案位置 | `position: absolute; right: 24px; top: 26px` | 
| 跳转箭头位置 | `position: absolute; right: 20px; bottom: 30px` |

### 2.2 营销类（`marketing`）

| variant | 名称 | 说明 |
|---------|------|------|
| `standard` | 常规内容 | 左侧 72×72px 图标/插画 + 标题 + 描述，容器 `padding: 0 24px` |
| `expanded` | 自定义图片内容 | 左侧**横向图片区 180×96px**，图片距容器左边界 **12px**（容器 `padding-left: 12px`），白色背景，适合展示宽幅插图/Banner |

| 属性 | `standard` 约束 | `expanded` 约束 |
|------|----------------|----------------|
| 容器高度 | **120px / 60pt**（固定） | **120px / 60pt**（固定） |
| 容器背景 | `#FFFFFF` | `#FFFFFF`（**固定白色**，❌ 禁止品牌色背景） |
| 容器内边距 | `padding: 0 24px` | `padding: 0 24px 0 12px`（左侧缩为 12px 供图片贴边） |
| 左侧区域 | 72×72px 图标，`border-radius: 12px` | **180×96px 图片区**，`border-radius: 12px`，`object-fit: cover` |
| 按钮 | 默认展示；无交互时可隐藏 | 默认展示；无交互时可隐藏 |
| 品牌色定制 | 文字色、按钮色可随业务品牌色调整 | 文字色、按钮色可随业务品牌色调整 |

### 2.3 商品类（`product`）

| variant | 名称 | 容器高度（2倍图） | 换算 pt |
|---------|------|----------------|--------|
| `no-tag` | 无标签 | **152px** | **76pt** |
| `with-tag` | 有标签 | **164px** | **82pt** |

> **标签使用警示**：标签会使容器顶部额外增加 36px padding（18pt），整体高度增加 6pt，建议**慎重**使用。

### 2.4 优惠券类（`coupon`）

优惠券类包含两个正交维度，共 2×2 = 4 种组合：

| 维度 A（标签） | 维度 B（优惠类型） | 组合名称 | 容器高度（2倍图） | 换算 pt |
|--------------|----------------|---------|----------------|--------|
| `no-tag`（无标签） | `amount`（金额，如"¥72"） | 无标签-金额 | **120px** | **60pt** |
| `no-tag`（无标签） | `discount`（折扣，如"8折"） | 无标签-折扣 | **120px** | **60pt** |
| `with-tag`（有标签） | `amount`（金额） | 有标签-金额 | **132px** | **66pt** |
| `with-tag`（有标签） | `discount`（折扣） | 有标签-折扣 | **132px** | **66pt** |

> **标签使用警示**：有标签变体高度比无标签高 12px（6pt），原因是顶部 padding 由 8px 增加至 20px（+12px），为标签层叠留出空间；建议**慎重**使用。

---

## 3. 固定规格（不可调整）

以下属性在所有变体中**均不可修改**：

| 属性 | 规格（2倍图 px） | 换算（pt） | Token 引用 |
|------|----------------|-----------|-----------|
| 定位 | 距顶部状态栏（Status Bar）bottom **8px** | **4pt** | 精确约束值 |
| 容器高度（通知类/营销类/优惠券-无标签） | **120px** | **60pt** | 由 `contentType` + `variant` 决定 |
| 容器高度（优惠券-有标签） | **132px** | **66pt** | 顶部 padding 增至 20px（+12px）供标签占位 |
| 容器高度（商品类-无标签） | **152px** | **76pt** | — |
| 容器高度（商品类-有标签） | **164px** | **82pt** | 顶部额外 +12px 供标签占位 |
| 容器宽度 | 屏幕宽度 - 左右各 **48px** 边距 | 左右各 **24pt** | `spacing-l` |
| 容器定位偏移 | `top: 40px; left: 48px` | top 20pt, left 24pt | — |
| 外圆角 | **24px** | **12pt**（四级圆角） | `radius-m`（`radius-semantic.md`） |
| 容器内边距（营销类 standard / 通用） | `padding: 0px 24px 0px 24px` | 上下 0，左右各 12pt | `spacing-l`（左右对称） |
| 容器内边距（营销类 expanded） | `padding: 0px 24px 0px 12px` | 上下 0，右 12pt，**左 6pt**（图片距左边界 12px） | 左侧缩进以使图片紧贴边界 |
| 容器内边距（商品类-有大图，前一版代码） | `padding: 0px 24px 0px 0px` | 上下 0，右 12pt，左 0（大图区自带间距） | — |
| 容器内边距（商品类-无标签） | `padding: 24px`（四周均等） | 上下左右各 12pt | `spacing-l` |
| 容器内边距（商品类-有标签） | `padding: 36px 24px 24px 24px` | 上 18pt，下左右各 12pt（顶部留标签空间） | — |
| 容器内边距（优惠券类，无左边距） | `padding: 0px 24px 0px 0px` | 上下 0，右 12pt，左 0（左侧价格区自带 32px 内边距） | — |
| 左侧图标区尺寸（通知类 / 营销类 standard） | **72×72px**，圆角 **12px** | **36×36pt**，圆角 **6pt** | — |
| 左侧图片区尺寸（营销类 expanded） | **180×96px**，圆角 **12px**，`object-fit: cover` | **90×48pt**，圆角 **6pt** | 横向宽幅图片，❌ 禁止拉伸 |
| 左侧图标区尺寸（商品类） | **104×104px**，圆角 **12px** | **52×52pt**，圆角 **6pt** | — |
| 图标与文字区间距 | `column-gap: 20px` | **10pt** | — |
| 文字区内边距 | `padding: 22px 0px 24px 0px` | top 11pt, bottom 12pt | — |
| 标题行高度 | **40px**，`column-gap: 24px` | 20pt 行高，12pt 间距 | — |
| 描述行高度 | **32px**，`column-gap: 24px` | 16pt 行高，12pt 间距 | — |
| 标题与描述间距 | `row-gap: 2px` | **1pt** | `spacing-3xs` |
| 标题文字 | `font-size: 28px; line-height: 40px; font-weight: 500; color: #111111` | 14pt / 20pt 行高 / Medium | `body-l-14-medium`（`font-semantic.md`） |
| 时间文字（通知类） | `font-size: 24px; line-height: 32px; font-weight: 400; color: #888888` | 12pt / 16pt 行高 / Regular | `body-s-12-regular`（`font-semantic.md`）；color: `text-tertiary`（#888888） |
| 时间文字定位（通知类） | `position: absolute; right: 24px; top: 26px` | right 12pt，top 13pt | 相对容器绝对定位 |
| 跳转箭头图标（通知类） | `icon-iconfont-right-line-regular`，`font-size: 20px; color: #888888` | 10pt，`text-tertiary` | iconfont，❌ 禁止 SVG |
| 跳转箭头定位（通知类） | `position: absolute; right: 20px; bottom: 30px` | right 10pt，bottom 15pt | 相对容器绝对定位 |
| 副标题/描述文字 | `font-size: 24px; line-height: 32px; font-weight: 400; color: #555555` | 12pt / 16pt 行高 / Regular | `body-s-12-regular`（`font-semantic.md`）；color: `text-secondary`（#555555） |
| 商品类标签尺寸 | **104×32px** | **52×16pt** | — |
| 商品类标签圆角 | `border-radius: 24px 0px 16px 0px`（左上大/右上无/右下中/左下无） | 12pt / 0 / 8pt / 0 | 异形圆角：`cr-12` / `cr-0` / `cr-8` / `cr-0`（`component-radius.md`） |
| 商品类标签内边距 | `padding: 2px 12px 2px 12px` | 上下 1pt，左右 6pt | `cs-1` / `cs-6`（`component-spacing.md`） |
| 商品类标签背景 | `#FF2D19` | — | `red-default`（`color-semantic.md`） |
| 商品类标签文字 | `font-size: 20px; line-height: 28px; font-weight: 400; color: #FFFFFF` | 10pt / 14pt 行高 / Regular | `caption-s-10-regular`（`font-semantic.md`） |
| 标签文字（通用） | 20px，高度 16pt | — | `caption-s-10-regular`（`font-semantic.md`） |
| 操作按钮尺寸 | `height: 48px; min-width: 96px`（**宽度自适应，由内容撑开**） | 高 24pt，min-width 48pt | — |
| 操作按钮圆角 | `border-radius: 24px` | **12pt** | `radius-m`（`radius-semantic.md`） |
| 操作按钮内边距 | `padding: 7px 20px 7px 20px` | 上下 3.5pt，**左右各 10pt** | `cs-3.5` / `cs-10`（`component-spacing.md`） |
| 操作按钮文字 | `font-size: 24px; line-height: 32px; font-weight: 500; color: #111111` | 12pt / 16pt 行高 / Medium / 居中 | `body-s-12-medium`（`font-semantic.md`） |
| 操作按钮背景（营销类默认） | `linear-gradient(135deg, #FFE74D 0%, #FFDD00 100%)` | 黄色渐变 | 业务品牌色，可定制 |
| 阴影 | `box-shadow: 0px 8px 32px 0px rgba(0,0,0,0.12)` | — | `shadow-overlay`（`shadow-semantic.md`） |
| 容器背景 | `#FFFFFF` | — | `white`（`color-semantic.md`） |

> ⚠️ 以上属性**不允许业务方自行调整**，如有特殊需求需与设计系统团队沟通。

---

## 4. 布局结构（Slots）

```
[ 左侧内容区 ] + [ 中间文字区 ] + [ 右侧操作区（可选） ]
```

### 4.0 DOM 层级树（基于 2倍图代码）

#### 通知类（`notification`）

```
.component                          // 容器：702×120px，padding: 0 24px 0 24px，column-gap: 20px，position: relative
├── .frame                          // 左侧图标区：72×72px，border-radius: 12px，flex-shrink: 0，overflow: hidden
├── .frame-1                        // 右侧文字区：flex-grow: 1，flex-direction: column，padding: 22px 0 24px 0，row-gap: 2px
│   ├── .text                       // 主标题：28px/40px，Medium，#111111，单行省略溢出
│   └── .text-1                     // 描述文字：24px/32px，Regular，#555555（text-secondary）
├── .time                           // 时间文案：position: absolute; right: 24px; top: 26px
│                                   //           24px/32px，Regular，#888888（text-tertiary），white-space: nowrap
└── .arrow                          // 跳转箭头：position: absolute; right: 20px; bottom: 30px
                                    //           icon-iconfont-right-line-regular，font-size: 20px，color: #888888（text-tertiary）
```

#### 营销类（`marketing`）— standard（常规内容）

```
.component                          // 容器：702×120px，padding: 0 24px 0 24px，column-gap: 20px
├── .frame                          // 左侧图标区：72×72px，border-radius: 12px，flex-shrink: 0，overflow: hidden
└── .frame-1                        // 右侧内容区（文字+按钮）：flex-grow: 1，flex-direction: row，column-gap: 24px
    ├── .frame-2                    // 文字列：flex-grow: 1，flex-direction: column，padding: 22px 0 24px 0，row-gap: 2px
    │   ├── .text                   // 主标题：28px/40px，Medium，#111111，单行省略溢出
    │   └── .text-1                 // 描述文字：24px/32px，Regular，#555555
    └── .instance                   // 操作按钮：117×48px，min-width: 96px，border-radius: 24px，flex-shrink: 0
        └── .text-2                 // 按钮文字：24px/32px，Medium，#111111，居中
```

#### 营销类（`marketing`）— expanded（自定义图片内容）

```
.component                          // 容器：702×120px，padding: 0 24px 0 12px，column-gap: 20px，background: #FFFFFF
├── .frame                          // 左侧图片区：180×96px，border-radius: 12px，flex-shrink: 0，overflow: hidden
│   └── img                         // 占位图：width:180px; height:96px; object-fit:cover; display:block
└── .frame-1                        // 右侧内容区（文字+按钮）：flex-grow: 1，flex-direction: row，column-gap: 24px
    ├── .frame-2                    // 文字列：flex-grow: 1，flex-direction: column，padding: 22px 0 24px 0，row-gap: 2px
    │   ├── .text                   // 主标题：28px/40px，Medium，#111111，单行省略溢出
    │   └── .text-1                 // 描述文字：24px/32px，Regular，#555555
    └── .instance                   // 操作按钮：height: 48px，min-width: 96px，padding: 7px 20px，border-radius: 24px，flex-shrink: 0
        └── .text-2                 // 按钮文字：24px/32px，Medium，#111111，居中
```

#### 商品类（`product`）— 无标签变体（`no-tag`）

```
.component                          // 容器：702×152px，padding: 24px（四周均等），column-gap: 20px
├── .frame                          // 左侧图标区：104×104px，border-radius: 12px，flex-shrink: 0
└── .frame-1                        // 右侧内容区（文字+按钮）：flex-grow: 1，flex-direction: row，justify-content: end
    ├── .frame-2                    // 文字列：flex-grow: 1，flex-direction: column，padding: 10px 0 4px 0，column-gap: -2px
    │   ├── .text                   // 主标题：28px/40px，Medium，#111111，单行省略溢出
    │   └── .frame-3                // 价格行：height: 52px，flex-direction: row，column-gap: 8px
    │       ├── .instance           // 价格主体：91×52px，flex-direction: row，column-gap: 2px
    │       │   ├── .text-          // "¥"符号：15×32px，24px/32px，Bold，#FF2D19，MT New Digital Display，margin-top: 14px（相对整数顶部下沉 14px）
    │       │   └── .frame-4        // 数字区：74×52px，flex-direction: row，align-items: start
    │       │       ├── .text-72    // 整数部分：40×52px，36px/52px，Bold，#FF2D19，MT New Digital Display
    │       │       └── .text-88    // 小数部分：34×32px，24px/32px，Bold，#FF2D19，MT New Digital Display，margin-top: 14px（相对整数顶部下沉 14px）
    │       └── .frame-5            // 划线价区：74×52px，flex-direction: column，padding: 14px 0 6px 0
    │           └── .text-1         // 划线原价：24px/32px，Regular，#888888，text-decoration: line-through
    └── .frame-6                    // 按钮容器：141×48px，padding: 0 0 0 24px（左间距24px）
        └── .instance-1             // 操作按钮：117×48px，min-width: 96px，border-radius: 24px
            └── .text-2             // 按钮文字：24px/32px，Medium，#111111，居中
```

#### 商品类（`product`）— 有标签变体（`with-tag`）

```
.component-1                        // 容器：702×164px，padding: 36px 24px 24px 24px（顶部留标签位），column-gap: 20px
├── .instance-4                     // 标签：position: absolute，top:0 left:0，104×32px
│   │                               //       border-radius: 24px 0px 16px 0px，background: #FF2D19
│   │                               //       padding: 2px 12px，column-gap: 4px
│   ├── .instance-5                 // 标签图标：24×24px
│   └── .text-6                     // 标签文字：80×28px，20px/28px，Regular，#FFFFFF
├── .frame-7                        // 左侧图标区：104×104px，border-radius: 12px，flex-shrink: 0
└── .frame-8                        // 右侧内容区（文字+按钮）：flex-grow: 1，flex-direction: row，justify-content: end
    ├── .frame-9                    // 文字列：flex-grow: 1，flex-direction: column，padding: 10px 0 4px 0，column-gap: -2px
    │   ├── .text-3                 // 主标题：28px/40px，Medium，#111111，单行省略溢出
    │   └── .frame-10               // 价格行：height: 52px，flex-direction: row，column-gap: 8px（结构同无标签）
    │       ├── .instance-2         // 价格主体：91×52px（¥符号 + 整数 + 小数，同无标签结构）
    │       └── .frame-12           // 划线价区：74×52px，padding: 14px 0 6px 0
    │           └── .text-4         // 划线原价：24px/32px，Regular，#888888，line-through
    └── .frame-13                   // 按钮容器：141×48px，padding: 0 0 0 24px
        └── .instance-3             // 操作按钮：117×48px，min-width: 96px，border-radius: 24px
            └── .text-5             // 按钮文字：24px/32px，Medium，#111111，居中
```

> **说明**：
> - 商品类左侧图标区尺寸为 **104×104px**（52×52pt），比营销/通知类的 72×72px 更大，用于展示商品缩略图。
> - 价格区采用三段独立元素组合：`¥`符号（24px，`margin-top: 14px` 下沉对齐）+ 整数（36px，高52px）+ 小数（24px，`margin-top: 14px` 下沉对齐）+ 划线原价；字体为 `MT New Digital Display`。`¥` 符号与小数通过 `margin-top: 14px` 相对整数顶部下沉，实现视觉上标效果。
> - 有标签变体通过 `position: absolute` 在容器左上角叠加标签元素，容器顶部 padding 从 24px 扩大到 36px 以避免遮挡内容。

#### 优惠券类（`coupon`）— 无标签-金额（`no-tag-amount`）

```
.component                          // 容器：702×120px，padding: 0 24px 0 0，无左内边距（左侧价格区自带间距）
├── .frame                          // 左侧价格区：180×120px，flex-shrink: 0，flex-direction: column，padding: 8px 32px 24px 32px，column-gap: -8px
│   ├── .instance                   // 价格主体：68×64px，flex-direction: row，column-gap: 2px，align-items: start
│   │   ├── .text-                  // "¥"符号：28px/40px，Bold，#FF2D19，MT New Digital Display，align-self: flex-end，margin-bottom: 6px（底对齐后上移 6px）
│   │   └── .frame-1                // 数字区：flex-direction: row，align-items: start
│   │       ├── .text-72            // 整数部分：44px/64px，Bold，#FF2D19，MT New Digital Display
│   │       └── .text-88            // 小数部分：44px/64px，Bold，#FF2D19，MT New Digital Display（visibility: hidden，占位用）
│   └── .text                       // 使用条件文案：116×32px，24px/32px，Regular，#FF2D19，PingFang SC，居中
└── .frame-2                        // 右侧内容区（文字+按钮）：flex-grow: 1，flex-direction: row，column-gap: 24px
    ├── .frame-3                    // 文字列：flex-grow: 1，flex-direction: column，padding: 22px 0 24px 0，row-gap: 2px
    │   ├── .text-1                 // 主标题：28px/40px，Medium，#111111，单行省略溢出
    │   └── .text-2                 // 描述文字：24px/32px，Regular，#555555
    └── .instance-1                 // 操作按钮：117×48px，min-width: 96px，border-radius: 24px
        └── .text-3                 // 按钮文字：24px/32px，Medium，#111111，居中
```

#### 优惠券类（`coupon`）— 有标签-金额（`with-tag-amount`）

```
.component-1                        // 容器：702×132px，padding: 0 24px 0 0（顶部 padding 20px 由左侧价格区控制）
├── .instance-4                     // 标签：position: absolute，top: 0 left: 0，64×32px
│   │                               //       border-radius: 24px 0px 16px 0px，background: #FF2D19
│   │                               //       padding: 2px 12px，column-gap: 4px
│   ├── .instance-5                 // 标签图标：24×24px
│   └── .text-8                     // 标签文字：40×28px，20px/28px，Regular，#FFFFFF
├── .frame-4                        // 左侧价格区：180×132px，flex-shrink: 0，flex-direction: column，padding: 20px 32px 24px 32px，column-gap: -8px
│   ├── .instance-2                 // 价格主体：68×64px（结构同无标签-金额）
│   │   ├── .text--1                // "¥"符号：28px/40px，Bold，#FF2D19，MT New Digital Display，align-self: flex-end，margin-bottom: 6px（底对齐后上移 6px）
│   │   └── .frame-5                // 数字区：flex-direction: row，align-items: start
│   │       ├── .text-73            // 整数部分：44px/64px，Bold，#FF2D19，MT New Digital Display
│   │       └── .text-89            // 小数部分：63×64px（visibility: hidden，占位用）
│   └── .text-4                     // 使用条件文案：116×32px，24px/32px，Regular，#FF2D19，居中
└── .frame-6                        // 右侧内容区（文字+按钮）：flex-grow: 1，flex-direction: row，column-gap: 24px
    ├── .frame-7                    // 文字列：flex-grow: 1，flex-direction: column，padding: 34px 0 24px 0，row-gap: 2px
    │   ├── .text-5                 // 主标题：28px/40px，Medium，#111111，单行省略溢出
    │   └── .text-6                 // 描述文字：24px/32px，Regular，#555555
    └── .instance-3                 // 操作按钮：117×48px，min-width: 96px，border-radius: 24px
        └── .text-7                 // 按钮文字：24px/32px，Medium，#111111，居中
```

#### 优惠券类（`coupon`）— 无标签-折扣（`no-tag-discount`）

```
.component-3                        // 容器：702×120px，padding: 0 24px 0 0
├── .frame-13                       // 左侧价格区：180×120px，flex-shrink: 0，flex-direction: column，padding: 8px 32px 24px 32px，column-gap: -8px
│   ├── .frame-14                   // 折扣数字区：52×64px，flex-direction: row，column-gap: 2px，align-items: center
│   │   ├── .text-16                // 折扣整数：26×64px，44px/64px，Bold，#FF2D19，MT New Digital Display
│   │   └── .frame-15               // 折扣上标区：24×64px，flex-direction: row，padding: 20px 0 12px 0
│   │       └── .text-17            // "折"字：24×32px，24px/32px，SemiBold（font-weight: 600），#FF2D19，PingFang SC
│   └── .text-18                    // 使用条件文案：116×32px，24px/32px，Regular，#FF2D19，居中
└── .frame-16                       // 右侧内容区（文字+按钮）：flex-grow: 1，flex-direction: row，column-gap: 24px
    ├── .frame-17                   // 文字列：flex-grow: 1，flex-direction: column，padding: 22px 0 24px 0，row-gap: 2px
    │   ├── .text-19                // 主标题：28px/40px，Medium，#111111，单行省略溢出
    │   └── .text-20                // 描述文字：24px/32px，Regular，#555555
    └── .instance-9                 // 操作按钮：117×48px，min-width: 96px，border-radius: 24px
        └── .text-21                // 按钮文字：24px/32px，Medium，#111111，居中
```

#### 优惠券类（`coupon`）— 有标签-折扣（`with-tag-discount`）

```
.component-2                        // 容器：702×132px，padding: 0 24px 0 0
├── .instance-7                     // 标签：position: absolute，top: 0 left: 0，64×32px
│   │                               //       border-radius: 24px 0px 16px 0px，background: #FF2D19
│   │                               //       padding: 2px 12px，column-gap: 4px
│   ├── .instance-8                 // 标签图标：24×24px
│   └── .text-15                    // 标签文字：40×28px，20px/28px，Regular，#FFFFFF
├── .frame-8                        // 左侧价格区：180×132px，flex-shrink: 0，flex-direction: column，padding: 20px 32px 24px 32px，column-gap: -8px
│   ├── .frame-9                    // 折扣数字区：52×64px（结构同无标签-折扣）
│   │   ├── .text-9                 // 折扣整数：26×64px，44px/64px，Bold，#FF2D19，MT New Digital Display
│   │   └── .frame-10               // 折扣上标区：24×64px，padding: 20px 0 12px 0
│   │       └── .text-10            // "折"字：24×32px，24px/32px，SemiBold，#FF2D19，PingFang SC
│   └── .text-11                    // 使用条件文案：116×32px，24px/32px，Regular，#FF2D19，居中
└── .frame-11                       // 右侧内容区（文字+按钮）：flex-grow: 1，flex-direction: row，column-gap: 24px
    ├── .frame-12                   // 文字列：flex-grow: 1，flex-direction: column，padding: 34px 0 24px 0，row-gap: 2px
    │   ├── .text-12                // 主标题：28px/40px，Medium，#111111，单行省略溢出
    │   └── .text-13                // 描述文字：24px/32px，Regular，#555555
    └── .instance-6                 // 操作按钮：117×48px，min-width: 96px，border-radius: 24px
        └── .text-14                // 按钮文字：24px/32px，Medium，#111111，居中
```

> **优惠券类结构说明**：
> - 左侧价格区（`.frame`）宽度固定为 **180px（90pt）**，包含左右各 32px 内边距（16pt），使内容区宽 116px（58pt）。
> - 无标签变体左侧区顶部 padding 为 **8px（4pt）**，有标签变体为 **20px（10pt）**，增量 12px 为标签层叠区域预留。
> - **金额型**价格结构：`¥`符号（**28px/40px**，MT New Digital Display，`price-28-bold`，`align-self: flex-end` + `margin-bottom: 6px` 实现底部与整数对齐后再上移 6px）+ 整数（44px/64px，MT New Digital Display）；小数部分（`.text-88`/`.text-89`）设 `visibility: hidden`，为可能存在的小数占位，不展示时仍占据空间。
> - **折扣型**价格结构：整数（44px，MT New Digital Display）+ "折"字（24px SemiBold，PingFang SC），"折"字通过顶部 padding（20px）实现上标位置效果。
> - 优惠券类标签尺寸（64×32px）比商品类标签（104×32px）更小，但圆角形状相同（`24px 0px 16px 0px`）。
> - 右侧文字列有标签变体顶部 padding 从 22px 增加到 **34px（+12px）**，配合容器高度的增加保持内容垂直居中对齐。

| slot | data-slot 值 | 说明 |
|------|-------------|------|
| `icon` | `"nb-icon"` | 左侧图标/商品图/价格区，尺寸随类型变化 |
| `tag` | `"nb-tag"` | 营销/商品/优惠券标签（可选，有标签变体时出现） |
| `title` | `"nb-title"` | 主标题，建议**不超过一行** |
| `description` | `"nb-description"` | 副标题/描述，建议**不超过两行** |
| `time` | `"nb-time"` | 时间信息（仅通知类展示，如"刚刚"） |
| `action` | `"nb-action"` | 右侧操作按钮（可选） |

### 4.1 各类型左侧区域说明

| contentType | 左侧内容 | 容器尺寸（2倍图） | 换算 pt |
|-------------|---------|----------------|--------|
| `notification` | App icon 或系统图标，搭配时间戳；图标区为正方形 | 72×72px，圆角 12px | 36×36pt，圆角 6pt |
| `marketing` | 自定义图标/插画，正方形固定区域，内容居中 | 72×72px，圆角 12px | 36×36pt，圆角 6pt |
| `product` | 商品缩略图/图标，正方形区域，`overflow: hidden` | **104×104px**，圆角 12px | **52×52pt**，圆角 6pt |
| `coupon` | 大号价格数字（金额型：¥+整数；折扣型：整数+折） + 条件文案（如"满200可用"）；文字颜色固定为 `#FF2D19` | 宽 **180px**，等高容器；内边距 `32px 32px`（左右各 16pt），内容宽 116px | 宽 **90pt**，随容器等高 |

---

## 5. 交互规则

| 阶段 | 行为 | 说明 |
|------|------|------|
| 触发 | 系统自动弹出 | 根据推送内容定义触发条件；系统希望引导用户进行某操作时自动出现 |
| 出现 | 从页面顶部向下滑入 | 位于页面顶层，在所有信息上层显示；动效参考动效规范 |
| 点击（跳转类） | 点击横幅或按钮，跳转相关页面 | — |
| 点击（纯展示类） | 点击后无任何交互 | — |
| 向上滑动 | 用户上滑，横幅关闭 | — |
| 停留后消失 | 停留 **3 秒**内无任何交互，横幅向上位移并消失 | 消失动效与出现方向相反 |

---

## 6. 屏幕适配规则

| 屏幕类型 | 适配说明 |
|---------|---------|
| 非刘海屏 | 距状态栏 **4pt**；左右距屏幕边缘 **12pt** |
| 刘海屏 | 距刘海底部 **4pt**；左右距屏幕边缘 **12pt** |
| 挖孔屏（灵动岛）| 距挖孔区域底部 **4pt**；左右距屏幕边缘 **12pt** |

> 各机型状态栏高度不同，**4pt 间距从对应机型 Status Bar 底部开始计算**。

---

## 7. Token 引用

### 7.1 颜色 Token

| 用途 | Token 名称 | hex 值 | 语义层来源 |
|------|-----------|--------|-----------|
| 容器背景 | `white` | `#FFFFFF` | `color-semantic.md` §三 Background Color |
| 标题文字 | `text-primary` | `#111111` | `color-semantic.md` §二 Text Color |
| 描述文字 | `text-secondary` | `#555555` | `color-semantic.md` §二 Text Color |
| 时间文字（通知类） | `text-tertiary` | `#888888` | `color-semantic.md` §二 Text Color |
| 营销类按钮背景（黄色渐变，默认） | — | `linear-gradient(135deg, #FFE74D 0%, #FFDD00 100%)` | 业务品牌色，可定制 |
| 营销类其他品牌色背景 | `gradient-red` / `gradient-orange` / `gradient-yellow` 等 | — | `color-semantic.md` §八 Gradient Color |
| 价格文字（商品类，¥符号+整数+小数） | `red-default` | `#FF2D19` | `color-semantic.md` §七 Functional Color |
| 价格文字（优惠券类，¥符号+整数+折扣数字） | `red-default` | `#FF2D19` | `color-semantic.md` §七 Functional Color |
| 使用条件文案（优惠券类，如"满200可用"） | `red-default` | `#FF2D19` | `color-semantic.md` §七 Functional Color |
| 划线原价文字（商品类） | `text-tertiary` | `#888888` | `color-semantic.md` §二 Text Color |
| 优惠券类标签背景 | `red-default` | `#FF2D19` | `color-semantic.md` §七 Functional Color |
| 优惠券类标签文字 | `white` | `#FFFFFF` | `color-semantic.md` §一 Neutral Color |
| 商品类标签背景 | `red-default` | `#FF2D19` | `color-semantic.md` §七 Functional Color |
| 商品类标签文字 | `white` | `#FFFFFF` | `color-semantic.md` §一 Neutral Color |
| 标签背景（营销类） | `red-default` / `orange-default` 等 | — | `color-semantic.md` §七 Functional Color |
| 标签文字（营销类） | `white` | `#FFFFFF` | `color-semantic.md` §一 Neutral Color |

### 7.2 字体 Token

| 元素 | Token 名称 | 语义层来源 |
|------|-----------|-----------|
| 主标题（28px / **14pt**，Medium） | `body-l-14-medium` | `font-semantic.md` §一 Body；@2x 实际渲染：28px/40px，Medium |
| 描述/副标题（24px / **12pt**，Regular） | `body-s-12-regular` | `font-semantic.md` §一 Body；@2x 实际渲染：24px/32px，Regular |
| 时间文字（24px / **12pt**，Regular） | `body-s-12-regular` | `font-semantic.md` §一 Body；@2x 实际渲染：24px/32px，Regular |
| 操作按钮文字（24px / **12pt**，Medium） | `body-s-12-medium` | `font-semantic.md` §一 Body；@2x 实际渲染：24px/32px，Medium |
| 标签文字（20px / **10pt**，Regular） | `caption-s-10-regular` | `font-semantic.md` §一 Caption；@2x 实际渲染：20px/28px，Regular |
| 价格整数（36px / **18pt**，Bold，商品类） | `price-18-bold` | `font-semantic.md` §三 Price Font；字体：MT New Digital Display；颜色：`#FF2D19` |
| 价格符号"¥"（24px / **12pt**，Bold，商品类） | `price-12-bold` | `font-semantic.md` §三 Price Font；字体：MT New Digital Display；颜色：`#FF2D19`；**`margin-top: 14px`**（相对整数顶部下沉 14px） |
| 价格小数（24px / **12pt**，Bold，商品类） | `price-12-bold` | `font-semantic.md` §三 Price Font；字体：MT New Digital Display；颜色：`#FF2D19`；**`margin-top: 14px`**（相对整数顶部下沉 14px） |
| 划线原价（24px / **12pt**，Regular，商品类） | `body-s-12-regular` | `font-semantic.md` §一 Body；颜色：`#888888`（text-tertiary）；`text-decoration: line-through` |
| 价格符号"¥"（28px / **14pt**，Bold，优惠券类-金额型） | `price-14-bold` | `font-semantic.md` §三 Price Font；字体：MT New Digital Display；颜色：`#FF2D19`；`align-self: flex-end` + **`margin-bottom: 6px`**，底对齐后上移 6px |
| 价格整数（44px / **22pt**，Bold，优惠券类-金额型） | `price-22-bold` | `font-semantic.md` §三 Price Font；字体：MT New Digital Display；@2x 规格：44px/64px，高度64px；颜色：`#FF2D19` |
| 折扣整数（44px / **22pt**，Bold，优惠券类-折扣型） | `price-22-bold` | `font-semantic.md` §三 Price Font；字体：MT New Digital Display；@2x 大小26×64px；颜色：`#FF2D19` |
| "折"字（24px / **12pt**，SemiBold，优惠券类-折扣型） | `body-s-12-semibold` | `font-semantic.md` §一 Body；字体：PingFang SC；font-weight: 600；大小24px/32px；通过顶部padding(20px)实现上标位置；颜色：`#FF2D19` |
| 使用条件文案（24px / **12pt**，Regular，优惠券类） | `body-s-12-regular` | `font-semantic.md` §一 Body；字体：PingFang SC；颜色：`#FF2D19`；展示在价格下方，居中 |

### 7.3 间距 Token

| 用途 | Token 名称 | 值（2倍图 px） | 换算 pt | 语义层来源 |
|------|-----------|--------------|---------|-----------|
| 横幅距屏幕左右边缘 | `spacing-l` | 48px | 12pt×2 | `spacing-semantic.md` |
| 容器左右内边距（营销类/通用） | `spacing-l` | 24px | 12pt（左右对称） | `spacing-semantic.md` |
| 容器右内边距（商品类/优惠券类，左侧无内边距） | `spacing-l` | 24px（仅右侧） | 12pt | `spacing-semantic.md` |
| 左侧 icon 区与右侧内容区间距（column-gap） | `cs-10` | 20px | 10pt | `component-spacing.md` |
| 文字列与操作按钮间距（column-gap） | `spacing-l` | 24px | 12pt | `spacing-semantic.md` |
| 文字列上内边距（营销/通知类） | `cs-11` | 22px | 11pt | `component-spacing.md` |
| 文字列下内边距（营销/通知类） | `spacing-l` | 24px | 12pt | `spacing-semantic.md` |
| 文字列上内边距（商品类） | `cs-5` | 10px | 5pt | `component-spacing.md` |
| 文字列下内边距（商品类） | `cs-2` | 4px | 2pt | `component-spacing.md` |
| 价格符号与数字区间距（column-gap） | `cs-1` | 2px | 1pt | `component-spacing.md` |
| 价格主体与划线价间距（column-gap） | `cs-4` | 8px | 4pt | `component-spacing.md` |
| 划线价区上内边距 | `cs-7` | 14px | 7pt | `component-spacing.md` |
| 划线价区下内边距 | `cs-3` | 6px | 3pt | `component-spacing.md` |
| 按钮容器左内边距（与文字列间距） | `spacing-l` | 24px | 12pt | `spacing-semantic.md` |
| 商品类标签图标与文字间距（column-gap） | `cs-2` | 4px | 2pt | `component-spacing.md` |
| 标题与描述行间距（row-gap） | `spacing-3xs` | 2px | 1pt | `spacing-semantic.md` |
| 操作按钮左右内边距 | `cs-10` | 20px | 10pt | `component-spacing.md` |
| 操作按钮上下内边距 | `cs-3.5` | 7px | 3.5pt | `component-spacing.md` |
| 商品类大图容器与图片本体间距（四周） | `cs-6` | 12px | 6pt | `component-spacing.md` |
| 优惠券类左侧价格区左右内边距 | `cs-16` | 32px（左右各 16pt） | 16pt | `component-spacing.md` |
| 优惠券类左侧价格区顶部内边距（无标签） | `cs-4` | 8px | 4pt | `component-spacing.md` |
| 优惠券类左侧价格区顶部内边距（有标签） | `cs-10` | 20px | 10pt | `component-spacing.md` |
| 优惠券类左侧价格区底部内边距 | `spacing-l` | 24px | 12pt | `spacing-semantic.md` |
| 优惠券类价格区元素间距（column-gap） | `cs-1` | 2px | 1pt | `component-spacing.md` |
| 优惠券类价格区内容行间距（column-gap: -8px，重叠） | — | -8px | — | 负值特殊处理，价格与条件文案视觉贴合效果，不引用 Token |
| 优惠券类"折"字上标区顶部padding | `cs-10` | 20px | 10pt | `component-spacing.md` |
| 优惠券类"折"字上标区底部padding | `cs-6` | 12px | 6pt | `component-spacing.md` |
| 优惠券类标签图标与文字间距（column-gap） | `cs-2` | 4px | 2pt | `component-spacing.md` |
| 文字列上内边距（优惠券-有标签） | `cs-17` | 34px | 17pt | `component-spacing.md` |

### 7.4 圆角 Token

| 用途 | Token 名称 | 值（2倍图 px） | 换算 pt | 语义层来源 |
|------|-----------|--------------|---------|-----------|
| 容器外圆角 | `radius-m` | 24px | 12pt | `radius-semantic.md` |
| 左侧图标区圆角（通知/营销/商品类） | `radius-xs` | 12px | 6pt | `radius-semantic.md` |
| 商品类/优惠券类标签圆角（异形，左上/右上/右下/左下） | `cr-12` / `cr-0` / `cr-8` / `cr-0` | `24px 0px 16px 0px` | `12pt 0 8pt 0` | `component-radius.md`；商品类标签（104×32px）和优惠券类标签（64×32px）均使用此形状 |
| 标签圆角（营销类，普通） | `cr-4`（同 `radius-xxs`） | 8px | 4pt | `component-radius.md`（`cr-4` 与 `radius-xxs` 数值相同，组件层统一引用 `cr-4`） |

---

## 8. Props API（供 AI 生码参考）

```typescript
export type NotificationBannerProps = {
  /**
   * 内容类型
   */
  contentType: "notification" | "marketing" | "product" | "coupon";

  /**
   * 子变体（不同 contentType 有不同值）
   * - marketing: "standard" | "expanded"
   * - product: "no-tag" | "with-tag"
   * - coupon: "no-tag-amount" | "no-tag-discount" | "with-tag-amount" | "with-tag-discount"
   * - notification: 无子变体，可省略
   */
  variant?:
    | "standard"
    | "expanded"
    | "no-tag"
    | "with-tag"
    | "no-tag-amount"
    | "no-tag-discount"
    | "with-tag-amount"
    | "with-tag-discount";

  /**
   * 主标题
   */
  title: string;

  /**
   * 副标题/描述（建议不超过两行）
   */
  description?: string;

  /**
   * 时间信息（仅 notification 类型展示）
   */
  time?: string;

  /**
   * 左侧图标/插图节点（notification/marketing 类型）
   */
  icon?: React.ReactNode;

  /**
   * 商品图片 URL（product 类型）
   */
  productImage?: string;

  /**
   * 价格展示内容（product/coupon 类型）
   */
  price?: {
    /** 价格整数/折扣数字（如 "72" 或 "8"） */
    value: string;
    /** 单位（"¥" 或 "折"） */
    unit: string;
    /** 价格小数（如 ".88"，product 类型） */
    decimal?: string;
    /** 划线原价（如 "¥13.88"，product 类型） */
    originalPrice?: string;
    /** 使用条件（如 "满200可用"，coupon 类型） */
    condition?: string;
  };

  /**
   * 标签内容（product/coupon/marketing 类型有标签变体）
   */
  tag?: string;

  /**
   * 操作按钮（可选）
   */
  action?: {
    label: string;
    onClick: () => void;
  };

  /**
   * 整体点击回调（纯展示类可不传）
   */
  onClick?: () => void;

  /**
   * 自动消失时长（毫秒，默认 3000）
   * @default 3000
   */
  duration?: number;

  /**
   * 关闭回调
   */
  onClose?: () => void;
};
```

---

## 9. data-attribute 规范

| 属性 | 值 | 说明 |
|------|----|------|
| `data-slot` | `"notification-banner"` | 全局稳定标识 |
| `data-content-type` | `"notification"` / `"marketing"` / `"product"` / `"coupon"` | 当前内容类型 |
| `data-variant` | 对应 variant 值 | 当前子变体 |
| `data-visible` | `"true"` / `"false"` | 展示/隐藏状态 |

---

## 10. 无障碍（Accessibility）

- 容器使用 `role="alert"` 或 `aria-live="polite"`，确保屏幕阅读器能即时读出内容
- 操作按钮使用语义化 `<button>` 元素，包含明确的 `aria-label`
- 横幅消失时通知无障碍工具（如通过 `aria-live` 区域更新）
- 点击区域高度 ≥ 20pt（对应五级按钮规格）

---

## 11. 使用约束（AI 生成时的硬性规则）

1. **禁止跨类型混用内容**：`coupon` 类型不展示商品图，`product` 类型不展示优惠券大数字
2. **标题不超过一行，描述不超过两行**：超出用省略号截断，不允许自动换行撑高容器
3. **禁止自定义容器高度**：高度由 `contentType` + `variant` 组合决定（见 §2），不可自定义
4. **标签慎用**：有标签变体会增加整体高度，非必要不使用
5. **禁止直接写 hex 颜色**：颜色必须使用 §7.1 中的 Token 名称
6. **营销类品牌色定制**：只有 `marketing` 类型允许自定义背景色/文字色/按钮色，其他类型使用系统默认色
7. **层级**：横幅始终位于页面顶层（`z-index` 最高），不受页面内容遮挡
8. **强提示警示**：顶部横幅属于系统强提示，可能打断用户操作，需**谨慎使用**
   - **形式过强**：若信息不具时效性或重要性低，避免使用，改用底部横幅（Snackbar）或通告栏（Notice Bar）
   - **信息重复**：若用户在当前页面已能获取同等信息，避免再次推送
   - **场景冲突**：若页面内已有弹窗等其他提示，需考虑优先级，同一时刻**只保留一个**或按顺序展示

---

## 12. 与其他组件的关系

| 关联组件 | 关系说明 |
|----------|----------|
| `button.md` | 横幅内操作按钮使用 Button 组件 size=`xs`（五级按钮） |
| `snackbar.md` | 底部横幅；打扰性更低，适合非时效性/低重要性信息 |
| `notice-bar.md` | 通告栏；常驻展示，无自动消失，适合持续性系统公告 |
| `toast.md` | Toast；居中/底部短暂提示，无交互操作，信息量更少 |
| `dialog.md` | 弹窗；需用户主动确认操作，打扰性最高；与 Notification Banner 互斥，不同时出现 |

---

## 13. 常见组合示例

### 13.1 IM 通知类

```
NotificationBanner
  contentType: notification
  title: "现金奖励通知"
  description: "0.42 元已经打款至微信，请查收"
  time: "刚刚"
  icon: <img src={appIconUrl} alt="应用图标" width={40} height={40} />  {/* IM 通知左侧为 App 头像图片，非 iconfont */}
  action: { label: "查看", onClick: ... }
  duration: 3000
```

### 13.2 营销活动类（常规）

```
NotificationBanner
  contentType: marketing
  variant: standard
  title: "限时红包活动"
  description: "领取后立即可用，今天 20:00 截止"
  icon: <img src={redPacketImgUrl} alt="红包" width={48} height={48} />  {/* 营销插图为业务图片，非 iconfont */}
  action: { label: "立即领取", onClick: ... }
```

### 13.3 商品促销类（有标签）

```
NotificationBanner
  contentType: product
  variant: with-tag
  title: "商品名称商品名称商品名称"
  tag: "营销标签"
  productImage: "https://..."
  price: { value: "72", unit: "¥", decimal: ".88", originalPrice: "¥13.88" }
  action: { label: "抢购", onClick: ... }
```

### 13.4 优惠券类（有标签-金额）

```
NotificationBanner
  contentType: coupon
  variant: with-tag-amount
  title: "这是一行标题"
  description: "这是一段描述内容"
  tag: "标签"
  price: { value: "72", unit: "¥", condition: "满200可用" }
  action: { label: "立即使用", onClick: ... }
```

### 13.5 优惠券类（无标签-折扣）

```
NotificationBanner
  contentType: coupon
  variant: no-tag-discount
  title: "这是一行标题"
  description: "这是一段描述内容"
  price: { value: "8", unit: "折", condition: "满100可用" }
  action: { label: "立即使用", onClick: ... }
```
