# Image Selection & Upload 图像选择与上传

> **组件分类**：Component（组件级）
> **定义**：图像选择与上传组件系列，用于用户在应用中**从相册选择图片/视频**或**拍照**，以及**上传图片/视频**后的卡片状态展示。分为两大使用场景：
> - **图像选择**（Image Selection）：在系统相册选图时展示的缩略格组件，含选中标记、拍照入口
> - **图像上传**（Image    Upload）：用户触发上传后，展示上传状态（默认/按下/上传中/成功/失败）的卡片组件
> **Style 依赖**：`color-semantic.md` · `font-semantic.md` · `spacing-semantic.md` · `component-spacing.md` · `radius-semantic.md` · `component-radius.md` · `stroke-semantic.md`

> ⚠️ **核心约束**：
> - **图像选择格**尺寸固定 **182×182px @2x**（91×91pt @1x）；**预览格**固定 **108×108px @2x**（54×54pt @1x）
> - **上传卡片**通用尺寸 **156×156px @2x**（78×78pt @1x）；**证件型**尺寸 **336×220px @2x**（168×110pt @1x）
> - 所有卡片圆角统一 **12px @2x / 6pt @1x**（`radius-xs`，见 `radius-semantic.md`）
> - 上传失败/上传中状态使用深色蒙层覆盖（`#000000CC`，80%黑）

---

## 0. 图标 / 间距 / Ownership 约束

- **icon-route（默认）**：本组件内功能图标默认回 `component/atoms/icon.md`，并沿用本文件已声明的 iconfont class / weight。
- **fixed-asset 例外**：若正文已指定 `assets/*.svg`、官方 SVG、PNG/CDN 切图、URL 尖角资源或固定插画，该位点必须走固定资产，不得强行回 iconfont；输出时可标注 `icon-route=fixed-asset`。
- **spacing-owner（归属）**：组件内部 slot、行内/容器内 gap、padding、对齐归本组件；页面边距、吸顶/吸底占位、列表外层留白归宿主。
- **宿主裁决（优先级）**：冲突遵循 `宿主 > 组合场景 > 本组件通用规则`，子组件仅拥有自身内部样式，不反向改宿主排布。
- **不可跳步**：先回 `references/INDEX.md` 完成区域路由与宿主锁定，再用 `component-quickref.md` 做宿主级收敛；本文件仅承接组件内 ownership 细则，不承担前置路由改判；不得凭语义猜测。

## 1. 子组件概览

| 子组件 | 英文名 | 尺寸（@2x） | 变体数 | 用途 |
|--------|--------|-----------|-------|------|
| 图像选择 | `MediaPickerCell` | 182×182px | 10 | 相册选图时的缩略图格，含选中状态、拍照入口 |
| 图像选择预览 | `MediaPickerPreview` | 108×108px | 4 | 已选中图片/视频的预览缩略格（发布前确认区） |
| 图像上传 | `ImageUpload` | 156×156px | 6 | 图片上传的触发入口卡片（含数量提示） |
| 视频上传 | `VideoUpload` | 156×156px | 5 | 视频上传的触发入口卡片 |
| 图片上传/常规型 | `ImageUploadCard` | 156×156px | 8 | 上传成功后的图片卡片（含覆盖删除按钮） |
| 图片上传/证件型 | `IdCardUpload` | 336×220px | 6 | 证件（身份证/护照等）专用上传卡片 |
| 图片上传/证件型/自定义 | `IdCardUploadCustom` | 336×220px | 1 | 证件型自定义图片内容 |

---

## 2. 图像选择（MediaPickerCell）

### 2.1 变体维度

| 维度 | 属性名 | 可选值 | 说明 |
|------|--------|--------|------|
| 媒体类型 | `mediaType` | `photo`（图片）、`video`（视频）、`camera-dark`（拍照-深色底）、`camera-light`（拍照-浅色底） | 格子展示的内容类型 |
| 选中状态 | `selected` | `off`（未选中）、`on`（选中） | 是否处于选中状态 |
| 选中类型 | `selectionType` | `default`（默认，仅用于 off 状态）、`number`（数字序号）、`check`（勾选） | 选中标记的样式 |
| 禁用状态 | `disabled` | `off`（可用）、`on`（禁用） | 是否禁用该格子 |

> **约束**：`selectionType` 仅在 `selected=on` 时生效；`selected=off` 时 `selectionType` 固定为 `default`

### 2.2 完整变体矩阵

| mediaType | selected | selectionType | disabled | 外观描述 |
|-----------|----------|---------------|----------|----------|
| `photo` | `off` | `default` | `off` | 普通图片缩略图，右上角选择圆（1pt `#FFFFFF` 描边，15% 白色填充 `rgba(255,255,255,0.15)`） |
| `photo` | `off` | `default` | `on` | 普通图片缩略图，整体叠加 30% 白色蒙层（禁用），右上角禁用状选择圆（1pt `#FFFFFF` 描边，30% 白色填充 `rgba(255,255,255,0.3)`） |
| `photo` | `on` | `number` | `off` | 图片选中，叠加 30% 黑色蒙层，右上角显示**数字序号**（黄色填充圆，黑字，**1pt 白色描边**） |
| `photo` | `on` | `check` | `off` | 图片选中，叠加 30% 黑色蒙层，右上角显示**对勾图标**（黄色填充圆，**1pt 白色描边**） |
| `video` | `off` | `default` | `off` | 视频缩略图，底部渐变蒙层（`linear-gradient(180deg, transparent 0%, #000000B2 100%)`），左下角展示时长（白色，24px），右上角选择圆（1pt `#FFFFFF` 描边，15% 白色填充 `rgba(255,255,255,0.15)`） |
| `video` | `on` | `number` | `off` | 视频选中，叠加 30% 黑色蒙层（叠加于渐变蒙层之上），数字序号（**1pt 白色描边**） |
| `video` | `on` | `check` | `off` | 视频选中，叠加 30% 黑色蒙层，对勾图标（黄色填充圆，**1pt 白色描边**） |
| `video` | `off` | `default` | `on` | 视频缩略图，叠加 30% 白色蒙层（禁用），右上角禁用状选择圆（1pt `#FFFFFF` 描边，30% 白色填充 `rgba(255,255,255,0.3)`） |
| `camera-dark` | `off` | `default` | `off` | 深色背景（`#FFFFFF26`，15%白），居中展示相机图标（56px）+ "拍照"文字 |
| `camera-light` | `off` | `default` | `off` | 浅色背景（`#F5F5F5`），居中展示相机图标（56px）+ "拍照"文字 |

### 2.3 尺寸规格（@2x，px）

| 属性 | 值（@2x） | @1x | 说明 |
|------|---------|-----|------|
| 格子尺寸 | **182×182px** | 91×91pt | 正方形缩略格 |
| 选择圆圈尺寸 | **44×44px** | 22×22pt | 右上角选择框圆形区域 |
| 选择圆圈位置 | 右上角 | — | 绝对定位于格子右上角 |
| 未选中圆背景 | `rgba(255,255,255,0.15)` | — | 未选中时选择圆 15% 白色半透明填充 |
| 选中蒙层透明度 | **30%黑** `#111111 opacity: 0.3` | — | 选中遮罩层 |
| 禁用蒙层 | **30%白** `#FFFFFF4C` | — | 禁用遮罩层 |
| 禁用态选择圆描边 | **2px solid #FFFFFF**（@2x） | 1pt | 禁用时选择圆描边色，纯白 `#FFFFFF` |
| 禁用态选择圆填充 | `rgba(255,255,255,0.3)` | — | 禁用时选择圆 30% 白色半透明填充 |
| 数字序号文字 | **24px** / 44px行高 | 12pt | `#111111`，PingFang SC Medium（500） |
| 数字序号圆形描边 | **2px solid #FFFFFF**（@2x） | 1pt | 选中数字圆外圈白色描边（`outline` 或 `box-shadow`），用于与图片背景区分 |
| 对勾图标尺寸 | **22×22px** | 11×11pt | 填充型对勾，黑色（`#111111`），使用图标 `check-fill` |
| 对勾圆形描边 | **2px solid #FFFFFF**（@2x） | 1pt | 与数字序号圆一致，外圈白色描边（`border: 2px solid #FFFFFF`）用于与图片背景区分 |
| 拍照图标尺寸 | **56×56px** | 28×28pt | 相机图标 |
| 拍照文字 | **24px** / 32px行高 | — | `caption-l-24-regular` |
| 视频时长文字 | **24px** / 32px行高，左对齐 | — | 白色，Medium（500），左下角 |
| 视频时长文字位置 | `bottom: 12px, left: 12px`（@2x） | bottom: 6pt, left: 6pt | 距视频格左边缘 6pt，距底边缘 6pt |
| 视频渐变蒙层高度 | **64px** | 32pt | 底部渐变，从透明到 `#000000B2`（70%黑） |

---

## 3. 图像选择预览（MediaPickerPreview）

用于发布确认区，展示已选中的图片/视频缩略图（较小尺寸）。

### 3.1 变体矩阵

| mediaType | selected | 外观描述 |
|-----------|----------|----------|
| `photo` | `off` | 普通图片缩略图，无选中标记 |
| `photo` | `on` | 图片加 **6px 黄色内描边**（`#FFDD00`，3pt）表示选中 |
| `video` | `off` | 视频缩略图，底部渐变蒙层，左下角时长 |
| `video` | `on` | 视频加 **6px 黄色内描边**（`#FFDD00`，3pt）表示选中，描边盖于渐变蒙层之上 |

### 3.2 尺寸规格

| 属性 | 值（@2x） | @1x | 说明 |
|------|---------|-----|------|
| 格子尺寸 | **108×108px** | 54×54pt | 正方形预览格 |
| 选中边框 | **6px solid #FFDD00** | 3pt | 黄色内描边，`brand-yellow`，`::after` 伪元素实现（`z-index: 10`），盖于渐变蒙层之上 |
| 视频渐变蒙层高度 | **60px** | 30pt | 底部渐变 |
| 视频时长文字 | **24px** / 32px行高 | — | 白色 |
| 视频时长文字位置 | `bottom: 16px, left: 16px`（@2x） | bottom: 8pt, left: 8pt | 距预览格左边缘 8pt，距底边缘 8pt |

---

## 4. 图像上传（ImageUpload）

用于「点击上传」触发入口卡片，展示上传前状态和上传后的图片缩略卡片。

> **注**：本子组件包含`图标`和`数字`两个可选元素，但根据设计稿，标准用法均包含图标（icon=on）。

### 4.1 变体矩阵

| state | strongText | number | 外观描述 |
|-------|-----------|--------|----------|
| `default` | `off` | `off` | 内描边（`box-shadow: inset 0 0 0 1px #CCCCCC`），圆角 12px @2x，居中展示图标（48px，`camera-line-regular`，`#555555`）+ "添加图片"文字（`#555555`）；无背景色 |
| `default` | `off` | `on` | 同上，图标下方附带数量文字（如"3/9"），间距 4px，文字色 `#555555` |
| `default` | `on` | `off` | 空态 + 底部纯黑强文字条（40px，`rgba(0,0,0,0.8)`）+ 行排图标（`edit-line-regular`，24px）+ 文字"文字说明"；有**透明底**和**灰色底（`#F5F5F5`）**两种子变体 |
| `pressed` | `off` | `off` | 按下态，叠加灰色背景（`#F5F5F5`），内描边，居中图标+文字（同默认态） |
| `pressed` | `off` | `on` | 按下态（`#F5F5F5` 背景），同上含数量文字 |
| `uploading` | `off` | `off` | 深色蒙层（`rgba(0,0,0,0.8)`）覆盖，居中图标（48px，`refresh-line-regular`）+ "上传中"白色文字（24px），图文区 72×84px，间距 4px |
| `failed` | `off` | `off` | 深色蒙层（`rgba(0,0,0,0.8)`）覆盖，居中图标（48px，`warning-line-regular`，`#FFFFFF`）+ "上传失败"白色文字，图文区 96×84px，右上角删除按钮（40×40px，`cancelcircle-fill` 图标） |
| `success` | `off` | `off` | 图片缩略图（`object-fit: cover`），右上角删除按钮（40×40px，`cancelcircle-fill` 图标） |
| `success` | `on` | `off` | 图片缩略图 + 底部强文字条（40px，`rgba(0,0,0,0.8)`）+ 行排图标（`camera-line-regular`，24px）+ 文字"换一张"，右上角删除按钮 |
| `failed` | `on` | `off` | 深色蒙层 + 底部强文字条（40px，`rgba(0,0,0,0.8)`）+ 行排图标（`warning-line-regular`，24px）+ 文字"上传失败"，右上角删除按钮 |

### 4.2 尺寸规格

| 属性 | 值（@2x） | @1x | 说明 |
|------|---------|-----|------|
| 卡片尺寸 | **156×156px** | 78×78pt | 正方形卡片 |
| 圆角 | **12px** | 6pt | `radius-xs`（`radius-semantic.md`） |
| 默认描边 | `box-shadow: inset 0 0 0 1px #CCCCCC` | — | 内描边实现，不占外部空间，`stroke-tertiary`（default/pressed 态） |
| 默认背景 | 无（透明） | — | default 态无填充背景色 |
| 按下背景 | `#F5F5F5` | — | `surface-secondary`（pressed 态添加） |
| 蒙层背景 | `rgba(0,0,0,0.8)`（即 `#000000CC`，80%黑） | — | `bg-overlay-dark`，用于 uploading/failed 态 |
| 图标尺寸（默认态） | **48×48px** | 24×24pt | 图片上传图标 `camera-line-regular`，颜色 `#555555` |
| 上传中图标 | **48×48px** | 24×24pt | `refresh-line-regular`，颜色 `#FFFFFF` |
| 失败图标 | **48×48px** | 24×24pt | `warning-line-regular`，颜色 `#FFFFFF` |
| 图标+文字区域（默认/空态） | **96×84px**（宽×高） | 48×42pt | flex-column，`top: 36px, left: 30px`（@2x） |
| 图标+文字区域（上传中） | **72×84px**（宽×高） | 36×42pt | flex-column，`top: 36px, left: 42px`（@2x） |
| 图标+文字区域（失败） | **96×84px**（宽×高） | 48×42pt | flex-column，`top: 36px, left: 30px`（@2x） |
| 图标与文字间距 | **4px**（row-gap） | 2pt | `cs-2`（`component-spacing.md`），flex-column gap |
| 状态文字（uploading） | **24px** / 32px行高，宽 72px | — | 白色（`#FFFFFF`），PingFang SC Regular 400，文案"上传中" |
| 状态文字（failed） | **24px** / 32px行高，宽 96px | — | 白色（`#FFFFFF`），PingFang SC Regular 400，文案"上传失败" |
| 说明文字（默认态） | **24px** / 32px行高，宽 96px | — | `#555555`，PingFang SC Regular 400，文案"添加图片" |
| 强文字条（strongText=on） | **40px** 高，`rgba(0,0,0,0.8)`，`bottom:0 left:0 right:0` | — | 纯黑蒙层，圆角 `0 0 12px 12px`；空态图标 `edit-line-regular`，成功/失败态图标 `camera-line-regular`/`warning-line-regular`，文字 22px |
| 删除按钮尺寸（失败/成功态） | **40×40px** | 20×20pt | 右上角圆形，定位 `top: -15px, left: 131px`（@2x），`background: transparent`；图标 `cancelcircle-fill` **40px（20pt）**，颜色 `#888888`，图标内嵌 33×33px 白色圆形底（`::after` 伪元素，`z-index:0`，图标 `z-index:1`） |

### 4.3 组件集布局规格（ComponentSet @2x）

> 以下为 Figma 组件集画布中的排列坐标，供设计还原参考：

| 组件编号 | 对应变体 | top（@2x） | left（@2x） | 说明 |
|----------|----------|-----------|------------|------|
| `.component`（row 1） | default / 有图 | 46px | 52px | 第一行第 1 列 |
| `.component-1`（row 2） | default / 空态（无图） | 247px | 52px | 第二行第 1 列 |
| `.component-2`（row 1） | pressed / 有图 | 46px | 406px | 第一行第 2 列 |
| `.component-3`（row 2） | pressed / 空态 | 247px | 406px | 第二行第 2 列 |
| `.component-4`（row 1） | uploading 或 failed（蒙层态） | 46px | 762px | 第一行第 3 列 |
| `.component-5`（row 1） | success（含删除按钮） | 46px | 1474px | 第一行最后列 |

**组件集画布参数：**
- 整体尺寸：**1684×457px @2x**
- 边框：3px dashed `#111111`（设计稿标注线，非生产样式）
- 圆角：40px（组件集画框，非生产样式）
- 行间距（行 1 底部 → 行 2 顶部）：`247 - 46 - 156 = 45px`（约 22pt @1x）

---

## 5. 视频上传（VideoUpload）

用于视频上传触发入口，结构与图像上传相似，增加上传成功后的视频缩略状态。

### 5.1 变体矩阵

| state | 外观描述 |
|-------|----------|
| `default` | 内描边（`box-shadow: inset 0 0 0 1px #CCCCCC`），无填充背景，居中展示视频图标（48px，`shootvideo-line-regular`，`#555555`）+ "添加视频"文字（`#555555`），图文区 96×84px |
| `pressed` | 按下态，背景变为 `#F7F7F7`，内描边（`box-shadow: inset 0 0 0 1px #CCCCCC`）保留，图文区同默认态 |
| `success` | 视频缩略图背景（`#D8D8D8` 占位 + 真实图片），居中展示**播放图标**（48×48px，定位 `top:54px, left:54px`），右上角删除按钮（40×40px） |
| `uploading` | 深色蒙层（`rgba(0,0,0,0.8)`），居中展示加载图标（48px）+ "上传中"白色文字（24px），图文区 72×84px |
| `failed` | 深色蒙层（`rgba(0,0,0,0.8)`），居中展示失败状态图标（48px）+ 白色文字（24px），图文区 96×84px，右上角删除按钮（40×40px） |

### 5.2 尺寸规格

| 属性 | 值（@2x） | @1x | 说明 |
|------|---------|-----|------|
| 卡片尺寸 | **156×156px** | 78×78pt | 正方形卡片 |
| 圆角 | **12px** | 6pt | `radius-xs`（`radius-semantic.md`） |
| 默认描边 | `box-shadow: inset 0 0 0 1px #CCCCCC` | — | 内描边实现，不占外部空间，`stroke-tertiary`（default/pressed 态） |
| 默认背景 | 无（透明） | — | default 态无填充背景色 |
| 按下背景 | `#F7F7F7` | — | pressed 态填充（注意：视频上传用 `#F7F7F7`，深于图像上传的 `#F5F5F5`） |
| 蒙层背景 | `rgba(0,0,0,0.8)`（即 `#000000CC`，80%黑） | — | `bg-overlay-dark`，uploading/failed 态 |
| 图标+文字区域（default/pressed/failed） | **96×84px**（宽×高） | 48×42pt | flex-column，`top: 36px, left: 30px`（@2x） |
| 图标+文字区域（uploading） | **72×84px**（宽×高） | 36×42pt | flex-column，`top: 36px, left: 42px`（@2x） |
| 图标尺寸（default/pressed） | **48×48px** | 24×24pt | 视频上传图标 `shootvideo-line-regular`，颜色 `#555555` |
| 图标与文字间距 | **4px**（row-gap） | 2pt | `cs-2`（`component-spacing.md`），flex-column gap |
| 说明文字（default/pressed） | **24px** / 32px行高，宽 96px | — | `#555555`，PingFang SC Regular 400，"添加视频" |
| 状态文字（uploading/failed） | **24px** / 32px行高 | — | 白色（`#FFFFFF`），PingFang SC Regular 400 |
| 缩略图背景占位色（success） | `#D8D8D8` | — | 图片未加载时的占位背景 |
| 播放图标（success） | **26×26px** | 13×13pt | 居中于 40×40px 圆形底之上；图标 `play-fill` 白色，图标下层叠加 **40×40px（20×20pt）圆形底**（`rgba(0,0,0,0.6)`，`::after` 伪元素居中，整体定位 `top: 54px, left: 54px`（@2x）） |
| 删除按钮（success/failed） | **40×40px** | 20×20pt | 右上角圆形，定位 `top: -15px, left: 131px`（@2x），图标 `cancelcircle-fill` **40px（20pt）**，颜色 `#888888`，图标内嵌 33×33px 白色圆形底（`::after` 伪元素，居中叠于图标下层） |

### 5.3 组件集布局规格（ComponentSet @2x）

> 以下为 Figma 组件集画布中的排列坐标，供设计还原参考：

| 组件编号 | 对应变体 | top（@2x） | left（@2x） | 说明 |
|----------|----------|-----------|------------|------|
| `.component` | default | 35px | 52px | 第 1 列 |
| `.component-1` | pressed | 35px | 406px | 第 2 列 |
| `.component-3` | uploading（蒙层态） | 35px | 762px | 第 3 列 |
| `.component-2` | success（播放图标+删除按钮） | 35px | 1118px | 第 4 列 |
| `.component-4` | failed（蒙层+删除按钮） | 35px | 1474px | 第 5 列 |

**组件集画布参数：**
- 整体尺寸：**1684×229px @2x**（单行，仅一行变体）
- 边框：3px dashed `#111111`（设计稿标注线，非生产样式）
- 圆角：40px（组件集画框，非生产样式）
- 纵向内边距：top 35px，bottom 38px（`229 - 35 - 156 = 38px`）

### 5.4 视频上传 组件树

```
[VideoUpload] 156×156px，圆角 12px
  │
  ├── [default 态] — .component
  │     ├── [描边] box-shadow: inset 0 0 0 1px #CCCCCC（内描边，不占外部空间）
  │     └── [图文区 Frame] 96×84px，absolute top:36px left:30px
  │           ├── flex-column，row-gap:4px（cs-2），align-items:center
  │           ├── [图标] 48×48px，flex-shrink:0
  │           └── [文字] 96×32px，24px/32px，#555555，Regular 400
  │
  ├── [pressed 态] — .component-1
  │     ├── background: #F7F7F7
  │     ├── [描边] box-shadow: inset 0 0 0 1px #CCCCCC（内描边）
  │     └── [图文区 Frame] 96×84px，absolute top:36px left:30px（同 default）
  │
  ├── [uploading 态] — .component-3，overflow: hidden
  │     ├── [图片背景层 Frame] 156×156px（含 Group：占位矩形 #D8D8D8 + 图片 object-fit:cover）
  │     ├── [深色蒙层] 156×156px，rgba(0,0,0,0.8)，圆角 12px
  │     └── [图文区 Frame] 72×84px，absolute top:36px left:42px
  │           ├── flex-column，row-gap:4px，align-items:center
  │           ├── [图标] 48×48px
  │           └── [文字] 72×32px，24px/32px，#FFFFFF，Regular 400
  │
  ├── [success 态] — .component-2
  │     ├── background: #F7F7F7
  │     ├── [图片背景层 Group] 156×156px（占位矩形 #D8D8D8 + 图片 object-fit:cover）
  │     ├── [播放图标] 48×48px，absolute top:54px left:54px（水平垂直居中）
  │     └── [删除按钮] 40×40px，absolute top:-15px left:131px
  │
  └── [failed 态] — .component-4
        ├── [图片背景层 Frame] 156×156px（含 Group：占位矩形 #D8D8D8 + 图片）
        ├── [深色蒙层] 156×156px，rgba(0,0,0,0.8)，圆角 12px
        ├── [内容覆盖层] 156×156px，圆角 12px，overflow: hidden
        │     └── [图文区 Frame] 96×84px，absolute top:36px left:30px
        │           ├── flex-column，row-gap:4px，align-items:center
        │           ├── [图标] 48×48px
        │           └── [文字] 96×32px，24px/32px，#FFFFFF，Regular 400
        └── [删除按钮] 40×40px，absolute top:-15px left:131px
```

> **图文区宽度规律**：uploading 态文字较短用 72px（`left: 42px`）；default/pressed/failed 态文字较宽用 96px（`left: 30px`），均水平居中于 156px 卡片。播放图标居中计算：`(156-48)/2 = 54px`。

---

## 6. 图片上传/常规型（ImageUploadCard）

用于图片上传后的内容卡片，既作上传前触发，又展示上传中/成功/失败各态。

### 6.1 变体维度

| 维度 | 属性名 | 可选值 |
|------|--------|--------|
| 状态 | `state` | `default`、`pressed`、`uploading`、`success`、`failed` |
| 强文字 | `strongText` | `on`（底部深色遮罩+图标+文字）、`off` |

> **说明**：`icon` 和 `text` 不作为独立维度；空态固定显示图标+文字（居中），蒙层态固定显示状态图标+文字，strongText 在 `default`/`pressed`/`success`/`failed` 四种状态下均可叠加。描边均使用**内描边**（`box-shadow: inset 0 0 0 1px #CCCCCC`）实现，不占外部布局空间。

### 6.2 完整变体矩阵

| state | strongText | 外观描述 |
|-------|------------|----------|
| `default` | `off` | 内描边（`box-shadow: inset 0 0 0 1px #CCCCCC`），无背景色，居中图标（48px）+ 说明文字（`#555555`），图文区 96×84px |
| `default` | `on` | 同上空态，底部叠加强文字条（40px 高纯黑蒙层 `rgba(0,0,0,0.8)` + 行排图标+文字）；有透明底/`#F5F5F5` 灰底两种子变体 |
| `pressed` | `off` | 按下态，`#F5F5F5` 背景，内描边，居中图标+文字（同 default） |
| `pressed` | `on` | 按下态（`#F5F5F5`），底部叠加强文字条（同 default/on） |
| `uploading` | `off` | 深色蒙层（`rgba(0,0,0,0.8)`），居中图标（48px）+ "上传中"白色文字，图文区 72×84px |
| `success` | `off` | 图片缩略图（`object-fit: cover`），右上角删除按钮（40×40px） |
| `success` | `on` | 图片缩略图 + 底部强文字条（40px 高纯黑蒙层 `rgba(0,0,0,0.8)` + 图标+文字“换一张”）+ 右上角删除按钮 |
| `failed` | `off` | 深色蒙层（`rgba(0,0,0,0.8)`），居中图标（48px，`warning-line-regular`，`#FFFFFF`）+ "上传失败"白色文字，图文区 96×84px，右上角删除按钮（`cancelcircle-fill`，`#888888`） |
| `failed` | `on` | 深色蒙层 + 底部强文字条（40px 高纯黑蒙层 `rgba(0,0,0,0.8)` + 图标 `warning-line-regular`+文字**"上传失败"**）+ 右上角删除按钮 |

### 6.3 尺寸规格

| 属性 | 值（@2x） | @1x | 说明 |
|------|---------|-----|------|
| 卡片尺寸 | **156×156px** | 78×78pt | 正方形卡片 |
| 圆角 | **12px** | 6pt | `radius-xs`（`radius-semantic.md`），overflow: hidden |
| 默认描边 | `box-shadow: inset 0 0 0 1px #CCCCCC` | — | 内描边实现，不占外部空间，`stroke-tertiary`（default/pressed 态） |
| 默认背景 | 无（透明） | — | default 态无填充背景色 |
| 按下背景 | `#F5F5F5` | — | `surface-secondary`（pressed 态） |
| 蒙层背景 | `rgba(0,0,0,0.8)`（即 `#000000CC`，80%黑） | — | `bg-overlay-dark`，uploading/failed 态 |
| 图标+文字区域（default/pressed） | **96×84px**（宽×高） | 48×42pt | flex-column，`top: 36px, left: 30px`（@2x） |
| 图标+文字区域（uploading） | **72×84px**（宽×高） | 36×42pt | flex-column，`top: 36px, left: 42px`（@2x） |
| 图标+文字区域（failed） | **96×84px**（宽×高） | 48×42pt | flex-column，`top: 36px, left: 30px`（@2x） |
| 图标尺寸（空态/蒙层态） | **48×48px** | 24×24pt | flex-shrink: 0 |
| 图标与文字间距 | **4px**（row-gap） | 2pt | `cs-2`（`component-spacing.md`），flex-column gap |
| 说明文字（default/pressed） | **24px** / 32px行高，宽 96px | — | `#555555`，PingFang SC Regular 400 |
| 状态文字（uploading/failed） | **24px** / 32px行高，宽 72px / 96px | — | 白色（`#FFFFFF`），PingFang SC Regular 400 |
| 缩略图背景占位色（success） | `#D8D8D8` | — | 图片加载前占位色 |
| 删除按钮（success/failed） | **40×40px** | 20×20pt | 右上角圆形，定位 `top: -15px, left: 131px`（@2x），`background: transparent`；图标 `cancelcircle-fill` **40px（20pt）**，颜色 `#888888`，图标内嵌 33×33px 白色圆形底（`::after` 伪元素，`z-index:0`；图标 `::before` `z-index:1`） |

### 6.4 强文字（strongText）规格

强文字为底部覆盖条，结构为纯黑蒙层（`rgba(0,0,0,0.8)`，非渐变）+ 横排图标+文字，固定贴底。适用于 `default`/`success`/`failed` 三种状态。

| 属性 | 值（@2x） | @1x | 说明 |
|------|---------|-----|------|
| 底部蒙层（`.strong-bar`） | **40px** 高，`left:0 right:0 bottom:0`，`rgba(0,0,0,0.8)` | 20pt | 纯黑 80% 不透明蒙层（非渐变），圆角 `0 0 12px 12px` |
| 强文字行容器（`.strong-row`） | **156×32px**，`top: 120px, left: 0` | — | 绝对定位，贴近底部；flex-row，justify:center，column-gap: 4px（`cs-2`），align-items:center |
| 强文字图标（空态/failed） | **24×24px**，flex-shrink:0 | 12×12pt | 空态：`edit-line-regular`；失败态：`warning-line-regular`；白色（`#FFFFFF`） |
| 强文字图标（success） | **24×24px**，flex-shrink:0 | 12×12pt | `camera-line-regular`，白色（`#FFFFFF`） |
| 强文字文字 | **22px** / `line-height: 1`，`white-space: nowrap` | — | 白色（`#FFFFFF`），PingFang SC Regular 400；空态文案"文字说明"，成功态"换一张"，失败态"上传失败" |
| 强文字图标与文字间距 | **4px**（column-gap，横排） | 2pt | `cs-2`（`component-spacing.md`） |

> **注意**：强文字字号为 **22px**（而非普通状态文字的 24px），`line-height: 1`，`white-space: nowrap`；图标为 24px（区别于居中态的 48px）。`default/strongText=on` 有两个子变体：透明底（无背景色）和灰色底（`background: #F5F5F5`）。

### 6.5 组件集布局规格（ComponentSet @2x）

> 以下为 Figma 组件集画布中的排列坐标，供设计还原参考：

| 组件编号 | 对应变体 | top（@2x） | left（@2x） | 说明 |
|----------|----------|-----------|------------|------|
| `.component` | default / strongText=off | 35px | 52px | 第一行第 1 列 |
| `.component-1` | success / strongText=on（第二行） | 271px | 52px | 第二行第 1 列 |
| `.component-2` | pressed / strongText=off | 35px | 406px | 第一行第 2 列 |
| `.component-3` | pressed / strongText=on（第二行） | 271px | 406px | 第二行第 2 列 |
| `.component-4` | uploading | 35px | 762px | 第一行第 3 列 |
| `.component-5` | success / strongText=off | 35px | 1118px | 第一行第 4 列 |
| `.component-6` | success / strongText=on（第二行） | 271px | 1118px | 第二行第 4 列 |
| `.component-7` | failed | 35px | 1474px | 第一行第 5 列 |

**组件集画布参数：**
- 整体尺寸：**1684×483px @2x**（两行布局）
- 背景色：`#FFFFFF`（白色，区别于其他无背景组件集）
- 边框：3px dashed `#111111`（设计稿标注线，非生产样式）
- 圆角：40px（组件集画框，非生产样式）
- 行间距（行 1 底部 → 行 2 顶部）：`271 - 35 - 156 = 80px`（约 40pt @1x）

### 6.6 ImageUploadCard 组件树

```
[ImageUploadCard] 156×156px，圆角 12px，overflow: hidden
  │
  ├── [default / strongText=off] — .component
  │     ├── [描边] box-shadow: inset 0 0 0 1px #CCCCCC（内描边，不占外部空间）
  │     └── [图文区 Frame] 96×84px，absolute top:36px left:30px
  │           ├── flex-column，row-gap:4px，align-items:center
  │           ├── [图标 camera-line-regular] 48×48px，flex-shrink:0，颜色 #555555
  │           └── [文字] 96×32px，24px/32px，#555555，Regular 400，"添加图片"
  │
  ├── [pressed / strongText=off] — .component-2
  │     ├── background: #F5F5F5
  │     ├── [描边] box-shadow: inset 0 0 0 1px #CCCCCC（内描边）
  │     └── [图文区 Frame] 96×84px，absolute top:36px left:30px（同 default）
  │           └── [文字] "添加图片"，#555555
  │
  ├── [uploading] — .component-4，overflow: hidden
  │     ├── [图片背景层] 156×156px，Group：占位矩形 #D8D8D8 + 图片 object-fit:cover
  │     ├── [深色蒙层 .overlay] 156×156px，rgba(0,0,0,0.8)，圆角 12px
  │     └── [图文区 Frame .content-area.narrow] 72×84px，absolute top:36px left:42px
  │           ├── flex-column，row-gap:4px，align-items:center
  │           ├── [图标 refresh-line-regular] 48×48px，颜色 #FFFFFF
  │           └── [文字] 72×32px，24px/32px，#FFFFFF，Regular 400，"上传中"
  │
  ├── [success / strongText=off] — .component-5
  │     ├── [图片] 156×156px，object-fit:cover，absolute top:0 left:0
  │     └── [删除按钮 .del-btn] 40×40px，absolute top:-15px left:131px，background:transparent
  │           └── [图标 cancelcircle-fill] 40px，颜色 #888888，内嵌 33×33px 白色圆底（::after）
  │
  ├── [success / strongText=on] — .component-6
  │     ├── [图片] 156×156px，object-fit:cover，absolute top:0 left:0
  │     ├── [纯黑蒙层 .strong-bar] 156×40px，rgba(0,0,0,0.8)，absolute left:0 right:0 bottom:0，圆角 0 0 12px 12px
  │     ├── [强文字行 .strong-row] 156×32px，absolute top:120px left:0
  │     │     ├── flex-row，justify:center，column-gap:4px，align-items:center
  │     │     ├── [图标 camera-line-regular] 24×24px，flex-shrink:0，颜色 #FFFFFF
  │     │     └── [文字] 22px，line-height:1，#FFFFFF，Regular 400，"换一张"
  │     └── [删除按钮 .del-btn] 40×40px，absolute top:-15px left:131px，background:transparent
  │           └── [图标 cancelcircle-fill] 40px，颜色 #888888，内嵌 33×33px 白色圆底（::after）
  │
  ├── [default / strongText=on] — .component-1（第二行）
  │     ├── [描边] box-shadow: inset 0 0 0 1px #CCCCCC（内描边）
  │     ├── [纯黑蒙层 .strong-bar] 156×40px，rgba(0,0,0,0.8)，absolute left:0 right:0 bottom:0，圆角 0 0 12px 12px
  │     └── [强文字行 .strong-row] 156×32px，absolute top:120px left:0
  │           ├── flex-row，justify:center，column-gap:4px，align-items:center
  │           ├── [图标 edit-line-regular] 24×24px，颜色 #FFFFFF
  │           └── [文字] 22px，line-height:1，#FFFFFF，Regular 400，"文字说明"
  │
  ├── [pressed / strongText=on] — .component-3（第二行）
  │     ├── background: #F5F5F5
  │     ├── [描边] box-shadow: inset 0 0 0 1px #CCCCCC（内描边）
  │     └── （同 .component-1 强文字结构）
  │
  ├── [failed / strongText=off] — .component-7
  │     ├── [图片背景层] 156×156px，Group：占位矩形 #D8D8D8 + 图片 object-fit:cover
  │     ├── [深色蒙层 .overlay] 156×156px，rgba(0,0,0,0.8)，圆角 12px
  │     ├── [图文区 Frame .content-area.normal] 96×84px，absolute top:36px left:30px
  │     │     ├── flex-column，row-gap:4px，align-items:center
  │     │     ├── [图标 warning-line-regular] 48×48px，颜色 #FFFFFF
  │     │     └── [文字] 96×32px，24px/32px，#FFFFFF，Regular 400，"上传失败"
  │     └── [删除按钮 .del-btn] 40×40px，absolute top:-15px left:131px，background:transparent
  │           └── [图标 cancelcircle-fill] 40px，颜色 #888888，内嵌 33×33px 白色圆底（::after）
  │
  └── [failed / strongText=on]
        ├── [图片背景层] 156×156px，Group：占位矩形 #D8D8D8 + 图片 object-fit:cover
        ├── [纯黑蒙层 .strong-bar] 156×40px，rgba(0,0,0,0.8)，absolute left:0 right:0 bottom:0，圆角 0 0 12px 12px
        ├── [强文字行 .strong-row] 156×32px，absolute top:120px left:0
        │     ├── [图标 warning-line-regular] 24×24px，颜色 #FFFFFF
        │     └── [文字] 22px，line-height:1，#FFFFFF，Regular 400，"上传失败"
        └── [删除按钮 .del-btn] 40×40px，absolute top:-15px left:131px，background:transparent
```

> **strongText 定位推导**：强文字行 `top: 120px` = 156 - 40（蒙层高）+ 4（视觉微调）= 底部 36px 处；蒙层 `bottom: 0, height: 40px` 覆盖最底部 40px；图标 + 文字排成一行居中对齐于卡片宽度（156px）。

---

## 7. 图片上传/证件型（IdCardUpload）

用于身份证、护照等证件上传，卡片尺寸更宽（横版 336×220px），包含证件示意内容区和特殊失败重试机制。

### 7.1 变体矩阵

| state | 外观描述 |
|-------|----------|
| `default` | 灰色内描边（`box-shadow: inset 0 0 0 1px #CCCCCC`），无填充背景；内含证件示意插图区（312×196px，背景图 `id-card-illus.png` cover 填充，正面人像插图）+ 底部图文区（60px 图标 + 说明文字"上传身份证人像面照片"，`#555555`） |
| `pressed` | 按下态（`background: #F7F7F7`），灰色内描边；证件示意插图区改用背面插图 `id-card-back-illus.png` cover 填充；底部文字为"上传身份证国徽面照片" |
| `uploading` | 图片背景 + 深色蒙层（`rgba(0,0,0,0.8)`），居中图文区（72×100px）：60px 加载图标 + "上传中"白色文字，gap 8px |
| `success` | 图片背景（`object-fit: cover`）+ 底部纯黑遮罩（`.strong-bar`，48px 高，`rgba(0,0,0,0.8)`）+ 底部强文字行（32px图标 + 96px文字"重新上传"）+ 右上角删除按钮（40×40px） |
| `failed-blur` | 图片背景 + 深色蒙层，居中信息区（192×156px）：60px 警示图标 + "照片模糊或不完整"文字 + 重试按钮（136×48px） |
| `failed-network` | 图片背景 + 深色蒙层，居中信息区（192×156px）：60px 警示图标 + "网络错误，请重试"文字 + 重试按钮（136×48px） |

### 7.2 尺寸规格（@2x，px）

| 属性 | 值（@2x） | @1x | 说明 |
|------|---------|-----|------|
| 卡片尺寸 | **336×220px** | 168×110pt | 横版证件尺寸，圆角 12px（`radius-xs`），overflow: hidden |
| 圆角 | **12px** | 6pt | `radius-xs`（`radius-semantic.md`） |
| 默认描边 | `box-shadow: inset 0 0 0 1px #CCCCCC` | — | 内描边实现，不占外部空间，`stroke-tertiary`（default/pressed 态） |
| 默认背景 | 无（透明） | — | default 态无填充背景色 |
| 按下背景 | `#F7F7F7` | — | pressed 态填充（注意：视频上传用 `#F7F7F7`，深于图像上传的 `#F5F5F5`） |
| 蒙层背景 | `rgba(0,0,0,0.8)`（即 `#000000CC`，80%黑） | — | `bg-overlay-dark`，uploading/failed 态 |
| **证件示意插图区** | **312×196px** | 156×98pt | 绝对定位 `top:12px, left:12px`，圆角 12px，overflow:hidden；**正面**（default）使用 `background: url('id-card-illus.png') center center / cover no-repeat`；**背面**（pressed）使用 `background: url('id-card-back-illus.png') center center / cover no-repeat` |
| **default/pressed 图文区** | **240×100px** | 120×50pt | flex-column，`top: 60px, left: 48px`，gap: 8px（`cs-4`），align-items: center |
| 图文区图标（default/pressed） | **60×60px** | 30×30pt | 上传图标 `camera-line-regular`，颜色 `#555555` |
| 图文区文字（default/pressed） | **240×32px**，24px/32px | — | `#555555`，PingFang SC Regular 400，text-align: center；**正面文案**："上传身份证人像面照片"；**背面文案**："上传身份证国徽面照片" |
| **uploading 图文区** | **72×100px** | 36×50pt | flex-column，`top: 60px, left: 132px`（336/2-36=132，水平居中），gap: 8px（`cs-4`） |
| 上传中图标 | **60×60px** | 30×30pt | 加载动画图标 |
| 上传中文字 | **72×32px**，24px/32px | — | 白色（`#FFFFFF`），Regular 400，居中 |
| **failed 信息区** | **192×156px** | 96×78pt | flex-column，`top: 32px, left: 72px`（336/2-96=72，水平居中），gap: 8px（`cs-4`） |
| 失败图标 | **60×60px** | 30×30pt | 警示图标 |
| 失败说明文字 | **192×32px**，24px/32px | — | 白色（`#FFFFFF`），Regular 400，居中 |
| **重试按钮** | **136×48px** | 68×24pt | `border: 1px solid #FFFFFF`，`border-radius: 24px`（全圆角），padding `7px 20px` |
| 重试按钮文字 | **96×32px**，24px/32px | — | 白色（`#FFFFFF`），Regular 400，居中，`min-width: 96px` |
| **success 底部遮罩** | **336×48px**，`bottom: 0, left: 0, right: 0` | — | 纯黑蒙层（`.strong-bar`），`rgba(0,0,0,0.8)`，圆角 `0 0 12px 12px`（非渐变，与 ImageUploadCard 强文字条一致） |
| **success 强文字行** | **336×32px**，`top: 180px, left: 0` | — | flex-row，justify: center，column-gap: 4px（`cs-2`），align-items: center |
| success 强文字图标 | **32×32px** | 16×16pt | 相机图标 `camera-line-regular`，颜色 `#FFFFFF` |
| success 强文字文字 | **96×32px**，24px/32px | — | 白色（`#FFFFFF`），Regular 400，文案"重新上传" |
| **删除按钮（success）** | **40×40px** | 20×20pt | 右上角圆形，定位 `top: -15px, left: 311px`（@2x）；`336-311-40=−15`，贴近右上角；图标 `cancelcircle-fill` **40px（20pt）**，颜色 `#888888`，图标内嵌 33×33px 白色圆形底（`::after` 伪元素，居中叠于图标下层） |

### 7.3 组件集布局规格（ComponentSet @2x）

> 以下为 Figma 组件集画布中的排列坐标，供设计还原参考：

| 组件编号 | 对应变体 | top（@2x） | left（@2x） | 说明 |
|----------|----------|-----------|------------|------|
| `.component` | default | 60px | 50px | 第 1 列 |
| `.component-1` | pressed | 60px | 406px | 第 2 列 |
| `.component-2` | uploading | 60px | 762px | 第 3 列 |
| `.component-5` | success（底部强文字+删除按钮） | 60px | 1118px | 第 4 列 |
| `.component-3` | failed-blur（重试按钮） | 60px | 1474px | 第 5 列 |
| `.component-4` | failed-network（重试按钮） | 60px | 1830px | 第 6 列 |

**组件集画布参数：**
- 整体尺寸：**2221×346px @2x**（单行）
- 边框：3px dashed `#111111`（设计稿标注线，非生产样式）
- 圆角：40px（组件集画框，非生产样式）
- 纵向内边距：top 60px，bottom 66px（`346 - 60 - 220 = 66px`）
- 列间距：`406 - 50 - 336 = 20px`（约 10pt @1x）

### 7.4 IdCardUpload 组件树

```
[IdCardUpload] 336×220px，圆角 12px，overflow: hidden
  │
  ├── [default 态] — .component（正面/人像面）
  │     ├── box-shadow: inset 0 0 0 1px #CCCCCC（内描边，stroke-tertiary）
  │     ├── [证件插图区 .id-illus-bg] 312×196px，absolute top:12px（cs-6）left:12px（cs-6），圆角 12px（radius-xs），overflow:hidden
  │     │     └── background: url('id-card-illus.png') center center / cover no-repeat（正面人像插图）
  │     └── [图文区 .id-content] 240×100px，absolute top:60px left:48px
  │           ├── flex-column，row-gap:8px（cs-4），align-items:center
  │           ├── [图标 camera-line-regular] 60×60px，颜色 #555555，flex-shrink:0
  │           └── [文字 .id-label] 240×32px，24px/32px，#555555，Regular 400，text-align:center，"上传身份证人像面照片"
  │
  ├── [pressed 态] — .component-1（背面/国徽面）
  │     ├── background: #F7F7F7
  │     ├── box-shadow: inset 0 0 0 1px #CCCCCC（内描边，stroke-tertiary）
  │     ├── [证件插图区 .id-illus-bg] 312×196px，absolute top:12px（cs-6）left:12px（cs-6），圆角 12px（radius-xs），overflow:hidden
  │     │     └── background: url('id-card-back-illus.png') center center / cover no-repeat（背面国徽插图）
  │     └── [图文区 .id-content] 240×100px，absolute top:60px left:48px（同 default）
  │           └── [文字 .id-label] "上传身份证国徽面照片"
  │
  ├── [uploading 态] — .component-2，overflow: hidden
  │     ├── [图片背景] 336×220px，object-fit:cover，圆角 12px（radius-xs）
  │     ├── [深色蒙层] 336×220px，rgba(0,0,0,0.8)（bg-overlay-dark），圆角 12px（radius-xs）
  │     └── [图文区 Frame] 72×100px，absolute top:60px left:132px
  │           ├── flex-column，row-gap:8px（cs-4），align-items:center
  │           ├── [图标] 60×60px
  │           └── [文字] 72×32px，24px/32px，#FFFFFF，Regular 400
  │
  ├── [success 态] — .component-5
  │     ├── background: #D8D8D8（占位色）
  │     ├── [图片 img] 336×220px，absolute top:0 left:0，object-fit:cover
  │     ├── [底部纯黑遮罩 .strong-bar] 336×48px，absolute left:0 right:0 bottom:0，background:rgba(0,0,0,0.8)，border-radius:0 0 12px 12px
  │     ├── [强文字行 .id-success-row] 336×32px，absolute top:180px left:0
  │     │     ├── flex-row，justify:center，column-gap:4px，align-items:center
  │     │     ├── [图标 camera-line-regular] 32×32px，颜色 #FFFFFF，flex-shrink:0
  │     │     └── [文字 .id-success-text] 96×32px，24px/32px，#FFFFFF，Regular 400，"重新上传"
  │     └── [删除按钮 .id-del-btn] 40×40px，absolute top:-15px left:311px
  │
  ├── [failed-blur 态] — .component-3，overflow: hidden
  │     ├── [图片背景] 336×220px，object-fit:cover，圆角 12px（radius-xs）
  │     ├── [深色蒙层] 336×220px，rgba(0,0,0,0.8)（bg-overlay-dark），圆角 12px（radius-xs）
  │     └── [信息区 Frame] 192×156px，absolute top:32px left:72px
  │           ├── flex-column，row-gap:8px（cs-4），align-items:center
  │           ├── [警示图标] 60×60px，flex-shrink:0
  │           ├── [说明文字] 192×32px，24px/32px，#FFFFFF，Regular 400，text-align:center
  │           └── [重试按钮] 136×48px，flex-shrink:0，border-radius:24px（radius-full），border:1px solid #FFFFFF
  │                 ├── flex-row，justify:center，align-items:center，padding:7px 20px
  │                 └── [按钮文字] 96×32px，24px/32px，#FFFFFF，Regular 400，text-align:center
  │
  └── [failed-network 态] — .component-4，overflow: hidden
        ├── [图片背景] 336×220px，object-fit:cover，圆角 12px（radius-xs）
        ├── [深色蒙层] 336×220px，rgba(0,0,0,0.8)（bg-overlay-dark），圆角 12px（radius-xs）
        └── [信息区 Frame] 192×156px，absolute top:32px left:72px（同 failed-blur）
              ├── flex-column，row-gap:8px（cs-4），align-items:center
              ├── [警示图标] 60×60px
              ├── [说明文字] 192×32px，24px/32px，#FFFFFF
              └── [重试按钮] 136×48px，border-radius:24px（radius-full），border:1px solid #FFFFFF（同 failed-blur）
```

> **关键定位推导**：
> - uploading 图文区水平居中：`left = (336 - 72) / 2 = 132px`
> - failed 信息区水平居中：`left = (336 - 192) / 2 = 72px`；`top = 32px` 使内容偏上以留出重试按钮空间
> - success 强文字行 `top: 180px` = `220 - 48（遮罩高）+ 8（视觉微调）`，贴近底部
> - 删除按钮 `left: 311px`：`311 + 40 = 351 > 336`，即超出卡片右边缘 15px，视觉上贴右上角

### 7.5 证件型/自定义（IdCardUploadCustom）

证件型自定义变体，用于展示自定义背景图片 + 半透明蒙层 + 居中图文提示，供设计师自定义内容使用。

#### 7.5.1 外观描述

- 尺寸同证件型 **336×220px**，圆角 12px，overflow: hidden
- 自定义背景图片（位图，带 `top: -12px` 垂直偏移裁剪）
- 图片上叠加半透明蒙层（`rgba(0,0,0,0.6)`，即 60%黑，`#00000099`），圆角 **8px**（内层）
- 蒙层上居中展示图文区：相机/上传图标（60px）+ 自定义文字（白色，24px）

#### 7.5.2 尺寸规格（@2x，px）

| 属性 | 值（@2x） | @1x | 说明 |
|------|---------|-----|------|
| 卡片尺寸 | **336×220px** | 168×110pt | 同证件型，圆角 12px，overflow: hidden |
| **背景图层** | **336×245px**，`top: -12px` | — | 图片高于容器，向上偏移 12px 实现裁剪效果 |
| **半透明蒙层** | **336×220px**，`top: 0, right: 0` | — | `rgba(0,0,0,0.6)`（60%黑），圆角 **8px** |
| **图文区（`.frame-1`）** | **120×100px** | 60×50pt | flex-column，`top: 60px, left: 108px`（水平居中：`(336-120)/2=108`），gap: 8px（`cs-4`），align-items: center |
| 图标 | **60×60px** | 30×30pt | flex-shrink: 0（相机或自定义图标） |
| 文字 | **120×32px**，24px / 32px行高 | — | 白色（`#FFFFFF`），PingFang SC Regular 400，text-align: center |
| 图标与文字间距 | **8px**（row-gap） | 4pt | `cs-4`（`component-spacing.md`），flex-column gap |

> **与其他蒙层的区别**：自定义变体蒙层为 `rgba(0,0,0,0.6)`（**60%黑**），圆角 8px；uploading/failed 蒙层为 `rgba(0,0,0,0.8)`（80%黑），圆角 12px。图文区宽 **120px**（`left:108px`），比 uploading 的 72px（`left:132px`）更宽。

#### 7.5.3 IdCardUploadCustom 组件树

```
[IdCardUploadCustom] 336×220px，圆角 12px，overflow: hidden
  │
  ├── [背景层 .frame] 336×220px，absolute top:0 left:0 right:0 bottom:0
  │     ├── [自定义图片 .rectangle] 336×245px，absolute top:-12px left:0
  │     │     └── object-fit: cover（图片超出高度，向上裁剪 12px）
  │     └── [蒙层 .rectangle-1] 336×220px，absolute top:0 right:0
  │           └── background: rgba(0,0,0,0.6)，border-radius: 8px
  │
  └── [图文区 .frame-1] 120×100px，absolute top:60px left:108px
        ├── flex-column，row-gap:8px（cs-4），align-items:center
        ├── [图标 .instance-1] 60×60px，flex-shrink:0
        └── [文字 .text] 120×32px，24px/32px，#FFFFFF，Regular 400，text-align:center
```

> **定位推导**：图文区垂直居中：`top = (220 - 100) / 2 = 60px`；水平居中：`left = (336 - 120) / 2 = 108px`。背景图 `top: -12px` 使图片从顶部偏移裁剪，避免被卡片顶部圆角截断时出现白边。

---

### 7.6 证件通用案例

在 `default` 态的基础上，针对不同证件类型展示对应的示意插图和引导文案。整体样式与 `default`/`pressed` 态完全一致：**336×220px 卡片 + `box-shadow: inset 0 0 0 1px #CCCCCC` 内描边 + 透明背景**；差异仅在于插图区背景和图文区文案。

#### 7.6.1 变体说明

| 证件类型 | 插图区背景（.id-illus-bg） | 图文区文案（.id-label） | 图文区宽/left |
|---------|------------------------|----------------------|--------------|
| **身份证正面**（人像面） | `url('id-card-illus.png') center/cover no-repeat` | "上传身份证人像面照片" | 240px / left:48px |
| **身份证背面**（国徽面） | `url('id-card-back-illus.png') center/cover no-repeat`（`.id-illus-back`） | "上传身份证国徽面照片" | 240px / left:48px |
| **驾驶证正页** | `url('driver-license-illus.png') center/cover no-repeat`（`.id-illus-license`，真实插图文件） | "上传驾驶证正页照片" | 216px / left:60px |
| **驾驶证副页** | `url('driver-license-back-illus.png') center/cover no-repeat`（`.id-illus-license-back2`，真实插图文件） | "上传驾驶证副页照片" | 216px / left:60px |
| **营业执照反面** | `url('license-back-illus.png') center/cover no-repeat`（`.id-illus-license-back`，真实插图文件） | "上传营业执照反面" | 216px / left:60px |
| **护照** | `url('passport-illus.png') center/cover no-repeat`（`.id-illus-passport`，真实插图文件） | "上传护照照片" | 192px / left:72px |
| **往来港澳通行证** | `url('hkmo-permit-illus.png') center/cover no-repeat`（`.id-illus-hkmo`，真实插图文件） | "上传港澳台通行证" | 216px / left:60px |
| **往来台湾通行证** | `url('tw-permit-illus.png') center/cover no-repeat`（`.id-illus-tw`，真实插图文件） | "上传往来台湾通行证" | 216px / left:60px |
| **民办非企业单位登记证书** | `url('civil-org-cert-illus.png') center/cover no-repeat`（`.id-illus-civil-org`，真实插图文件） | "上传民办非企业单位登记证书" | 216px / left:60px |
| **社会团体法人登记证书** | `url('social-org-cert-illus.png') center/cover no-repeat`（`.id-illus-social-org`，真实插图文件） | "上传社会团体法人登记证书" | 216px / left:60px |
| **律师事务所执业许可证** | `url('law-firm-license-illus.png') center/cover no-repeat`（`.id-illus-law-firm`，真实插图文件） | "上传律师事务所执业许可证" | 216px / left:60px |

#### 7.6.2 通用结构（与 default 态相同）

```
[id-card id-default] 336×220px，圆角 12px
  └── [.inner] 336×220px，圆角 12px，overflow:hidden，box-shadow: inset 0 0 0 1px #CCCCCC
        ├── [.id-illus-bg {variant}] 312×196px，absolute top:12px left:12px，圆角 12px，overflow:hidden
        │     └── 不同证件类型叠加对应的修饰类（id-illus-back / id-illus-license / ...）
        └── [.id-content] 宽度/left 见上表，absolute top:60px，height:100px
              ├── flex-column，row-gap:8px，align-items:center
              ├── [图标 camera-line-regular] 60×60px，颜色 #555555，flex-shrink:0
              └── [文字 .id-label] 高32px，24px/32px，#555555，Regular 400，text-align:center
```

> **图文区宽度说明**：身份证类（240px，left:48px）→ 营业执照/港澳台类（216px，left:60px）→ 护照类（192px，left:72px），均满足 `left = (336-width)/2` 居中约束。

---

### 7.7 证件示意图变体（IdCardIllustration ComponentSet）

IdCardUpload 的 `default`/`pressed` 态内部，证件示意插图区（312×196px）根据**证件类型（cardType）**展示不同的内容。**所有证件类型均已采用真实插图文件**，以 `background: url(xxx) center center / cover no-repeat` 方式填充，不再使用 CSS 渐变+文字条+人物插画的组合方式。该组件集包含 **6 个核心变体**，对应不同证件类型；证件通用案例模块（§7.6）扩展了更多证件类型。

#### 7.7.1 组件集画布参数（@2x）

- **整体尺寸**：**2274×562px**
- **背景**：`#FFFFFF`（白色）
- **边框**：`2px dashed #111111`（设计稿标注线，非生产样式）
- **圆角**：40px（组件集画框，非生产样式）
- **纵向内边距**：top 41px，bottom 301px（`562 - 41 - 220 = 301px`）
- **列间距**：40px（`396 - 20 - 336 = 40px`）
- **单变体尺寸**：**336×220px**，圆角 12px，overflow: hidden

#### 7.7.2 变体矩阵

| 组件编号 | left（@2x） | 证件类型 | 内容区背景 | 证件插图区尺寸 | 图文区宽/left | 特征元素 |
|---------|-----------|---------|-----------|------------|------------|---------|
| `.component` | 20px | **身份证正面**（人像面） | `url('id-card-illus.png') center/cover no-repeat` | **312×196px** | **240px** / left:48px | 正面人像真实插图文件，cover 填充 |
| `.component-1` | 396px | **身份证背面**（国徽面） | `url('id-card-back-illus.png') center/cover no-repeat` | **312×196px** | **240px** / left:48px | 背面国徽真实插图文件，cover 填充 |
| `.component-2` | 772px | **营业执照** | `url('driver-license-illus.png') center/cover no-repeat` | **312×196px** | **216px** / left:60px | 真实插图文件，cover 填充 |
| `.component-3` | 1148px | **营业执照反面** | `url('license-back-illus.png') center/cover no-repeat` | **312×196px** | **216px** / left:60px | 真实插图文件，cover 填充 |
| `.component-4` | 1524px | **护照** | `url('passport-illus.png') center/cover no-repeat` | **312×196px** | **192px** / left:72px | 真实插图文件，cover 填充 |
| `.component-5` | 1900px | **往来港澳通行证** | `url('hkmo-permit-illus.png') center/cover no-repeat` | **312×196px** | **216px** / left:60px | 真实插图文件，cover 填充 |

#### 7.7.3 证件示意内容区规格（@2x）

内容区均为 **312×196px**，`top: 12px, left: 12px`，圆角 12px（内边距 12px 四边）。

**身份证正面（`.component`）示意区结构：**

| 属性 | 值（@2x） | 说明 |
|------|---------|------|
| 插图区整体 | **312×196px**，absolute `top:12px, left:12px`，圆角 12px，overflow:hidden | 相对于卡片 |
| 背景图 | `url('id-card-illus.png') center center / cover no-repeat` | 正面人像插图，cover 填充，随容器缩放 |
| 图文区 | **240×100px**，flex-column，`top:60px, left:48px`，gap:8px | 水平居中：`(336-240)/2=48` |
| 图文区文字 | "上传身份证人像面照片"，`#555555`，PingFang SC Regular 400，text-align:center | 正面文案 |

**身份证背面（`.component-1`）示意区结构：**

| 属性 | 值（@2x） | 说明 |
|------|---------|------|
| 插图区整体 | **312×196px**，absolute `top:12px, left:12px`，圆角 12px，overflow:hidden | 相对于卡片，同正面尺寸 |
| 背景图 | `url('id-card-back-illus.png') center center / cover no-repeat` | 背面国徽插图，cover 填充 |
| 图文区 | **240×100px**，flex-column，`top:60px, left:48px`，gap:8px | 同正面 |
| 图文区文字 | "上传身份证国徽面照片"，`#555555`，PingFang SC Regular 400，text-align:center | 背面文案 |

**营业执照（`.component-2`）示意区结构：**

| 属性 | 值（@2x） | 说明 |
|------|---------|------|
| 插图区整体 | **312×196px**，absolute `top:12px, left:12px`，圆角 12px，overflow:hidden | 相对于卡片 |
| 背景图 | `url('driver-license-illus.png') center center / cover no-repeat` | 真实插图文件，cover 填充 |
| 图文区 | **216×100px**，flex-column，`top:60px, left:60px`，gap:8px | 水平居中：`(336-216)/2=60` |
| 图文区文字 | "上传驾驶证正页照片"，`#555555`，Regular 400，text-align:center | 文案 |

**营业执照反面（`.component-3`）示意区结构：**

| 属性 | 值（@2x） | 说明 |
|------|---------|------|
| 插图区整体 | **312×196px**，absolute `top:12px, left:12px`，圆角 12px，overflow:hidden | 相对于卡片 |
| 背景图 | `url('license-back-illus.png') center center / cover no-repeat` | 真实插图文件，cover 填充 |
| 图文区 | **216×100px**，flex-column，`top:60px, left:60px`，gap:8px | 同营业执照正面 |
| 图文区文字 | "上传营业执照反面"，`#555555`，Regular 400，text-align:center | 文案 |

**护照（`.component-4`）示意区结构：**

| 属性 | 值（@2x） | 说明 |
|------|---------|------|
| 插图区整体 | **312×196px**，absolute `top:12px, left:12px`，圆角 12px，overflow:hidden | 相对于卡片 |
| 背景图 | `url('passport-illus.png') center center / cover no-repeat` | 真实插图文件，cover 填充 |
| 图文区 | **192×100px**，flex-column，`top:60px, left:72px`，gap:8px | 水平居中：`(336-192)/2=72` |
| 图文区文字 | "上传护照照片"，`#555555`，Regular 400，text-align:center | 文案 |

**往来港澳通行证（`.component-5`）示意区结构：**

| 属性 | 值（@2x） | 说明 |
|------|---------|------|
| 插图区整体 | **312×196px**，absolute `top:12px, left:12px`，圆角 12px，overflow:hidden | 相对于卡片 |
| 背景图 | `url('hkmo-permit-illus.png') center center / cover no-repeat` | 真实插图文件，cover 填充 |
| 图文区 | **216×100px**，flex-column，`top:60px, left:60px`，gap:8px | 水平居中：`(336-216)/2=60` |
| 图文区文字 | "上传港澳台通行证"，`#555555`，Regular 400，text-align:center | 文案 |

> **图文区宽度差异说明**：身份证系列图文区宽 **240px**（`left:48px`），文字可容纳较宽内容；营业执照/港澳台系列图文区宽 **216px**（`left:60px`）；护照系列图文区宽 **192px**（`left:72px`），均满足水平居中约束 `left = (336-width)/2`。

#### 7.7.4 组件集布局规格（ComponentSet @2x）

| 组件编号 | top（@2x） | left（@2x） | 对应证件类型 |
|---------|-----------|------------|------------|
| `.component` | 41px | 20px | 身份证正面 |
| `.component-1` | 41px | 396px | 身份证反面 |
| `.component-2` | 41px | 772px | 营业执照 |
| `.component-3` | 41px | 1148px | 营业执照反面 |
| `.component-4` | 41px | 1524px | 护照 |
| `.component-5` | 41px | 1900px | 港澳台通行证/其他 |

---

## 8. Token 引用

### 8.1 颜色 Token

| 用途 | Token 名称 | 值 | 语义层来源 |
|------|-----------|-----|-----------|
| 卡片默认描边 | `stroke-tertiary` | `#CCCCCC` | `color-semantic.md` §四 Stroke |
| 按下背景 | `surface-secondary` | `#F5F5F5` / `#F7F7F7` | `color-semantic.md` §一 Surface |
| 蒙层（上传中/失败/自定义） | `bg-overlay-dark` | `#000000CC`（80%黑） | `color-semantic.md` §六 Overlay |
| 选中高亮蒙层 | `bg-overlay-medium` | `#11111133`（30%黑） | `color-semantic.md` §六 Overlay |
| 禁用蒙层 | `bg-overlay-light` | `#FFFFFF4C`（30%白） | `color-semantic.md` §六 Overlay |
| 选中边框（预览格） | `brand-yellow` | `#FFDD00` | `color-semantic.md` §三 Brand |
| 视频底部渐变蒙层 | — | `linear-gradient(180deg, #00000000 0%, #000000B2 100%)` | 自定义渐变 |
| 拍照-浅色底背景 | `surface-tertiary` | `#F5F5F5` | `color-semantic.md` §一 Surface |
| 拍照-深色底背景 | `white-16` | `#FFFFFF26`（15%白） | `color-semantic.md` §一 |
| 文字色（白） | `white` | `#FFFFFF` | — |
| 文字色（次要，默认空态） | `text-secondary` | `#555555` | `color-semantic.md` §二 Text，用于默认/按下态空态文字 |
| 自定义蒙层（证件自定义） | — | `#00000099`（60%黑） | `color-semantic.md` §六 Overlay |

### 8.2 字体 Token

| 用途 | Token 名称 | 字号 @2x | 行高 @2x | 字重 |
|------|-----------|---------|---------|------|
| 拍照文字 / 视频时长 | `caption-l-24-regular` | 24px | 32px | 400（Regular） |
| 数量文字（图像上传） | `caption-l-24-regular` | 24px | 32px | 400 |
| 状态文字（上传中等） | `caption-l-24-regular` | 24px | 32px | 400 |
| 视频上传说明文字 | `caption-l-24-regular` | 24px | 32px | 400 |
| 证件型状态说明文字 | `caption-l-24-regular` | 24px | 32px | 400 |
| 证件型强文字/重试按钮文字 | `caption-l-24-regular` | 24px | 32px | 400 |

### 8.3 间距 Token

> 间距来源双轨：**页面/模块级间距**引用 `spacing-semantic.md`；**组件内部 gap / padding** 引用 `component-spacing.md`（Token 格式 `cs-{N}`）。

| 用途 | Token 名称 | 值（@2x） | @1x | 来源 |
|------|-----------|---------|-----|------|
| 图标与文字间距（ImageUpload/ImageUploadCard，`row-gap`） | `cs-2` | 4px | 2pt | `component-spacing.md` |
| 证件型图标文字间距（IdCardUpload/IdCardUploadCustom，`gap`） | `cs-4` | 8px | 4pt | `component-spacing.md` |
| 图像选择格图文间距（拍照入口，`gap`） | `cs-2` | 4px | 2pt | `component-spacing.md` |
| 强文字行图标与文字间距（`column-gap`） | `cs-2` | 4px | 2pt | `component-spacing.md` |
| 证件插图区内边距（`.id-illus-bg` 距卡片边缘，`top`/`left`） | `cs-6` | 12px | 6pt | `component-spacing.md` |

### 8.4 圆角 Token

> Token 来源：`radius-semantic.md`（≥4pt 场景）；`component-radius.md`（<4pt 组件内圆角）。

| 用途 | Token 名称 | 值（@2x） | @1x | 来源 |
|------|-----------|---------|-----|------|
| 所有上传卡片主圆角（卡片外轮廓） | `radius-xs` | 12px | 6pt | `radius-semantic.md` |
| 证件示意插图区圆角（`.id-illus-bg`） | `radius-xs` | 12px | 6pt | `radius-semantic.md` |
| `strong-bar` 局部圆角（`0 0 6pt 6pt`） | `radius-xs` | `0 0 12px 12px` | `0 0 6pt 6pt` | `radius-semantic.md` |
| 证件自定义内容区蒙层圆角（`.rectangle-1`） | `radius-s` | 16px | 8pt | `radius-semantic.md` |
| 重试按钮圆角 | `radius-full` | `border-radius: 9999px` | — | `radius-semantic.md` |

---

## 9. 结构规格

### 9.1 图像选择格（MediaPickerCell）组件树

```
[MediaPickerCell] 182×182px，正方形，圆角由图片决定
  ├── [图片/视频缩略图] 182×182px（RECTANGLE，占位图或真实图片）
  ├── [视频渐变蒙层] 182×64px（底部，渐变，仅视频类型）
  ├── [视频时长文字] 50×32px，absolute `bottom: 12px, left: 12px`（@2x），即距左 6pt、距底 6pt（仅视频类型）
  ├── [选中蒙层] 182×182px，30%黑（selected=on 时显示）
  ├── [禁用蒙层] 182×182px，30%白（disabled=on 时显示）
  └── [选择框] 44×44px，右上角
        ├── [空心圆] 44×44px（未选中）
        ├── [数字序号圆] 44×44px，background:#FFDD00，border-radius:50%，**border: 2px solid #FFFFFF**（@2x，即 1pt 白描边）
        │     └── [数字文字] "1"，32px，PingFang SC Medium 500，黑色，居中
        └── [对勾圆] 44×44px，background:#FFDD00，border-radius:50%，**border: 2px solid #FFFFFF**（@2x，即 1pt 白描边）
              └── [对勾图标] 22×22px，`check-fill` 图标，黑色（`#111111`），居中
```

```
[CameraCell] 182×182px（拍照入口）
  ├── [背景] 182×182px（深色 #FFFFFF26 或浅色 #F5F5F5）
  └── [图文区] 56×93px，flex-column，gap: `cs-2`（2pt，`component-spacing.md`）
        ├── [相机图标] 56×56px
        └── [文字] "拍照" 48×32px，24px
```

### 9.2 上传卡片组件树

> 以下为**图像上传（ImageUpload）** 的组件树；**ImageUploadCard 常规型**组件树见 §6.6；**视频上传（VideoUpload）** 组件树见 §5.4。

```
[ImageUpload] 156×156px，圆角 12px（radius-xs），overflow: hidden
  │
  ├── [default / number=off] — 空态
  │     ├── [描边] box-shadow: inset 0 0 0 1px #CCCCCC（stroke-tertiary，内描边不占外部空间）
  │     └── [图文区 Frame] 96×84px，absolute top:36px left:30px
  │           ├── flex-column，row-gap: 4px（cs-2），align-items: center
  │           ├── [图标 camera-line-regular] 48×48px，flex-shrink:0，颜色 #555555
  │           └── [文字] 96×32px，24px/32px，#555555，Regular 400，"添加图片"
  │
  ├── [default / number=on] — 含数量文字
  │     ├── [描边] box-shadow: inset 0 0 0 1px #CCCCCC
  │     └── [图文区 Frame] 96×84px，absolute top:36px left:30px（同 default，文字为 "3/9" 等）
  │
  ├── [pressed / number=off] — 按下态
  │     ├── background: #F5F5F5（surface-secondary）
  │     ├── [描边] box-shadow: inset 0 0 0 1px #CCCCCC
  │     └── [图文区 Frame] 96×84px，absolute top:36px left:30px（同 default）
  │
  ├── [uploading] — 上传中
  │     ├── [图片背景层] 156×156px，Group：占位矩形 #D8D8D8 + 图片 object-fit:cover
  │     ├── [深色蒙层] 156×156px，rgba(0,0,0,0.8)（bg-overlay-dark），圆角 12px
  │     └── [图文区 Frame] 72×84px，absolute top:36px left:42px
  │           ├── flex-column，row-gap: 4px（cs-2），align-items: center
  │           ├── [图标 refresh-line-regular] 48×48px，颜色 #FFFFFF
  │           └── [文字] 72×32px，24px/32px，#FFFFFF，Regular 400，"上传中"
  │
  ├── [success] — 成功态
  │     ├── [图片] 156×156px，object-fit:cover，absolute top:0 left:0
  │     └── [删除按钮 .del-btn] 40×40px，absolute top:-15px left:131px，background:transparent
  │           └── [图标 cancelcircle-fill] 40px，颜色 #888888，内嵌 33×33px 白色圆底（::after）
  │
  └── [failed] — 失败态
        ├── [图片背景层] 156×156px，Group：占位矩形 #D8D8D8 + 图片 object-fit:cover
        ├── [深色蒙层] 156×156px，rgba(0,0,0,0.8)，圆角 12px
        ├── [图文区 Frame] 96×84px，absolute top:36px left:30px
        │     ├── flex-column，row-gap: 4px（cs-2），align-items: center
        │     ├── [图标 warning-line-regular] 48×48px，颜色 #FFFFFF
        │     └── [文字] 96×32px，24px/32px，#FFFFFF，Regular 400，"上传失败"
        └── [删除按钮 .del-btn] 40×40px，absolute top:-15px left:131px，background:transparent
```

> **定位说明**：`top: 36px` = (156 - 84) / 2 = 36px，信息区垂直居中；`left` 随宽度变化（72px→left:42px；96px→left:30px），均为水平居中。删除按钮 `top: -15px, left: 131px`（@2x）等价于距卡片右边缘 `156-131-40=−15`，即向右溢出 15px，视觉上贴近右上角。

---

## 10. 交互规则

### 10.1 图像选择格

| 行为 | 说明 |
|------|------|
| **点击未选中格** | 选中该图片/视频，显示选中标记（数字型时显示当前选中序号，勾选型显示对勾） |
| **点击已选中格** | 取消选中，恢复未选中状态 |
| **点击禁用格** | 不触发任何操作（已达到最大选择数量时禁用） |
| **点击拍照入口** | 调起系统相机 |

### 10.2 上传卡片

| 状态 | 交互说明 |
|------|----------|
| `default` | 可点击，触发图片/视频选择（相册或拍照） |
| `pressed` | 按下反馈，松开后触发选择 |
| `uploading` | **不可点击**，展示上传进度；无交互 |
| `success` | 点击卡片预览大图；点击右上角删除按钮移除该图 |
| `failed` | 点击右上角删除按钮移除；证件型还有专属重试按钮 |

### 10.3 证件型失败说明

| 失败类型 | 文案 | 重试动作 |
|----------|------|----------|
| `failed-blur` | "照片模糊或不完整" | 点击按钮重新拍照/选择 |
| `failed-network` | "网络错误，请重试" | 点击按钮重新上传 |

---

## 11. Props API（供 AI 生码参考）

```typescript
// 图像选择格
export type MediaPickerCellProps = {
  /** 媒体类型 */
  mediaType: "photo" | "video" | "camera-dark" | "camera-light";
  /** 缩略图 URL（photo/video 时） */
  thumbnailUrl?: string;
  /** 视频时长文字（如 "6:23"，仅 video 时） */
  duration?: string;
  /** 是否选中 */
  selected?: boolean;
  /** 选中标记类型 */
  selectionType?: "number" | "check";
  /** 选中序号（selectionType=number 时） */
  selectedIndex?: number;
  /** 是否禁用 */
  disabled?: boolean;
  /** 点击回调 */
  onPress?: () => void;
};

// 图像选择预览格
export type MediaPickerPreviewProps = {
  /** 媒体类型 */
  mediaType: "photo" | "video";
  /** 缩略图 URL */
  thumbnailUrl?: string;
  /** 视频时长 */
  duration?: string;
  /** 是否选中（selected 时显示黄色边框） */
  selected?: boolean;
  /** 点击回调 */
  onPress?: () => void;
};

// 上传卡片（通用）
export type UploadCardProps = {
  /**
   * 上传状态
   * @default "default"
   */
  state: "default" | "pressed" | "uploading" | "success" | "failed" | "failed-blur" | "failed-network";
  /** 已上传图片 URL（success/failed 时展示缩略） */
  imageUrl?: string;
  /** 是否显示数量提示 */
  showCount?: boolean;
  /** 已选数量 / 最大数量（如 "3/9"） */
  countText?: string;
  /** 是否显示强文字区（成功态底部） */
  showStrongText?: boolean;
  /** 强文字内容 */
  strongText?: string;
  /** 点击（默认/成功）回调 */
  onPress?: () => void;
  /** 删除回调 */
  onDelete?: () => void;
  /** 重试回调（failed 态） */
  onRetry?: () => void;
};

// 证件型上传
export type IdCardUploadProps = {
  /** 上传状态 */
  state: "default" | "pressed" | "uploading" | "success" | "failed-blur" | "failed-network";
  /** 已上传图片 URL */
  imageUrl?: string;
  /** 点击回调 */
  onPress?: () => void;
  /** 删除回调 */
  onDelete?: () => void;
  /** 重试回调 */
  onRetry?: () => void;
  /** 自定义内容（custom 变体用） */
  customContent?: React.ReactNode;
  /** 自定义文字提示 */
  customLabel?: string;
};
```

---

## 12. data-attribute 规范

| 组件 | 属性 | 值 | 说明 |
|------|------|----|------|
| MediaPickerCell | `data-slot` | `"media-picker-cell"` | 选图格根容器 |
| MediaPickerCell | `data-media-type` | `"photo"` / `"video"` / `"camera-dark"` / `"camera-light"` | 媒体类型 |
| MediaPickerCell | `data-selected` | `"true"` / `"false"` | 是否选中 |
| MediaPickerCell | `data-selection-type` | `"number"` / `"check"` | 选中类型 |
| MediaPickerCell | `data-disabled` | `"true"` / `"false"` | 是否禁用 |
| MediaPickerPreview | `data-slot` | `"media-picker-preview"` | 预览格根容器 |
| UploadCard | `data-slot` | `"upload-card"` | 上传卡片根容器 |
| UploadCard | `data-state` | `"default"` / `"pressed"` / `"uploading"` / `"success"` / `"failed"` | 上传状态 |
| UploadCard | `data-card-type` | `"image"` / `"video"` / `"id-card"` | 卡片类型 |
| 删除按钮 | `data-slot` | `"upload-delete"` | 删除按钮 |
| 重试按钮 | `data-slot` | `"upload-retry"` | 重试按钮 |

---

## 13. 无障碍（Accessibility）

- 图像选择格：`role="checkbox"`（可选状态），选中时 `aria-checked="true"`，禁用时 `aria-disabled="true"`
- 缩略图：`aria-label="图片缩略图"` 或 `aria-label="视频 {时长}"`
- 拍照入口：`role="button"`，`aria-label="拍照"`
- 上传卡片（默认/按下）：`role="button"`，`aria-label="添加图片"` / `"添加视频"` 等
- 上传中状态：`aria-busy="true"`，`aria-label="上传中"`
- 上传成功：`aria-label="已上传图片，点击预览"`
- 删除按钮：`aria-label="删除该图片/视频"`
- 重试按钮：`aria-label="重新上传"`

---

## 14. 变体矩阵总览

| 子组件 | 总变体数 | 主要维度 |
|--------|---------|----------|
| 图像选择（MediaPickerCell） | **10** | mediaType × selected × selectionType × disabled |
| 图像选择预览（MediaPickerPreview） | **4** | mediaType × selected |
| 图像上传（ImageUpload） | **6** | state × number |
| 视频上传（VideoUpload） | **5** | state |
| 图片上传/常规型（ImageUploadCard） | **8** | state × strongText |
| 图片上传/证件型（IdCardUpload） | **6** | state（default/pressed/uploading/success/failed-blur/failed-network） |
| 图片上传/证件型/自定义 | **1** | — |
| **合计** | **40** | — |

---

## 15. 使用约束

### 15.1 选图格使用规则

1. **选中类型统一**：同一选图页面只能使用一种选中类型（`number` 或 `check`），不能混用
2. **拍照入口位置**：拍照入口格（`camera-dark` / `camera-light`）通常放在选图格的**第一位**（最左上角）
3. **深色底 vs 浅色底**：深色相册背景（如暗色系页面）使用 `camera-dark`；白色/浅色背景使用 `camera-light`
4. **禁用时机**：已达到最大选择数量时，对未选中格设置 `disabled=on`

### 15.2 上传卡片使用规则

1. **卡片类型选择**：
   - 通用图片上传 → `ImageUploadCard`（常规型）
   - 视频上传 → `VideoUpload`
   - 仅触发入口（不展示已上传内容在同区域）→ `ImageUpload`
   - 证件（身份证/护照/驾照等）→ `IdCardUpload`（证件型）
2. **失败类型区分**：证件型区分"模糊不完整"和"网络错误"两种失败，其他类型统一展示失败态
3. **强文字（strongText）**：上传成功后如需引导用户"重新上传"等操作，使用强文字覆盖底部

### 15.3 常见组合示例

```
// 场景 1：社区动态发图（图片多选，数字型排序，最多 9 张）
<ImagePickerGrid>
  <MediaPickerCell mediaType="camera-light" />
  {photos.map((p, i) => (
    <MediaPickerCell
      mediaType="photo"
      thumbnailUrl={p.url}
      selected={selectedIds.includes(p.id)}
      selectionType="number"
      selectedIndex={selectedIds.indexOf(p.id) + 1}
      disabled={selectedIds.length >= 9 && !selectedIds.includes(p.id)}
    />
  ))}
</ImagePickerGrid>

// 场景 2：商品图片上传（常规型，上传中/成功/失败状态）
<ImageUploadCard
  state={uploadState}
  imageUrl={uploadedUrl}
  onPress={handlePickImage}
  onDelete={handleDelete}
  onRetry={handleRetry}
/>

// 场景 3：身份证实名认证（证件型）
<IdCardUpload
  state={verifyState}
  imageUrl={idCardUrl}
  onPress={handlePickIdCard}
  onDelete={handleDelete}
  onRetry={handleRetry}
/>
```

---

## 16. 与其他组件的关系

| 关联组件 | 关系说明 |
|----------|----------|
| `badge` | 选中序号数字可参考 Badge 数字样式（黄色背景圆形），但通常内嵌实现 |
| `half-screen-dialog` | 图像选择界面通常以半页弹窗形式呈现，选图格在弹窗内网格布局 |
| `button` | 上传卡片内重试按钮参考 Button 组件规范（全圆角，白色） |
| `navigation` | 图像选择全屏时，顶部有导航栏（含已选数量和确认按钮） |
