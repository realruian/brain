# Tooltip 气泡提示

> **组件分类**：Component（组件级）
> **定义**：气泡提示用于吸引用户关注被指向的页面元素，提供简短操作引导或拓展说明。通过尖角（三角指针）指向被引导项，通常由系统触发出现，用户操作或超时后消失。
> **Style 依赖**：`color-semantic.md` · `font-semantic.md` · `spacing-semantic.md` · `component-spacing.md` · `radius-semantic.md` · `shadow-semantic.md` · `stroke-semantic.md`
> ⚠️ 本组件**不使用** `component-radius.md`（该文件仅用于 ≤ 4pt 组件内部细粒度圆角，本组件无此需求）

> ⚠️ **核心约束**：
> - 气泡提示分为**常规型**（基础型 + 自定义型）和**内容型**两大类；规范组件仅提供常规型
> - 图标、按钮、关闭图标均可根据实际需要**独立开启/关闭**
> - 文案**不建议超过 2 行**
> - 气泡宽度最大时应与**页边距保持一致**
> - 尖角默认与气泡**水平方向居中**对齐，可根据被指引项位置调整

---

## 0. 图标 / 间距 / Ownership 约束

- **icon-route（默认）**：Tooltip 内功能图标默认回 `component/atoms/icon.md`，并沿用正文 iconfont class / weight。
- **fixed-asset 例外**：尖角、close icon、URL 切图及 CSS/SVG 降级位点属于 fixed-asset 或显式例外，必须按正文路由渲染。
- **spacing-owner（归属）**：Tooltip 气泡内部 slot、按钮区间距、容器 padding/对齐归 Tooltip；页面浮层定位留白归宿主。
- **宿主裁决（优先级）**：冲突按 `宿主 > 组合场景 > Tooltip`，避免把通用图标包装规则套到特殊位点。
- **不可跳步**：先回 `references/INDEX.md` 完成区域路由与宿主锁定，再用 `component-quickref.md` 做宿主级收敛；本文件仅承接组件内 ownership 细则，不承担前置路由改判；不得凭语义猜测。


## 1. 组件大类（tooltipType）

> **SVCS — Structure / Slot 层**：定义组件顶层结构变体。

| tooltipType | 名称 | 左侧区域 | 适用场景 |
|-------------|------|---------|---------|
| `basic` | 常规基础型 | 图标（可选） + 文案 | 操作引导、简短说明，适合大多数场景 |
| `custom` | 常规自定义型 | 自定义内容区 + 文案 | 红包/卡券等富内容展示，图片/动图配合文字 |

> **选型原则**：
> - 纯文字引导、操作说明 → `basic`（常规基础型）
> - 需要展示图片/卡券/动图等丰富内容 → `custom`（常规自定义型）
> - 内容型气泡提示（完全自定义布局）→ 使用单独的**尖角组件**自行组装

---

## 2. 容器主题（theme）

> **SVCS — Variant 层**：视觉外观变体，影响背景色和文字色。

| theme | 名称 | 背景色 | 文字/图标色 | 尖角色 | 投影 | 适用场景 |
|-------|------|-------|-----------|-------|------|---------|
| `dark` | 深色容器 | `#000000CC`（80% 不透明度黑色） | `#FFFFFF` | `#000000CC` | 无 | 推荐，通用场景，视觉突出 |
| `light` | 浅色容器 | `#FFFFFF` | `#111111` | `#FFFFFF` | `shadow-overlay` | 浅色背景中使用，靠投影与背景区分层级 |

> ⚠️ **浅色容器必须加投影**：`light` 主题背景色为白色，在浅色页面背景上会失去边界感，必须通过 `shadow-overlay` 体现浮层层级。`dark` 主题依靠背景色本身区分，无需投影。

---

## 3. 行数（rowCount）

> **SVCS — Variant 层**：内容行数变体，影响高度与文案折行行为。

| rowCount | 名称 | 文案要求 | 说明 |
|----------|------|---------|------|
| `single` | 单行 | 文案在一行内展示，**不能折行** | 适用于简短引导说明（≤20字） |
| `double` | 双行 | 文案最多展示两行 | 适用于稍长的引导内容（21-40字） |

> ⚠️ **单行和双行实现逻辑不同**：单行文本为**适应内容**宽度，双行文本为**充满容器**宽度，调整宽度时请注意差异。

---

## 4. 尺寸（size）

> **SVCS — Variant 层**：尺寸变体，影响内容容器高和上下内边距。

| size | 名称 | 上下内边距 | 内容容器高（单行） | 内容容器高（双行） | 总高（单行含尖角） | 总高（双行含尖角） | 说明 |
|------|------|-----------|---------------|---------------|----------------|----------------|------|
| `loose` | 宽松 | 10pt（20px @2x） | **36pt**（72px @2x） | **52pt**（104px @2x） | **42pt**（84px @2x） | **58pt**（116px @2x） | 推荐，适用于大部分页面场景 |
| `medium` | 适中 | 8pt（16px @2x） | **32pt**（64px @2x） | **48pt**（96px @2x） | **38pt**（76px @2x） | **54pt**（108px @2x） | 适用于需遮挡较少或文案较少的场景 |

> ℹ️ **内容容器高 = 上下 padding × 2 + 内容净高**（如 loose 单行：10+16+10=36pt，双行：10+32+10=52pt）。总高 = 内容容器高 + 尖角占位高 6pt。

> ✅ **推荐**：宽松（`spacing-m` = 10pt）适用于大部分场景。
> 左右内边距：均为 **12pt**（`spacing-l`，24px @2x）。
> 尖角宽度：**16pt**（32px @2x），高度 **6pt**（12px @2x）。

---

## 5. 尖角位置（arrowPosition）

> **SVCS — Variant 层**：位置变体，影响尖角渲染位置。

| arrowPosition | 名称 | 尖角所在区域 | 说明 |
|--------------|------|-----------|------|
| `top` | 尖角在上 | 气泡顶部（"顶部区域"） | 气泡在被引导项下方 |
| `bottom` | 尖角在下 | 气泡底部（"底部区域"） | 气泡在被引导项上方 |

> **尖角对齐规则**：
> - 默认：尖角与气泡**水平方向居中**对齐
> - 实际使用时，尖角应与被引导项**水平方向居中**对齐
> - 距被引导项 **4pt**（`spacing-2xs`），与气泡边缘间距 **≥ 12pt**（`spacing-l`）
> - 被引导项靠近屏幕边缘时，允许尖角与气泡保持 12pt 间距后与被引导项不完全对齐
> - 也可解绑组件后，将尖角调整至气泡左侧（或右侧），与被引导项竖直方向居中对齐

> ⚠️ **`arrowPosition=top` 时尖角必须在上层渲染**：`light` 主题的 `tooltip-content` 带有 `box-shadow`（`shadow-overlay`），其阴影会向上扩散遮盖尖角。实现时须给 `tooltip-arrow` 设置 `position: relative; z-index: 1`，确保尖角在内容容器阴影之上可见。`arrowPosition=bottom` 时尖角位于内容容器之后，不受此影响。CSS 写法示例：
> ```css
> [data-arrow-position="top"] [data-slot="tooltip-arrow"] {
>   position: relative;
>   z-index: 1;
> }
> ```

---

## 6. 尖角规格

> **SVCS — Structure 层**：固定结构元素的精确尺寸。

| 属性 | 值（@1x） | 值（@2x） | Token 引用 | 说明 |
|------|----------|----------|-----------|------|
| 尖角宽度 | **16pt** | 32px | — | 固定尺寸，不建议调整 |
| 尖角高度（图形自身） | **6pt** | 12px | — | 固定尺寸，不建议调整 |
| 尖角颜色 | 与气泡背景色一致 | — | `mask-heavy` / `white` | 深色容器：`#000000CC`（80%黑）；浅色容器：`#FFFFFF` |
| 尖角所在区域 frame 占位高 | **6pt** | 12px | `spacing-xs` | 尖角占位区（上/下区域）高度，与尖角图形等高 |

> **@2x 组件集代码验证值（来自实际设计稿代码）**：尖角 frame 高 `12px`，内容容器圆角 `border-radius: 16px`（radius-s = 8pt × 2）；宽松尺寸 padding `20px 24px`，适中尺寸 padding `16px 24px`；图标区 `30×30px`；按钮 `min-width:84px; height:40px`（自适应文字宽度），`border-radius: 9999px`；浅色投影 `box-shadow: 0px 8px 32px 0px rgba(0, 0, 0, 0.12)`。
> **关闭图标 iconfont class**：使用 `icon-iconfont-cancel-line-semibold`（对应字符 `\e051`）；❌ 不得使用 `icon-iconfont-close-line-semibold`（该 class 在字体文件中不存在）。

> 内容型气泡提示的尖角使用同款尖角组件（`COMPONENT_SET "尖角"`），颜色可自定义。
>
> ✅ **尖角实现方式：优先使用 URL 图片**；若 URL 不可用（网络受限/离线环境），可降级用 CSS border-trick 或 SVG 代码模拟。
> 切图资源（@2x PNG，`width: 32px; height: 12px`）：
>
> | 主题 | 方向 | URL |
> |------|------|-----|
> | 深色 | 尖角在下（`arrowPosition=bottom`） | `https://p0.meituan.net/ingee/fc3c9d5d62d59c579afbf95fc4d85889315.png` |
> | 深色 | 尖角在上（`arrowPosition=top`） | `https://p0.meituan.net/ingee/d3e79e33bf811316bef555e75765fa46314.png` |
> | 浅色 | 尖角在下（`arrowPosition=bottom`） | `https://p0.meituan.net/ingee/7b50133522a83723deaa699a6d78e14c261.png` |
> | 浅色 | 尖角在上（`arrowPosition=top`） | `https://p0.meituan.net/ingee/b31962020be4e23a69a850092e36b876267.png` |

---

## 7. 结构规格

> **SVCS — Structure / Slot 层**：描述组件 Slot 组合方式及精确布局。

### 7.1 常规基础型（tooltipType=basic）内部结构

```
[顶部区域（尖角在上时）] 占位区高 6pt（12px @2x，spacing-xs）+ 尖角图形 16×6pt
[内容容器] border-radius: radius-s（8pt，16px @2x），上下 padding: size 决定，左 padding: spacing-l（12pt，24px @2x），右 padding: 0
  ⚠️ 右 padding 由内层 wrapper 的 padding-right 承担（见下），不在容器本身设置
  align-items: center（所有子元素与文案区域上下居中对齐）
  column-gap: spacing-2xs（4pt，8px @2x，图标区与组合区之间）
  [图标区] 15×15pt（30×30px @2x，可选），align-self: center
  [组合区 wrapper] flex: 1; min-width: 0; padding-right: spacing-l（24px @2x）← 此处承担整体右边距（无关闭区时）
    [文案] 12pt / 行高 16pt（24px / 32px @2x）（单行 white-space: nowrap；双行 width: 336px，flex-shrink: 0，外层容器自适应）
    [按钮区] 可选，flex-shrink: 0，左 margin: spacing-l（12pt，24px @2x，文案与按钮的间距）
      操作按钮: min-width: 84px，height: 40px（宽度随文字内容自适应，最小 84px），border-radius: 9999px，padding: cs-2.5 spacing-s（5px 16px @2x）
    [关闭区] 可选，flex-shrink: 0，左 padding: spacing-l（24px @2x），右 padding: spacing-l（24px @2x）← 有关闭区时由此承担整体右边距，占位 width: 24px / height: 24px（@2x）；通过 align-items: center 与文案垂直居中
[底部区域（尖角在下时）] 占位区高 6pt（12px @2x，spacing-xs）+ 尖角图形 16×6pt
```

> **注意**：图标区（`tooltip-icon`）与右侧组合区的间距通过外层内容容器的 `column-gap: spacing-2xs`（8px @2x / 4pt）实现；❌ **图标区自身不加 `margin-right`**，否则与容器 `column-gap` 叠加导致间距翻倍。左边距 `spacing-l`（24px @2x / 12pt）由容器承担。**右边距承担规则**：
> - 无关闭区：由组合区 wrapper 的 `padding-right: 24px` 承担
> - 有关闭区：wrapper 的 `padding-right` 改为 **`0`**，由关闭区的 `padding-left: 24px` 承担按钮→关闭间距，`padding-right: 24px` 承担整体右边距；❌ 若 wrapper 保持 `padding-right: 24px` 不变，按钮右侧会出现多余空白
> ⚠️ **内容容器不设右 padding**：正确写法：容器 `padding: 20px 0 20px 24px`，右边距由组合区 wrapper 或关闭区承担。
> 图标尺寸：15×15pt（30×30px @2x）；**不使用 12×12pt 图标**，设计规范中均为 30px @2x。
> **双行对齐**：内容容器设置 `align-items: center`，左侧图标区和右侧关闭图标区均与双行文案**上下居中**对齐；单行同理。

### 7.2 常规自定义型（tooltipType=custom）内部结构

```
[顶部区域（尖角在上时）] 占位区高 6pt（12px @2x，spacing-xs）+ 尖角图形 16×6pt
[内容容器] 横向排列，整体无外 padding，内部由左右分区承担
  [左区] border-radius: 16px 0 0 16px（左两角 radius-s = 8pt×2），自定义内容区（图片/动图/卡券等）
    左区为正方形，宽 = 内容容器高度（随 size 变化）
    loose 单行：36×36pt（72×72px @2x）
    loose 双行：52×52pt（104×104px @2x）
    medium 单行：32×32pt（64×64px @2x）
    medium 双行：48×48pt（96×96px @2x）
    左区内部 padding：无（内容通过绝对定位实现溢出效果）
    图片内容从底部溢出对齐：position: absolute; left: 16px（@2x）; bottom: 0; overflow: hidden
      loose 单行图片占位容器：64×84px @2x（图片宽=左区宽-32px，高=含尖角总高）
      loose 双行图片占位容器：88×116px @2x
      medium 单行图片占位容器：64×76px @2x（参考值）
      medium 双行图片占位容器：88×108px @2x（参考值）
  [右区] border-radius: 0 16px 16px 0（右两角 radius-s = 8pt×2），上下 padding: size 决定（loose: 20px；medium: 16px），左 padding: 0
    右 padding: 有关闭区时为 0（由关闭区的 padding-right: 24px 承担）；无关闭区时为 24px
    overflow: hidden；column-gap: 8px（与图标gap一致）
    [组合区 wrapper] flex: 1; min-width: 0
      [文案] 12pt / 行高 16pt（24px / 32px @2x）
      [按钮区] 可选（同 basic 型规格）
    [关闭区] 可选，在组合区 wrapper 外（右区的直接子元素），左 padding: spacing-l（24px @2x），右 padding: spacing-l（24px @2x）← 承担右边距
[底部区域（尖角在下时）] 占位区高 6pt（12px @2x，spacing-xs）+ 尖角图形 16×6pt
```

> ⚠️ **重要**：左区为**正方形**，宽 = 内容容器高度。loose 尺寸：单行 **36×36pt**，双行 **52×52pt**；medium 尺寸：单行 **32×32pt**，双行 **48×48pt**。
> 左区内部**无额外 padding**，图片通过绝对定位实现视觉溢出效果：`position: absolute; left: 16px(@2x); bottom: 0; overflow: hidden`。图片容器宽 = 左区宽 − 32px（两侧各16px留白），高 = 组件总高度（含尖角12px），从底部向上溢出超出气泡顶/底边缘。
> 右区 padding：左0、上下 loose 用 `spacing-m`（20px@2x）/ medium 用 `spacing-s`（16px@2x）；右边距承担规则同 basic 型——有关闭区时右区 `padding-right: 0`，由关闭区（右区的直接子元素）的 `padding-right: spacing-l`（24px@2x）承担；无关闭区时右区 `padding-right: spacing-l`（24px@2x）。

### 7.3 按钮区规格（可选）

| 属性 | 值（@1x） | 值（@2x） | Token 引用 |
|------|----------|----------|-----------|
| 按钮尺寸 | min-width: 42pt，height: 20pt | `min-width: 84px; height: 40px`（宽度随文字自适应，最小 84px） | — |
| 按钮圆角 | 胶囊形 | `border-radius: 9999px`（按钮高 40px 时实际渲染为 20px） | `radius-full` |
| 按钮内边距 | 2.5pt 8pt | 5px 16px | `cs-2.5` `spacing-s` |
| 按钮字号 | 11pt | 22px | `caption-l-22-medium` |
| 按钮行高 | 16pt | 32px | — |
| 按钮字重 | 500（Medium） | — | — |
| 按钮字色 | `#111111`（`text-primary`） | — | `text-primary` |
| 按钮与文案间距（左 padding） | 12pt | 24px | `spacing-l` |
| 按钮背景色 | `linear-gradient(135deg, rgba(255,231,77,1) 0%, rgba(255,221,0,1) 100%)`（等价于 `to bottom right` / `#FFE74D → #FFDD00`） | — | `gradient-yellow` |

### 7.4 气泡宽度规则

| 场景 | 宽度 |
|------|------|
| 基础型单行（适应内容） | `white-space: nowrap`，随文案长度自适应 |
| 基础型双行（充满容器） | 文案 span 固定 `width: 336px`（168pt @1x），`flex-shrink: 0`；整体 tooltip 宽度随内容自适应（文案 336px + 按钮宽 + 关闭区宽）|
| 自定义型组件集参考宽度 | 单行: 298pt（596px @2x）；双行: 310pt（620px @2x）|
| 最大宽度 | 与页面左右边距保持一致（如 375pt - 24pt = 351pt） |
| 调整方式 | 拖拽组件边框（单行自适应）/ 固定宽度（双行） |

> **组件集整体画框参考尺寸（@2x，来自实际设计稿代码）**：
> - 基础型: 1436×880px（单行组件集）、1436×1008px（双行组件集）
> - 自定义型: 1520×408px（单行组件集）、1520×472px（双行组件集）
>
> **自定义型组件宽度（@2x）**：单行 596px（298pt @1x）、双行 620px（310pt @1x）。左区宽：loose 单行 80px、loose 双行 104px；medium 单行 64px、medium 双行 96px。
> 左区内图片 frame：以 `position: absolute; left: 16px; bottom: 0` 定位，图片高度等于组件总高（含尖角 12px），宽度 = 左区宽 - 32px（左右各 16px 留白）。

---

## 8. Token 引用

> **SVCS — Style 层**：完整三层引用路径 Reference → Semantic → Component。
> 本组件无自定义 Component Token（全部直接使用 Semantic Token），引用链为 **Reference → Semantic → 直接使用**。
> `component-radius.md` 仅用于 ≤ 4pt 细粒度圆角，本组件不使用；`component-spacing.md` 仅用于 spacing-semantic 未覆盖的细粒度间距（如 `cs-2.5`）。

### 8.1 颜色 Token（Reference → Semantic）

| 用途 | Semantic Token | Reference 路径 | 值 |
|------|---------------|---------------|-----|
| 深色容器背景 / 尖角 | `mask-heavy` | `Color/Neutral/.Black-Opacity-80` | `rgba(0,0,0,0.8)`（`#000000CC`） |
| 浅色容器背景 / 尖角 | `white` | `Color/Neutral/.White` | `#FFFFFF` |
| 深色容器文字 | `white` | `Color/Neutral/.White` | `#FFFFFF` |
| 浅色容器文字/图标 | `text-primary` | `Color/Neutral/.Grey-1` | `#111111` |
| 关闭图标色 | `text-tertiary` | `Color/Neutral/.Grey-3` | `#888888`（固定，不随 `theme` 变化；❌ 不得使用 `#999999`，那是 `Grey-4` = `text-quaternary`） |
| 按钮文字色 | `text-primary` | `Color/Neutral/.Grey-1` | `#111111` |
| 按钮背景 | `gradient-yellow` | `Color/Gradient Color/.Yellow` | `linear-gradient(135deg, rgba(255,231,77,1) 0%, rgba(255,221,0,1) 100%)` |

> **关闭图标占位区实际尺寸（@2x 代码值）**：`width: 48px; height: 24px`（对应 @1x：24pt × 12pt）。规范描述中「占位宽 24pt，高 16pt」中的高度以实际组件集 @2x 代码为准（24px = 12pt），请在生成代码时以此为准。

### 8.2 字体 Token（Reference → Semantic）

| 用途 | Semantic Token | Reference 路径 | 字号（@2x） | 字号（@1x） | 字重 | 行高（@2x） |
|------|---------------|---------------|------------|------------|------|------------|
| 气泡提示文案 | `body-s-12-regular` | `Font/Text Font/.24-Regular` | 24px | 12pt | 400 | 32px |
| 操作按钮文字 | `caption-l-11-medium` | `Font/Text Font/.22-Medium` | 22px | 11pt | 500 | 32px |

> 字体均使用 `"PingFang SC"`（含完整 fallback 链）。

### 8.3 间距 Token（Reference → Semantic / component-spacing）

> **引用规则**：与 `spacing-semantic.md` 有对应档位时优先引用语义层（Reference → Semantic）；仅 spacing-semantic 未覆盖的组件内部细粒度值（如 2.5pt）从 `component-spacing.md` 引用 `cs-*`（Reference → component-spacing）。

| 用途 | Token 引用 | Reference 路径 | @1x 值 | @2x 值 | 来源 |
|------|-----------|---------------|--------|--------|------|
| 左右内边距 | `spacing-l` | `Grid Spacing/.12pt` | 12pt | 24px | `spacing-semantic.md` |
| 宽松上下内边距 | `spacing-m` | `Grid Spacing/.10pt` | 10pt | 20px | `spacing-semantic.md` |
| 适中上下内边距 | `spacing-s` | `Grid Spacing/.8pt` | 8pt | 16px | `spacing-semantic.md` |
| 图标区与组合区 column-gap | `spacing-2xs` | `Grid Spacing/.4pt` | 4pt | 8px | `spacing-semantic.md`（❌ 图标区自身不加 `margin-right`） |
| 按钮/关闭区与文案间距（左 padding） | `spacing-l` | `Grid Spacing/.12pt` | 12pt | 24px | `spacing-semantic.md` |
| 按钮上下内边距 | `cs-2.5` | —（component-spacing 细粒度档位） | 2.5pt | 5px | `component-spacing.md` |
| 按钮左右内边距 | `spacing-s` | `Grid Spacing/.8pt` | 8pt | 16px | `spacing-semantic.md`（与 `cs-8` 等值，优先语义层） |
| 尖角与被引导项间距（垂直方向） | `spacing-2xs` | `Grid Spacing/.4pt` | 4pt | 8px | `spacing-semantic.md` |
| 尖角 frame 占位高 | `spacing-xs` | `Grid Spacing/.6pt` | 6pt | 12px | `spacing-semantic.md` |
| 尖角与气泡边缘最小间距 | `spacing-l` | `Grid Spacing/.12pt` | 12pt | 24px | `spacing-semantic.md` |
| 自定义型图片左侧留白（left 偏移） | `spacing-l` | `Grid Spacing/.12pt` | 8pt | 16px | `spacing-semantic.md`（图片 `left:16px @2x`，@1x = 8pt）|

### 8.4 圆角 Token（Reference → radius-semantic.md）

> **引用规则**：气泡容器（8pt）和按钮（`radius-full`）均从 `radius-semantic.md` 引用；**`component-radius.md` 仅用于 ≤ 4pt 组件内部细粒度圆角，本组件不使用**。

| 用途 | Semantic Token | @1x 值 | @2x 值 | 来源 |
|------|---------------|--------|--------|------|
| 气泡内容容器 | `radius-s` | 8pt | 16px | `radius-semantic.md` |
| 操作按钮（胶囊形） | `radius-full` | — | 9999px（clamp 为 20px，呈胶囊形） | `radius-semantic.md` |
| 气泡容器胶囊变体（可选） | `radius-full` | — | 9999px（整体呈胶囊形，替换 `radius-s`） | `radius-semantic.md` |

### 8.5 投影 Token（Reference → shadow-semantic.md）

| 用途 | Semantic Token | 实际 CSS 值（@2x） | 来源 |
|------|---------------|------------------|------|
| 浅色容器（`theme=light`）投影 | `shadow-overlay` | `box-shadow: 0px 8px 32px 0px rgba(0, 0, 0, 0.12)` | `shadow-semantic.md` |
| 深色容器（`theme=dark`） | 无投影 | — | — |

---

## 9. Props API（供 AI 生码参考）

```typescript
export type TooltipProps = {
  /**
   * 气泡提示类型
   * @default "basic"
   */
  tooltipType?: "basic" | "custom";

  /**
   * 容器主题（深色 / 浅色）
   * @default "dark"
   */
  theme?: "dark" | "light";

  /**
   * 行数
   * @default "single"
   */
  rowCount?: "single" | "double";

  /**
   * 尺寸（宽松 / 适中）
   * @default "loose"
   */
  size?: "loose" | "medium";

  /**
   * 尖角位置
   * @default "bottom"
   */
  arrowPosition?: "top" | "bottom";

  /**
   * 文案内容
   */
  content: string;

  /**
   * 左侧图标（可选，basic 类型时有效）
   */
  icon?: React.ReactNode;

  /**
   * 自定义左侧内容（tooltipType=custom 时有效）
   */
  customContent?: React.ReactNode;

  /**
   * 操作按钮文字（可选）
   */
  buttonText?: string;

  /**
   * 是否显示关闭图标
   * @default false
   */
  showClose?: boolean;

  /**
   * 点击操作按钮的回调
   */
  onButtonPress?: () => void;

  /**
   * 点击关闭图标的回调
   */
  onClose?: () => void;

  /**
   * 气泡宽度（可选，不设置则自适应）
   */
  width?: number;
};
```

---

## 10. data-attribute 规范

> **SVCS — Structure / Slot 层**：每个 Slot 对应唯一 data-attribute，供样式查询和测试。

| 属性 | 值 | 说明 |
|------|----|------|
| `data-slot` | `"tooltip"` | 组件根容器 |
| `data-slot` | `"tooltip-arrow"` | 尖角（顶部/底部区域） |
| `data-slot` | `"tooltip-content"` | 内容容器 |
| `data-slot` | `"tooltip-icon"` | 左侧图标区 |
| `data-slot` | `"tooltip-text"` | 文案区域 |
| `data-slot` | `"tooltip-button"` | 操作按钮 |
| `data-slot` | `"tooltip-close"` | 关闭图标 |
| `data-slot` | `"tooltip-custom"` | 自定义左侧内容区 |
| `data-tooltip-type` | `"basic"` / `"custom"` | 类型 |
| `data-theme` | `"dark"` / `"light"` | 容器主题 |
| `data-row-count` | `"single"` / `"double"` | 行数 |
| `data-size` | `"loose"` / `"medium"` | 尺寸 |
| `data-arrow-position` | `"top"` / `"bottom"` | 尖角位置 |

---

## 11. 无障碍（Accessibility）

- 气泡容器：`role="tooltip"` / `aria-live="polite"`
- 关闭按钮：`aria-label="关闭气泡提示"`
- 操作按钮：`aria-label` 与按钮文字一致
- 尖角元素：`aria-hidden="true"`（装饰性元素）
- 触发项：`aria-describedby` 指向气泡 ID

---

## 12. 变体矩阵（完整 MECE）

> **SVCS — Variant 层**：所有 Prop 组合的完整枚举，确保每种变体均被覆盖。

### 常规基础型（tooltipType=basic）

| size | rowCount | theme | arrowPosition | 内容容器高 | 总高度 |
|------|----------|-------|--------------|---------|------|
| `loose` | `single` | `dark` | `top` / `bottom` | 36pt | **42pt** |
| `loose` | `single` | `light` | `top` / `bottom` | 36pt | **42pt** |
| `loose` | `double` | `dark` | `top` / `bottom` | 52pt | **58pt** |
| `loose` | `double` | `light` | `top` / `bottom` | 52pt | **58pt** |
| `medium` | `single` | `dark` | `top` / `bottom` | 32pt | **38pt** |
| `medium` | `single` | `light` | `top` / `bottom` | 32pt | **38pt** |
| `medium` | `double` | `dark` | `top` / `bottom` | 48pt | **54pt** |
| `medium` | `double` | `light` | `top` / `bottom` | 48pt | **54pt** |

> 每种组合下，图标/按钮/关闭图标可独立开启或关闭，共 8 种基础变体 × 可选元素组合。

### 常规自定义型（tooltipType=custom）

| size | rowCount | theme | arrowPosition | 内容容器高 | 总高度（@1x） | 总高度（@2x） |
|------|----------|-------|--------------|---------|------------|------------|
| `loose` | `single` | `dark` / `light` | `top` / `bottom` | 36pt | **42pt** | 84px |
| `loose` | `double` | `dark` / `light` | `top` / `bottom` | 52pt | **58pt** | 116px |
| `medium` | `single` | `dark` / `light` | `top` / `bottom` | 32pt | **38pt** | 76px |
| `medium` | `double` | `dark` / `light` | `top` / `bottom` | 48pt | **54pt** | 108px |

> 自定义型右侧区域 padding：loose 上下 `spacing-m`（10pt），medium 上下 `spacing-s`（8pt），右均为 `spacing-l`（12pt），左 0。
> 左侧自定义区域为**正方形**（宽 = 内容容器高）：loose 单行 **36×36pt**（72×72px @2x），loose 双行 **52×52pt**（104×104px @2x）；medium 单行 **32×32pt**，medium 双行 **48×48pt**。

---

## 13. 使用约束（AI 生成时的硬性规则）

> **SVCS — Constraint 层**：所有不可违反的布局与样式硬性规则。

1. **文案不超过 2 行**：超过 2 行时需截断处理
2. **单行不换行**：单行类型（`rowCount=single`）文案必须设置 `white-space: nowrap`
3. **尖角尺寸固定**：16×6pt（32×12px @2x），颜色与气泡背景一致，**不建议调整尺寸**
4. **尖角边缘间距 ≥ 12pt**（`spacing-l`）：尖角水平位置与气泡左右边缘最小间距为 12pt
5. **最大宽度受页边距限制**：气泡宽度最大不超过 `页面宽度 - 2 × 页边距`
6. **按钮文字色固定为 #111111**：无论容器深浅，按钮内文字颜色均为 `text-primary`（`#111111`）
7. **关闭图标色固定为 #999999**：对应 `text-tertiary`，不随主题变化
8. **深色背景使用 80% 不透明黑**：必须使用 `rgba(0, 0, 0, 0.8)`（`mask-heavy`），不得使用纯黑 `#000000`
9. **浅色容器必须加投影**：`theme=light` 时必须添加 `shadow-overlay`；`theme=dark` 时不加投影，❌ 两者不得互换
10. **圆角默认 radius-s（8pt）**：气泡容器默认圆角为 `radius-s`（8pt），可根据场景调整为更大的值（如 `radius-full` 胶囊形气泡），但不建议减小
11. **自定义型左区为正方形**：宽 = 内容容器高度。loose 单行 **36×36pt（72×72px @2x）**，loose 双行 **52×52pt（104×104px @2x）**；medium 单行 **32×32pt**，medium 双行 **48×48pt**；左区内部**无额外 padding**，图片通过绝对定位底部溢出对齐：`position: absolute; left: 16px(@2x); bottom: 0; overflow: hidden`，图片容器高度 = 组件含尖角总高，宽度 = 左区宽 − 32px（@2x）；右区上下 padding：loose 20px / medium 16px（@2x），右 24px，左 0
12. **按钮背景色**：一律使用黄色渐变 `linear-gradient(135deg, rgba(255, 231, 77, 1) 0%, rgba(255, 221, 0, 1) 100%)`（`gradient-yellow`），不随主题深浅变化；⚠️ 与 `to bottom right` 完全等价（135deg = to bottom right），两者均可使用；实际组件集代码采用 `135deg` 写法
13. **按钮圆角**：使用 `radius-full`（`border-radius: 9999px`），呈胶囊形；`component-radius.md` 的 `cr-*` 仅用于 ≤ 4pt 细粒度圆角，❌ 不得用于按钮
14. **尖角优先用 URL 图片**：优先使用 §6 切图资源表中的 CDN 链接（`<img>` 标签，`width:32px; height:12px`）；仅在 URL 不可用时，才降级用 CSS border-trick 或 SVG 代码模拟
15. **内容容器右 padding 必须由最右子元素承担**：`tooltip-content` 容器的 `padding` 只设左（和上下），右侧设为 `0`；右边距规则：
    - 无关闭区：wrapper `padding-right: 24px` 承担
    - 有关闭区：wrapper `padding-right: 0`，关闭区 `padding-left: 24px` 承担按钮→图标间距，`padding-right: 24px` 承担整体右边距
    - ❌ 禁止 wrapper 在有关闭区时仍保持 `padding-right: 24px`，否则按钮右侧出现多余空白
    - custom 型同理，右区 `padding-right` 有关闭区时为 `0`，无关闭区时为 `24px`
16. **`arrowPosition=top` 时尖角必须提升层级**：尖角（`tooltip-arrow`）在 DOM 中位于 `tooltip-content` 之前（上方），但 `light` 主题的 `tooltip-content` 带有 `box-shadow`，阴影向上扩散会遮盖尖角。**必须**给 `[data-arrow-position="top"] [data-slot="tooltip-arrow"]` 设置 `position: relative; z-index: 1`，使尖角在阴影层之上渲染。`arrowPosition=bottom` 时尖角在 DOM 末尾，不受此问题影响

---

## 14. 交互行为规范

| 行为 | 说明 |
|------|------|
| **出现时机** | 由系统自动触发（如进入页面、到达关键节点） |
| **消失时机** | 用户点击关闭图标 / 点击操作按钮 / 超时自动消失 / 点击气泡外区域 |
| **遮挡原则** | 气泡应尽量减少对核心内容的遮挡，优先选择适中尺寸 |
| **尖角与被引导项的间距** | `spacing-2xs`（4pt，垂直方向），水平方向居中对齐 |

---

## 15. 常见组合示例

### 15.1 操作引导（常规基础型，深色，单行，宽松，尖角在下）

```
Tooltip
  tooltipType: basic
  theme: dark
  rowCount: single
  size: loose
  arrowPosition: bottom
  content: "点击这里查看订单详情"
  showClose: true
  onClose: () => dismissTooltip()
```

### 15.2 功能说明（常规基础型，浅色，双行，宽松，尖角在上，带图标和按钮）

```
Tooltip
  tooltipType: basic
  theme: light
  rowCount: double
  size: loose
  arrowPosition: top
  icon: <InfoIcon />
  content: "当前版本已更新，点击了解新功能详情，获得更好的使用体验"
  buttonText: "了解更多"
  showClose: true
  onButtonPress: () => navigateToUpdate()
  onClose: () => dismissTooltip()
```

### 15.3 卡券展示（常规自定义型，深色，双行，尖角在下）

```
Tooltip
  tooltipType: custom
  theme: dark
  rowCount: double
  arrowPosition: bottom
  customContent: <CouponImage />
  content: "您有一张专属优惠券，下单立减5元"
  buttonText: "立即使用"
  onButtonPress: () => applyDiscount()
```

---

## 16. 与其他组件的关系

| 关联组件 | 关系说明 |
|----------|----------|
| `button.md` | 操作按钮区域使用原子层小号胶囊操作按钮（42×20pt，圆角 `radius-full`） |
| `dialog.md` / `bottom-sheets.md` | 气泡提示与弹窗不同，气泡为轻量引导，不阻断主流程 |
| `toast.md` | Toast 用于全局轻提示，气泡提示用于特定元素的局部引导 |
