# Text Input 文本输入框

> **组件分类**：Component（组件级）
> **定义**：文本输入框是一种允许用户在区域内输入或编辑文本、数值等内容的组件，通常用于信息录入、会话等场景。
> **Style 依赖**：`color-semantic.md` · `font-semantic.md` · `spacing-semantic.md` · `component-spacing.md` · `radius-semantic.md` · `component-radius.md` · `stroke-semantic.md`

---

## 0. 图标 / 间距 / Ownership 约束

- **icon-route（默认）**：本组件内功能图标默认回 `component/atoms/icon.md`，并沿用本文件已声明的 iconfont class / weight。
- **fixed-asset 例外**：若正文已指定 `assets/*.svg`、官方 SVG、PNG/CDN 切图、URL 尖角资源或固定插画，该位点必须走固定资产，不得强行回 iconfont；输出时可标注 `icon-route=fixed-asset`。
- **spacing-owner（归属）**：组件内部 slot、行内/容器内 gap、padding、对齐归本组件；页面边距、吸顶/吸底占位、列表外层留白归宿主。
- **宿主裁决（优先级）**：冲突遵循 `宿主 > 组合场景 > 本组件通用规则`，子组件仅拥有自身内部样式，不反向改宿主排布。
- **不可跳步**：先回 `references/INDEX.md` 完成区域路由与宿主锁定，再用 `component-quickref.md` 做宿主级收敛；本文件仅承接组件内 ownership 细则，不承担前置路由改判；不得凭语义猜测。

## 1. 组件大类（category）

| category | 名称 | 说明 | 典型场景 |
|----------|------|------|---------|
| `message` | 消息输入型 | 用于对话场景，支持可选发送按钮，分大号和标准两种尺寸 | 客服对话、AI 帮办、评论发布 |
| `review` | 评价模块型 | 用于评价场景，带字数限制指示器，支持多行扩展，分卡片型（白底/灰底）和白底通栏型三种变体 | 订单评价、商品评价、维度评分组合 |

---

## 2. 消息输入型（category=message）

### 2.1 尺寸（size）

| size | 名称 | 单行容器高度 | 文字字号 | 外层容器圆角 | 内层输入区圆角 | 功能图标 | 适用场景 |
|------|------|------------|---------|------------|--------------|---------|---------|
| `large` | 大号 | **48pt** | **15pt** | **24pt** (`radius-2xl`) | **24pt** (`radius-2xl`) | **48pt** | 强调文本输入对话交互体验，有空间展示长文本，如 AI 帮办对话页、客服对话系统 |
| `standard` | 标准（推荐） | **36pt** | **14pt** | **24pt** (`radius-2xl`) | **18pt** (`radius-xl`) | **26pt** | 界面信息密度高，文本输入为非核心场景，用户通常输入简单短文本，如文章/视频/帖子下方评论、用户反馈 |

> 推荐优先使用 **标准尺寸**，仅在需要强调对话体验时使用大号。

> **注意**：外层容器圆角两种尺寸均为 `radius-2xl`（24pt）；内层输入文本区域圆角 large 为 24pt、standard 为 18pt，两层圆角不同，实现时需分别设置。

### 2.2 发送按钮（Send Button，仅消息输入型）

发送按钮在不同平台和场景下有不同的展示逻辑。

| 属性 | 大号（large） | 标准（standard） | 说明 |
|------|-------------|----------------|------|
| 按钮尺寸 | **64×32pt**（128×64px @2x） | **52×30pt** | 拼装按钮，非标准 Button 组件 |
| 按钮圆角 | `radius-full`（5000px） | `radius-full`（5000px） | 胶囊圆角 |
| 按钮背景 | `gradient-yellow`（`to bottom right`，同 `button.md`） | `gradient-yellow`（`to bottom right`，同 `button.md`） | 黄色渐变，方向 follow Button 组件规范 |
| 按钮文字字号 | **14pt**（28px @2x，`label-m-14-medium`） | **14pt**（28px @2x，`label-m-14-medium`） | 字重 500 |
| 按钮 padding top/bottom | **6pt**（12px @2x，`cs-6`） | **5pt**（10px @2x，`cs-5`） | 上下内边距 |
| 按钮 padding left/right | **12pt**（24px @2x，`spacing-l`） | **12pt**（24px @2x，`spacing-l`） | 左右内边距 |
| 按钮定位方式（outside） | 与输入框底部对齐（`align-items: flex-end`） | 包装容器 **height:36pt**，内部 flex 垂直居中 | outside 时按钮与输入框同行，均为底部对齐 |

#### buttonPosition 枚举：
| buttonPosition | 名称 | 适用平台 | 说明 |
|---------------|------|---------|------|
| `none` | 无发送按钮 | iOS 默认 | iOS 键盘自带发送键，输入框无需内置按钮 |
| `inside` | 按钮在内 | Android 默认 | 按钮绝对定位于输入框右侧 btn-area 区域右下角 |
| `outside` | 按钮在外 | 可选 | 按钮独立于输入框容器外侧 |

#### 平台适配逻辑：
- **无发送按钮（iOS 默认）**：因 iOS 键盘提供发送键，样式作为 iOS 系统默认消息型输入框默认状态。
- **有发送按钮（Android 默认）**：因部分 Android 键盘未提供发送键，样式作为 Android 系统默认消息型输入框默认状态。

### 2.3 布局结构与间距

#### 容器外部（外层 flex row，align-items: flex-end）

| 元素 | 说明 | 大号（@1x） | 标准（@1x） | @2x 备注 |
|------|------|-----------|-----------|----------|
| 左侧功能图标区 | 语音/表情等辅助功能（可选） | 容器 **48pt**，图标 **32pt** | 容器 **26pt**，图标 **20pt** | — |
| 输入框主体（flex: 1） | 输入区域 + 可选发送按钮 | 弹性撑满 | 弹性撑满 | — |
| 外置发送按钮（outside） | 按钮及其包装容器 | — | 包装容器 **36pt** 高（72px），按钮 **52×30pt**（104×60px） | — |
| 右侧功能图标区 | 相机/附件等（可选） | 容器 **48pt**，图标 **32pt** | 容器 **26pt**，图标 **20pt** | — |
| 元素间距（gap） | 图标区/按钮 与输入框之间 | **8pt**（16px @2x） | **10pt**（20px @2x） | 两种尺寸间距不同 |

> ⚠️ 外层 `align-items: flex-end`（底部对齐），各子元素与输入框底边对齐。标准型 outside 按钮采用包装容器等高方案（36pt），按钮在容器内垂直居中。

#### 输入文本区域内部结构

**标准型（standard）— buttonPosition=none / outside**：
```
输入框容器（flex-column, justify-content: flex-start, align-items: flex-start,
            padding: 8pt 16pt, border-radius: 18pt/36px, background: #FFFFFF）
└── 文字/引导语（align-self: stretch, flex-shrink: 0）
```

**标准型（standard）— buttonPosition=outside，带光标（输入中）**：
```
输入框容器（flex-column → 输入中切为 flex-row，padding: 8pt 16pt）
└── 内容行（flex-row, justify-content: flex-start, align-items: flex-start）
    ├── 输入文字（span，color: text-primary）
    └── 光标（div，width: 1.5pt/3px，height: 20pt/40px，
                background: blue-default/#0A77F5，border-radius: 5000px）
```

**大号（large）— buttonPosition=inside**：
```
输入框容器（flex-row, align-items: flex-start, border-radius: 24pt/48px）
├── 文本区（flex:1, flex-column, align-items: flex-start, padding: 13pt 0 13pt 16pt）
│   └── 文字/引导语（align-self: stretch）
└── 按钮区（flex-shrink:0, width: 80pt/160px, align-self: stretch,
           border-radius: 0 24pt 24pt 0, overflow: hidden, position: relative）
    └── 发送按钮（position: absolute, right: 8pt/16px, bottom: 8pt/16px,
                 width: 64pt/128px, height: 32pt/64px）
```

**标准型（standard）— buttonPosition=outside，按钮容器结构**：
```
按钮包装容器（height: 36pt/72px, flex-column, justify-content: center, align-items: center）
└── 发送按钮（width: 52pt/104px, height: 30pt/60px, flex-row, justify-content: center,
             align-items: center, padding: 5pt/12pt, border-radius: 5000px,
             background: gradient-yellow（to bottom right））
```

> ⚠️ 标准型输入框四边均有 padding（上下 8pt，左右 16pt）；outside 按钮通过包装容器（高度=输入框单行高 36pt）实现底部对齐。

| 属性 | 大号 none/outside | 大号 inside | 标准 none/outside | Token |
|------|-----------------|------------|-----------------|-------|
| padding top | **13pt**（26px） | **13pt**（26px） | **8pt**（16px） | 大号 `cs-13`，标准 `spacing-s` |
| padding bottom | **13pt**（26px） | **13pt**（26px） | **8pt**（16px） | 大号 `cs-13`，标准 `spacing-s` |
| padding left | **16pt**（32px） | **16pt**（32px） | **16pt**（32px） | `spacing-xl` |
| padding right | **16pt**（32px） | **0**（btn-area 占位） | **16pt**（32px） | `spacing-xl` |

#### 页面栅格边距（gridPadding）
| size | gridPadding | Token | 值 |
|------|-------------|-------|-----|
| `large` | — | `spacing-l` | 12pt（左右各） |
| `standard`（外侧有按钮） | — | `spacing-l` | 12pt |
| `standard`（无按钮或内侧按钮） | — | `spacing-xl` | 16pt |

### 2.4 多行高度规则

| 文字行数 | 容器高度策略 |
|---------|------------|
| 行数 = 1 | 固定高度（`large`: 48pt，`standard`: 36pt） |
| 1 < 行数 ≤ 5 | **自适应高度**（随内容增加） |
| 行数 > 5 | **最大高度**（超出后内容区可滚动） |

大号最大高度：**134pt**

### 2.5 发送按钮置灰态

输入框获得焦点但内容为空时，发送按钮（组件内的按钮或键盘的"发送"键）应保持**禁用（置灰）状态**。

---

## 3. 评价模块型（category=review）

常用于订单评价、商品评价等场景，支持多行文字输入 + 字数限制指示器，根据页面背景色和布局形式分为三种样式变体。

### 3.1 样式变体（reviewStyle）

| reviewStyle | 名称 | 背景 | 描边 | 圆角 | 宽度规则 | 适用场景 |
|-------------|------|------|------|------|---------|---------|
| `card-white` | 卡片型-白底 | `white`（`#FFFFFF` 纯白） | 四边 `stroke-strong`（`#CCCCCC`） | **8pt** (`radius-m`) | 卡片内等分，如 343pt | 灰色背景页面中的卡片评价模块 |
| `card-gray` | 卡片型-灰底 | `bg-subtle`（浅灰 `#FAFAFA`） | 无描边 | **8pt** (`radius-m`) | 卡片内等分，如 343pt | 白色背景页面中的卡片评价模块 |
| `fullwidth-white` | 白底通栏型 | `white`（`#FFFFFF` 纯白） | 无描边、无圆角 | **0pt** | 撑满页面宽度（375pt） | 通栏型页面，与多个评价维度组合使用，通常不展示评价标题 |

> **使用原则**：白底（`card-white`）用于灰色背景；灰底（`card-gray`）用于白色背景；两者均为卡片型，宽度适配容器。`fullwidth-white` 为通栏型，专用于评价维度横向组合场景。

### 3.2 布局结构（flex column）

评价模块型由上下两层组成：

```
评价模块容器（flex column）
├── 上层：文本输入区（flex-grow: 1，flex column）
│   ├── 圆角：top-left/top-right = 8pt（fullwidth-white 为 0pt）
│   ├── padding: 8pt 12pt（上下 8pt，左右 12pt）
│   ├── 引导语文字（text-quaternary，body-l-15-regular，行高 24pt）
│   └── 实际输入内容（text-primary，body-l-15-regular，行高 24pt）
│       ⚠️ 溢出时隐藏（overflow: hidden），单行展示时 text-overflow: ellipsis
└── 下层：字数指示器区（flex-shrink: 0，flex row，align-items: center，justify-content: end）
    ├── 圆角：bottom-left/bottom-right = 8pt（fullwidth-white 为 0pt）
    ├── padding: 8pt 12pt（上下 8pt，左右 12pt）
    ├── 高度（两种规格）：
    │   - 正常态：**32pt**（64px @2x），padding top/bottom = 8pt
    │   - 超限警告态：**36pt**（72px @2x），padding top/bottom = 10pt
    ├── 左侧清空图标（可选）：flex-shrink:0，**15pt**（30px @2x），位于最左侧
    ├── 右侧内容区（flex-grow:1，flex row，justify-content: end，align-items: center）
    │   ├── 字数指示器（当前字数 / 分隔符 / 最大字数，flex-grow:1）
    │   │   - 正常态颜色：text-quaternary（`#999999`），body-m-13-regular（13pt，行高 18pt）
    │   │   - 超限警告态颜色：warning-text（`#7A3100`），字号不变
    │   │   - 格式：`0/100`，分子动态更新；超限后禁止输入
    │   └── 右侧小图标（flex-shrink:0，**24×12pt**，48×24px @2x）
    └── column-gap: 4pt（column-gap: 8px @2x，各子元素间距）
```

### 3.3 字数指示器组成

字数指示器由三段文字拼接，均使用相同字体样式：

| 元素 | 说明 | 宽度参考 | 正常态 Token | 超限警告态 Token |
|------|------|---------|------------|----------------|
| 当前字数（动态） | 实时显示已输入字数 | ≈8pt | `body-m-13-regular`，`text-quaternary`（`#999999`） | `body-m-13-regular`，`warning-text`（`#7A3100`） |
| 分隔符 `/` | 固定字符 | ≈6.5pt | 同上 | 同上 |
| 最大字数（固定） | 如 `100` | ≈21pt | 同上 | 同上 |

> **超限警告态**：当输入字数超过 `maxLength` 时，字数指示器文字整体切换为 `warning-text`（`#7A3100`），同时计数区容器高度由 **32pt 升至 36pt**（padding top/bottom 由 8pt 增至 10pt），视觉上产生轻微撑高效果。超限后禁止继续输入。

### 3.4 多行高度规则

| 文字行数 | 上层文本区高度策略 |
|---------|----------------|
| 行数 = 1 | 文本区最小高度：**100pt**（200px @2x） |
| 1 < 行数 ≤ 4 | **自适应高度**（随内容行数增加） |
| 行数 > 4 | **固定最大高度**，超出后内容区滚动 |

> 字数指示器区（下层）高度与文本区无关，独立固定：正常态 **32pt**，超限警告态 **36pt**。

### 3.5 Token 引用（评价模块型专项）

#### 颜色 Token
| 用途 | Token 名称 | 色值 | 语义层来源 |
|------|-----------|------|-----------|
| 卡片型白底背景 | `white` | `#FFFFFF` | `color-semantic.md` §一 Neutral Color |
| 卡片型灰底背景 | `bg-subtle` | `#FAFAFA` | `color-semantic.md` §三 Background Color |
| 通栏型背景 | `white` | `#FFFFFF` | `color-semantic.md` §一 Neutral Color |
| 卡片型白底描边 | `stroke-strong` | `#CCCCCC` | `color-semantic.md` §四 Stroke Color |
| 引导语颜色 | `text-quaternary` | `#888888` | `color-semantic.md` §二 Text Color |
| 输入文字颜色 | `text-primary` | `#111111` | `color-semantic.md` §二 Text Color |
| 字数指示器颜色（正常） | `text-quaternary` | `#999999` | `color-semantic.md` §二 Text Color |
| 字数指示器颜色（超限警告） | `warning-text` | `#7A3100` | `color-semantic.md` §五 Warning Color |
| 计数区背景（超限警告） | `warning-bg` | `#FFFADB` | `color-semantic.md` §五 Warning Color |

#### 圆角 Token
| 用途 | Token 名称 | 值 | 语义层来源 |
|------|-----------|-----|----------|
| 卡片型整体圆角 | `radius-m` | 8pt | `component-radius.md` |
| 通栏型圆角 | — | 0pt（无圆角） | — |

#### 间距 Token
| 用途 | Token 名称 | 值 | 语义层来源 |
|------|-----------|-----|----------|
| 文本区 padding top/bottom | `spacing-s` | 8pt | `spacing-semantic.md` |
| 文本区 padding left/right | `spacing-l` | 12pt | `spacing-semantic.md` |
| 计数区 padding top/bottom（正常态） | `spacing-s` | 8pt → 计数区高 32pt | `spacing-semantic.md` |
| 计数区 padding top/bottom（超限警告态） | `cs-10` | 10pt → 计数区高 36pt | `component-spacing.md` |
| 计数区 padding left/right | `spacing-l` | 12pt | `spacing-semantic.md` |
| 计数区各子元素间距 column-gap | `cs-4` | 4pt（8px @2x） | `component-spacing.md` |

#### 描边 Token
| 用途 | Token 名称 | 值 | 语义层来源 |
|------|-----------|-----|----------|
| 卡片型白底描边粗细 | `stroke-thin` | 0.5pt | `stroke-semantic.md` |

> **注意**：CSS 中 `border-width: 1px`（@2x），对应 @1x 0.5pt，使用 `stroke-thin`。描边颜色 `#CCCCCC` 映射至 `stroke-strong`（`color-semantic.md` §四 Stroke Color）。

---

## 4. 交互说明

### 4.1 默认态（unfocused）

- 展示**引导语（Placeholder）**
- 引导语文字颜色：`text-quaternary`（`#888888`）

### 4.2 输入中态（focused）

- 隐藏引导语，展示输入光标和系统键盘
- 文字颜色：`text-primary`（`#111111`）

### 4.3 失焦态（blurred）

- 点击页面其他位置时，输入框光标和键盘消失

### 4.4 按钮展示

- 根据实际需求展示或不展示按钮（`buttonPosition=none` 时不展示）

---

## 5. 可选功能

### 5.1 语音输入和表情等选项

通过"切换标题辅助功能"可打开或关闭语音输入、表情等辅助选项。

### 5.2 动态调整栅格

在适配不同页面栅格时，调用组件时先调整水平宽度至卡片/容器宽度，然后在右侧面板调整对应左右边距。

---

## 6. 固定规格（不可调整）

| 属性 | 大号（large） | 标准（standard） |
|------|-------------|----------------|
| 单行容器高度 | **48pt** | **36pt** |
| 文字/引导语字号 | **15pt** | **14pt** |
| 文字行高 | **22pt** | **20pt** |
| 文字字重 | **常规体（400）** | **常规体（400）** |
| 文字颜色（输入中） | `text-primary` | `text-primary` |
| 引导语颜色 | `text-quaternary` | `text-quaternary` |
| 图标容器大小 | 容器 **48pt**，图标本身 **32pt** | 容器 **26pt**，图标本身 **20pt** |
| 图标容器内边距 | **8pt**（padding） | **3pt** |
| 外层容器圆角 | **24pt** (`radius-2xl`) | **24pt** (`radius-2xl`) |
| 内层输入区圆角 | **24pt** (`radius-2xl`) | **18pt** (`radius-xl`) |
| 输入区 padding top/bottom | **13pt**（26px @2x） | **8pt**（16px @2x） |
| 输入区 padding left/right | **16pt**（32px @2x） | **16pt**（32px @2x） |
| 外层元素间距（gap） | **8pt**（16px @2x） | **10pt**（20px @2x） |
| 按钮尺寸 | **64×32pt**（128×64px @2x） | **52×30pt**（104×60px @2x） |
| 按钮 padding top/bottom | **6pt**（12px @2x） | **5pt**（10px @2x） |
| 按钮 padding left/right | **12pt**（24px @2x） | **12pt**（24px @2x） |
| 按钮渐变方向 | `to bottom right`（同 `button.md`） | `to bottom right`（同 `button.md`） |
| 按钮 btn-area 宽度（inside） | **80pt**（160px @2x） | — |
| 光标宽 × 高 | **1.5×22pt** | **1.5×20pt**（3×40px @2x） |
| 光标颜色 | `blue-default`（`#0A77F5`） | `blue-default`（`#0A77F5`） |

---

## 7. Token 引用

### 7.1 颜色 Token

| 用途 | Token 名称 | 语义层来源 |
|------|-----------|-----------|
| 输入文字颜色 | `text-primary` | `color-semantic.md` §二 Text Color |
| 引导语颜色 | `text-quaternary` | `color-semantic.md` §二 Text Color |
| 输入框背景 | `white`（`#FFFFFF`） | `color-semantic.md` §三 Background Color |
| 光标颜色 | `blue-default`（`#0A77F5`） | `color-semantic.md` §七 Functional Color |
| 发送按钮（可交互） | `text-primary` | `color-semantic.md` §二 Text Color |
| 发送按钮（置灰，不可交互） | `text-disabled` | `color-semantic.md` §二 Text Color |
| 功能图标 | `text-primary` | `color-semantic.md` §二 Text Color |
| 关闭图标（清除） | `text-primary` | `color-semantic.md` §二 Text Color |
| 评价模块灰底背景 | `bg-subtle` | `color-semantic.md` §三 Background Color |
| 评价模块白底描边 | `stroke-strong` | `color-semantic.md` §四 Stroke Color |
| 字数指示器文字（正常） | `text-quaternary` | `color-semantic.md` §二 Text Color |
| 字数指示器文字（超限警告） | `warning-text` | `color-semantic.md` §五 Warning Color |
| 计数区背景（超限警告） | `warning-bg` | `color-semantic.md` §五 Warning Color |

### 7.2 字体 Token

| 用途 | Token 名称 | 语义层来源 |
|------|-----------|-----------|
| 大号——输入文字/引导语 | `body-l-15-regular` | `font-semantic.md` §一 Body |
| 标准——输入文字/引导语 | `body-m-14-regular` | `font-semantic.md` §一 Body |
| 发送按钮文字（大号） | `label-m-14-medium` | `font-semantic.md` §三 Label |
| 发送按钮文字（标准） | `label-m-14-medium` | `font-semantic.md` §三 Label（与大号相同，均为 14pt/28px） |
| 评价模块——输入文字/引导语 | `body-l-15-regular` | `font-semantic.md` §一 Body |
| 评价模块字数指示器 | `body-m-13-regular` | `font-semantic.md` §一 Body（13pt/26px @2x，行高 18pt/36px @2x） |

### 7.3 圆角 Token

| 用途 | Token 名称 | 值 | 语义层来源 |
|------|-----------|-----|----------|
| 大号/标准外层容器圆角 | `radius-2xl` | 24pt | `component-radius.md` |
| 大号内层输入区圆角 | `radius-2xl` | 24pt | `component-radius.md` |
| 标准内层输入区圆角 | `radius-xl` | 18pt | `component-radius.md` |
| 发送按钮圆角 | `radius-full` | 胶囊（5000px） | `component-radius.md` |

### 7.4 间距 Token

| 用途 | Token 名称 | 值 | 语义层来源 |
|------|-----------|-----|----------|
| 大号输入区 padding top/bottom | `cs-13` | 13pt | `component-spacing.md` |
| 大号输入区 padding left/right | `spacing-xl` | 16pt | `spacing-semantic.md` |
| 标准输入区 padding top/bottom | `spacing-s` | 8pt | `spacing-semantic.md` |
| 标准输入区 padding left/right | `spacing-xl` | 16pt | `spacing-semantic.md` |
| 大号按钮 padding top/bottom | `cs-6` | 6pt（12px @2x） | `component-spacing.md` |
| 大号按钮 padding left/right | `spacing-l` | 12pt（24px @2x） | `spacing-semantic.md` |
| 标准按钮 padding top/bottom | `cs-5` | 5pt（10px @2x） | `component-spacing.md` |
| 标准按钮 padding left/right | `spacing-l` | 12pt（24px @2x） | `spacing-semantic.md` |
| 外层间距-大号（图标/按钮与输入框） | `spacing-s` | 8pt（16px @2x） | `spacing-semantic.md` |
| 外层间距-标准（图标/按钮与输入框） | `cs-10` | 10pt（20px @2x） | `component-spacing.md` |

---

## 8. Props API（供 AI 生码参考）

```typescript
export type TextInputProps = {
  /**
   * 组件大类
   * @default "message"
   */
  category?: "message" | "review";

  /**
   * 尺寸（仅 message 有效）
   * @default "standard"
   */
  size?: "large" | "standard";

  /**
   * 发送按钮位置（仅 message 有效）
   * @default "none"
   */
  buttonPosition?: "none" | "outside" | "inside";

  /**
   * 引导文字（Placeholder）
   */
  placeholder?: string;

  /**
   * 当前输入内容
   */
  value?: string;

  /**
   * 最大字数（仅 review 有效）
   */
  maxLength?: number;

  /**
   * 评价模块型样式变体（仅 review 有效）
   * - card-white: 卡片型白底，带描边，用于灰色背景
   * - card-gray: 卡片型灰底，无描边，用于白色背景
   * - fullwidth-white: 白底通栏型，无圆角无描边，与多维度评价组合使用
   * @default "card-white"
   */
  reviewStyle?: "card-white" | "card-gray" | "fullwidth-white";

  /**
   * 是否展示语音输入、表情等辅助功能
   * @default false
   */
  showAuxiliary?: boolean;

  /**
   * 内容变化回调
   */
  onChange?: (value: string) => void;

  /**
   * 发送回调
   */
  onSend?: (value: string) => void;
};
```

---

## 9. data-attribute 规范

| 属性 | 值 | 说明 |
|------|----|------|
| `data-slot` | `"text-input"` | 输入框根容器 |
| `data-slot` | `"text-input-placeholder"` | 引导语文字 |
| `data-slot` | `"text-input-send"` | 发送按钮 |
| `data-slot` | `"text-input-counter"` | 字数指示器（review 类型） |
| `data-category` | `"message"` / `"review"` | 组件大类 |
| `data-size` | `"large"` / `"standard"` | 尺寸 |
| `data-button-position` | `"none"` / `"outside"` / `"inside"` | 发送按钮位置 |
| `data-state` | `"default"` / `"focused"` / `"blurred"` | 输入框状态 |

---

## 10. 无障碍（Accessibility）

- 使用 `<input>` 或 `<textarea>` 元素实现
- 必须设置 `aria-label` 或 `<label>` 关联描述输入框功能
- 引导语通过 `placeholder` 属性实现（不能替代 `<label>`）
- 发送按钮使用 `aria-disabled="true"` 表示禁用态
- 字数指示器使用 `aria-live="polite"` 实时通知屏幕阅读器

---

## 11. 使用约束（AI 生成时的硬性规则）

1. **尺寸固定**：大号单行高度固定 **48pt**，标准固定 **36pt**，不可随意修改
2. **圆角固定**：大号内层 **24pt**，标准内层 **18pt**；外层两种均为 **24pt**，不可修改
3. **圆角层级区别**：外层容器圆角两种尺寸均为 `radius-2xl`（24pt）；内层输入文本区域 large 为 `radius-2xl`（24pt），standard 为 `radius-xl`（18pt），两层圆角必须分别设置
4. **发送按钮置灰**：焦点获取但内容为空时，发送按钮必须置灰，不可点击
5. **多行高度自适应**：1<行数≤5 时容器自适应，>5 时使用最大高度，内容滚动
6. **按钮平台一致性**：iOS 推荐 `buttonPosition=none`（键盘自带发送），Android 推荐 `outside` 或 `inside`
7. **平台默认样式**：iOS 默认不带发送按钮（`buttonPosition=none`），Android 默认带发送按钮（`buttonPosition=inside`）
8. **引导语颜色**：必须使用 `text-quaternary`，不可使用 `text-secondary` 或其他颜色
9. **禁止直接写 hex 颜色**：颜色必须使用 §7.1 中的语义 Token
10. **功能图标尺寸固定**：大号 48pt，标准 26pt，不可修改
11. **推荐标准尺寸**：默认优先 `size=standard`，有强对话诉求时才选 `size=large`
12. **发送按钮拼装规则**：圆角 `radius-full`；背景 `gradient-yellow`（`linear-gradient(to bottom right, rgba(255,231,77,1) 0%, rgba(255,221,0,1) 100%)`），方向 follow `button.md`，不区分大号/标准；文字均使用 `label-m-14-medium`；大号 64×32pt，padding `cs-6`/`spacing-l`；标准 52×30pt，padding `cs-5`/`spacing-l`
13. **字数超限禁止输入**：评价模块型达到 `maxLength` 后禁止继续输入
14. **超限警告态颜色切换**：字数达到 `maxLength` 后，计数区字数指示器文字必须切换为 `warning-text`（`#7A3100`），计数区背景切换为 `warning-bg`（`#FFFADB`），不可保持 `text-quaternary`
15. **超限警告态高度变化**：字数超限时，计数区 padding top/bottom 由 `spacing-s`（8pt）升至 `cs-10`（10pt），容器高度由 32pt 升至 36pt，禁止强制固定高度
16. **评价模块型背景选择**：`card-white` 用于灰色背景；`card-gray` 用于白色背景；两者不可对调，否则对比度不足
17. **评价模块型描边规则**：只有 `card-white` 有描边，使用 `stroke-strong`（`#CCCCCC`），粗细 `stroke-thin`（0.5pt）；`card-gray` 和 `fullwidth-white` 均无描边
18. **评价模块型圆角规则**：卡片型两种均为 `radius-m`（8pt）；`fullwidth-white` 圆角必须为 0，不可添加圆角

---

## 12. 常见组合示例

### 12.1 iOS 客服对话页（大号，无按钮）

```
TextInput
  category: message
  size: large
  buttonPosition: none
  placeholder: "输入您要咨询的内容"
```

### 12.2 Android AI 帮办（大号，按钮在外）

```
TextInput
  category: message
  size: large
  buttonPosition: outside
  placeholder: "请描述您的问题"
  onSend: (value) => sendMessage(value)
```

### 12.3 iOS 文章评论（标准，无按钮）

```
TextInput
  category: message
  size: standard
  buttonPosition: none
  placeholder: "写评论..."
  // iOS 键盘自带发送键
  // 外层容器圆角 radius-2xl（24pt），内层输入区圆角 radius-xl（18pt）
  // 输入区 padding: 8pt 16pt，功能图标 26pt，图标间距 10pt
```

### 12.4 Android 视频评论（标准，按钮在内）

```
TextInput
  category: message
  size: standard
  buttonPosition: inside
  placeholder: "喜欢就给个评论支持下"
  onSend: (value) => postComment(value)
  // 按钮 52×30pt，gradient-yellow，radius-full，padding 5pt/12pt
  // 按钮 flex 垂直居中对齐于输入区右侧
```

### 12.5 卡片型评价-白底（灰色背景页面）

```
TextInput
  category: review
  reviewStyle: card-white
  maxLength: 100
  placeholder: "描述您的用餐体验"
  onChange: (value) => setReviewText(value)
  // white 纯白底 + stroke-strong 描边（#CCCCCC，stroke-thin 0.5pt）
  // 圆角 radius-m（8pt），宽度适配卡片容器（如 343pt）
  // 文本区 padding 8pt/12pt，字数指示器颜色 text-quaternary（`#999999`）
```

### 12.6 卡片型评价-灰底（白色背景页面）

```
TextInput
  category: review
  reviewStyle: card-gray
  maxLength: 200
  placeholder: "说说您对商品的感受"
  onChange: (value) => setReviewText(value)
  // bg-subtle 灰底（#FAFAFA）+ 无描边
  // 圆角 radius-m（8pt），宽度适配卡片容器（如 343pt）
```

### 12.7 白底通栏型评价（多维度组合场景）

```
TextInput
  category: review
  reviewStyle: fullwidth-white
  maxLength: 100
  placeholder: "整体评价..."
  onChange: (value) => setReviewText(value)
  // white 纯白底 + 无描边 + 无圆角（0pt）
  // 宽度撑满页面（375pt），通常不展示评价标题
  // 与其他维度评价（星级/标签等）水平组合使用
```

---

## 13. 与其他组件的关系

| 关联组件 | 关系说明 |
|----------|----------|
| `button` | 发送按钮参考 `button.md` 六级按钮（文字型）规范 |
| `half-screen-dialog` | 半页弹窗内可嵌套文本输入框（如评论、快速回复） |
| `form` | 表单场景下的文本输入使用 Form Input 规范，区别于消息输入型 |
| `badge` | 评价模块型字数指示器逻辑与 badge 独立，不复用 Badge 组件 |
