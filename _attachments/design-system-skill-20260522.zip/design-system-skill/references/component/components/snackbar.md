# Snackbar 底部横幅

> **组件分类**：Component（组件级）
> **定义**：底部横幅是一种出现在页面底部、悬浮于页面上的消息提示，通常用作操作引导。
> **Style 依赖**：`color-semantic.md` · `font-semantic.md` · `spacing-semantic.md` · `component-spacing.md` · `radius-semantic.md` · `component-radius.md` · `stroke-semantic.md`

---

## 0. 图标 / 间距 / Ownership 约束

- **icon-route（默认）**：组件自带图标按正文规则走 icon route，默认回 `component/atoms/icon.md` 并遵循既定 class / weight。
- **fixed-asset 例外**：正文若指定官方 SVG、`assets/*.svg`、PNG/CDN 或 URL 切图，该位点必须走 fixed-asset。
- **spacing-owner（归属）**：Snackbar 内部文本、按钮、自带图标的间距与对齐归本组件；页面外层浮层留白与位置归宿主。
- **宿主裁决（优先级）**：冲突按 `宿主 > 组合场景 > 本组件`，宿主裁决悬浮层挂载与外部占位。
- **不可跳步**：先回 `references/INDEX.md` 完成区域路由与宿主锁定，再用 `component-quickref.md` 做宿主级收敛；本文件仅承接组件内 ownership 细则，不承担前置路由改判；不得凭语义猜测。


## 1. 组件大类（category）

| category | 名称 | 说明 | 典型场景 |
|----------|------|------|---------|
| `regular` | 常规类 | 用于操作引导，分为功能类和运营类 | 登录引导、权限申请、促销活动 |
| `anchor` | 锚点类 | 引导用户滚动至当前页面指定区域 | 跳转到页面内容模块 |

---

## 2. 常规类（category=regular）

### 2.1 内容类型（contentType）

| contentType | 名称 | 说明 |
|-------------|------|------|
| `functional` | 功能类 | 需要用户跳转至其他页面或用户点击按钮即可立即完成操作 |
| `operational` | 运营类 | 对"屏效"要求较高，内容营销为主 |

> **颜色选用规则**：以浅色页面为默认状态，**功能类建议使用深色容器**，**运营类建议使用浅色容器**。如果是深色页面或其他非浅色页面，可结合实际场景考虑，可不遵循以上规则。
> ⚠️ **注意**：功能类所有变体（含 `rowCount=double-with-title`）均使用**深色容器（`rgba(0,0,0,0.8)`）**，无阴影，圆角 `16px`（`8pt`），与上述"深色容器"原则一致。

### 2.2 布局类型（layoutType）

| layoutType | 名称 | 适用条件 | 特征 |
|------------|------|---------|------|
| `full-width` | 通栏布局 | 横幕下方有底部导航栏等内容时 | 水平方向撑满屏幕，外圆角 0pt |
| `inset` | 留边布局 | 横幅下方无其他内容时 | 左右各 12pt 边距，外圆角 8pt |

> **通栏布局**：内部元素左右边距不建议调整
> **留边布局**：左右边距固定 **12pt**，可结合页面栅格对齐（建议选用 12pt 或 8pt 的栅格）
> 极端个别场景下，留边布局类可采取自适应的方式

### 2.3 内容行数（rowCount）

| rowCount | 名称 | 容器高度 | 适用 layoutType | 特征 |
|----------|------|---------|----------------|------|
| `single` | 单行内容 | **36pt** | 通栏/留边（功能类）| 内容一行展示 |
| `double-no-title` | 双行内容（无主副标题） | **52pt** | 留边（功能类）| 正文最多 2 行，无标题层级 |
| `double-with-title` | 双行内容（有主副标题） | **60pt** | 留边（运营类/功能类）| 标题 + 副标题结构，标题不超过 1 行，正文不超过 2 行 |

### 2.4 左侧内容（leftContent，可选）

左侧可根据实际需要展示或不展示，类型如下：

| leftContent | 名称 | 说明 |
|-------------|------|------|
| `none` | 无 | 无左侧内容 |
| `icon` | 图标 | 功能图标建议使用中黑体；示例使用 `inform-line-medium` |
| `amount` | 金额 | 展示价格/金额，品牌红色字体 |
| `custom` | 自定义 | 可在左侧自行定义内容，建议符合原子层规范 |

> **自定义区域宽度**：建议 ≤ **90pt**

### 2.5 按钮数量（buttonCount）

| buttonCount | 说明 | 限制 |
|-------------|------|------|
| `single` | 单按钮 | — |
| `double` | 双按钮 | 按钮最多展示 **2 个** |

**按钮类型规则：**

| 容器高度 | 按钮级别 |
|---------|---------|
| 36pt（单行） | **六级按钮** |
| 52pt（双行，无标题） | **六级按钮** |
| 60pt（双行，有标题） | **五级按钮** |

---

## 3. 锚点类（category=anchor）

### 3.1 功能说明

锚点类底部横幅用于引导用户滚动至当前页面的指定模块，不跳转至其他页面。

### 3.2 触发逻辑

| 触发方式 | 说明 |
|---------|------|
| 用户进入特定场景 | 需要用户前往当前页面相应模块进行操作时出现 |
| 系统引导 | 系统希望引导用户进行某操作时，自动出现 |

### 3.3 消失逻辑

| 消失条件 | 说明 |
|---------|------|
| 点击横幅 | 页面滚动至锚定区域并停止，然后横幅消失 |
| 自动消失 | 用户滑动屏幕至锚定区域露出后，横幅消失 |

### 3.4 内容行数（rowCount，锚点类）

| rowCount | 容器高度 |
|----------|---------|
| `single` | **36pt** |
| `double` | **52pt**（文字不建议超过 2 行） |

### 3.5 箭头图标

| 箭头方向 | 含义 |
|---------|------|
| 向下（↓） | 引导滚动到页面下方的锚定区域 |
| 向上（↑） | 引导滚动到页面上方的锚定区域 |

> 右侧箭头建议使用**白色**；功能图标建议使用中黑体，示例使用 `inform-line-medium`。

#### 箭头图标实现规范

| 属性 | 值 | 说明 |
|------|----|------|
| 图标名 | `icon-iconfont-pullup-line-regular` | 统一使用 `pullup-line-regular` |
| 字号 | 28px（@2x） | `font-size: 28px` |
| 颜色 | `#FFFFFF` | `color: #FFFFFF`（白色） |
| 向下箭头（↓） | `transform: rotate(180deg)` | 将向上箭头旋转 180° 实现向下效果 |
| 向上箭头（↑） | 无旋转 | 图标默认朝上方向 |
| 显示方式 | `display: inline-block` | 确保旋转 transform 生效 |

### 3.6 锚点类——固定规格（不可调整）

| 属性 | 值 |
|------|-----|
| 圆角 | **四级圆角** / **8pt**（`border-radius: 16px @2x`） |
| 文字 | **24号常规体**（`font-size: 24px; font-weight: 400; line-height: 32px`） |
| 箭头图标 | 右侧箭头/图标占位区，**36×24px @2x（18×12pt）** |
| 气泡底色 | **#000000 80%**（`rgba(0,0,0,0.8)`，`mask-heavy`） |
| 宽度策略 | 根据文字内容**自适应**（不拉伸至满屏） |
| 横幅位置 | 距底部 12pt（整体宽度建议与页面保持 12pt 边距） |

> ⚠️ **文字字重说明**：锚点类文字实测为 `font-weight: 400`（Regular 常规体），非中黑体（500）。

### 3.7 组件集画板信息（@2x 设计稿整体）

| 属性 | @2x 值（px） | pt 值 | 说明 |
|------|------------|------|------|
| 画板尺寸 | 862×384px | **431×192pt** | `.componentset` 整体容器 |
| 画板边框 | `3px dashed #111111` | **1.5pt dashed** | 仅设计稿展示用，非运行时样式 |
| 画板圆角 | 40px | **20pt** | 仅设计稿展示用 |
| **变体一位置（向下箭头↓）** | top:80px, left:178px | **top:40pt, left:89pt** | `.component` 绝对定位 |
| **变体二位置（向上箭头↑）** | top:232px, left:178px | **top:116pt, left:89pt** | `.component-1` 绝对定位 |
| 变体垂直间距 | 80px（232−80−72） | **40pt** | 两变体之间的间隔 |

> 画板边框和圆角仅为组件集展示时的装饰性样式，**不代表实际运行时组件外观**。

### 3.8 实测变体尺寸（源自组件集设计稿，@2x）

#### 3.8.1 变体总览

| 变体 | 容器尺寸（@2x） | 容器尺寸（pt） | 说明 |
|------|--------------|-------------|------|
| 向下箭头（`.component`，rowCount=single） | 506×72px | **253×36pt** | 引导滚动到下方区域 |
| 向上箭头（`.component-1`，rowCount=single） | 506×72px | **253×36pt** | 引导滚动到上方区域 |

> ⚠️ 容器宽度 **506px（253pt）** 为本组件集示例宽度；实际宽度根据文字内容**自适应**，设计稿中的宽度仅为参考值。

#### 3.8.2 各区域详细尺寸（@2x → pt）

##### （A）通用属性（两变体共享）

| 区域 | @2x 尺寸（px） | pt 值 | Token / 说明 |
|------|-------------|------|------------|
| **容器整体** | 506×72px（示例宽度） | **253×36pt** | `border-radius: 16px`（8pt），`background: rgba(0,0,0,0.8)` |
| 容器背景色 | `rgba(0,0,0,0.8)` | — | `mask-heavy` |
| 容器内边距（上下） | 20px | **10pt** | — |
| 容器内边距（左右） | 24px | **12pt** | `cs-12` |
| 容器列间距 | 无（仅内部 `.frame` 有 column-gap） | — | — |
| **内容区（.frame / .frame-2）** | 422×32px | **211×16pt** | `flex-direction: row; align-items: center; column-gap: 8px（4pt）` |
| **左侧图标区（.instance / .instance-2）** | 30×30px | **15×15pt** | `flex-shrink: 0`，固定尺寸；图标使用 `inform-line-medium`，字号 30px，颜色 `#FFFFFF` |
| **文字区（.text / .text-1）** | 384×32px | **192×16pt** | `flex-shrink: 0`；`white-space: nowrap`（不换行） |
| 文字字体 | `"PingFang SC"` | — | — |
| 文字字号 | 24px | **12pt** | Regular 400（`font-weight: 400`） |
| 文字行高 | 32px | **16pt** | — |
| 文字颜色 | `#FFFFFF` | — | `text-on-dark` |
| **右侧箭头/占位区（.frame-1 / .frame-3）** | 36×24px | **18×12pt** | `flex-shrink: 0`，用于放置箭头图标（向下↓ 或 向上↑） |

##### （B）两变体结构对比

| 属性 | 变体一（`.component`，向下↓） | 变体二（`.component-1`，向上↑） |
|------|----------------------------|-------------------------------|
| 画板位置（@2x） | top:80px, left:178px | top:232px, left:178px |
| 内容区类名 | `.frame` | `.frame-2` |
| 图标区类名 | `.instance` | `.instance-2` |
| 文字类名 | `.text` | `.text-1` |
| 箭头占位区类名 | `.frame-1` | `.frame-3` |
| 容器尺寸 | 506×72px（253×36pt） | 506×72px（253×36pt） |
| 样式规格 | 完全一致 | 完全一致 |

> **两个变体的所有样式属性完全相同**，差异仅在于箭头方向（↓ vs ↑）及图标内容，由设计时填入的图标决定。

### 3.9 DOM 结构规范（锚点类 · 单行，rowCount=single）

```
.component（容器，flex-row，justify-start，align-items-center，padding 10pt上下/12pt左右，253pt×36pt（示例宽度，自适应），border-radius 8pt，background:rgba(0,0,0,0.8)）
├── .frame（内容区，flex-row，align-items:center，column-gap 4pt，211×16pt）
│   ├── .instance（左侧图标区，15×15pt，flex-shrink:0）
│   └── .text（文字区，192×16pt，flex-shrink:0，24px/400，#FFFFFF，white-space:nowrap）
└── .frame-1（右侧箭头区，18×12pt，flex-shrink:0）
```

> - **宽度自适应**：容器宽度随文字内容伸缩，不固定；设计稿示例宽度 506px（253pt）仅供参考
> - **文字不换行**：`.text` 设置 `white-space: nowrap`，锚点气泡始终单行展示
> - **右侧箭头区（.frame-1 / .frame-3）**：36×24px @2x（18×12pt），放置方向箭头图标（↓ 或 ↑）；使用 `icon-iconfont-pullup-line-regular`，字号 28px，颜色 `#FFFFFF`；向下箭头需加 `transform: rotate(180deg)`
> - **图标区（.instance）**：30×30px @2x（15×15pt），放置功能性图标；示例使用 `icon-iconfont-inform-line-medium`，字号 30px，颜色 `#FFFFFF`
> - **按钮级别**：锚点类不使用独立按钮，整个横幅本身即为可点击区域

---

## 4. 常规类——固定规格（不可调整）

### 4.1 位置

| 类型 | 距底部 |
|------|-------|
| 留边类 | 距离底部参考各自高度规范 |
| 通栏类 | 贴底部安全区 |

### 4.2 圆角

| layoutType | 圆角 |
|------------|------|
| 通栏布局 | **0pt** |
| 留边布局 | **8pt**（四级圆角，`radius-m`） |

### 4.3 整体宽度

| layoutType | 宽度策略 |
|------------|---------|
| 通栏布局 | 水平方向**撑满屏幕** |
| 留边布局 | 左右各保留 **12pt**（对齐页面栅格） |

### 4.4 文字规格

| 用途 | 字号 | 字重 |
|------|------|------|
| 双行标题 | **28号** | **中黑体** |
| 单行标题 | **24号** | **中黑体** |
| 正文/副标题 | **24号** | **常规体** |

### 4.5 阴影

| 场景 | 阴影 |
|------|------|
| 容器为白色时 | **强阴影**（`shadow-overlay`） |

### 2.6 组件集画板信息（@2x 设计稿整体）

以下为组件集 Figma/CSS 导出的画板（Artboard）整体参数：

| 属性 | @2x 值（px） | pt 值 | 说明 |
|------|------------|------|------|
| 画板尺寸 | 910×384px | **455×192pt** | `.componentset` 整体容器 |
| 画板边框 | `3px dashed #111111` | **1.5pt dashed** | 仅设计稿展示用，非运行时样式 |
| 画板圆角 | 40px | **20pt** | 仅设计稿展示用 |
| **变体一位置（单按钮）** | top:80px, left:104px | **top:40pt, left:52pt** | `.component` 绝对定位 |
| **变体二位置（双按钮）** | top:232px, left:104px | **top:116pt, left:52pt** | `.component-1` 绝对定位 |
| 变体垂直间距 | 80px（232−80−72） | **40pt** | 两变体之间的间隔 |

> 画板边框和圆角仅为组件集展示时的装饰性样式，**不代表实际运行时组件外观**。

### 2.7 实测变体尺寸（源自组件集设计稿，@2x）

以下数据直接从组件集 CSS 提取，供 AI 生码与走查核对使用。

#### 2.7.1 功能类 · 单行内容（contentType=functional, rowCount=single）

| 变体 | 容器尺寸（@2x） | 容器尺寸（pt） | 按钮数量 | 说明 |
|------|--------------|-------------|---------|------|
| 单按钮（`buttonCount=single`） | 702×72px | **351×36pt** | 1 个主按钮（黄色渐变） | 左侧图标 + 文字（自适应）+ 右侧主按钮 + 右侧占位区 |
| 双按钮（`buttonCount=double`） | 702×72px | **351×36pt** | 1 个次按钮（描边）+ 1 个主按钮（黄色渐变） | 左侧图标 + 文字（自适应）+ 右侧次/主按钮 |

#### 2.7.2 各区域详细尺寸（@2x → pt）

##### （A）通用属性（两变体共享）

| 区域 | @2x 尺寸（px） | pt 值 | Token / 说明 |
|------|-------------|------|------------|
| **容器整体** | 702×72px | **351×36pt** | `border-radius: 16px`（8pt） |
| 容器背景色 | `rgba(0,0,0,0.8)` | — | `mask-heavy` |
| 容器内边距（上下） | 20px | **10pt** | — |
| 容器内边距（左右） | 24px | **12pt** | `cs-12` |
| 容器列间距（column-gap） | 8px | **4pt** | 图标与内容区间距 |
| **左侧图标区（.instance / .instance-4）** | 30×30px | **15×15pt** | `flex-shrink: 0`，固定尺寸；图标使用 `inform-line-medium`，字号 30px，颜色 `#FFFFFF` |
| **中间内容区（.frame / .frame-3）** | 弹性（flex-grow:1） | — | 高度 32px（16pt） |
| 文字字体 | `"PingFang SC"` | — | 完整 fallback 链见设计系统规范 |
| 文字字号 | 24px | **12pt** | Regular 400 |
| 文字行高 | 32px | **16pt** | — |
| 文字颜色 | `#FFFFFF` | — | `text-on-dark` |
| 文字溢出处理 | `ellipsis` | — | `overflow:hidden; white-space:nowrap; text-overflow:ellipsis` |

##### （B）单按钮变体专属（`.component`）

| 区域 | @2x 尺寸（px） | pt 值 | Token / 说明 |
|------|-------------|------|------------|
| 文字区（.text）宽度 | 460px（弹性） | **230pt**（弹性） | `flex-grow: 1`，最大可用宽度 |
| **按钮区（.frame-1）** | 108×32px | **54×16pt** | `flex-shrink: 0` |
| 按钮区间距（padding-left） | 24px | **12pt** | 按钮区与文字区间距 |
| 按钮区内部列间距（column-gap） | 24px | **12pt** | — |
| **主按钮（.instance-2）** | 84×40px | **42×20pt** | `min-width: 84px`（42pt） |
| 主按钮圆角 | 20px | **10pt** | 胶囊形按钮 |
| 主按钮内边距 | 5px 16px | **2.5pt 8pt** | 上下 2.5pt、左右 8pt |
| 主按钮背景 | `linear-gradient(135deg, rgba(255,231,77,1), rgba(255,221,0,1))` | — | `gradient-yellow`（135° 渐变） |
| 主按钮文字字号 | 22px | **11pt** | Medium 500（`font-weight: 500`） |
| 主按钮文字颜色 | `#111111` | — | `text-primary` |
| 主按钮文字对齐 | `text-align: center` | — | 居中对齐 |
| **右侧关闭图标区（.frame-2）** | 24×24px | **12×12pt** | `flex-shrink: 0`，放置关闭图标（`icon-iconfont-cancel-line-regular`，24px，`rgba(255,255,255,0.6)`）|

##### （C）双按钮变体专属（`.component-1`）

| 区域 | @2x 尺寸（px） | pt 值 | Token / 说明 |
|------|-------------|------|------------|
| 文字区（.text-2）宽度 | 400px（弹性） | **200pt**（弹性） | `flex-grow: 1`，比单按钮变体窄 60px（30pt）以容纳额外按钮 |
| **次按钮区（.frame-4）** | 108×32px | **54×16pt** | `flex-shrink: 0` |
| 次按钮区间距（padding-left） | 24px | **12pt** | 与单按钮变体一致 |
| 次按钮区内部列间距（column-gap） | 24px | **12pt** | 与单按钮变体一致 |
| **次按钮（.instance-6）** | 84×40px | **42×20pt** | `min-width: 84px`（42pt） |
| 次按钮圆角 | 20px | **10pt** | 胶囊形按钮，与主按钮一致 |
| 次按钮内边距 | 5px 16px | **2.5pt 8pt** | 与主按钮一致 |
| 次按钮背景色 | 无（透明） | — | 不设 background，仅靠描边区分边界 |
| 次按钮描边 | `1px solid #CCCCCC` | **0.5pt** | `stroke-disabled` |
| 次按钮文字字号 | 22px | **11pt** | Regular 400（区别于主按钮的 Medium 500） |
| 次按钮文字颜色 | `#FFFFFF` | — | `white` |
| 次按钮文字对齐 | `text-align: center` | — | 居中对齐 |
| **主按钮区（.frame-5）** | 108×32px | **54×16pt** | `flex-shrink: 0` |
| 主按钮区间距（padding-left） | 24px | **12pt** | 与次按钮区一致 |
| 主按钮区内部列间距（column-gap） | 24px | **12pt** | 与次按钮区一致 |
| **主按钮（.instance-7）** | 84×40px | **42×20pt** | 与 `.instance-2` 完全一致 |
| 主按钮圆角 | 20px | **10pt** | — |
| 主按钮内边距 | 5px 16px | **2.5pt 8pt** | — |
| 主按钮背景 | `linear-gradient(135deg, rgba(255,231,77,1), rgba(255,221,0,1))` | — | `gradient-yellow`（135° 渐变） |
| 主按钮文字字号 | 22px | **11pt** | Medium 500 |
| 主按钮文字颜色 | `#111111` | — | `text-primary` |

> **@2x → pt 换算规则**：所有 @2x 设计稿尺寸均除以 2 得到 pt 值。
>
> ⚠️ **注意**：
> - 容器宽度固定 **702px（351pt）**，不随内容拉伸；文字区通过 `flex-grow: 1` 自适应填充剩余空间
> - 文字区设置 `overflow: hidden; white-space: nowrap; text-overflow: ellipsis`，超长文案自动截断省略
> - **单按钮变体**文字区最大宽度约 **460px（230pt）**，右侧 **48px（24pt）** 的 `.frame-2` 为关闭图标区，放置 `icon-iconfont-cancel-line-regular`（24px，`rgba(255,255,255,0.6)`）
> - **双按钮变体**文字区最大宽度缩减至 **400px（200pt）**（比单按钮窄 60px/30pt），以容纳额外的次按钮；**无** `.frame-2` 占位区，两个按钮紧贴排列
> - **次按钮与主按钮外形尺寸完全一致**（84×40px @2x / 42×20pt），差异仅在：次按钮透明背景+描边+Regular 字重 vs 主按钮渐变背景+Medium 字重

#### 2.7.3 功能类 · 双行内容·无主副标题（contentType=functional, rowCount=double-no-title）

| 变体 | 容器尺寸（@2x） | 容器尺寸（pt） | 按钮数量 | 说明 |
|------|--------------|-------------|---------|------|
| 单按钮（`buttonCount=single`） | 702×104px | **351×52pt** | 1 个主按钮（黄色渐变） | 左侧图片/图标区（带圆角背景）+ 双行正文 + 右侧主按钮 + 占位区 |
| 无按钮（`buttonCount=none`） | 702×104px | **351×52pt** | 无按钮 | 左侧图片/图标区 + 双行正文（宽度更大）+ 右侧占位区 |

##### （A）容器及布局（double-no-title · 单按钮）

| 区域 | @2x 尺寸（px） | pt 值 | Token / 说明 |
|------|-------------|------|------------|
| **外层容器（.component）** | 702×104px | **351×52pt** | `flex-direction: column; justify-content: start; align-items: start` |
| **内层容器（.frame）** | 702×104px | **351×52pt** | `align-self: stretch`，`border-radius: 16px`（8pt） |
| 容器背景色 | `rgba(0,0,0,0.8)` | — | `mask-heavy`，与单行变体一致 |
| 容器内边距（上下） | 20px | **10pt** | — |
| 容器内边距（左右） | 24px | **12pt** | `cs-12` |
| 容器列间距（column-gap） | 16px | **8pt** | ⚠️ 比单行变体（8px/4pt）大一倍，因左侧图片区更大 |

##### （B）左侧图片/图标区（.frame-1）

| 属性 | @2x 值（px） | pt 值 | Token / 说明 |
|------|------------|------|------------|
| 尺寸 | 56×56px | **28×28pt** | `flex-shrink: 0`，固定正方形 |
| 圆角 | 8px | **4pt** | 二级圆角（`radius-s`） |
| 背景色 | `#FFF6B8` | — | 淡黄色底（可配合图标/图片使用），`overflow: hidden` |

> ⚠️ 与单行变体（30×30px 图标区）不同：double-no-title 变体左侧区域更大（56×56px），有明确的圆角背景，适合放置**商品小图或品牌图标**。

##### （C）单按钮变体 · 中间内容区（.frame-2，buttonCount=single）

| 属性 | @2x 值（px） | pt 值 | Token / 说明 |
|------|------------|------|------------|
| 整体尺寸 | 弹性（flex-grow:1），582×64px | **291×32pt** | `flex-direction: row; align-items: center` |
| **文字区（.text）** | 弹性（flex-grow:1），426×64px | **213×32pt** | `flex-grow: 1` |
| 文字高度 | 64px | **32pt** | 允许双行展示，行高 32px × 2 行 |
| 文字字体 | `"PingFang SC"` | — | 完整 fallback 链见设计系统规范 |
| 文字字号 | 24px | **12pt** | Regular 400 |
| 文字行高 | 32px | **16pt** | — |
| 文字颜色 | `#FFFFFF` | — | `text-on-dark` |
| 文字溢出 | **不截断**（无 `white-space: nowrap`，无 `text-overflow: ellipsis`） | — | ⚠️ 与单行变体不同，允许自然换行最多 2 行 |

##### （D）单按钮变体 · 按钮区（.frame-3）及按钮（.instance，buttonCount=single）

| 属性 | @2x 值（px） | pt 值 | Token / 说明 |
|------|------------|------|------------|
| **按钮区（.frame-3）** | 108×32px | **54×16pt** | `flex-shrink: 0`，与单行变体 `.frame-1` 尺寸一致 |
| 按钮区 padding-left | 24px | **12pt** | 按钮区与文字区的间距 |
| 按钮区 column-gap | 24px | **12pt** | — |
| **主按钮（.instance）** | 84×40px | **42×20pt** | `min-width: 84px`（42pt），胶囊形 |
| 主按钮圆角 | 20px | **10pt** | — |
| 主按钮内边距 | 5px 16px | **2.5pt 8pt** | 上下 2.5pt、左右 8pt |
| 主按钮背景 | `linear-gradient(135deg, rgba(255,231,77,1), rgba(255,221,0,1))` | — | `gradient-yellow`（与单行变体完全一致） |
| 主按钮文字字号 | 22px | **11pt** | Medium 500 |
| 主按钮文字颜色 | `#111111` | — | `text-primary` |
| 主按钮文字对齐 | `text-align: center` | — | 居中对齐 |
| **右侧占位区（.frame-4）** | 24×24px | **12×12pt** | `flex-shrink: 0`，与单行变体 `.frame-2` 完全一致，预留关闭图标位 |

##### （E）无按钮变体属性（buttonCount=none）

无按钮变体内部布局简化，去掉了按钮区，文字区进一步宽度。

| 属性 | @2x 值（px） | pt 值 | Token / 说明 |
|------|------------|------|------------|
| **内层容器（.frame / .frame-4）** | 702×104px | **351×52pt** | `align-self: stretch`；`border-radius: 16px`（8pt）；`justify-content: center` |
| 内层容器列间距 | 16px | **8pt** | 与单按钮变体一致 |
| **左侧图片区（.frame-1 / .frame-5）** | 56×56px | **28×28pt** | `flex-shrink: 0`；`border-radius: 8px`（4pt）；`overflow: hidden`；背景色 `#FFF6B8` |
| **中间内容区（.frame-2 / .frame-6）** | 弹性（flex-grow:1），582×64px | **291×32pt** | `flex-direction: row; align-items: center` |
| **文字区（.text / .text-1）** | 弹性（flex-grow:1），534×64px | **267×32pt** | ⚠️ `flex-grow: 1`；**无按钮使文字区可用宽度更大**（534px vs 单按钮的 426px） |
| 文字字号 | 24px | **12pt** | Regular 400，与单按钮变体一致 |
| 文字行高 | 32px | **16pt** | — |
| 文字颜色 | `#FFFFFF` | — | `text-on-dark` |
| 文字高度 | 64px | **32pt** | 双行容器，自然换行最多 2 行 |
| **右侧占位区（.frame-3 / .frame-7）** | 24×24px | **12×12pt** | `flex-shrink: 0`，与单按钮变体占位区尺寸相同，预留关闭图标位 |

**无按钮变体的组件集画板信息：**

| 属性 | @2x 值（px） | pt 值 | 说明 |
|------|------------|------|------|
| 画板尺寸 | 862×448px | **431×224pt** | `.componentset` 整体容器 |
| 画板边框 | `3px dashed #111111` | **1.5pt dashed** | 仅设计稿展示用 |
| 画板圆角 | 40px | **20pt** | 仅设计稿展示用 |
| **变体一位置（单按钮）** | top:80px, left:80px | **top:40pt, left:40pt** | `.component` 绝对定位 |
| **变体二位置（无按钮）** | top:264px, left:80px | **top:132pt, left:40pt** | `.component-1` 绝对定位 |
| 变体垂直间距 | 80px（264−80−104） | **40pt** | 两变体之间的间隔 |

> **@2x → pt 换算规则**：所有 @2x 设计稿尺寸均除以 2 得到 pt 值。
>
> ⚠️ **与单行变体的关键差异对比**：
>
> | 属性 | 单行变体（rowCount=single） | 双行无标题·单按钮 | 双行无标题·无按钮 |
> |------|--------------------------|----------------------|--------------------|
> | 容器高度 | 72px（36pt） | **104px（52pt）** | **104px（52pt）** |
> | 左侧区域尺寸 | 30×30px（15pt），无背景 | **56×56px（28pt），圆角 8px，#FFF6B8** | **56×56px（28pt），圆角 8px，#FFF6B8** |
> | 容器列间距 | 8px（4pt） | **16px（8pt）** | **16px（8pt）** |
> | 文字区宽度 | 弹性 | **426px（213pt）**（按钮占用部分空间） | **534px（267pt）**（无按钮，可用空间更大） |
> | 文字溢出 | `ellipsis` 截断 | **自然换行，最多 2 行** | **自然换行，最多 2 行** |
> | 按钮规格 | 六级按钮，84×40px | **六级按钮，84×40px** | **无按钮** |
> | 右侧占位区 | 48×24px（`.frame-2`） | **48×24px（`.frame-4`）** | **48×24px（`.frame-3/.frame-7`）** |

### 2.8 DOM 结构规范（功能类 · 单行内容，rowCount=single）

#### 2.8.1 单按钮变体（buttonCount=single）

对应组件集中 `.component`（top:80px, left:104px）。

```
.component（容器，flex-row，justify-center，align-items-center，column-gap 4pt，padding 10pt上下/12pt左右，border-radius:8pt，background:rgba(0,0,0,0.8)，351×36pt）
├── .instance（左侧图标区，15×15pt，flex-shrink:0）
└── .frame（中间内容区，flex-row，justify-start，align-items-center，flex-grow:1，308×16pt）
    ├── .text（正文文字区，flex-grow:1，230×16pt，ellipsis 截断，24px/400，#FFFFFF）
    └── .frame-1（按钮区，flex-shrink:0，54×16pt，padding-left:12pt，column-gap:12pt）
        ├── .instance-2（主按钮，42×20pt，胶囊形，gradient-yellow，border-radius:10pt）
        │   └── .text-1（按钮文字，22px/500，#111111，text-align:center）
        └── .frame-2（右侧关闭图标区，12×12pt，flex-shrink:0，padding:0）
            └── .close-icon（icon-iconfont-cancel-line-regular，24px，rgba(255,255,255,0.6)，aria-label:关闭）
```

#### 2.8.2 双按钮变体（buttonCount=double）

对应组件集中 `.component-1`（top:232px, left:104px）。

```
.component-1（容器，flex-row，justify-center，align-items-center，column-gap 4pt，padding 10pt上下/12pt左右，border-radius:8pt，background:rgba(0,0,0,0.8)，351×36pt）
├── .instance-4（左侧图标区，15×15pt，flex-shrink:0）
└── .frame-3（中间内容区，flex-row，justify-start，align-items-center，flex-grow:1，308×16pt）
    ├── .text-2（正文文字区，flex-grow:1，200×16pt，ellipsis 截断，24px/400，#FFFFFF）
    ├── .frame-4（次按钮区，flex-shrink:0，54×16pt，padding-left:12pt，column-gap:12pt）
    │   └── .instance-6（次按钮，42×20pt，胶囊形，透明背景，border:1px solid #CCCCCC）
    │       └── .text-3（按钮文字，22px/400，#FFFFFF，text-align:center）
    └── .frame-5（主按钮区，flex-shrink:0，54×16pt，padding-left:12pt，column-gap:12pt）
        └── .instance-7（主按钮，42×20pt，胶囊形，gradient-yellow，border-radius:10pt）
            └── .text-4（按钮文字，22px/500，#111111，text-align:center）
```

> - **单按钮变体**：`.frame` 内三子元素横排：`.text`（文字，230pt宽）+ `.frame-1`（主按钮区）+ `.frame-2`（关闭图标区）；文字区更宽（460px/230pt vs 双按钮的 400px/200pt）
> - **双按钮变体**：`.frame-3` 内三子元素横排：`.text-2`（文字，200pt宽）+ `.frame-4`（次按钮区）+ `.frame-5`（主按钮区）；**无占位区 `.frame-2`**，两个按钮紧贴排列
> - **次按钮（.instance-6）与主按钮（.instance-7）外形完全一致**（84×40px @2x / 42×20pt），差异仅在：次按钮用 `border: 1px solid #CCCCCC` + Regular 400 + 白色文字；主按钮用 `gradient-yellow` + Medium 500 + 深色文字
> - **图标区（.instance / .instance-4）**：15×15pt，始终为 `flex-shrink: 0` 固定位置；示例使用 `icon-iconfont-inform-line-medium`，字号 30px，颜色 `#FFFFFF`
> - **按钮级别**：单行内容的按钮对应 **六级按钮** 规范（详见 `button.md` 六级按钮章节）

### 2.9 DOM 结构规范（功能类 · 双行内容·无主副标题，rowCount=double-no-title）

#### 2.9.1 单按钮变体（buttonCount=single）

```
.component（外层容器，flex-col，justify-start，align-items-start，351×52pt）
└── .frame（内层容器，flex-row，justify-center，align-items-center，column-gap 8pt，padding 10pt上下/12pt左右，align-self:stretch，border-radius:8pt，background:rgba(0,0,0,0.8)，351×52pt）
    ├── .frame-1（左侧图片/图标区，28×28pt，flex-shrink:0，border-radius:cr-4/4pt，背景色 #FFF6B8，overflow:hidden）
    └── .frame-2（中间+右侧内容区，flex-row，flex-grow:1，291×32pt）
        ├── .text（正文文字区，flex-grow:1，最多双行，213×32pt，24px/400，#FFFFFF，自然换行）
        └── .frame-3（按钮区，flex-shrink:0，54×16pt，padding-left:cs-12/12pt，column-gap:12pt）
            ├── .instance（主按钮，42×20pt，胶囊形，gradient-yellow）
            │   └── .text-1（按钮文字，11pt/Medium 500，#111111）
            └── .frame-4（右侧占位/关闭图标区，12×12pt，flex-shrink:0，padding:0）
```

#### 2.9.2 无按钮变体（buttonCount=none）

此变体对应本次 @2x CSS 代码（两个实例 `.component` / `.component-1`），去掉了按钮区，文字区宽度更大。

```
.component / .component-1（外层容器，flex-col，justify-start，align-items-start，351×52pt，position:absolute）
│   top:40pt, left:40pt（变体一）  /  top:132pt, left:40pt（变体二）
└── .frame / .frame-4（内层容器，flex-row，justify-center，align-items-center，column-gap 8pt，padding 10pt上下/12pt左右，align-self:stretch，border-radius:8pt，background:rgba(0,0,0,0.8)，351×52pt）
    ├── .frame-1 / .frame-5（左侧图片区，28×28pt，flex-shrink:0，border-radius:4pt，背景色 #FFF6B8，overflow:hidden）
    └── .frame-2 / .frame-6（中间+右侧内容区，flex-row，align-items:center，flex-grow:1，291×32pt）
        ├── .text / .text-1（正文文字区，flex-grow:1，最多双行，267×32pt，24px/400，#FFFFFF，自然换行）
        └── .frame-3 / .frame-7（右侧占位区，flex-shrink:0，24×12pt）
```

> - **外层容器与内层容器尺寸相同**（702×104px @2x），外层为 flex-col 包裹，内层（`.frame/.frame-4`）为实际渲染的深色横幅
> - **左侧区域（.frame-1 / .frame-5）**：有圆角背景的图片容器（28×28pt），背景色 `#FFF6B8`（淡黄色），`overflow:hidden` 确保图片不超出圆角
> - **文字区（.text / .text-1）**：无 `white-space:nowrap`，允许自然换行；**无按钮时宽度达 534px（267pt）**，比单按钮变体的 426px 宽出 108px（54pt）
> - **右侧占位区（.frame-3 / .frame-7）**：24×24px @2x（12×12pt），仅保留占位区，**不含按钮**；预留关闭图标位
> - **两个变体差异**：仅在于画板内绝对定位的 `top` 值（40pt vs 132pt），内容结构完全一致
> - **按钮级别**：单按钮变体的按钮对应 **六级按钮** 规范（详见 `button.md` 六级按钮章节）

#### 2.7.4 功能类 · 双行内容·有主副标题（contentType=functional, rowCount=double-with-title）

| 变体 | 容器尺寸（@2x） | 容器尺寸（pt） | 按钮数量 | 说明 |
|------|--------------|-------------|---------|------|
| 单按钮·标准图片区（`buttonCount=single, leftContent=icon`） | 702×120px | **351×60pt** | 1 个主按钮（黄色渐变，五级） | 左侧72×72px正方形图片区 + 主标题 + 副标题 + 右侧主按钮 + 占位区 |
| 单按钮·大图出血区（`buttonCount=single, leftContent=custom-large`） | 702×120px | **351×60pt** | 1 个主按钮（黄色渐变，五级） | 左侧180×120px出血图片区（绝对定位，超出容器顶部12px）+ 主标题 + 副标题 + 右侧主按钮 + 占位区 |

##### （A）容器及布局（double-with-title · 单按钮）

| 区域 | @2x 尺寸（px） | pt 值 | Token / 说明 |
|------|-------------|------|------------|
| **容器（.component）** | 702×120px | **351×60pt** | `position: absolute; flex-direction: row; justify-content: start; align-items: center` |
| 容器背景色 | `rgba(0,0,0,0.8)` | — | 深色容器（与功能类其他变体一致） |
| 容器阴影 | 无 | — | 深色容器无需阴影 |
| 容器内边距（上下） | **0px** | **0pt** | ⚠️ 无上下内边距，垂直间距由内部 `.frame-3` padding 控制 |
| 容器内边距（左右） | 24px | **12pt** | `cs-12`，与其他变体一致 |
| 容器列间距（column-gap） | 16px | **8pt** | 与双行无标题（16px）一致 |
| 容器圆角 | 16px | **8pt** | 与其他功能类变体一致（`radius-m`） |

##### （B-1）标准图片区 · 左侧图片/图标区（.frame，leftContent=icon）

| 属性 | @2x 值（px） | pt 值 | Token / 说明 |
|------|------------|------|------------|
| 尺寸 | 72×72px | **36×36pt** | `flex-shrink: 0`，固定正方形 |
| 圆角 | 12px | **6pt** | 三级圆角（`radius-m-s`） |
| 背景色 | `#FFFADB` | — | 淡黄色底，与 double-no-title 变体一致（可配合图标/图片） |

> ⚠️ 与 double-no-title（56×56px）和 single（30×30px）相比，此变体左侧图片区最大（72×72px/36pt），圆角也更大（12px vs 8px vs 无）。

##### （B-2）大图出血区 · 容器及布局（leftContent=custom-large，单按钮）

此变体左侧图片区采用**出血设计**：图片容器宽度 192px，内部图片元素（`.frame-1`）使用 `position: absolute` 溢出容器顶部 12px，实现视觉上超出横幅边界的大图效果。

| 区域 | @2x 尺寸（px） | pt 值 | Token / 说明 |
|------|-------------|------|------------|
| **容器（.component）** | 702×120px | **351×60pt** | `position: absolute; flex-direction: row; justify-content: start; align-items: center` |
| 容器背景色 | `rgba(0,0,0,0.8)` | — | 深色容器，与功能类其他变体一致 |
| 容器阴影 | 无 | — | 深色容器无需阴影 |
| 容器内边距 | `padding: 0px 24px 0px 0px` | **0右12pt** | ⚠️ **仅右侧有 24px（12pt）内边距，左侧为 0**；区别于标准图片区变体的左右对称内边距 |
| 容器列间距（column-gap） | 16px | **8pt** | 与标准图片区变体一致 |
| 容器圆角 | 16px | **8pt** | 与功能类其他变体一致（`radius-m`） |
| **左侧出血容器（.frame）** | 192×120px | **96×60pt** | `flex-shrink: 0`，`align-self: stretch`；⚠️ 无背景色，无圆角，仅作定位容器 |
| **图片本体（.frame-1，绝对定位）** | 180×120px | **90×60pt** | `position: absolute; top: -12px; left: 12px; bottom: 12px`；`border-radius: 12px`（6pt）；`overflow: hidden`；背景色 `#FFFADB` |
| 图片溢出量（顶部） | -12px | **-6pt** | ⚠️ 图片向上溢出容器 12px，实现出血效果（超出横幅上边界） |
| 图片 left 偏移 | 12px | **6pt** | 图片距容器左边 6pt |
| 图片 bottom 偏移 | 12px | **6pt** | 图片距容器底部 6pt |

> ⚠️ **出血布局要点**：
> - `.frame`（192×120px）是一个无视觉样式的占位容器，在 flex 流中占据左侧空间
> - `.frame-1` 使用 `position:absolute` 相对于 `.frame` 定位，`top:-12px` 使图片向上超出横幅边界 12px（6pt），产生出血视觉效果
> - 图片实际显示尺寸为 180×120px @2x（90×60pt），但视觉上方会超出横幅 12px（6pt）
> - 容器需设置 `overflow: visible`（或不裁剪）才能让图片溢出顶部显示

##### （B-2 续）大图出血区 · 右侧内容区

| 区域 | @2x 尺寸（px） | pt 值 | Token / 说明 |
|------|-------------|------|------------|
| **右侧内容区（.frame-2）** | 弹性（flex-grow:1），466×120px | **233×60pt** | `flex-direction: row; justify-content: start; align-items: center` |
| **中内容区（.frame-3）** | 弹性（flex-grow:1），418×120px | **209×60pt** | `flex-direction: row; align-items: center; column-gap: 24px（12pt）` |
| **文字列（.frame-4）** | 弹性（flex-grow:1），298×120px | **149×60pt** | `flex-direction: column; justify-content: start; align-items: start; row-gap: 2px（1pt）`；`padding: 22px 0px 24px 0px` |
| **主标题（.text）** | `align-self: stretch`，298×40px | **149×20pt** | `flex-shrink: 0`；28px/500；`#111111`；`overflow:hidden; white-space:nowrap; text-overflow:ellipsis` |
| **副标题（.text-1）** | `align-self: stretch`，298×32px | **149×16pt** | `flex-shrink: 0`；24px/400；`#555555`；自然换行 |
| **主按钮（.instance）** | 96×48px | **48×24pt** | 五级按钮，与标准图片区变体完全一致 |
| **右侧占位区（.frame-5）** | 24×24px | **12×12pt** | `flex-shrink: 0`，预留关闭图标位 |

> ⚠️ **与标准图片区变体（leftContent=icon）的差异**：
> - 容器左侧内边距为 **0**（标准变体为 24px/12pt），左侧空间完全交给图片出血区
> - 左侧占位区宽度 **192px（96pt）**（标准变体为 72px/36pt），出血图片更宽
> - 文字列宽度 **298px（149pt）**（标准变体为 394px/197pt），因左侧图片区更宽而相应缩短

##### （C）标准图片区 · 内容区（.frame-1 → .frame-2 → .frame-3 文字区，leftContent=icon）

| 属性 | @2x 值（px） | pt 值 | Token / 说明 |
|------|------------|------|------------|
| **外内容区（.frame-1）** | 弹性（flex-grow:1），562×120px | **281×60pt** | `flex-direction: row; align-items: center` |
| **中内容区（.frame-2）** | 弹性（flex-grow:1），514×120px | **257×60pt** | `flex-direction: row; align-items: center; column-gap: 24px（12pt）` |
| **文字列（.frame-3）** | 弹性（flex-grow:1），394×120px | **197×60pt** | `flex-direction: column; justify-content: start; align-items: start; row-gap: 2px（1pt）` |
| 文字列内边距（上） | 22px | **11pt** | 垂直位置控制（顶部） |
| 文字列内边距（下） | 24px | **12pt** | 垂直位置控制（底部） |
| 文字列左右内边距 | 0px | **0pt** | — |

##### （D）标准图片区 · 主标题（.text，leftContent=icon）

| 属性 | @2x 值（px） | pt 值 | Token / 说明 |
|------|------------|------|------------|
| 尺寸 | `align-self: stretch`，394×40px | **197×20pt** | `flex-shrink: 0`，宽度撑满文字列 |
| 字体 | `"PingFang SC"` | — | — |
| 字号 | 28px | **14pt** | ⚠️ 比正文（24px）更大，体现标题层级 |
| 行高 | 40px | **20pt** | — |
| 字重 | 500（Medium） | — | ⚠️ `font-weight: 500`，中黑体 |
| 颜色 | `#FFFFFF` | — | 白色主标题（深色容器上使用） |
| 溢出处理 | `ellipsis` 截断 | — | `overflow:hidden; white-space:nowrap; text-overflow:ellipsis`，标题限 1 行 |

##### （E）标准图片区 · 副标题（.text-1，leftContent=icon）

| 属性 | @2x 值（px） | pt 值 | Token / 说明 |
|------|------------|------|------------|
| 尺寸 | `align-self: stretch`，394×32px | **197×16pt** | `flex-shrink: 0`，宽度撑满文字列 |
| 字体 | `"PingFang SC"` | — | — |
| 字号 | 24px | **12pt** | 与正文字号一致 |
| 行高 | 32px | **16pt** | — |
| 字重 | 400（Regular） | — | 常规体 |
| 颜色 | `rgba(255,255,255,0.6)` | — | 半透明白色，`text-secondary`（深色容器）；与主标题（`#FFFFFF`）形成层级对比 |
| 溢出处理 | **不截断** | — | 无 `white-space:nowrap`，可自然换行（建议不超过 2 行） |

##### （F）标准图片区 · 按钮区（.frame-2 内 .instance）及右侧占位区（.frame-4，leftContent=icon）

| 属性 | @2x 值（px） | pt 值 | Token / 说明 |
|------|------------|------|------------|
| 中内容区列间距 | 24px | **12pt** | 文字列与按钮间距（`.frame-2` 的 `column-gap`） |
| **主按钮（.instance）** | 96×48px | **48×24pt** | ⚠️ **五级按钮**，比六级按钮（84×40px）更大 |
| 主按钮 min-width | 96px | **48pt** | — |
| 主按钮圆角 | 24px | **12pt** | 胶囊形（`border-radius = height / 2`） |
| 主按钮内边距 | 7px 20px | **3.5pt 10pt** | 上下 3.5pt（`padding: 7px 20px 7px 20px`）、左右 10pt |
| 主按钮背景 | `linear-gradient(135deg, rgba(255,231,77,1) 0%, rgba(255,221,0,1) 100%)` | — | `gradient-yellow`（135° 渐变，与其他变体一致） |
| 主按钮文字字号 | 24px | **12pt** | ⚠️ 比六级按钮文字（22px/11pt）更大 |
| 主按钮文字行高 | 32px | **16pt** | — |
| 主按钮文字字重 | 500（Medium） | — | — |
| 主按钮文字颜色 | `#111111` | — | `text-primary` |
| 主按钮文字对齐 | `text-align: center` | — | 居中 |
| 主按钮文字宽度 | 48px | **24pt** | `white-space: nowrap`，固定宽度不换行 |
| **右侧占位区（.frame-4）** | 24×24px | **12×12pt** | `flex-shrink: 0`，与其他变体占位区完全一致，预留关闭图标位 |

> **@2x → pt 换算规则**：所有 @2x 设计稿尺寸均除以 2 得到 pt 值。
>
> ⚠️ **与前两种变体的关键差异对比**：
>
> | 属性 | 单行（single） | 双行无标题（double-no-title） | 双行有标题·标准（double-with-title, icon） | 双行有标题·大图（double-with-title, custom-large） |
> |------|-------------|--------------------------|------------------------------------------|-------------------------------------------------|
> | 容器高度 | 72px（36pt） | 104px（52pt） | **120px（60pt）** | **120px（60pt）** |
> | 容器圆角 | 16px（8pt） | 16px（8pt） | **16px（8pt）** | **16px（8pt）** |
> | 容器内边距 | 20px上下/24px左右 | 20px上下/24px左右 | **0上下/24px左右** | **0上下/0左+24px右** |
> | 容器列间距 | 8px（4pt） | 16px（8pt） | **16px（8pt）** | **16px（8pt）** |
> | 左侧区域尺寸 | 30×30px（15pt） | 56×56px（28pt） | **72×72px（36pt）正方形** | **192×120px（96×60pt）出血容器** |
> | 图片实际尺寸 | — | — | 72×72px（36pt） | **180×120px（90×60pt），top:-12px溢出** |
> | 容器背景色 | `rgba(0,0,0,0.8)` 深色 | `rgba(0,0,0,0.8)` 深色 | **`rgba(0,0,0,0.8)` 深色** | **`rgba(0,0,0,0.8)` 深色** |
> | 文字列宽度 | 弹性 | 弹性 | **394px（197pt）** | **298px（149pt）**（因图片区更宽而缩短） |
> | 文字层级 | 单行正文（白色） | 双行正文（白色） | **主标题（#FFFFFF/500）+ 副标题（rgba(255,255,255,0.6)/400）** | **同左** |
> | 按钮级别 | 六级（84×40px） | 六级（84×40px） | **五级（96×48px）** | **五级（96×48px）** |
> | 按钮字号 | 22px（11pt） | 22px（11pt） | **24px（12pt）** | **24px（12pt）** |

### 2.10 DOM 结构规范（功能类 · 双行内容·有主副标题，rowCount=double-with-title）

#### 2.10.1 标准图片区变体（leftContent=icon）

```
.component（容器，position:absolute，flex-row，justify-start，align-items-center，column-gap 8pt，padding 0上下/12pt左右，351×60pt，border-radius 8pt，background:rgba(0,0,0,0.8)，无阴影）
├── .frame（左侧图片/图标区，36×36pt，flex-shrink:0，border-radius:6pt，背景色 #FFFADB）
└── .frame-1（右侧内容区，flex-row，flex-grow:1，281×60pt，align-items:center）
    └── .frame-2（中间+按钮区，flex-row，flex-grow:1，align-items:center，column-gap:12pt，257×60pt）
        ├── .frame-3（文字列，flex-col，flex-grow:1，justify-start，align-items:start，row-gap:1pt，padding:11pt上/12pt下，197×60pt）
        │   ├── .text（主标题，align-self:stretch，197×20pt，28px/500，#FFFFFF，ellipsis截断）
        │   └── .text-1（副标题，align-self:stretch，197×16pt，24px/400，rgba(255,255,255,0.6)，可换行）
        ├── .instance（主按钮，48×24pt，min-width:48pt，胶囊形，gradient-yellow）
        │   └── .text-2（按钮文字，24px/500，#111111，text-align:center，white-space:nowrap，24×16pt）
        └── .frame-4（右侧占位/关闭图标区，12×12pt，flex-shrink:0，padding:0）
```

> - **容器为深色背景**：`background: rgba(0,0,0,0.8)`，无阴影，与功能类其他变体保持一致
> - **容器无上下内边距**：垂直间距完全由 `.frame-3` 的 `padding-top: 22px（11pt）/ padding-bottom: 24px（12pt）` 控制
> - **主标题（.text）**：`white-space:nowrap` + `text-overflow:ellipsis`，强制单行显示，超长截断；颜色 `#FFFFFF`（深色容器上的白色主标题）
> - **副标题（.text-1）**：无 `white-space:nowrap`，允许换行，建议不超过 2 行；颜色 `rgba(255,255,255,0.6)`（半透明白色，与主标题形成层级对比）
> - **`.frame-3` 行间距（row-gap）**：2px（1pt），主副标题之间几乎无额外间距，靠行高自然堆叠
> - **`.frame-3` 垂直内边距不对称**：`padding-top: 22px（11pt）`，`padding-bottom: 24px（12pt）`，底部略大 2px
> - **按钮（.instance）直接挂在 `.frame-2` 下**，不再有单独的按钮区包裹层（区别于 single / double-no-title 变体的 `.frame-1/.frame-3` 按钮区包裹）
> - **按钮级别**：double-with-title 对应 **五级按钮** 规范（详见 `button.md` 五级按钮章节）
> - **右侧占位区（.frame-4）**：位置与其他变体一致，24×24px @2x（12×12pt），用于放置关闭图标，`padding:0`

#### 2.10.2 大图出血区变体（leftContent=custom-large）

```
.component（容器，position:absolute，flex-row，justify-start，align-items-center，column-gap 8pt，padding 0上下/0左+12pt右，351×60pt，border-radius 8pt，background:rgba(0,0,0,0.8)，无阴影）
├── .frame（左侧出血容器，96×60pt，flex-shrink:0，align-self:stretch，无背景无圆角）
│   └── .frame-1（图片本体，position:absolute，top:-6pt left:6pt bottom:6pt，90×60pt，border-radius:6pt，overflow:hidden，背景色#FFFADB）
└── .frame-2（右侧内容区，flex-row，flex-grow:1，233×60pt，align-items:center）
    └── .frame-3（中间+按钮区，flex-row，flex-grow:1，align-items:center，column-gap:12pt，209×60pt）
        ├── .frame-4（文字列，flex-col，flex-grow:1，justify-start，align-items:start，row-gap:1pt，padding:11pt上/12pt下，149×60pt）
        │   ├── .text（主标题，align-self:stretch，149×20pt，28px/500，#FFFFFF，ellipsis截断）
        │   └── .text-1（副标题，align-self:stretch，149×16pt，24px/400，rgba(255,255,255,0.6)，可换行）
        ├── .instance（主按钮，48×24pt，min-width:48pt，胶囊形，gradient-yellow）
        │   └── .text-2（按钮文字，24px/500，#111111，text-align:center，white-space:nowrap，24×16pt）
        └── .frame-5（右侧占位/关闭图标区，12×12pt，flex-shrink:0，padding:0）
```

> - **容器为深色背景**：`background: rgba(0,0,0,0.8)`，无阴影，与功能类其他变体保持一致
> - **容器左侧无内边距**：`padding: 0px 24px 0px 0px`，左侧空间完全由 `.frame`（出血容器）在 flex 流中占据
> - **出血容器（.frame）**：`align-self: stretch` 使其高度撑满容器；无背景、无圆角，仅作绝对定位的参照父元素
> - **图片本体（.frame-1）**：`position: absolute; top: -12px; left: 12px; bottom: 12px`（@2x），`top:-6pt` 使图片向上溢出横幅边界 6pt，产生出血视觉效果
> - **文字列（.frame-4）宽度缩短**：298px（149pt），比标准图片区变体（394px/197pt）窄 96px（48pt），对应左侧图片区多出的宽度差
> - 其余按钮样式与标准图片区变体**完全一致**（按钮规格均相同）；文字颜色同为深色容器规范（主标题 `#FFFFFF`，副标题 `rgba(255,255,255,0.6)`）

### 2.6（补充）运营类组件集画板信息（@2x 设计稿整体）

以下为**运营类（contentType=operational）** 组件集画板的整体参数：

| 属性 | @2x 值（px） | pt 值 | 说明 |
|------|------------|------|------|
| 画板尺寸 | 910×1072px | **455×536pt** | `.componentset` 整体容器（高于功能类） |
| 画板边框 | `3px dashed #111111` | **1.5pt dashed** | 仅设计稿展示用 |
| 画板圆角 | 40px | **20pt** | 仅设计稿展示用 |

**变体在画板中的绝对定位：**

| 变体 | 类名 | top | left | 尺寸（@2x） | 布局 | leftContent |
|------|------|-----|------|------------|------|------------|
| 通栏·图片区 | `.component` | 80px（40pt） | 80px（40pt） | 750×72px | 通栏 | 图片区 |
| 通栏·金额区 | `.component-2` | 232px（116pt） | 80px（40pt） | 750×72px | 通栏 | 金额区 |
| 通栏·自定义图片 | `.component-4` | 384px（192pt） | 80px（40pt） | 750×72px | 通栏 | 自定义满铺图片 |
| 留边·图片区 | `.component-1` | 616px（308pt） | 104px（52pt） | 702×72px | 留边 | 图片区 |
| 留边·金额区 | `.component-3` | 768px（384pt） | 104px（52pt） | 702×72px | 留边 | 金额区 |
| 留边·自定义图片 | `.component-5` | 920px（460pt） | 104px（52pt） | 702×72px | 留边 | 自定义满铺图片 |

> ⚠️ 通栏变体宽度为 **750px（375pt）**，无圆角（**0pt**）；留边变体宽度为 **702px（351pt）**，圆角 **16px（8pt）**。

#### 2.7.5 运营类 · 单行内容（contentType=operational, rowCount=single）

运营类单行横幅使用**浅色容器**（`#FFF1F0` 浅红底色），配合**红色渐变主按钮**（`gradient-red`），与功能类深色容器形成对比。

**变体总览：**

| 变体 | 容器尺寸（@2x） | 容器尺寸（pt） | 圆角 | leftContent | 说明 |
|------|--------------|-------------|------|------------|------|
| 通栏·图片区（`.component`） | 750×72px | **375×36pt** | **0pt** | 56×56px 图片区（无圆角） | 图片 + 文字 + 橙红主按钮 + 占位区 |
| 通栏·金额区（`.component-2`） | 750×72px | **375×36pt** | **0pt** | 68×64px 金额显示区 | 价格数字 + 文字 + 橙红主按钮 + 占位区 |
| 通栏·自定义图片（`.component-4`） | 750×72px | **375×36pt** | **0pt** | 537px 满铺背景图（绝对定位） | 左侧满铺图 + 右侧按钮区（绝对定位） |
| 留边·图片区（`.component-1`） | 702×72px | **351×36pt** | **8pt** | 56×56px 图片区（无圆角） | 图片 + 文字 + 橙红主按钮 + 占位区 |
| 留边·金额区（`.component-3`） | 702×72px | **351×36pt** | **8pt** | 68×64px 金额显示区 | 价格数字 + 文字 + 橙红主按钮 + 占位区 |
| 留边·自定义图片（`.component-5`） | 702×72px | **351×36pt** | **8pt** | 489px 满铺背景图（绝对定位） | 左侧满铺图 + 右侧按钮区（绝对定位） |

##### （A）运营类通用属性（所有变体共享）

| 属性 | @2x 值（px） | pt 值 | Token / 说明 |
|------|------------|------|------------|
| 容器高度 | 72px | **36pt** | 与功能类单行等高 |
| 容器上下内边距 | 8px | **4pt** | ⚠️ 比功能类（20px/10pt）**更小** |
| 容器左右内边距 | 24px | **12pt** | `cs-12`，与功能类一致 |
| 容器列间距（column-gap） | 12px | **6pt** | ⚠️ 比功能类单行（8px/4pt）稍大 |
| 容器背景色 | `#FFF1F0` | — | 浅红色底（运营类浅色容器），`bg-surface` / 品牌浅色 |
| **主按钮（.instance）** | 96×48px | **48×24pt** | **五级按钮**（与功能类 double-with-title 一致） |
| 主按钮 min-width | 96px | **48pt** | — |
| 主按钮圆角 | 24px | **12pt** | 胶囊形 |
| 主按钮内边距 | 7px 20px | **3.5pt 10pt** | — |
| 主按钮背景 | `linear-gradient(135deg, #FF5533 0%, #FF2D19 100%)` | — | **红色渐变**（`gradient-red`，运营类单行专属）|
| 主按钮文字字号 | 24px | **12pt** | Medium 500，`font-weight: 500` |
| 主按钮文字颜色 | `#FFFFFF` | — | **白色**（红色按钮上使用白色文字） |
| 主按钮文字对齐 | `text-align: center` | — | 居中 |
| **按钮区（.frame-2 / .frame-6 / .frame-10...）** | 120×48px | **60×24pt** | `flex-shrink: 0`，`padding-left: 24px（12pt）`，`column-gap: 24px（12pt）` |
| **右侧占位区（.frame-3 / .frame-7...）** | 24×24px | **12×12pt** | `flex-shrink: 0`，与功能类一致 |
| 文字字体 | `"PingFang SC"` | — | — |
| 文字字号 | 24px | **12pt** | **Medium 500**（⚠️ 运营类文字字重为 500，区别于功能类 Regular 400） |
| 文字行高 | 32px | **16pt** | — |
| 文字颜色 | `rgba(0,0,0,0.9)` | — | ⚠️ **深色文字**（运营类浅色容器上的深色字，区别于功能类白色文字） |

##### （B）通栏·图片区（`.component`）和留边·图片区（`.component-1`）专属

| 属性 | 通栏（.component） @2x | 留边（.component-1） @2x | pt 值 | 说明 |
|------|----------------------|------------------------|------|------|
| 容器宽度 | 750px | 702px | 375pt / **351pt** | 通栏撑满，留边 351pt |
| 容器圆角 | **无（0pt）** | **16px（8pt）** | — | 布局类型决定 |
| **左侧图片区（.frame / .frame-4）** | 56×56px | 56×56px | **28×28pt** | `flex-shrink: 0`，**无圆角**（区别于功能类有圆角） |
| 图片区 overflow | `overflow: hidden` | `overflow: hidden` | — | 裁剪内部图片 |
| 图片区背景色 | `#FFFADB` | `#FFFADB` | — | 淡黄色底（示意背景） |
| 文字区（.text / .text-2）宽度 | 466px（弹性） | 418px（弹性） | **233pt / 209pt** | `flex-grow: 1`；留边比通栏窄约 24pt |
| 内容区（.frame-1 / .frame-5）高度 | 48px | 48px | **24pt** | — |

> ⚠️ 运营类图片区（56×56px）与 `double-no-title` 功能类图片区同尺寸，但**无圆角**（运营类为 0pt，功能类为 4pt）。

##### （C）通栏·金额区（`.component-2`）和留边·金额区（`.component-3`）专属

金额区采用 **`MT New Digital Display`** 数字展示字体，品牌红色 `#FF2D19`，结构为「¥ 符号 + 主数字」组合。

| 属性 | @2x 值（px） | pt 值 | Token / 说明 |
|------|------------|------|------------|
| **金额区整体（.instance-4 / .instance-7）** | 68×64px | **34×32pt** | `flex-shrink: 0`，`flex-direction: row; align-items: flex-end; column-gap: 2px（1pt）` |
| **¥ 符号（.text- / .text--1）** | 17×40px | **8.5×20pt** | `flex-shrink: 0` |
| ¥ 符号字体 | `"PingFang SC"` | — | Web 环境下使用 PingFang SC 字体 |
| ¥ 符号字号 | 28px | **14pt** | `font-weight: 900`（Extra-Bold，⚠️ 比设计稿 700 更重，增强视觉对比） |
| ¥ 符号行高 | 44px | **22pt** | 与数字行高一致 |
| ¥ 符号颜色 | `#FF2D19` | — | 品牌红色（`brand-red`） |
| ¥ 符号垂直偏移 | `position: relative; top: -4px` | — | ⚠️ 向上偏移 4px，使 ¥ 符号视觉位置与数字视觉重心对齐 |
| **数字区（.frame-8 / .frame-12）** | 49×64px | **24.5×32pt** | `flex-direction: row; align-items: start` |
| **主数字（.text-72 / .text-73）** | 49×64px | **24.5×32pt** | `flex-shrink: 0`，`white-space: nowrap` |
| 主数字字体 | `"MT New Digital Display"` | — | 美团品牌数字字体 |
| 主数字字号 | 44px | **22pt** | `font-weight: 700`（Bold） |
| 主数字行高 | 64px | **32pt** | — |
| 主数字颜色 | `#FF2D19` | — | 品牌红色 |
| **备用数字（.text-88 / .text-89，隐藏）** | 63×64px | **31.5×32pt** | `visibility: hidden`，占位用（不渲染但保留空间） |
| 备用数字字号 | 44px | **22pt** | — |
| 容器上下内边距 | 4px | **2pt** | ⚠️ 比图片区变体（8px/4pt）更小，因金额区更高（64px vs 56px） |
| 文字区（.text-4 / .text-6）宽度 | 454px / 406px（弹性） | **227pt / 203pt** | `flex-grow: 1`；通栏/留边各异 |

> ⚠️ **金额区设计要点**：
> - 金额区整体高度 **64px（32pt）**，超出容器内容高度（容器 72px - padding 8px = 64px），与容器等高
> - `align-items: flex-end`（底部对齐），使 ¥ 符号与数字底部视觉对齐
> - ¥ 符号额外设置 `position: relative; top: -4px`，向上偏移 4px 微调视觉位置，实现 ¥ 符号与数字视觉重心对齐
> - `.text-88/.text-89` 为 `visibility: hidden` 的备用位，用于在数字宽度变化时保持布局稳定（最宽占位）
> - ¥ 符号字重使用 `font-weight: 900`（Extra-Bold），视觉上更厚重，与大字号数字形成整体感

##### （D）通栏·自定义图片（`.component-4`）和留边·自定义图片（`.component-5`）专属

自定义图片变体使用**绝对定位**方式将背景图和按钮区叠加，实现图片满铺左侧效果：

| 属性 | 通栏（.component-4） @2x | 留边（.component-5） @2x | pt 值 | 说明 |
|------|------------------------|------------------------|------|------|
| 容器尺寸 | 750×72px | 702×72px | 375×36pt / **351×36pt** | `overflow: hidden` |
| 容器圆角 | **无（0pt）** | **16px（8pt）** | — | — |
| **背景图区（.frame-19 / .frame-23）** | 537×72px | 489×72px | **268.5×36pt / 244.5×36pt** | 绝对定位：`top:0, left:0`，`overflow:hidden`，背景色 `#FFFADB` |
| 背景图区宽度占比 | 537/750 ≈ **71.6%** | 489/702 ≈ **69.7%** | — | 左侧约 70% 为图片区域 |
| **按钮区（.frame-16 / .frame-20）** | 192×48px | 192×48px | **96×24pt** | 绝对定位：`top:12px（6pt）, right:0`，`padding-right:24px（12pt）`，`justify-content:end` |
| 按钮区内部布局（.frame-17 / .frame-21） | 120×48px | 120×48px | **60×24pt** | `padding-left:24px（12pt）`，`column-gap:24px（12pt）` |
| 主按钮 | 与通用属性一致 | 与通用属性一致 | **48×24pt** | 红色渐变（`gradient-red`），五级按钮 |
| 右侧占位区（.frame-18 / .frame-22） | 24×24px | 24×24px | **12×12pt** | — |

> ⚠️ **自定义图片变体的特殊布局**：
> - 整个容器设置 `overflow: hidden`，子元素使用**绝对定位**叠层，而非 flexbox 横排
> - 背景图区（`.frame-19/.frame-23`）从容器左上角铺开，高度撑满容器（72px/36pt）
> - 按钮区（`.frame-16/.frame-20`）绝对定位于右侧，`top:12px` 垂直居中于容器（(72-48)/2=12px）
> - 背景图与按钮区存在**视觉重叠**，背景图自然在按钮区下方，层叠关系由 DOM 顺序决定（后者在上）
> - 通栏版背景图 537px，留边版 489px，差异约 24pt，与两者宽度差（750-702=48px/24pt）的一半对应

#### 2.7.6 运营类 · 双行内容·有主副标题（contentType=operational, rowCount=double-with-title）

运营类双行留边横幅使用**白色容器**（`#FFFFFF`），配合 `box-shadow` 阴影区分层次，与运营类单行的浅红底色不同。

| 变体 | 容器尺寸（@2x） | 容器尺寸（pt） | 按钮数量 | 说明 |
|------|--------------|-------------|---------|------|
| 标准图片区（`leftContent=icon`） | 702×120px | **351×60pt** | 1 个主按钮（黄色渐变，五级）+ 关闭图标 | 左侧 72×72px 正方形图片区 + 主标题 + 副标题 + 右侧主按钮 + 关闭图标 |
| 大图出血区（`leftContent=custom-large`） | 702×120px | **351×60pt** | 1 个主按钮（黄色渐变，五级）+ 关闭图标 | 左侧 192×120px 出血图片区（绝对定位，超出容器顶部 12px）+ 主标题 + 副标题 + 右侧主按钮 + 关闭图标 |

##### （A）容器及布局（operational · double-with-title）

| 区域 | @2x 尺寸（px） | pt 值 | Token / 说明 |
|------|-------------|------|------------|
| **容器（.component）** | 702×120px | **351×60pt** | `flex-direction: row; justify-content: start; align-items: center` |
| 容器背景色 | `#FFFFFF` | — | ⚠️ **白色容器**（运营类 double-with-title 使用白色容器，区别于运营类单行 `#FFF1F0`） |
| 容器阴影 | `box-shadow: 0px 8px 32px 0px rgba(0,0,0,0.12)` | — | `shadow-overlay`，白色容器时需加阴影 |
| 容器内边距（上下） | 16px | **8pt** | 垂直内边距，确保内容区居中 |
| 容器内边距（左右） | 24px | **12pt** | `cs-12` |
| 容器列间距（column-gap） | 12px | **6pt** | 与运营类单行一致 |
| 容器圆角 | 16px | **8pt** | `radius-m`，与运营类单行留边一致 |
| 容器最小高度 | 120px | **60pt** | `min-height: 120px`，内容较多时可撑高 |

##### （B）文字样式

| 属性 | @2x 值（px） | pt 值 | Token / 说明 |
|------|------------|------|------------|
| **主标题字号** | 28px | **14pt** | `font-weight: 500`（Medium），标题层级 |
| 主标题行高 | 40px | **20pt** | — |
| 主标题颜色 | `rgba(0,0,0,0.9)` | — | 深色主标题（白色容器上使用） |
| 主标题溢出 | `ellipsis` 截断 | — | `overflow:hidden; white-space:nowrap; text-overflow:ellipsis`，限 1 行 |
| **副标题字号** | 24px | **12pt** | `font-weight: 400`（Regular） |
| 副标题行高 | 32px | **16pt** | — |
| 副标题颜色 | `#555555` | — | `text-secondary`，中灰色 |
| 副标题溢出 | 自然换行 | — | 无 `white-space:nowrap`，建议不超过 2 行 |
| 文字列 row-gap | 2px | **1pt** | 主副标题间距 |

##### （C）按钮及关闭图标

| 属性 | @2x 值（px） | pt 值 | Token / 说明 |
|------|------------|------|------------|
| **主按钮（.instance）** | 96×48px | **48×24pt** | 五级按钮，黄色渐变（`gradient-yellow`） |
| 主按钮圆角 | 24px | **12pt** | 胶囊形 |
| 主按钮背景 | `linear-gradient(135deg, rgba(255,231,77,1) 0%, rgba(255,221,0,1) 100%)` | — | `gradient-yellow` |
| 主按钮文字字号 | 24px | **12pt** | `font-weight: 500`，颜色 `#111111` |
| 按钮区列间距 | 24px | **12pt** | 按钮与关闭图标间距 |
| **关闭图标** | 24×24px | **12×12pt** | `icon-iconfont-cancel-line-regular`，`padding:0` |
| 关闭图标颜色 | `rgba(0,0,0,0.35)` | — | 深色图标（白色容器上使用） |

##### （E）功能类 vs 运营类关键差异对比

| 属性 | 功能类（functional） | 运营类（operational） |
|------|---------------------|---------------------|
| 容器背景色 | `rgba(0,0,0,0.8)` 深色 | 单行：`#FFF1F0` 浅红；双行：`#FFFFFF` **白色** |
| 文字颜色 | `#FFFFFF` 白色 | `rgba(0,0,0,0.9)` **深色**（单行）；`rgba(0,0,0,0.9)` / `#555555`（双行主/副标题） |
| 文字字重 | Regular 400 | **Medium 500** |
| 按钮背景 | 黄色渐变（`#FFE74D→#FFDD00`） | 单行：**红色渐变**（`#FF5533→#FF2D19`，`gradient-red`）；双行：**黄色渐变**（`#FFE74D→#FFDD00`，`gradient-yellow`） |
| 按钮文字颜色 | `#111111` 深色 | 单行：**`#FFFFFF` 白色**（红色按钮）；双行：**`#111111` 深色**（黄色按钮） |
| 按钮尺寸（单行） | 六级（84×40px @2x） | **五级（96×48px @2x）** |
| 容器上下内边距（单行） | 20px（10pt） | **8px（4pt）** 或 **4px（2pt）**（金额区） |
| 圆角（留边） | `border-radius: 16px`（8pt） | **`border-radius: 16px`（8pt）**（一致） |
| 图片区圆角 | 有圆角（4pt 或 6pt） | **无圆角（0pt）** |

### 2.11 DOM 结构规范（运营类 · 单行·图片区，contentType=operational, leftContent=icon）

```
.component（容器，flex-row，justify-start，align-items-center，column-gap 6pt，padding 4pt上下/12pt左右，375×36pt 通栏 / 351×36pt 留边）
├── .frame（左侧图片区，28×28pt，flex-shrink:0，无圆角，overflow:hidden，背景色 #FFFADB）
└── .frame-1（内容区，flex-row，flex-grow:1，24pt高）
    ├── .text（文字区，flex-grow:1，24px/500，rgba(0,0,0,0.9)，16pt高）
└── .frame-2（按钮区，flex-shrink:0，60×24pt，padding-left:12pt，column-gap:12pt）
├── .instance（主按钮，48×24pt，胶囊形，红色渐变 gradient-red）
│   └── .text-1（按钮文字，24px/500，#FFFFFF）
        └── .frame-3（右侧占位区，12×12pt，flex-shrink:0，padding:0）
```

### 2.12 DOM 结构规范（运营类 · 单行·金额区，contentType=operational, leftContent=amount）

```
.component（容器，flex-row，justify-start，align-items-center，column-gap 6pt，padding 2pt上下/12pt左右，375×36pt 通栏 / 351×36pt 留边）
├── .instance-4（金额区，34×32pt，flex-shrink:0，flex-row，align-items:flex-end，column-gap:1pt）
│   ├── .text-（¥符号，8.5×20pt，14px/900，#FF2D19，PingFang SC，position:relative top:-4px）
│   └── .frame-8（数字容器，flex-row，align-items:start）
│       ├── .text-72（主数字，可见，24.5×32pt，44px/700，#FF2D19）
│       └── .text-88（备用数字，隐藏，visibility:hidden，31.5×32pt，占位用）
└── .frame-9（内容区，flex-row，flex-grow:1，24pt高）
    ├── .text-4（文字区，flex-grow:1，24px/500，rgba(0,0,0,0.9)，16pt高）
    └── .frame-10（按钮区，flex-shrink:0，60×24pt，padding-left:12pt，column-gap:12pt）
├── .instance-5（主按钮，48×24pt，胶囊形，红色渐变 gradient-red）
│   └── .text-5（按钮文字，24px/500，#FFFFFF）
        └── .frame-11（右侧占位区，12×12pt，flex-shrink:0，padding:0）
```

### 2.13 DOM 结构规范（运营类 · 单行·自定义满铺图片，contentType=operational, leftContent=custom）

```
.component（容器，position:relative，overflow:hidden，375×36pt 通栏 / 351×36pt 留边，无上下左右 padding）
├── .frame-19（背景图区，绝对定位 top:0 left:0，268.5×36pt 通栏 / 244.5×36pt 留边，overflow:hidden，背景色 #FFFADB）
└── .frame-16（按钮区，绝对定位 top:6pt right:0，96×24pt，justify-content:end，padding-right:12pt）
    └── .frame-17（按钮容器，60×24pt，padding-left:12pt，column-gap:12pt）
├── .instance-10（主按钮，48×24pt，胶囊形，红色渐变 gradient-red）
│   └── .text-8（按钮文字，24px/500，#FFFFFF）
        └── .frame-18（右侧占位区，12×12pt，flex-shrink:0，padding:0）
```

> - **自定义满铺图片变体不使用 flexbox 横排**，而是通过绝对定位实现背景图满铺 + 按钮区浮于右侧的效果
> - **背景图区**从容器左上角铺开，宽度约占容器 70%（通栏 537px，留边 489px），高度满铺（72px/36pt）
> - **按钮区**绝对定位于右侧，`top: 12px（6pt）` 实现垂直居中（(72-48)/2=12px）
> - 此变体适合运营横幅展示品牌图片/活动图作为左侧背景，无需在 flex 流中占位

### 2.14 DOM 结构规范（运营类 · 双行·有主副标题，contentType=operational, rowCount=double-with-title）

#### 2.14.1 标准图片区变体（leftContent=icon）

```
.component（容器，flex-row，justify-start，align-items-center，column-gap 6pt，padding 8pt上下/12pt左右，351×60pt，border-radius 8pt，background:#FFFFFF，box-shadow:0px 8px 32px rgba(0,0,0,0.12)）
├── .frame（左侧图片/图标区，36×36pt，flex-shrink:0，border-radius:6pt，背景色 #FFFADB）
└── .frame-1（右侧内容+按钮区，flex-row，flex-grow:1，align-items:center，column-gap:12pt）
    ├── .frame-2（文字列，flex-col，flex-grow:1，justify-center，row-gap:1pt）
    │   ├── .text（主标题，align-self:stretch，28px/500，rgba(0,0,0,0.9)，40px行高，ellipsis截断）
    │   └── .text-1（副标题，align-self:stretch，24px/400，#555555，32px行高，可换行）
    └── .frame-3（按钮区，flex-shrink:0，flex-row，align-items:center，column-gap:12pt）
        ├── .instance（主按钮，48×24pt，min-width:48pt，胶囊形，gradient-yellow）
        │   └── .text-2（按钮文字，24px/500，#111111，text-align:center）
        └── .frame-4（关闭图标区，12×12pt，flex-shrink:0，padding:0）
            └── .close-icon（icon-iconfont-cancel-line-regular，24px，rgba(0,0,0,0.35)，aria-label:关闭）
```

> - **容器为白色背景**：`background: #FFFFFF`，配合 `box-shadow: 0px 8px 32px 0px rgba(0,0,0,0.12)` 区分层次
> - **主标题**：`white-space:nowrap` + `text-overflow:ellipsis`，强制单行截断；颜色 `rgba(0,0,0,0.9)`
> - **副标题**：无截断，可自然换行，颜色 `#555555`（`text-secondary`）
> - **关闭图标**：使用深色图标 `rgba(0,0,0,0.35)`（白色容器），区别于功能类深色容器的白色图标

#### 2.14.2 大图出血区变体（leftContent=custom-large）

```
.component（容器，flex-row，justify-start，align-items-center，column-gap 6pt，padding 8pt上下/0左+12pt右，351×60pt，border-radius 8pt，background:#FFFFFF，box-shadow:0px 8px 32px rgba(0,0,0,0.12)，overflow:visible）
├── .frame（左侧出血容器，96×60pt，flex-shrink:0，align-self:stretch，无背景无圆角）
│   └── .frame-1（图片本体，position:absolute，top:-6pt left:6pt bottom:6pt，90×60pt，border-radius:6pt，overflow:hidden，背景色 #FFFADB）
└── .frame-2（右侧内容+按钮区，flex-row，flex-grow:1，align-items:center，column-gap:12pt）
    ├── .frame-3（文字列，flex-col，flex-grow:1，justify-center，row-gap:1pt）
    │   ├── .text（主标题，align-self:stretch，28px/500，rgba(0,0,0,0.9)，40px行高，ellipsis截断）
    │   └── .text-1（副标题，align-self:stretch，24px/400，#555555，32px行高，可换行）
    └── .frame-4（按钮区，flex-shrink:0，flex-row，align-items:center，column-gap:12pt）
        ├── .instance（主按钮，48×24pt，min-width:48pt，胶囊形，gradient-yellow）
        │   └── .text-2（按钮文字，24px/500，#111111，text-align:center）
        └── .frame-5（关闭图标区，12×12pt，flex-shrink:0，padding:0）
            └── .close-icon（icon-iconfont-cancel-line-regular，24px，rgba(0,0,0,0.35)，aria-label:关闭）
```

> - **容器左侧无内边距**：`padding: 0 24px 0 0`，出血图片容器在 flex 流中占据左侧空间
> - **出血图片**：图片本体 `position:absolute; top:-12px` 向上溢出横幅边界 12px，产生出血视觉效果
> - 其余文字、按钮、关闭图标样式与标准图片区变体**完全一致**

---

## 5. 交互说明

### 5.1 常规类

| 阶段 | 说明 |
|------|------|
| 触发出现 | 用户进行特定操作后出现；或系统引导时自动出现 |
| 出现 | 层级始终置于页面顶层；动效参考相关规范 |
| 点击 | 点击按钮或关闭图标，执行相关操作 |
| 消失（无关闭图标） | 触发操作的同时组件消失 |
| 消失（有关闭图标） | 点击关闭图标后消失 |

### 5.2 关闭图标规则

| 场景 | 展示建议 |
|------|---------|
| 不执行横幅操作会影响后续流程（如登录） | **建议不展示**关闭图标 |
| 其他情况 | **可根据实际情况选择**展示/不展示 |

**关闭图标实现规范：**

| 属性 | 值 | 说明 |
|------|-----|------|
| 图标名称 | `cancel-line-regular` | 使用图标库 `icon-iconfont-cancel-line-regular` |
| 图标尺寸 | **24×24px（12pt）** | 固定尺寸，不可缩放 |
| 按钮容器尺寸 | **24×24px（12pt）** | `width:24px; height:24px; padding:0`（无额外内边距，间距完全由父容器 `column-gap:24px` 控制） |
| 与左侧按钮间距 | **24px（12pt）** | `margin-left: 24px`，固定间距 |
| 深色背景（功能类）图标色 | `rgba(255,255,255,0.6)` | `close-icon` class，白色半透明 |
| 浅色背景（运营类）图标色 | `rgba(0,0,0,0.35)` | `close-icon-dark` class，深色半透明 |

> **文案规范**：
> - 不要使用与操作结果或进程无关的文案
> - 不要使用"忽略"或"取消"的按钮文案；如允许关闭横幅，建议直接使用**关闭图标**

---

## 6. 页面适配

### 6.1 全面屏通用规则

| 场景 | 底部边距（留边类） |
|------|----------------|
| 默认情况 | **10pt** |
| 个别场景可微调 | 建议符合 **4N**（4 的倍数） |

**特殊场景底部间距（留边类）：**

| 场景 | 底部间距 |
|------|---------|
| 有底部工具栏（运营类通栏） | 0pt（顶紧底部工具栏） |
| 有底部工具栏（功能类留边） | **10pt** |
| 无底部工具栏（功能/运营类通栏） | **10pt** |
| 有悬浮按钮或运营位 | **10pt** |

### 6.2 锚点类底部间距

整体宽度建议与页面保持 **12pt** 的边距。

---

## 7. 颜色选用规则（详细说明）

| 颜色策略 | 功能类 | 运营类 |
|---------|-------|-------|
| 浅色页面（默认） | **深色容器** | **浅色容器** |
| 深色页面 | 结合实际场景，可不遵循 | 结合实际场景，可不遵循 |

> 横幅背景、文字、按钮等可以根据**品牌色**调整（尤其是运营类）。

---

## 8. Token 引用

### 8.1 颜色 Token

| 用途 | Token 名称 | 语义层来源 |
|------|-----------|-----------|
| 功能类容器背景（深色） | `bg-inverse` / `bg-dark` | `color-semantic.md` §三 Background Color |
| 运营类容器背景（浅色） | `bg-surface` / `white` | `color-semantic.md` §三 Background Color |
| 功能类主文字（白色） | `text-on-dark` | `color-semantic.md` §二 Text Color |
| 运营类主文字（深色） | `text-primary` | `color-semantic.md` §二 Text Color |
| 运营类副标题文字 | `text-secondary` | `color-semantic.md` §二 Text Color |
| 六级按钮（功能类） | 参考 `button.md` 六级按钮规范 | — |
| 五级按钮（有标题型） | 参考 `button.md` 五级按钮规范 | — |
| 容器白色时阴影 | `shadow-overlay` | `shadow-semantic.md` |
| 锚点类气泡底色 | `mask-heavy`（#000000 80%） | `color-semantic.md` §六 Mask Color |

### 8.2 字体 Token

| 用途 | Token 名称 | 语义层来源 |
|------|-----------|-----------|
| 常规类——双行标题 | `body-l-28-semibold` | `font-semantic.md` §一 Body |
| 常规类——单行标题 | `body-m-24-semibold` | `font-semantic.md` §一 Body |
| 常规类——正文/副标题 | `body-m-24-regular` | `font-semantic.md` §一 Body |
| 锚点类——文字 | `body-m-24-regular` | `font-semantic.md` §一 Body（⚠️ 实测字重为 Regular 400，非 Semibold） |
| 锚点类——箭头图标标注 | `body-m-24-regular` | `font-semantic.md` §一 Body |

### 8.3 圆角 Token

| 用途 | Token 名称 | 层次 | 值 |
|------|-----------|------|-----|
| 留边布局外圆角（functional/operational 单/双行） | `radius-m` | `radius-semantic.md` | 8pt |
| 锚点类圆角 | `radius-m` | `radius-semantic.md` | 8pt |
| double-with-title 容器圆角 | `radius-m` | `radius-semantic.md` | 8pt |
| 通栏布局 | — | — | 0pt |
| 左侧图片区圆角（double-no-title） | `cr-4` | `component-radius.md` | 4pt |
| 左侧图片区圆角（double-with-title 标准图片区） | `cr-6` | `component-radius.md` | 6pt |
| 左侧图片区圆角（double-with-title 大图出血区） | `cr-6` | `component-radius.md` | 6pt |

### 8.4 间距 Token

#### 页面级间距（`spacing-semantic.md`）

| 用途 | Token 名称 | 值 |
|------|-----------|-----|
| 留边布局左右边距 | `spacing-l` | 12pt |
| 底部默认间距 | `spacing-m` | 10pt |

#### 组件内部间距（`component-spacing.md`）

| 用途 | Token 名称 | 值 |
|------|-----------|-----|
| 容器左右 padding（所有变体） | `cs-12` | 12pt |
| 容器上下 padding（功能类单/双行） | `cs-10` | 10pt |
| 容器上下 padding（运营类图片区） | `cs-4` | 4pt |
| 容器上下 padding（运营类金额区） | `cs-2` | 2pt |
| 单行功能类 column-gap（图标与内容区） | `cs-4` | 4pt |
| 双行无标题 column-gap | `cs-8` | 8pt |
| 双行有标题 column-gap | `cs-10` | 10pt |
| 运营类单行 column-gap | `cs-6` | 6pt |
| 按钮区 padding-left（与文字区间距） | `cs-12` | 12pt |
| 按钮区内部 column-gap | `cs-12` | 12pt |
| 文字列 row-gap（主副标题行间距） | `cs-1` | 1pt |
| 文字列 padding-top | `cs-11` | 11pt |
| 文字列 padding-bottom | `cs-12` | 12pt |

---

## 9. Props API（供 AI 生码参考）

```typescript
export type BottomBannerProps = {
  /**
   * 组件大类
   * @default "regular"
   */
  category?: "regular" | "anchor";

  /**
   * 内容类型（仅 regular 有效）
   * @default "functional"
   */
  contentType?: "functional" | "operational";

  /**
   * 布局类型（仅 regular 有效）
   * @default "inset"
   */
  layoutType?: "full-width" | "inset";

  /**
   * 内容行数
   * @default "single"
   */
  rowCount?: "single" | "double-no-title" | "double-with-title";

  /**
   * 主标题（double-with-title 时必填）
   */
  title?: string;

  /**
   * 副标题/正文
   */
  description?: string;

  /**
   * 左侧内容类型
   * @default "none"
   */
  leftContent?: "none" | "icon" | "amount" | "custom";

  /**
   * 左侧图标（leftContent=icon 时）
   */
  leftIcon?: React.ReactNode;

  /**
   * 左侧金额（leftContent=amount 时）
   */
  leftAmount?: string;

  /**
   * 左侧自定义内容（leftContent=custom 时）
   */
  leftCustom?: React.ReactNode;

  /**
   * 按钮配置（最多 2 个）
   */
  buttons?: Array<{
    label: string;
    variant?: "primary" | "secondary";
    onClick?: () => void;
  }>;

  /**
   * 是否展示关闭图标
   * @default false
   */
  showClose?: boolean;

  /**
   * 关闭回调
   */
  onClose?: () => void;

  /**
   * 锚点方向（仅 anchor 有效）
   */
  anchorDirection?: "up" | "down";

  /**
   * 锚点文案（仅 anchor 有效）
   */
  anchorLabel?: string;

  /**
   * 锚点点击回调（仅 anchor 有效）
   */
  onAnchorClick?: () => void;
};
```

---

## 10. data-attribute 规范

| 属性 | 值 | 说明 |
|------|----|------|
| `data-slot` | `"bottom-banner"` | 组件根容器 |
| `data-slot` | `"bottom-banner-content"` | 内容区 |
| `data-slot` | `"bottom-banner-buttons"` | 按钮区 |
| `data-slot` | `"bottom-banner-close"` | 关闭图标 |
| `data-category` | `"regular"` / `"anchor"` | 组件大类 |
| `data-content-type` | `"functional"` / `"operational"` | 内容类型 |
| `data-layout` | `"full-width"` / `"inset"` | 布局类型 |
| `data-row-count` | `"single"` / `"double-no-title"` / `"double-with-title"` | 内容行数 |

---

## 11. 无障碍（Accessibility）

- 组件使用 `role="banner"` 或 `role="complementary"` 描述角色
- 按钮使用 `<button>` 元素，设置明确的 `aria-label`
- 关闭图标设置 `aria-label="关闭"`
- 锚点类按钮 `aria-label` 描述目标区域（如"跳转到优惠券区域"）
- 支持键盘 `Tab` 键聚焦按钮，`Enter`/`Space` 触发

---

## 12. 使用约束（AI 生成时的硬性规则）

1. **按钮数量上限**：按钮最多 **2 个**，超出时需重新设计
2. **正文行数约束**：正文建议不超过 **2 行**；标题建议不超过 **1 行**
3. **文案规范**：不使用"忽略"/"取消"按钮文案；允许关闭时改用关闭图标
4. **圆角不可修改**：留边布局固定 8pt，通栏布局固定 0pt
5. **颜色规则**：功能类深色容器，运营类浅色容器；禁止直接写 hex 颜色
6. **通栏布局边距**：内部元素左右边距不建议调整
7. **留边布局宽度**：固定左右各 12pt，不可随意更改
8. **自定义左侧宽度**：自定义型左侧宽度建议 ≤ 90pt
9. **锚点类宽度自适应**：锚点气泡宽度根据文字内容自适应，不拉伸至满屏
10. **登录等关键流程不展示关闭**：不执行横幅操作会影响后续流程时，禁止展示关闭图标

---

## 13. 常见组合示例

### 13.1 登录引导（功能类，通栏，单行）

```
BottomBanner
  category: regular
  contentType: functional
  layoutType: full-width
  rowCount: single
  description: "终于等到你！快来登录吧！"
  leftContent: none
  buttons: [{ label: "马上登录", variant: "primary" }]
  showClose: false   // 登录流程不展示关闭图标
```

### 13.2 权限申请（功能类，留边，单行，可关闭）

```
BottomBanner
  category: regular
  contentType: functional
  layoutType: inset
  rowCount: single
  description: "开启定位权限，推荐结果更准确哦～"
  buttons: [{ label: "开启权限", variant: "primary" }]
  showClose: true
```

### 13.3 活动促销（运营类，留边，双行，有标题）

```
BottomBanner
  category: regular
  contentType: operational
  layoutType: inset
  rowCount: double-with-title
  title: "限时活动"
  description: "精选商品低至五折"
  leftContent: amount
  leftAmount: "¥72"
  buttons: [{ label: "去抢购", variant: "primary" }]
  showClose: true
```

### 13.4 锚点跳转（引导至优惠券区域）

```
BottomBanner
  category: anchor
  rowCount: single
  anchorLabel: "有一张优惠券可以使用"
  anchorDirection: down   // 目标在下方
  onAnchorClick: scrollToVoucherSection
```

---

## 14. 变体矩阵（常规类）

| layoutType | rowCount | contentType | 容器高度 | 按钮级别 | 外圆角 |
|------------|----------|-------------|---------|---------|-------|
| `full-width` | `single` | `functional` | 36pt | 六级按钮 | 0pt |
| `full-width` | `single` | `operational` | 36pt | 五级按钮 | 0pt |
| `inset` | `single` | `functional` | 36pt | 六级按钮 | 8pt |
| `inset` | `single` | `operational` | 36pt | 五级按钮 | 8pt |
| `inset` | `double-no-title` | `functional` | 52pt | 六级按钮 | 8pt |
| `inset` | `double-with-title` | `operational` | 60pt | 五级按钮 | 8pt |
| `inset` | `double-with-title` | `functional` | 60pt | 五级按钮 | 8pt |

### 14.1 锚点类变体矩阵

| rowCount | 箭头方向 | 容器高度 | 宽度策略 | 外圆角 |
|----------|---------|---------|---------|-------|
| `single` | 向下（↓） | 36pt | 自适应（内容宽度） | 8pt |
| `single` | 向上（↑） | 36pt | 自适应（内容宽度） | 8pt |
| `double` | 向下（↓） | 52pt（建议不超过 2 行） | 自适应 | 8pt |
| `double` | 向上（↑） | 52pt（建议不超过 2 行） | 自适应 | 8pt |

---

## 15. 与其他组件的关系

| 关联组件 | 关系说明 |
|----------|----------|
| `button` | 横幅内按钮复用 `button.md` 的五级/六级按钮规范 |
| `floating-button` | 页面同时有悬浮按钮时，底部横幅位置需上移避免遮挡 |
| `half-screen-dialog` | 半页弹窗和底部横幅均出现时，半页弹窗层级更高 |
| `toast` | Toast 轻量提示，不含操作按钮，区别于底部横幅 |
| `tab-bar` | 底部导航栏为固定层，底部横幅（通栏）在其上方展示 |
