# form.md — Form 表单 - 组件规范

> **组件分类**：Molecule（分子级组件）
> **定义**：表单行（Form Item）是填写类页面的基础信息采集单元，由左侧**标题区（title）** 和右侧**内容区（content）** 两段式横向布局构成。根据内容交互类型分为**输入型**（用户自由输入文字）和**选择型**（从预设选项或弹层中选择值）两大类，二者结构相似但右侧控件不同。多个表单行垂直堆叠形成表单容器。
> **Style 依赖**：`color-semantic.md` · `font-semantic.md` · `spacing-semantic.md` · `component-spacing.md` · `radius-semantic.md` · `stroke-semantic.md`

---

## 0. 图标 / 间距 / Ownership 约束

- **icon-route（默认）**：Form 行内功能图标默认回 `component/atoms/icon.md`，并沿用正文声明的 iconfont class / weight。
- **fixed-asset 例外**：正文位点若指定 `assets/*.svg`、官方 SVG、PNG/CDN 切图等固定资源，必须按 fixed-asset 渲染。
- **spacing-owner（Form 自持）**：标题区/内容区宽度、行高、分割线、行内对齐归 Form 拥有。
- **宿主裁决（优先级）**：`text-input` / `select` / `time-date-picker` 仅拥有各自内部内容，不得反向改 Form 的标题/内容分栏。
- **不可跳步**：先回 `references/INDEX.md` 完成区域路由与宿主锁定，再用 `component-quickref.md` 做宿主级收敛；本文件仅承接组件内 ownership 细则，不承担前置路由改判；不得凭语义猜测。


## 1. 组件类型（type）

| type | 名称 | 适用场景 |
|------|------|----------|
| `input` | 输入型 | 用户通过键盘自由填写文字，如姓名、手机号、备注 |
| `selection` | 选择型 | 用户通过右侧箭头进入弹层/picker 选择值，如日期、城市、证件类型 |

> **二者区分原则**：内容区右侧有**向右箭头**的固定为 `selection`；内容区可直接键入文字的为 `input`。

---

## 2. 两段式结构（slot）

表单行采用两段式横向布局，垂直方向居中对齐：

```
[ title-slot ] [ content-slot ]
```

| slot | 名称 | 是否必须 | 宽度规则 | 说明 |
|------|------|----------|---------|------|
| `title` | 标题区 | 是 | 标题字数 ≤5字：固定 82pt；标题字数 >5字且内容超出 154pt：换行为双行，宽度固定 154pt | 含字段名称、必填标记（可选）、展开图标（可选） |
| `content` | 内容区 | 是 | 填满剩余宽度（屏宽 − `spacing-xl`×2 − title宽 = 可变） | 含 placeholder/值文字、内联控件（可选）、功能图标（可选）、右侧箭头（仅选择型） |

**水平内边距**（左右 padding，组件内固定值，不可自定义）：

| 应用场景 | Token 名称 | 值 |
|---------|-----------|-----|
| 表单行左右 padding | `spacing-xl`（×2） | 各 16pt |

---

## 3. 行高规格

| 场景 | 行高 | 说明 |
|------|------|------|
| 默认态（单行内容） | **50pt** | 标题≤5字或≤2行标题，内容区单行 |
| 多行态（输入后内容折行或错误提示） | **70pt** | 内容区出现换行，或底部追加错误提示行 |

> **不可自定义行高**：表单行高度由内容层级和状态决定，必须从上表选取，禁止任意拉伸。

---

## 4. 标题区规格（title slot）

### 4.1 字数与宽度

| 标题字数 | 宽度 | 内部 padding | 标题文字对齐 |
|---------|------|-------------|-------------|
| ≤5字 | 82pt | `上下 cs-30（15pt），右 cs-12（12pt），左 0` | 左对齐 |
| >5字 | 154pt | `上下 cs-30（15pt），右 cs-12（12pt），左 0` | 左对齐，超出5字自动折行（最多2行） |

> 两种宽度在同一表单中不可混用。同一表单所有行的标签宽度必须保持统一（全部 ≤5字 或全部 >5字）。

### 4.2 字段标题文字

| 状态 | 字体 Token | 颜色 Token |
|-----|-----------|-----------|
| 默认 | `body-l-14-medium` | `text-primary` |
| 弱化 | `body-l-14-regular` | `text-secondary` |

> 弱化状态下字重和颜色同时降级，二者必须成对变化，❌ 禁止只改颜色不改字重（或反之）。

| 属性 | Token / 值 |
|------|-----------|
| 行高 | 20pt |

### 4.3 必填标记（required badge）

| 属性 | Token / 值 |
|------|-----------|
| 符号 | `*` |
| 字体 | `pricefont-14-regular`（美团新数字体，14pt，regular） |
| 颜色 | `red-default` |
| 尺寸 | 6.5×20pt |
| 位置 | 跟在标题文字右侧，gap `cs-2`（2pt） |

### 4.4 展开图标（expand icon）

| 属性 | Token / 值 |
|------|-----------|
| 尺寸 | 12×12pt |
| 颜色 | `text-quaternary` |
| 角度 | 默认 `rotate(-90deg)`（指向右，表示可折叠） |
| 位置 | 标题文字右侧，gap `cs-2`（2pt） |
| 用途 | 用于表单区块可折叠场景，非必须 |

### 4.5 标题区与内容区分割线

> ⚠️ 普通表单行（姓名、证件号等）**不渲染**标题区右侧竖向分割线。电话输入行（`data-input-type="phone"`）**仅在区号选择器右侧**渲染一根竖向分割线（见 §4.6），标题文字和区号选择器之间**不加**竖线。

### 4.6 区号选择器（仅 `data-input-type="phone"` 时使用）

电话号码输入行在标题区内嵌**区号选择器**，区号选择器右侧用竖向分割线与电话输入框隔开（标题文字和区号选择器之间**无竖线**）：

```
[ 标题文案 * ] [ +86 展开箭头 ] | [ 请输入电话号码 ] [ 📞 ]
```

| 元素 | 规格 |
|------|------|
| 区号文字 | `body-l-14-regular`，`text-primary`，如 `+86` |
| 展开箭头 | `icon-iconfont-expand-bold`，10pt，`text-quaternary`（`#999999`），与区号文字 gap `cs-2`（2pt） |
| 与内容区分割线 | 竖向 1px，`divider-primary`（`rgba(0,0,0,0.06)`）；位于区号选择器右侧，分割线右侧距电话输入框左边界 `cs-10`（10pt） |
| 交互 | 点击触发区号弹层（`role="button"`，`aria-haspopup="listbox"`） |

**电话号码输入格式**：

| 规则 | 说明 |
|-----|------|
| 分段格式 | 3-4-4 位，如 `138 0013 8000` |
| 分段间距 | `cs-4`（4pt） |
| 显示方式 | 输入时实时分段，占位符统一显示为 `请输入电话号码`（不分段） |

> ⚠️ 区号选择器**仅在** `data-input-type="phone"` 时渲染，其他输入类型（姓名、身份证等）❌ 禁止出现区号选择器。

---

## 5. 内容区规格（content slot）

### 5.1 通用内容区

| 属性 | Token / 值 |
|------|-----------|
| 内部 padding | 上下各 `cs-30`（15pt）；左右 0 |
| 距左侧分割线 | `cs-4`（4pt），通过内容区首个子元素的 `margin-left` 实现 |
| 布局 | 横向 flex，`align-items: center` |
| gap（各子区间） | `cs-6`（6pt） |

### 5.2 引导文字（placeholder / hint）

用于未输入/未选择时的占位提示，或已输入时右对齐的选填说明。

| 属性 | Token / 值 |
|------|-----------|
| 字体 | `body-l-14-regular`（font-semantic） |
| 颜色 | `text-tertiary`（`#888888`） |
| 行高 | 20pt |
| 文字对齐 | 左对齐（标题 ≤5字）/ 右对齐（标题 >5字或选择型） |

### 5.3 输入值 / 选择值文字

点击内容区后进入 `active` 状态，placeholder 隐藏，出现输入光标；填写内容后文字变为 `text-primary`，同时右侧出现清除图标。

| 属性 | Token / 值 |
|------|-----------|
| 字体 | `body-l-14-regular`（font-semantic） |
| 颜色 | `text-primary`（`#111111`） |
| 行高 | 20pt |

**输入光标**：

| 属性 | Token / 值 |
|------|-----------|
| 宽度 × 高度 | 1.5pt × 20pt |
| 颜色 | `color-brand`（品牌主色） |
| 圆角 | `radius-full` |
| 位置 | 紧跟输入文字右侧，gap 0 |
| 显示条件 | 仅 `data-state="active"` 时可见，闪烁 |

**清除图标（clear button）**：

| 属性 | Token / 值 |
|------|-----------|
| 图标 | `icon-iconfont-close-circle-filled`（面性） |
| 尺寸 | 16×16pt |
| 颜色 | `text-disabled`（`#CCCCCC`） |
| 位置 | 内容区最右侧 |
| 显示条件 | 仅**左对齐**内容区（标题 ≤5字）时显示：`data-state="active"` 且有文字，或 `data-state="filled"`；空内容或 `default` 态隐藏。❌ **右对齐**内容区（标题 >5字或选择型）不显示清除图标 |
| 交互 | 点击清空内容区文字，恢复 placeholder，`data-state` 回到 `active` |

### 5.4 内联控件区（inline controls，仅输入型）

位于内容区右侧，与内容区文字之间 `gap: cs-6`（6pt）。

| 控件 | 尺寸 | 说明 |
|------|------|------|
| 内联选项（单选 / 多选） | 引用 `select` 组件 `size=small`（16×16pt） | 用于性别、称谓等简单选项，最多 2～3 个选项内联展示 |
| 功能图标（如通讯录） | 16×16pt | 用于触发辅助弹层（如从通讯录选人），可点击 |

**内联单多选规格**：完整样式（圆圈背景、对号图标、状态矩阵）遵循 `select.md § size=small`，此处仅列出表单行内的布局参数：

| 属性 | 值 |
|------|---|
| 选项图标尺寸 | `select` `size=small`（16×16pt，`radius-full`） |
| 选项文字 | `text-primary`，`body-s-12-regular` |
| 图标与文字间 gap | `cs-4`（4pt） |
| 控件间 gap | `spacing-xl`（16pt） |

### 5.5 选择型右侧箭头（仅 selection 型）

| 属性 | Token / 值 |
|------|-----------|
| 图标 | `icon-iconfont-right-line-medium`（向右，中粗体） |
| 图标尺寸 | 12pt |
| 颜色 | `text-tertiary`（`#888888`） |
| 与文字间距 | `cs-0`（0pt，紧贴文字右侧） |
| 位置 | 内容区最右侧 |

---

## 6. 内容区对齐方式（content alignment）

对齐方式由**标题文案字数**决定，与输入型/选择型正交：

| 条件 | 对齐方式 | 内容区表现 | 典型标题示例 |
|-----|---------|-----------|------------|
| 标题字数 ≤ 5字 | `left-align` | 内容区左侧，左对齐 | 姓名、性别、地址、手机号、证件号码、与您的关系 |
| 5字 < 标题字数 ≤ 11字 | `right-align` | 内容区右侧，右对齐 | 证件有效期、紧急联系人、所在城市区域 |

> **选择型内容区对齐**：`right-align`，内容区文字与右侧箭头间保持 `cs-6`（6pt）。

---

## 7. 错误状态（error state）

表单行在提交校验失败或实时校验失败时进入错误状态，行高从 50pt 扩展至 **70pt**，底部追加错误提示行。

**错误提示文字规格**：

| 属性 | Token / 值 |
|------|-----------|
| 字体 | `caption-l-11-regular`（font-semantic，11pt 常规） |
| 颜色 | `#FF2D19` |
| 与上方内容间距 | `cs-4`（4pt） |

**错误提示位置规则**（由标题字数决定）：

| 条件 | 报错文字位置 | 左对齐基准 |
|-----|------------|----------|
| 标题字数 ≤ 5字（`left-align`） | 内容区文字下方 | 内容区左边界 |
| 标题字数 > 5字（`right-align`，含超长标题折行） | 标题区文字下方 | 行左边界（`spacing-xl` 16pt 处） |

| 区域 | 属性 | Token / 值 |
|------|------|-----------|
| 分割线 | 同默认态 | `divider-primary` |

> 错误状态下，标题区与内容区的文字颜色**不变**；仅底部追加错误提示文字，行高撑高至 70pt。

---

## 8. 交互状态（state）

| state | `data-state` | 视觉表现 |
|-------|-------------|---------|
| 默认态 | `default` | 正常展示，内容区显示 placeholder |
| 输入中 | `active` | 输入光标（1.5×20pt，`color-brand`，全圆角）可见；placeholder 隐藏 |
| 已填写 | `filled` | 显示用户输入的值，`text-primary` |
| 已选择 | `filled` | 显示选中值，`text-primary`（仅 selection 型） |
| 错误态 | `error` | 底部追加错误提示，行高 70pt |
| 禁用态 | `disabled` | 标题颜色降级为 `text-disabled`；内容区颜色降级为 `text-disabled`；不可交互 |
| 按压态 | `pressed` | 背景叠加 `bg-overlay-light`；**禁止 `transform: scale()`** |

---

## 9. 分割线（divider）

相邻表单行之间通过底部分割线区分，分割线位于每行**底部**，与内容区左边界左对齐（缩进，不从屏幕左侧延伸到屏幕右侧仅延伸至屏幕右侧）。

| 属性 | Token | 值 |
|------|-------|-----|
| 颜色 | `divider-secondary` | `Color/Neutral/.Black-Opacity-6` |
| 宽度 | `border-default` | 1px |
| 左缩进 | 对齐内容区左边界（即 title 区右分割线位置） | — |

> ⚠️ **电话行例外**：`data-input-type="phone"` 时，`.fit` 宽度为 `auto`（随「标题文字 + * + 竖线 + 区号选择器 + 竖线」内容撑开），底部分割线**改为全宽（`margin-left:0`）**，不做内容区左边界缩进。

> **最后一行不加分割线**：表单容器中最后一个 Form Item 的底部 divider 不显示。

---

## 10. 背景色

| 状态 | Token | 说明 |
|-----|-------|------|
| 默认 | `white` | 白色，与页面 `bg-page` 形成层次 |
| 按压态 | `bg-overlay-light` 叠加 | 轻叠加，不改变文字颜色 |

---

## 11. 表单区块（Form Section）

多个表单行可组合为一个**表单区块**，区块之间通过 `spacing-xl`（16pt）垂直间距或分组标题隔开：

| 元素 | 说明 |
|------|------|
| 区块容器 | `white`，无圆角（通栏）或 `radius-m`（卡片式） |
| 区块标题 | 可选，`body-s-12-regular`，`text-tertiary`，区块上方间距 `spacing-l`（12pt） |
| 区块间距 | `spacing-xl`（16pt），`bg-page` 填充 |

---

## 12. data-attribute 规范

| 属性 | 值 | 说明 |
|------|-----|------|
| `data-slot` | `"form-item"` | 全局稳定标识，供父容器 CSS 定向选中 |
| `data-type` | `"input"` / `"selection"` | 表单行交互类型 |
| `data-input-type` | `"phone"` / `"text"` / `"number"` / … | 输入内容类型；`"phone"` 时渲染区号选择器（§4.6），其他值不渲染 |
| `data-state` | `"default"` / `"active"` / `"filled"` / `"error"` / `"disabled"` / `"pressed"` | 当前交互状态 |
| `data-title-size` | `"short"` / `"long"` | 标题长度（≤5字/`short`，>5字/`long`），控制 title 宽度 |
| `data-required` | `"true"` / `"false"` | 是否为必填项（控制 `*` 显示） |
| `data-has-inline-controls` | `"true"` / `"false"` | 内容区是否有内联 Radio/Checkbox |
| `data-has-divider` | `"true"` / `"false"` | 是否显示底部分割线 |

---

## 13. 无障碍（a11y）

- 表单行使用 `role="group"` 包裹，关联 `aria-labelledby` 指向标题节点
- 必填项在标题节点上追加 `aria-required="true"`
- 输入框使用原生 `<input>` 或设置 `role="textbox"` + `aria-label`，`aria-placeholder` 描述占位文字
- 选择型使用 `role="button"` + `aria-haspopup="dialog"` 或 `aria-haspopup="listbox"`
- 错误提示使用 `role="alert"` 或 `aria-live="polite"`，与输入框通过 `aria-describedby` 关联
- 内联 Radio 使用 `role="radio"` + `role="radiogroup"` 包裹；Checkbox 使用 `role="checkbox"`
- 禁用态使用 `aria-disabled="true"`，不使用 HTML `disabled`（保留 focus 能力）
- 功能图标（通讯录等）必须有独立 `aria-label`

---

## 14. 与 list.md 的区别

| 维度 | Form Item（本文件） | List Item（list.md） |
|------|--------------------|--------------------|
| 核心用途 | 信息**采集**（填写、选择） | 信息**展示**（浏览、导航） |
| 布局结构 | 两段式（title + content） | 三段式（prefix + content + suffix） |
| 标题区 | 固定，承载字段名 | 无独立标题区（标题内嵌 content） |
| 右侧控件 | 箭头（selection）或无 | 箭头、开关、徽标等多种 |
| 交互状态 | 含 `active`（键盘输入）、`error` | 无 `active`、`error` |
| 行高 | 50pt / 70pt（错误态） | 50pt / 56pt / 66pt / 70pt / 72pt 等多档 |

---

## 15. 使用约束

- **宽度**：默认 100% 填满容器（375pt 全宽），不可自定义宽度
- **不加投影**：表单行不使用任何 shadow Token，层次通过分割线和背景色区分
- **与列表混排时字体统一**：同一页面中表单行与列表行同时出现时，主标题字体必须统一使用 `body-l-14-medium`，❌ 禁止两者字重不一致
- **标题宽度全局统一**：同一表单页面所有行的 `data-title-size` 必须一致，不可混用 short 和 long
- **内联控件数量**：内联 Radio/Checkbox 最多 3 个，超出应改用弹层选择（selection 型）
- **错误提示**：错误文字仅显示在对应行内，不可使用全局 toast 替代行内错误提示
- **输入光标**：仅在 `data-state="active"` 时显示，颜色 `color-focus`
- **必填 \* 位置**：`*` 号紧跟标题文字，不可放在右侧或单独一行
- **选择型禁止直接输入**：`data-type="selection"` 的行内容区不可聚焦输入，只能通过箭头触发弹层
