# Empty State 空状态占位图

> **组件分类**：Component（组件级）
> **定义**：空状态组件用于在列表、页面或模块**内容为空时**提供视觉占位，引导用户理解当前状态并执行下一步操作。由**插画图片** + **标题文字** + **描述文字** + **操作按钮**（可选）组成，垂直居中布局。
> **Style 依赖**：`color-semantic.md` · `font-semantic.md` · `spacing-semantic.md` · `component-spacing.md` · `radius-semantic.md` · `component-radius.md` · `stroke-semantic.md`

> ⚠️ **核心约束**：
> - 空状态**必须**展示占位插画（图片），不允许纯文字空状态
> - **标题**为必要元素；**描述文字**和**操作按钮**为可选元素
> - 空状态图片**不可缩放**，固定尺寸由 `size` 决定
> - 操作按钮**至多 2 个**（主操作 + 次操作），不可超过 2 个
> - 空状态组件**不包含**导航栏，应由父页面提供导航容器

---

## 0. 图标 / 间距 / Ownership 约束

- **icon-route（默认）**：空状态中的功能性小图标默认回 `component/atoms/icon.md` 并遵循正文 iconfont 约束。
- **fixed-asset 例外**：空状态插画属于 fixed-asset / 插画资产，必须按正文指定资源渲染，不受通用 iconfont 规则支配。
- **spacing-owner（归属）**：插画、标题、描述、按钮在组件内的纵向间距与对齐归 Empty State；页面边距与容器留白归宿主。
- **宿主裁决（优先级）**：冲突遵循 `宿主 > 组合场景 > 本组件`，空状态不反向改宿主布局规则。
- **不可跳步**：先回 `references/INDEX.md` 完成区域路由与宿主锁定，再用 `component-quickref.md` 做宿主级收敛；本文件仅承接组件内 ownership 细则，不承担前置路由改判；不得凭语义猜测。


## 1. 空状态类别（type）

| type | 名称 | 说明 | 典型场景 |
|------|------|------|----------|
| `no-data` | 通用无数据 | 列表/页面内容为空，暂无内容可展示 | 订单列表为空、收藏列表为空 |
| `no-search-result` | 搜索无结果 | 搜索后无匹配内容 | 搜索页无结果、筛选后为空 |
| `network-error` | 网络错误 | 网络请求失败或超时 | 断网、请求超时 |
| `no-permission` | 权限不足 | 用户没有访问该内容的权限 | 未登录访问、权限不够 |
| `load-error` | 加载失败 | 内容加载出错（非网络原因） | 资源加载失败、数据解析错误 |

---

## 2. 尺寸级别（size）

| size | 名称 | 插画尺寸（@2x） | 适用场景 |
|------|------|---------------|----------|
| `l` | 大 | **320×120pt** | 整页/全屏空状态（Tab 页、独立空状态页） |
| `m` | 中 | **240×90pt** | 半页/主内容区空状态（Tab 内容区、模块内） |
| `s` | 小 | **160×60pt** | 卡片/列表项内局部空状态（组件内嵌，空间有限） |

> **@1x 换算**：`l` = 160×120pt，`m` = 120×90pt，`s` = 80×60pt。

---

## 3. 内容构成（slots）

| slot | 必填 | 说明 |
|------|------|------|
| `illustration` | ✅ 必须 | 插画/占位图，SVG 或 PNG，尺寸由 `size` 决定 |
| `title` | ✅ 必须 | 简明描述空状态原因的标题文字（≤ 12 字） |
| `description` | 可选 | 对标题的补充说明，或用户可执行的操作提示（≤ 30 字） |
| `action` | 可选 | 主操作按钮（如"重试"、"去搜索"、"去登录"） |
| `secondaryAction` | 可选 | 次操作按钮（如"返回首页"），仅在有主操作时可用 |

---

## 4. 变体矩阵（完整 MECE）

### 4.1 按 type × size（15 种基础变体）

| type | size=l | size=m | size=s |
|------|--------|--------|--------|
| `no-data` | ✅ | ✅ | ✅ |
| `no-search-result` | ✅ | ✅ | ✅ |
| `network-error` | ✅ | ✅ | ✅ |
| `no-permission` | ✅ | ✅ | ✅ |
| `load-error` | ✅ | ✅ | ✅ |

### 4.2 按 slots 组合（内容变体）

| 组合 | 命名 | 说明 |
|------|------|------|
| 插画 + 标题 | `minimal` | 最简形态，不含描述和按钮 |
| 插画 + 标题 + 描述 | `with-desc` | 含描述，无操作按钮 |
| 插画 + 标题 + 操作按钮 | `with-action` | 含主操作，无描述 |
| 插画 + 标题 + 描述 + 操作按钮 | `full` | 完整形态 |
| 插画 + 标题 + 描述 + 双按钮 | `full-dual` | 主操作 + 次操作 |

> **约束**：`size=s` 小尺寸建议使用 `minimal` 或 `with-desc`，不建议添加操作按钮（空间受限）。

---

## 5. 插画（illustration）规格

### 5.1 图片类型与来源

| type | 插画风格描述 | 说明 |
|------|------------|------|
| `no-data` | 空盒子/空列表插画 | 灰色调，轻量线条风格 |
| `no-search-result` | 搜索/放大镜+空 | 搜索相关视觉元素 |
| `network-error` | 断网/云朵+感叹号 | 网络断连视觉元素 |
| `no-permission` | 锁/禁止图标 | 权限限制视觉元素 |
| `load-error` | 感叹号/错误 | 通用错误视觉元素 |

### 5.2 图片规格

| 属性 | 值（@2x） | 说明 |
|------|---------|------|
| `l` 尺寸 | **320×120pt** | 4:3 比例，最大展示尺寸 |
| `m` 尺寸 | **240×90pt** | 4:3 比例，标准展示尺寸 |
| `s` 尺寸 | **160×60pt** | 4:3 比例，最小展示尺寸 |
| 图片格式 | SVG（首选）/ PNG（@3x） | SVG 保证清晰度；PNG 需提供 @3x 版本 |
| 图片颜色 | 不超过 3 个主色 | 建议灰色/蓝色/黄色系，符合美团品牌调性 |
| 图片圆角 | 无 | 插画本身不需要圆角容器 |

---

## 6. 文字规格

### 6.1 标题文字

| size | 字体 Token | 字号 @2x | 行高 @2x | 字重 | 对齐 |
|------|-----------|---------|---------|------|------|
| `l` | `subtitle-m-32-medium` | 16pt | 22pt | 500 Medium | 居中 |
| `m` | `body-l-28-medium` | 14pt | 20pt | 500 Medium | 居中 |
| `s` | `body-s-24-medium` | 12pt | 16pt | 500 Medium | 居中 |

> **标题颜色**：`text-primary`（`#111111`），所有 size 统一。

### 6.2 描述文字

| size | 字体 Token | 字号 @2x | 行高 @2x | 字重 | 对齐 |
|------|-----------|---------|---------|------|------|
| `l` | `body-l-28-regular` | 14pt | 20pt | 400 Regular | 居中 |
| `m` | `body-s-24-regular` | 12pt | 16pt | 400 Regular | 居中 |
| `s` | `caption-l-22-regular` | 11pt | 16pt | 400 Regular | 居中 |

> **描述颜色**：`text-secondary`（`#555555`），所有 size 统一。
> **描述最大行数**：`l` / `m` ≤ 2 行；`s` ≤ 1 行。

---

## 7. 操作按钮（action）规格

### 7.1 主操作按钮（action）

| size | Button size | variant | 说明 |
|------|-------------|---------|------|
| `l` | `m`（Button size=m） | `primary` | 渐变黄色按钮 |
| `m` | `s`（Button size=s） | `primary` | |
| `s` | — | — | 小尺寸不建议操作按钮 |

### 7.2 次操作按钮（secondaryAction）

| size | Button size | variant | 说明 |
|------|-------------|---------|------|
| `l` | `m` | `secondary` | 灰色描边按钮，在主操作右侧或下方 |
| `m` | `s` | `secondary` | |

> **双按钮布局**：
> - 两个按钮**水平并列**时：左为次操作（secondary），右为主操作（primary），等宽
> - 空间不足时改为**纵向排列**：主操作在上，次操作在下

### 7.3 常见按钮文案

| type | 主操作文案 | 次操作文案 |
|------|----------|----------|
| `no-data` | "去浏览" / "去发现" | — |
| `no-search-result` | "换个关键词试试" | "返回" |
| `network-error` | "重试" / "刷新" | "返回首页" |
| `no-permission` | "去登录" | "暂不登录" |
| `load-error` | "重试" | "返回" |

---

## 8. 布局规格（@2x，单位 px）

### 8.1 整体布局

```
[EmptyState 根容器]           — flex-column，align: center，justify: center
  ├── [插画] 固定尺寸，不可缩放
  ├── [标题] 居中，margin-top: 间距A（见下表）
  ├── [描述] 居中，margin-top: 间距B（见下表），可选
  └── [按钮区] 居中，margin-top: 间距C（见下表），可选
        ├── [主操作按钮]（水平排列时左侧/纵向时上方）
        └── [次操作按钮]（可选）
```

### 8.2 间距规格

| size | 插画→标题（A） | 标题→描述（B） | 描述→按钮（C） | 标题→按钮（B'，无描述时） |
|------|-------------|-------------|-------------|----------------------|
| `l` | **16pt**（`spacing-xl`） | **4pt**（`spacing-2xs`） | **24pt**（`spacing-3xl`） | **24pt** |
| `m` | **12pt**（`spacing-l`） | **4pt**（`spacing-2xs`） | **16pt**（`spacing-xl`） | **16pt** |
| `s` | **8pt**（`spacing-s`） | **2pt**（`spacing-3xs`） | —（不建议） | —（不建议） |

### 8.3 容器宽度约束

| size | 内容最大宽度 | 说明 |
|------|-----------|------|
| `l` | **280pt**（@2x） | 左右留白 47.5pt，内容居中 |
| `m` | **240pt**（@2x） | 左右留白 67.5pt |
| `s` | **不限**，跟随父级 | 小尺寸通常在固定容器内 |

> **按钮宽度**（`size=l`）：主操作 **120pt**（@2x），两按钮并列时各 **110pt**（含 8pt 间距）。
> **按钮宽度**（`size=m`）：主操作 **100pt**（@2x）。

---

## 9. Token 引用

### 9.1 颜色 Token

| 用途 | Token 名称 | 值 | 语义层来源 |
|------|-----------|-----|-----------|
| 标题文字 | `text-primary` | `#111111` | `color-semantic.md` §二 Text |
| 描述文字 | `text-secondary` | `#555555` | `color-semantic.md` §二 Text |
| 页面背景 | `bg-page` | `#F5F5F5` | `color-semantic.md` §三 Background |
| 卡片/容器背景 | `white` | `#FFFFFF` | `color-semantic.md` §三 Background |
| 主操作按钮背景 | `gradient-yellow` | 渐变黄 | `color-semantic.md` §八 Gradient |
| 次操作按钮描边 | `stroke-default` | `#DDDDDD` | `color-semantic.md` §四 Stroke |

### 9.2 字体 Token

| 用途 | Token 名称 | 字号 @2x | 字重 | 语义层来源 |
|------|-----------|---------|------|-----------|
| `l` 标题 | `subtitle-m-32-medium` | 16pt | 500 | `font-semantic.md` §一 Subtitle |
| `m` 标题 | `body-l-28-medium` | 14pt | 500 | `font-semantic.md` §一 Body |
| `s` 标题 | `body-s-24-medium` | 12pt | 500 | `font-semantic.md` §一 Body |
| `l` 描述 | `body-l-28-regular` | 14pt | 400 | `font-semantic.md` §一 Body |
| `m` 描述 | `body-s-24-regular` | 12pt | 400 | `font-semantic.md` §一 Body |
| `s` 描述 | `caption-l-22-regular` | 11pt | 400 | `font-semantic.md` §一 Caption |

### 9.3 间距 Token

| 用途 | Token 名称 | 值（@2x） | @1x |
|------|-----------|---------|-----|
| `l` 插画→标题 | `spacing-xl` | 16pt | 16pt |
| `m` 插画→标题 | `spacing-l` | 12pt | 12pt |
| `s` 插画→标题 | `spacing-s` | 8pt | 8pt |
| 标题→描述（l/m） | `spacing-2xs` | 4pt | 4pt |
| 标题→描述（s） | `spacing-3xs` | 2pt | 2pt |
| `l` 描述→按钮 | `spacing-3xl` | 24pt | 24pt |
| `m` 描述→按钮 | `spacing-xl` | 16pt | 16pt |

---

## 10. 结构规格

### 10.1 完整形态组件树（size=l，type=network-error）

```
[EmptyState 根容器] flex-column，align: center，justify: center，width: ≤280pt
  ├── [插画] 320×120pt，SVG，断网图标
  ├── [标题] "网络开小差了"
  │     subtitle-m-32-medium，text-primary，居中，margin-top: `spacing-xl`（16pt）
  ├── [描述] "请检查网络连接后重试"
  │     body-l-28-regular，text-secondary，居中，margin-top: `spacing-2xs`（4pt），最多2行
  └── [按钮区] flex-row，gap: `spacing-s`（8pt），margin-top: `spacing-3xl`（24pt）
        ├── [次操作] Button size=m，variant=secondary，"返回首页"，width: 110pt
        └── [主操作] Button size=m，variant=primary，"重试"，width: 110pt
```

### 10.2 最简形态组件树（size=s，type=no-data）

```
[EmptyState 根容器] flex-column，align: center
  ├── [插画] 160×60pt
  └── [标题] "暂无数据"，body-s-24-medium，text-primary，margin-top: `spacing-s`（8pt）
```

---

## 11. 各场景文案规范

| type | 标题文案 | 描述文案 |
|------|---------|---------|
| `no-data` | "暂无内容" / "还没有记录" / "列表为空" | "快去浏览感兴趣的内容吧" |
| `no-search-result` | "没找到相关结果" | "试试换个关键词或者减少筛选条件" |
| `network-error` | "网络开小差了" | "请检查网络连接后重试" |
| `no-permission` | "需要登录才能查看" | "登录后可查看完整内容" |
| `load-error` | "加载失败" | "内容加载出现了问题，请稍后重试" |

> **文案原则**：
> 1. 标题**描述原因**，不超过 12 字
> 2. 描述**指引操作**，不超过 30 字
> 3. 避免负面、强制语气（不用"禁止"、"你不能"等）
> 4. 按钮文案动词优先（"重试"优于"我知道了"）

---

## 12. 交互规则

| 操作 | 行为 |
|------|------|
| 点击主操作按钮 | 执行对应操作（重试/跳转/登录等） |
| 点击次操作按钮 | 执行次要操作（返回/取消等） |
| 页面下拉刷新 | 触发数据重载（空状态组件本身不处理，由父页面控制） |
| 网络恢复 | 建议自动重试请求，更新空状态（需父组件监听） |

---

## 13. Props API（供 AI 生码参考）

```typescript
export type EmptyStateProps = {
  /**
   * 空状态类别
   * @default "no-data"
   */
  type?: "no-data" | "no-search-result" | "network-error" | "no-permission" | "load-error";

  /**
   * 尺寸级别
   * @default "m"
   */
  size?: "l" | "m" | "s";

  /**
   * 自定义插画（覆盖默认插画）
   */
  illustration?: React.ReactNode;

  /**
   * 自定义插画 URL（图片型）
   */
  illustrationUrl?: string;

  /**
   * 标题文字（覆盖默认文案）
   */
  title?: string;

  /**
   * 描述文字
   */
  description?: string;

  /**
   * 主操作按钮文字
   */
  actionText?: string;

  /**
   * 主操作按钮点击回调
   */
  onAction?: () => void;

  /**
   * 次操作按钮文字（需同时提供 actionText）
   */
  secondaryActionText?: string;

  /**
   * 次操作按钮点击回调
   */
  onSecondaryAction?: () => void;

  /**
   * 按钮布局（双按钮时有效）
   * @default "horizontal"（水平并列）
   */
  actionLayout?: "horizontal" | "vertical";

  /**
   * 自定义内容区（完全覆盖 title/description/action）
   */
  children?: React.ReactNode;
};
```

---

## 14. data-attribute 规范

| 属性 | 值 | 说明 |
|------|----|------|
| `data-slot` | `"empty-state"` | 组件根容器 |
| `data-type` | `"no-data"` / `"no-search-result"` / `"network-error"` / `"no-permission"` / `"load-error"` | 空状态类别 |
| `data-size` | `"l"` / `"m"` / `"s"` | 尺寸级别 |
| `data-slot` | `"empty-illustration"` | 插画区域 |
| `data-slot` | `"empty-title"` | 标题 |
| `data-slot` | `"empty-description"` | 描述 |
| `data-slot` | `"empty-action"` | 主操作按钮容器 |
| `data-slot` | `"empty-secondary-action"` | 次操作按钮 |

---

## 15. 无障碍（Accessibility）

- 根容器：`role="status"`，`aria-live="polite"`（列表内容更新时通知屏幕阅读器）
- 插画：`aria-hidden="true"`（装饰性，语义由标题承载）
- 标题：`<h2>` 或 `role="heading" aria-level="2"`（根据页面层级决定）
- 描述：与标题配合，由 `aria-describedby` 关联
- 按钮：遵循 `button.md` 无障碍规范

---

## 16. 使用约束（AI 生成时的硬性规则）

1. **空状态必须有插画**：不允许纯文字空状态（缺乏视觉引导）
2. **标题不可省略**：每个空状态必须有清晰的标题说明
3. **`size=s` 慎用操作按钮**：小尺寸空间有限，按钮会造成拥挤
4. **同一页面只允许一个空状态组件**：避免多个空状态同时出现
5. **禁止直接使用图片 URL**：必须通过 `illustration` 或 `illustrationUrl` Props 传入，便于主题替换
6. **操作按钮最多 2 个**：主操作优先，次操作补充，不可超过 2 个
7. **描述文字不超过 2 行**（`l`/`m`），超出部分截断

---

## 17. 常见组合示例

### 17.1 订单列表为空（通用无数据，中尺寸）
```
EmptyState
  type: "no-data"
  size: "m"
  title: "还没有订单"
  description: "快去下单，美味马上到～"
  actionText: "去浏览"
  onAction: () => router.push('/home')
```

### 17.2 搜索无结果（大尺寸，双操作）
```
EmptyState
  type: "no-search-result"
  size: "l"
  title: "没找到相关结果"
  description: "试试换个关键词"
  actionText: "清空搜索"
  onAction: () => clearSearch()
  secondaryActionText: "返回首页"
  onSecondaryAction: () => router.push('/home')
  actionLayout: "horizontal"
```

### 17.3 网络错误（大尺寸，单操作）
```
EmptyState
  type: "network-error"
  size: "l"
  title: "网络开小差了"
  description: "请检查网络连接后重试"
  actionText: "重试"
  onAction: () => refetch()
```

### 17.4 卡片内小尺寸占位
```
EmptyState
  type: "no-data"
  size: "s"
  title: "暂无评价"
```

---

## 18. 与其他组件的关系

| 关联组件 | 关系说明 |
|----------|----------|
| `list` | 列表组件内部数据为空时，使用 EmptyState 替代列表内容 |
| `button` | EmptyState 操作按钮使用 Button 组件实现（`size=m` / `size=s`，`variant=primary` / `secondary`） |
| `navigation` | EmptyState 通常在导航栏下方的内容区展示，不含导航栏 |
| `snackbar` | 网络错误等异常场景，可配合 Snackbar 展示简短提示（EmptyState 展示空状态，Snackbar 展示错误原因） |
| `skeleton` | 加载中状态使用 Skeleton 骨架屏；加载失败则切换为 EmptyState（type=load-error） |
