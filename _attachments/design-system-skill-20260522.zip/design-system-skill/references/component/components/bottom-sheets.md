# Bottom Sheets 半页弹窗
> **组件分类**：Component（组件级）
> **定义**：半页弹窗一般为用户主动操作触发，在页面最上层，从页面底部弹出的多功能组件，可包含各种信息和布局（如列表、网格、操作和补充内容等），用于补充当前页面信息或引导相关任务操作。
> **Style 依赖**：`color-semantic.md` · `font-semantic.md` · `spacing-semantic.md` · `component-spacing.md` · `radius-semantic.md` · `component-radius.md` · `stroke-semantic.md`
> ⚠️ **蒙层强制规则（最高优先级）**：只要使用半页弹窗组件，**必须**同时展示全屏蒙层覆盖下层页面。蒙层使用 `mask-default`（`rgba(0,0,0,0.6)`，60% 黑色）。任何场景**均不允许**无蒙层展示半页弹窗。
> **动效强制规则**：弹窗进场/离场的三层动效（半弹层 + 黑色遮罩 + 背景页面）参数**不可自定义**，必须按 §2.2 规格执行。
---
## 0. 图标 / 间距 / Ownership 约束

- **icon-route（默认）**：本组件内功能图标默认回 `component/atoms/icon.md`，并沿用本文件已声明的 iconfont class / weight。
- **fixed-asset 例外**：若正文已指定 `assets/*.svg`、官方 SVG、PNG/CDN 切图、URL 尖角资源或固定插画，该位点必须走固定资产，不得强行回 iconfont；输出时可标注 `icon-route=fixed-asset`。
- **spacing-owner（归属）**：组件内部 slot、行内/容器内 gap、padding、对齐归本组件；页面边距、吸顶/吸底占位、列表外层留白归宿主。
- **宿主裁决（优先级）**：冲突遵循 `宿主 > 组合场景 > 本组件通用规则`，子组件仅拥有自身内部样式，不反向改宿主排布。
- **不可跳步**：先回 `references/INDEX.md` 完成区域路由与宿主锁定，再用 `component-quickref.md` 做宿主级收敛；本文件仅承接组件内 ownership 细则，不承担前置路由改判；不得凭语义猜测。

## 1. 组件大类（category）
半页弹窗分为 3 个大类，按使用场景和交互模式区分：
| category | 名称 | 交互模式 | 典型场景 |
|----------|------|---------|---------|
| `content` | 内容弹窗 | **模态**（禁止与父视图交互） | 规则说明、优惠券展示、商品规格选择 |
| `action` | 行动面板 | **模态** | 快速操作选项，如分享、举报、更多操作 |
> **模态型**：不允许与父视图交互，需操作完成或关闭后才能继续主视图任务。
---
## 2. 交互行为
### 2.1 触发方式
| 触发方式 | 说明 | 示例 |
|---------|------|------|
| 系统触发 | 进入页面后由系统主动弹出 | 新功能引导、强提示 |
| 手动触发 | 用户主动操作触发 | 点击按钮/图标 |
### 2.2 动效规格
半页弹窗涉及三个层的联动动效，各层参数独立，**不可修改**（标注「不可变」）。

#### 进场动效（单击控件触发）
| 层 | 变化属性 | 起止值 | 时间 | 运动曲线 | 可变性 |
|----|---------|-------|------|---------|-------|
| **半弹层** | 位移（Y 轴，进入屏幕） | 弹窗高度 → 0 | 0ms → Spring 自然结束 | **Spring**：stiffness 720 / damping 61 / mass 1 / velocity 0 | 不可变 |
| **黑色遮罩** | 不透明度 | 0% → 100% | 0ms → 200ms | ease | 不可变 |
| **背景页面** | Scale（缩放） | 100% → 90% | 0ms → Spring 自然结束 | **Spring**：stiffness 720 / damping 61 / mass 1 / velocity 0 | 不可变 |

> Spring 参数说明：`stiffness` 对应 Principle 中的 `tension`，`damping` 对应 `friction`。

#### 离场动效——方式 1（点击关闭按钮 / 点击空白处）
| 层 | 变化属性 | 起止值 | 时间 | 运动曲线 | 可变性 |
|----|---------|-------|------|---------|-------|
| **半弹层** | 位移（Y 轴，离开屏幕） | 0 → 弹窗高度 | 0ms → 300ms | ease out | 不可变 |
| **黑色遮罩** | 不透明度 | 100% → 0% | 0ms → 200ms | ease | 不可变 |
| **背景页面** | Scale（缩放） | 90% → 100% | 0ms → 300ms | ease | 不可变 |

#### 离场动效——方式 2（侧滑手势触发关闭）
- **触发条件**：滑动距离或速度满足其一即触发退出
- **未达阈值**：浮层自动回弹至原位，避免误操作
- 背景页面缩放回弹同方式 1（90%→100%，0ms→300ms，ease）

#### 蒙层规格（配合动效）
| 属性 | 规范 |
|------|------|
| 颜色 | `mask-default`（`rgba(0,0,0,0.6)`，60% 黑色） |
| 进场透明度动效 | 0% → 100%，200ms，ease |
| 离场透明度动效 | 100% → 0%，200ms，ease |
| 覆盖范围 | 全屏（含状态栏） |
| 层级 | 位于背景页面之上、半弹层之下 |

### 2.3 关闭方式
| 关闭方式 | 适用场景 |
|---------|---------|
| 点击按钮（执行/取消/知道了） | 通用，执行按钮操作后自动关闭 |
| 点击关闭图标（×） | 通用 |
| 点击蒙层 | **可选**，业务自行判断；警示性/破坏性内容或复杂交易流程时**禁止**点击蒙层关闭 |
| 向下滑动 | 如内容支持滚动，须滚动到顶部后再继续下滑才触发关闭（优先保证内容滚动） |
---
## 3. 内容弹窗（category=content）
### 3.1 子类型（contentVariant）
内容弹窗包含**标准内容弹窗**和**自定义内容弹窗**两种：
| contentVariant | 名称 | 说明 |
|----------------|------|------|
| `standard` | 标准内容弹窗 | 有固定标题栏结构，内容区结构化，分为基础型/流程型/视觉引导型/选项卡型/模块型 |
| `custom` | 自定义内容弹窗 | 无通栏标题栏，内容直接顶边展示，顶部可带上挂模块 |
---
### 3.2 标准内容弹窗——样式类型（standardType）
| standardType | 名称 | 说明 | 典型场景 |
|--------------|------|------|---------|
| `basic` | 基础型 | 无返回操作，单次短时交互 | 轻量信息展示、快速确认 |
| `process` | 流程型 | 支持返回/步骤回溯，承载多步骤任务 | 分步填写表单、多步引导 |
| `visual` | 视觉引导型 | 顶部增加图片，用视觉元素降低认知成本 | 功能介绍、图文引导 |
| `tab` | 选项卡型 | 用于切换不同选项卡内容，数量支持 **4个及以上** | 多分类内容切换 |
| `module` | 模块型 | 用于切换不同功能模块，数量建议 **4个以下** | 同功能不同维度切换 |

#### 流程型（process）专属规格
流程型标题栏结构固定为：**左侧返回图标 + 居中主标题 + 右侧关闭图标**，并在主标题下方显示步骤副标题。

| 属性 | 规范 |
|------|------|
| 标题栏高度 | **76pt**（@2x 152px）——双行结构（主标题 + 步骤副标题） |
| 标题布局（titleType） | `center-double`（主标题居中 + 副标题在下）或 `left-double-vertical`（居左双行） |
| 左侧图标 | 返回图标（←），**18pt**（@2x 36px），与标题文字 `column-gap` 12pt（@2x 24px） |
| 右侧图标 | 关闭图标（×），**18pt**（@2x 36px），`justify-content: space-between` 两端对齐 |
| 步骤副标题字号/行高 | **14pt / 20pt**（`body-l-28-regular`），颜色 `text-quaternary`（#888888） |
| 主标题与步骤副标题间距 | `row-gap` **2pt**（@2x 4px） |
| gridPadding 推荐 | `24`（12pt）——流程型通常承载 ≥3 级信息层级 |
| 点击蒙层关闭 | **禁止**（`maskClosable=false`）——多步骤流程中途关闭会丢失进度 |
| 按钮区 | 主按钮「下一步」+ 次要按钮「返回」，双按钮并排或上下排列 |
| 步骤回溯 | 点击左侧返回图标或次要按钮「返回」均可回到上一步 |

**流程型双按钮布局（当同时有主/次按钮时）：**
| 属性 | 规范 |
|------|------|
| 按钮排列 | 水平并排，主按钮居右（或下），次要按钮居左（或上） |
| 次要按钮样式 | 描边型，`stroke-default` 边框，背景透明，文字 `text-primary` |
| 按钮区左右内边距 | **12pt**（@2x 24px） |
| 两按钮之间间距 | `cs-5`（5pt，来自 `component-spacing.md`）或按实际设计稿定 |

#### 视觉引导型（visual）专属规格
顶部增加图片，用视觉元素降低认知成本，适用于功能介绍、图文引导等场景。

**图片区规格：**
| 属性 | @2x 值 | @1x 值 | 说明 |
|------|--------|--------|------|
| 图片宽度 | 750px | **375pt**（全宽） | 贴边无留白 |
| 图片高度 | 422px | **211pt** | 约 16:9 比例（750:422 ≈ 16:9），**推荐比例** |
| 顶部圆角 | 40px | **20pt** | 与弹窗容器顶角对齐（`radius-xl`） |
| 下圆角 | 0 | 0 | 图片与标题栏无缝衔接 |
| 填充模式 | `object-fit: cover` | `object-fit: cover` | 保持比例裁剪居中填充 |
| 溢出 | `overflow: hidden` | `overflow: hidden` | 超出容器部分裁切 |

**关闭图标（浮于图片上方）：**
| 属性 | @2x 值 | @1x 值 | 说明 |
|------|--------|--------|------|
| 位置 | `top: 24px, right: 32px` | `top: 12pt, right: 16pt` | 右上角浮层，绝对定位 |
| 容器尺寸 | 44px × 44px | **22pt × 22pt** | 含 padding 的可点击区域 |
| 圆角 | 22px | **11pt**（全圆） | `border-radius: 50%` |
| 内边距 | 10px | **5pt** | 图标在容器内居中 |
| 图标尺寸 | 24px × 24px | **12pt × 12pt** | iconfont 关闭图标 |

**关闭按钮背景——两种变体（按图片明暗选择）：**
| 变体 | 背景色 | 适用场景 |
|------|--------|---------|
| 浅色图片 | `rgba(0, 0, 0, 0.04)` | 图片整体偏亮，黑色微透明背景保证图标可见 |
| 深色图片 | `rgba(255, 255, 255, 0.15)` | 图片整体偏暗，白色半透明背景保证图标可见 |

```css
/* 关闭按钮容器——浅色图片变体 */
.visual-close-btn--light {
  position: absolute;
  top: 24px;                        /* 12pt @1x */
  right: 32px;                      /* 16pt @1x */
  width: 44px;
  height: 44px;
  border-radius: 22px;              /* 全圆 */
  display: flex;
  justify-content: center;
  align-items: center;
  padding: 10px;                    /* 5pt @1x */
  background: rgba(0, 0, 0, 0.04); /* 浅色图片用，黑色微透明 */
}

/* 关闭按钮容器——深色图片变体 */
.visual-close-btn--dark {
  position: absolute;
  top: 24px;
  right: 32px;
  width: 44px;
  height: 44px;
  border-radius: 22px;
  display: flex;
  justify-content: center;
  align-items: center;
  padding: 10px;
  background: rgba(255, 255, 255, 0.15); /* 深色图片用，白色半透明 */
}

/* 图标本体（两种变体共用） */
.visual-close-btn__icon {
  flex-shrink: 0;
  width: 24px;                      /* 12pt @1x */
  height: 24px;
}
```

> ⚠️ **视觉引导型关闭图标规则（最高优先级）**：关闭图标**已浮于顶部图片右上角**，承担唯一的关闭入口职责。因此，**标题栏内不得再放置关闭图标**（无论左侧还是右侧），❌ 禁止在图片下方的标题栏内重复渲染关闭按钮。

**标题栏规格（4 种 titleType 变体）：**
| titleType | @2x 高度 | @1x 高度 | 左右内边距 | 结构 |
|-----------|---------|---------|---------|------|
| `center-single` | 108px | **54pt** | 16pt（@2x 32px） | 居中主标题，**无关闭图标**（关闭图标在图片上） |
| `center-double` | 152px | **76pt** | 16pt（@2x 32px） | 居中主标题+下方副标题，**无关闭图标** |
| `left-single` | 108px | **54pt** | 18pt（@2x 36px） | 居左主标题，**无关闭图标** |
| `left-wrap` | 156px | **78pt** | 18pt（@2x 36px） | 居左折行主标题（最多 2 行），**无关闭图标** |

**`center-double` 副标题规格：**
| 属性 | @2x 值 | @1x 值 | Token |
|------|--------|--------|-------|
| 字号/行高 | 28px / 40px | **14pt / 20pt** | `body-l-28-regular` |
| 字重 | 400 | 400 | — |
| 颜色 | #888888 | `text-quaternary` | `color-semantic.md` §二 |
| 对齐 | `text-align: center` | 居中 | — |
| 主标题与副标题间距 | `row-gap: 4px` | **2pt** | — |

**`left-wrap` 折行主标题规格：**
- 最多 **2 行**，超出时 `text-overflow: ellipsis` 截断
- 主标题容器高度 `78pt`（@2x 156px），`display: flex; align-items: center`

**视觉引导型整体层级结构：**
```
HalfScreenDialog (visual)
├── 图片区（全宽，211pt高，16:9，object-fit:cover）
│   └── 关闭图标（浮层，右上角 top:12pt right:16pt）
├── 标题栏（54pt 或 76pt 或 78pt）
│   ├── [left-single / left-wrap] 居左主标题 + 右侧关闭图标
│   └── [center-single / center-double] 左图标 + 居中主标题(+副标题) + 右图标
├── 内容区（flex-grow: 1，可滚动）
└── 按钮区（40pt，上内边距 8pt，左右内边距 12pt）
```

> **图片比例建议**：推荐使用 **16:9**（@1x 约 375×211pt）。图片内容为产品截图或插画时，可依实际内容适当调整高度，但不建议超过屏幕高度的 **30%**（约 230pt）。

---

#### 选项卡型（tab）专属规格
用于切换不同选项卡内的内容（如不同种类选项），数量支持 **4 个及以上**，Tab 项横向排列可左右滑动。

**标题栏结构（@2x → @1x）：**
| 属性 | @2x 值 | @1x 值 | 说明 |
|------|--------|--------|------|
| 标题栏高度 | 108px | **54pt** | 单行 Tab 项（无副标题） |
| 标题栏上内边距 | 32px | **16pt** | Tab 项距顶部 |
| 标题栏下内边距 | 22px | **11pt** | Tab 项距底部（含下划线） |
| 标题栏左内边距 | 32px | **16pt** | 左对齐起始位置 |
| Tab 项之间间距 | `column-gap: 48px` | **24pt** | 相邻 Tab 项水平间距 |
| 每个 Tab 项宽 | 192px | **96pt** | 文字宽度（居中对齐） |

**Tab 项文字规格：**
| 状态 | 字号/行高 | 字重 | 颜色 Token |
|------|---------|------|-----------|
| 选中 | **16pt / 22pt**（`subtitle-m-32-semibold`） | 600 | `text-primary`（#111111） |
| 未选中 | **16pt / 22pt**（`subtitle-m-32-regular`） | 400 | `text-secondary`（#555555） |

**选中指示器（下划线）：**
| 属性 | @2x 值 | @1x 值 |
|------|--------|--------|
| 宽度 | 64px | **32pt** |
| 高度 | 8px | **4pt** |
| 圆角 | 4px | **2pt** |
| 颜色 | #FFDD00 | `color-brand`（`color-semantic.md` §七 Brand Color） |
| 未选中时 | `opacity: 0` | 隐藏 |

**右侧渐出遮罩（Tab 超出屏幕时）：**
- 宽度：**30pt**（@2x 60px），覆盖标题栏右边缘，视觉截断提示可滑动

**Tab 标题栏 CSS 规格（@2x 画布，选项卡型）：**

```css
/* Tab 标题栏容器 */
[data-slot="half-screen-dialog-title"][data-standard-type="tab"] {
  width: 750px;
  height: 108px;              /* 54pt @1x */
  display: flex;
  flex-direction: row;
  justify-content: start;
  align-items: center;
  column-gap: 48px;           /* 24pt，Tab 项之间间距 */
  padding: 32px 0px 22px 32px; /* 上 16pt / 下 11pt / 左 16pt */
  overflow: hidden;
  background: #FFFFFF;
}

/* 单个 Tab 项（常规宽度，96px） */
.tab-item {
  flex-shrink: 0;
  width: 96px;                /* 48pt */
  height: 54px;               /* 27pt，含文字 + 下划线 */
  display: flex;
  flex-direction: column;
  justify-content: center;
  align-items: center;
  row-gap: 2px;               /* 1pt，文字与下划线间距 */
}

/* Tab 项文字——选中态 */
.tab-item__text--active {
  width: 96px;
  height: 44px;
  font-family: "PingFang SC";
  font-size: 32px;            /* 16pt subtitle-m-32-semibold */
  line-height: 44px;
  font-weight: 600;
  color: #111111;             /* text-primary */
  text-align: center;
}

/* Tab 项文字——未选中态 */
.tab-item__text--inactive {
  width: 96px;
  height: 44px;
  font-family: "PingFang SC";
  font-size: 32px;
  line-height: 44px;
  font-weight: 400;
  color: #555555;             /* text-secondary */
  text-align: center;
}

/* 选中指示器（下划线） */
.tab-item__indicator {
  flex-shrink: 0;
  width: 64px;                /* 32pt */
  height: 8px;                /* 4pt */
  border-radius: 4px;         /* 2pt */
  background: #FFDD00;        /* color-brand */
  /* 未选中时：opacity: 0 */
}

/* 超长 Tab 项（文字较多时，如 192px 宽） */
.tab-item--wide {
  width: 192px;               /* 96pt */
}
.tab-item--wide .tab-item__text--inactive {
  width: 192px;
}

/* 右侧渐出遮罩（Tab 数量超出屏幕时显示） */
.tab-title__fade-mask {
  position: absolute;
  top: 0; right: 0; bottom: 0;
  width: 60px;                /* 30pt */
  height: 108px;
  /* 渐出遮罩，从透明到白色 */
  background: linear-gradient(to right, transparent, #FFFFFF);
}
```

> **Tab 数量变体**：设计稿提供了 2～5 个 Tab 项的变体，所有变体容器高度和内边距相同（`108px`，`padding: 32px 0px 22px 32px`）；Tab 项间距固定 `column-gap: 48px`；超出屏幕时右侧显示 60px 渐出遮罩（`.tab-title__fade-mask`，`opacity: 1`），未超出时隐藏（`opacity: 0`）。

---

#### 模块型（module）专属规格
用于切换不同功能模块（如一个功能的不同维度），数量建议 **4 个以下**，Tab 项等分布局不支持滑动。

**标题栏结构（两种高度）：**
| 变体 | @2x 高度 | @1x 高度 | 说明 |
|------|---------|---------|------|
| 有副标题（标准） | 108px | **54pt** | 主标题 + 下方副文字 |
| 无副标题（紧凑） | 88px | **44pt** | 仅主标题 |

**Module 项文字规格：**
| 状态 | 主标题字号/行高 | 字重 | 颜色 Token |
|------|--------------|------|-----------|
| 选中 | **16pt / 22pt**（`subtitle-m-32-semibold`） | 600 | `text-primary`（#111111） |
| 未选中 | **16pt / 22pt**（`subtitle-m-32-regular`） | 400 | `text-secondary`（#555555） |

**Module 项副标题规格（仅标准变体有）：**
| 状态 | 字号/行高 | 字重 | 颜色 Token |
|------|---------|------|-----------|
| 选中 | **10pt / 14pt**（`caption-s-20-regular`） | 400 | `text-quaternary`（#888888） |
| 未选中 | **10pt / 14pt**（`caption-s-20-regular`） | 400 | `text-disabled`（#999999） |

**主标题与副标题间距：**`row-gap` **2pt**（@2x 4px）

**布局方式：**
- 等分列布局：每个 Module 项宽 = 750px ÷ 项数（2项时各 **188pt**，@2x 375px）
- 无选中指示器下划线，通过**字重 + 颜色**区分选中/未选中
- 无右侧渐出遮罩，不支持横向滑动

---
### 3.3 标准内容弹窗——标题区（titleType）
标题栏支持多种标题布局，按内容复杂度和对齐方式区分：

**标题栏高度：**
| 标题行数 | 高度 | 说明 |
|---------|------|------|
| 单行主标题 | **54pt**（@2x 108px） | 仅有主标题 |
| 双行标题（主+副） | **76pt**（@2x 152px） | 主标题 + 下方副标题 |

| titleType | 名称 | 对齐 | 主标题字号/行高 | 副标题字号/位置 | 适用场景 |
|-----------|------|------|----------------|---------------|---------|
| `center-single` | 居中单行主标题 | 居中 | **17pt / 24pt**（`subtitle-l-34-medium`） | 无副标题 | 内容层级简单 |
| `center-double` | 居中双行标题（主+副，上下） | 居中 | **17pt / 24pt**（`subtitle-l-34-medium`） | **14pt / 20pt** 在主标题下方 | 需补充说明 |
| `left-single` | 居左单行主标题 | 居左 | **17pt / 24pt**（`subtitle-l-34-medium`） | 无副标题 | 内容层级≥3级复杂场景 |
| `left-wrap` | 居左折行主标题 | 居左 | **17pt / 24pt**（`subtitle-l-34-medium`） | 无副标题 | 标题文字较长时 |
| `left-double-vertical` | 居左双行标题（主+辅，上下） | 居左 | **17pt / 24pt**（`subtitle-l-34-medium`） | **14pt / 20pt** 在主标题下方 | 复杂信息层级+副说明 |
| `left-double-horizontal` | 居左单行标题（主+辅，左右） | 居左 | **17pt / 24pt**（`subtitle-l-34-medium`） | **12pt** 在主标题右侧 | 紧凑的辅助标签信息 |

**标题区图标规格：**
| 图标 | 尺寸 | 距边缘间距 | 与标题文字间距 | 说明 |
|------|------|----------|-------------|------|
| 关闭图标（×） | **18pt**（@2x 36px） | **12pt**（@2x 24px） | — | 标题栏右侧，距右边缘 24px（@2x） |
| 返回图标（←） | **18pt**（@2x 36px） | **12pt**（@2x 24px） | **12pt**（@2x 24px） | 标题栏左侧，距左边缘 24px（@2x） |

> 图注说明：左侧返回图标距标题栏左边缘 **24px**（@2x / 12pt），右侧关闭图标距标题栏右边缘 **24px**（@2x / 12pt），两端对称；图标与居中主标题之间宽度自动分配（`auto`）。

**标题区功能区插槽 CSS 规格（@2x 画布）：**

**① 左侧功能区（`data-slot="title-leading"`）：**
```css
/* 左侧图标（返回 / 关闭），尺寸 36px，距左边缘 24px */
[data-slot="title-leading"] {
  position: absolute;
  left: 24px;    /* 12pt @1x，距标题栏左边缘 */
  width: 36px;   /* 18pt @2x */
  height: 36px;
}
/* 右侧辅助文字（如"跳过"），绝对定位，文字居左对齐 */
[data-slot="title-trailing-text"] {
  position: absolute;
  width: 56px;   /* 28pt @2x */
  height: 40px;  /* 20pt @2x */
  font-family: "PingFang SC";
  font-size: 28px;      /* 14pt body-l-28-regular */
  line-height: 40px;
  font-weight: 400;
  color: #111111;        /* text-primary */
  display: flex;
  align-items: center;
  /* text-align 默认 left，文字居左 */
}
```

**② 右侧功能区（`data-slot="title-trailing"`）：**
```css
/* 右侧图标（关闭 ×），尺寸 36px，距右边缘 24px */
[data-slot="title-trailing"] {
  position: absolute;
  right: 24px;   /* 12pt @1x，距标题栏右边缘 */
  width: 36px;   /* 18pt @2x */
  height: 36px;
}
/* 右侧辅助文字（如"跳过"），绝对定位，文字居右对齐 */
[data-slot="title-trailing-text"] {
  position: absolute;
  width: 56px;
  height: 40px;
  font-family: "PingFang SC";
  font-size: 28px;      /* 14pt */
  line-height: 40px;
  font-weight: 400;
  color: #111111;        /* text-primary */
  display: flex;
  align-items: center;
  justify-content: flex-end;  /* 文字靠右 */
  text-align: right;
}
```

> **左右功能区区别**：两者图标尺寸相同（36px），辅助文字容器尺寸相同（56×40px），区别仅在于辅助文字对齐方向——左侧功能区文字 `text-align: left`（默认），右侧功能区文字 `justify-content: flex-end; text-align: right`。

**双行标题行间距：**
- 主标题与副标题之间 `row-gap`：**2pt**（@2x 4px）
> **标题字号特殊规则**：当半页弹窗内容层级复杂（包含多级标题及多种字号）时，为强化视觉层次，主标题字号应调整为 **36号**（`title-s-36-medium`）。

**选项卡型/模块型标题字号：**
| 类型 | 选中标题 | 未选中标题 | 副标题（在标题下） |
|------|---------|-----------|--------------|
| `tab`（选项卡型） | **16pt/22pt** `subtitle-m-32-semibold`，w600，`text-primary` | **16pt/22pt** `subtitle-m-32-regular`，w400，`text-secondary` | 无副标题 |
| `module`（模块型） | **16pt/22pt** `subtitle-m-32-semibold`，w600，`text-primary` | **16pt/22pt** `subtitle-m-32-regular`，w400，`text-secondary` | **10pt/14pt** `caption-s-20-regular`，选中 `text-quaternary`，未选中 `text-disabled` |
**标题文字颜色：**
| 元素 | Token | 来源 |
|------|-------|------|
| 主标题 | `text-primary`（#111111） | `color-semantic.md` §二 Text Color |
| 副标题 / 辅标题 | `text-quaternary`（#888888） | `color-semantic.md` §二 Text Color |
| 正文说明 | `text-secondary`（#555555） | `color-semantic.md` §二 Text Color |
---
### 3.4 标准内容弹窗——左右栅格（gridPadding）
内容弹窗的左右内边距根据信息层级复杂度选择：
| gridPadding | 值 | Token | 适用场景 |
|-------------|-----|-------|---------|
| `32` | 16pt | `spacing-xl` | 承载 **≤2 级**信息层级，相对简单（如纯文本、基础表单） |
| `24` | 12pt | `spacing-l` | 承载 **≥3 级**信息层级，相对复杂（如多级分类列表、带图片的详情卡） |
---
### 3.5 自定义内容弹窗（contentVariant=custom）
| 属性 | 规范 |
|------|------|
| 标题栏 | **无**固定标题栏，内容直接顶边展示 |
| 上挂模块（hangTop） | 可选，顶部可附带上挂标题/操作模块（自定义） |
| 上挂模块圆角 | `radius-xl`（20pt）（上挂部分与主体分离，独立圆角） |
| 主体圆角 | `radius-xl`（20pt） |
| 内容嵌套圆角（完美嵌套型） | `radius-s`（8pt）（内容与容器完美贴合） |
| 内容嵌套圆角（灵活嵌套型） | `radius-s`（8pt）（内容与容器有间距，灵活排布） |
---
## 4. 内容弹窗通用规格
| 属性 | 值 | 语义 Token / 说明 |
|------|----|--------------------|
| 最小高度 | 屏幕高度的 **25%**（@2x 1624px 屏幕时约 **406px→203pt**） | 不可低于此高度；下边距可根据实际最小高度自定义调整 |
| 最大高度 | 距屏幕顶部至少 **6pt**（@2x 12px）间距（详见下方场景说明） | 超出内容时内容区支持上下滚动 |
| 顶部圆角 | `radius-xl`（**20pt**） | `radius-semantic.md` §一 Radius |
| 底部圆角 | 0（贴底） | — |
| 背景色（默认） | `white`（#FFFFFF） | `color-semantic.md` §一 Neutral Color |
| 背景色（备选） | `bg-surface`（#F7F7F7）或自定义氛围色 | `color-semantic.md` §三 Background Color |
| **全屏蒙层（必须）** | `mask-default`（60% 黑色） | `color-semantic.md` §六 Mask Color；不可省略 |
| 底部安全区高度 | **34pt**（@2x 68px） | 对应 Home Indicator 占位，内容不可侵入 |
| 按钮文字字号/行高 | **15pt / 22pt**（`subtitle-s-30-medium`） | `font-semantic.md` §一 Subtitle |
| 按钮高度 | **40pt**（@2x 80px） | 对应 Button `size=l` |
| 按钮圆角 | `radius-full`（9999px） | `component-radius.md` |
| 按钮区上内边距 | **8pt**（@2x 16px） | 按钮与内容区的间距 |
| 按钮区左右内边距 | **12pt**（@2x 24px） | `spacing-l` |
| 按钮内上下 padding | **10pt**（`cs-9`·`component-spacing.md`；@2x 19px→取整） | 按钮内容垂直居中 |
| 按钮内左右 padding | **20pt**（`cs-20`·`component-spacing.md`；@2x 40px） | 按钮内容水平留白 |
| 按钮内图标尺寸 | **17pt**（@2x 34px） | 按钮左侧配图图标 |
| 按钮内图标与文字间距 | **2pt**（@2x 4px） | `column-gap` |

**按钮插槽（`data-slot="half-screen-dialog-footer"`）CSS 规格（@2x 画布）：**

**① 单主按钮：**
```css
[data-slot="half-screen-dialog-footer"] {
  width: 750px;
  display: flex;
  flex-direction: column;
  justify-content: center;
  align-items: center;
  padding: 16px 24px 0px 24px;
  box-sizing: border-box;
  position: relative;
}
/* 主按钮：align-self:stretch 撑满（702px），高度 80px，圆角 40px，黄色渐变 */
.footer-btn-primary {
  align-self: stretch;       /* 宽 702px（750 - 24×2） */
  height: 80px;
  border-radius: 40px;       /* radius-full */
  display: flex;
  flex-direction: row;
  justify-content: center;
  align-items: center;
  column-gap: 4px;           /* 图标与文字间距 2pt */
  padding: 19px 40px;        /* cs-9 上下 / cs-20 左右 */
  background: linear-gradient(135deg, #FFE74D 0%, #FFDD00 100%); /* gradient-yellow */
  font-size: 30px;           /* 15pt subtitle-s-30-medium */
  line-height: 44px;
  font-weight: 500;
  color: #111111;            /* text-primary */
}
```

**② 双按钮并排（主 + 次，各 flex-grow:1）：**
```css
[data-slot="half-screen-dialog-footer"] {
  width: 750px;
  display: flex;
  flex-direction: row;       /* 水平并排 */
  justify-content: center;
  align-items: center;
  column-gap: 16px;          /* 双按钮间距，设计稿实测 @2x */
  padding: 16px 24px 0px 24px;
  position: relative;
}
/* 次要按钮（描边型，居左） */
.footer-btn-secondary {
  flex-grow: 1;              /* 与主按钮各占一半（约 343px） */
  height: 80px;
  border-radius: 40px;
  display: flex;
  justify-content: center;
  align-items: center;
  column-gap: 4px;
  padding: 19px 40px;
  border: 1px solid #CCCCCC; /* stroke-disabled */
  background: transparent;
  font-size: 30px;
  line-height: 44px;
  font-weight: 500;
  color: #111111;            /* text-primary */
}
/* 主按钮（黄色渐变，居右） */
.footer-btn-primary {
  flex-grow: 1;
  height: 80px;
  border-radius: 40px;
  display: flex;
  justify-content: center;
  align-items: center;
  column-gap: 4px;
  padding: 19px 40px;
  background: linear-gradient(135deg, #FFE74D 0%, #FFDD00 100%);
  font-size: 30px;
  line-height: 44px;
  font-weight: 500;
  color: #111111;
}
```

**③ 带辅助信息行（主按钮 + 下方辅助文字行）：**
```css
[data-slot="half-screen-dialog-footer"] {
  width: 750px;
  display: flex;
  flex-direction: column;
  justify-content: center;
  align-items: center;
  padding: 16px 24px 0px 24px;
  position: relative;
}
/* 辅助信息行（主按钮下方） */
.footer-auxiliary-row {
  width: 750px;
  height: 104px;             /* @2x，含 padding: 32px 0px */
  display: flex;
  flex-direction: column;
  justify-content: center;
  align-items: center;
  padding: 32px 0px;         /* 上下各 16pt */
  font-size: 28px;           /* 14pt body-l-28-regular */
  line-height: 40px;
  font-weight: 400;
  color: #888888;            /* text-quaternary */
}
```

**④ 顶部分割线（内容滚动时显示）：**
```css
/* 绝对定位于按钮区顶部，默认隐藏，内容上滚后 JS 切换 visibility */
.footer-divider {
  position: absolute;
  top: 0; left: 0; right: 0;
  width: 750px;
  height: 1px;
  overflow: hidden;
  background: rgba(0, 0, 0, 0.06); /* stroke-weak */
  visibility: hidden;
}

**最大高度——4 种场景说明（@2x → @1x）：**
| 场景 | 顶部间距（@2x） | 顶部间距（@1x） | 说明 |
|------|--------------|--------------|------|
| 关闭按钮在内 | **12px** | **6pt** | 弹窗距屏幕顶部最小留白；关闭图标位于弹窗内部标题栏 |
| 关闭按钮在外 | **12px** | **6pt** | 弹窗同样距顶 6pt，关闭图标悬浮于弹窗外上方 |
| 卡片堆叠型 | **0px**（背景层高 **20px→10pt**） | **0pt**（背景层 **10pt**） | 弹窗可贴顶；背景层（前一层卡片）高度为 10pt，营造堆叠感 |
| 微信小程序 | **32px** | **16pt** | 距小程序高标题栏底部 16pt，需为系统导航条预留空间 |

> **补充说明**：  
> - 所有场景下，若内容超出最大高度，内容区**支持上下滚动**，底部按钮区固定不动。  
> - 「关闭按钮在内」为最常见形态；「关闭按钮在外」适合内容需要最大化展示面积的场景。  
> - 如内容支持滚动，**需打开底部分割线**（`stroke-weak`，`rgba(0,0,0,0.06)`），以区分可滚动内容区与固定按钮区。

**最小高度补充：**
- 基准屏幕 @2x 高度 **1624px**（iPhone 14 Pro 等），25% = **406px → 203pt**
- 实际下边距（弹窗底部到屏幕底部）可根据最小高度值自定义调整，不固定为 0

---
## 5. 内容弹窗——建议做图区域（内容区左右边距）
| 场景 | 左右边距 | 说明 |
|------|---------|------|
| 简单内容（≤2 级信息层级） | **16pt** / `spacing-xl` | 纯文本、基础表单 |
| 复杂内容（≥3 级信息层级） | **12pt** / `spacing-l` | 多级列表、带图详情卡 |
---
## 6. 行动面板（category=action）
行动面板用于快速操作选项的展示，每个操作项独占一行，从底部弹出。

**整体结构规格（@2x → @1x）：**
| 属性 | @2x 值 | @1x 值 | 说明 |
|------|--------|--------|------|
| 面板背景色 | `#F7F7F7` | `bg-surface` | 操作项组与取消按钮的容器背景 |
| 顶部圆角 | 40px | **20pt**（`radius-xl`） | 与内容弹窗一致 |
| 底部安全区 | 68px | **34pt** | Home Indicator 占位，白色填充 |
| 蒙层 | `rgba(0,0,0,0.6)` | `mask-default`（60% 黑色） | 必须展示 |
| `maskClosable` | — | **true**（默认） | 点击蒙层可关闭 |

**操作项规格：**
| 属性 | @2x 值 | @1x 值 | 说明 |
|------|--------|--------|------|
| 操作项高度（常规） | 96px | **48pt** | 含上下内边距 |
| 操作项上下内边距 | 26px | **13pt** | |
| 操作项左右内边距 | 32px | **16pt** | |
| 操作项文字字号/行高 | 32px / 44px | **16pt / 22pt** | `subtitle-m-32-regular`，w400 |
| 操作项文字颜色 | `#111111` | `text-primary` | |
| 操作项文字对齐 | `text-align: center` | 居中 | |
| 相邻操作项分割线 | `border-top: 1px solid rgba(0,0,0,0.1)` | `stroke-weak` | 第一项无分割线，第二项起有 |
| 首项顶部圆角 | 40px | **20pt** | 与面板容器顶角对齐 |

**取消按钮规格：**
| 属性 | @2x 值 | @1x 值 | 说明 |
|------|--------|--------|------|
| 与操作项组间距 | padding-bottom: 16px | **8pt** | `#F7F7F7`（`bg-surface`）间隔带 |
| 取消按钮高度 | 96px | **48pt** | |
| 取消按钮内边距 | 10px | **5pt** | |
| 取消文字字号/行高 | 32px / 44px | **16pt / 22pt** | `subtitle-m-32-medium`，w500 |
| 取消文字颜色 | `#111111` | `text-primary` | |
| 取消按钮背景 | `#FFFFFF` | `white` | 独立白色背景，与操作项组分离 |

**标题行规格（可选，有标题变体）：**
| 属性 | @2x 值 | @1x 值 | 说明 |
|------|--------|--------|------|
| 标题行高度 | 88px | **44pt** | 比普通操作项稍矮 |
| 标题文字字号/行高 | 26px / 36px | **13pt / 18pt** | `caption-m-26-regular`，w400 |
| 标题文字颜色 | `#888888` | `text-quaternary` | 提示性辅助文字 |
| 标题行顶部圆角 | 40px | **20pt** | 首行，与面板顶角对齐 |

**图片堆叠变体（带顶部图片时）：**
| 属性 | @2x 值 | @1x 值 | 说明 |
|------|--------|--------|------|
| 图片区高度 | 220px | **110pt** | 顶部叠压在操作面板上方 |
| 叠压偏移 | `margin-top: -40px` | **-20pt** | 图片与操作面板形成视觉堆叠层次 |
| 图片区圆角 | 40px | **20pt** | 与面板顶角一致 |

---
## 9. 内容滚动区域说明
当内容超过弹窗高度时，内容区支持上下滚动：
| 场景 | 规则 |
|------|------|
| 底部无按钮 | 内容可自由滚动，展示未滚动和滚动到底部两种状态 |
| 底部有按钮 + 分割线 | 内容区滚动，底部按钮固定不随内容滚动 |
| 向下滑动关闭 | 须先滚动至内容**最顶部**，再继续向下滑动才触发关闭；未到顶部时禁止触发 |

**内容区内边距（@2x → @1x）：**
| 方向 | 值 | 说明 |
|------|----|------|
| 顶部 | **4pt**（@2x 8px） | 内容距标题栏底部的间距 |
| 底部 | **16pt**（@2x 32px） | 内容距按钮区顶部的间距 |
| 左右 | 由 `gridPadding` 决定（16pt 或 12pt） | 见 §3.4 |
---
## 10. Token 引用
### 10.1 颜色 Token
| 用途 | Token 名称 | 语义层来源 |
|------|-----------|-----------|
| 背景色（默认） | `white` | `color-semantic.md` §一 Neutral Color |
| 备选背景 | `bg-surface` | `color-semantic.md` §三 Background Color |
| **全屏蒙层（必须）** | `mask-default` | `color-semantic.md` §六 Mask Color |
| 主标题文字 | `text-primary` | `color-semantic.md` §二 Text Color |
| 副/辅标题文字 | `text-quaternary` | `color-semantic.md` §二 Text Color |
| 正文说明文字 | `text-secondary` | `color-semantic.md` §二 Text Color |
| 未选中 Tab/Module 主标题 | `text-secondary`（#555555） | `color-semantic.md` §二 Text Color |
| 选中 Module 副标题 | `text-quaternary`（#888888） | `color-semantic.md` §二 Text Color |
| 未选中 Module 副标题 | `text-disabled`（#999999） | `color-semantic.md` §二 Text Color |
| Tab 选中指示器（下划线） | `color-brand`（#FFDD00） | `color-semantic.md` §七 Brand Color |
| 行动面板操作项间分割线 | `stroke-weak`（rgba(0,0,0,0.1)） | `color-semantic.md` §四 Stroke Color；仅相邻操作项之间，第一项无 |
| 按钮上方分割线（可见时） | `stroke-weak`（rgba(0,0,0,0.06)） | `color-semantic.md` §四 Stroke Color；默认隐藏，内容滚动时显示 |
| 主按钮背景 | `gradient-yellow`（#FFE74D → #FFDD00，135deg） | `color-semantic.md` §八 Gradient Color |
| 次要按钮边框 | `stroke-default` | `color-semantic.md` §四 Stroke Color |
### 10.2 字体 Token
| 用途 | Token 名称 | 语义层来源 |
|------|-----------|-----------|
| 标题（标准，简单内容）17pt/24pt | `subtitle-l-34-medium` | `font-semantic.md` §一 Subtitle |
| 标题（增强，复杂内容层级） | `title-s-36-medium` | `font-semantic.md` §一 Title |
| 副标题（主标题下方）14pt/20pt | `body-l-28-regular` | `font-semantic.md` §一 Body |
| 辅标题（主标题右侧） | `body-s-24-regular` | `font-semantic.md` §一 Body |
| 正文说明 | `body-l-28-regular` | `font-semantic.md` §一 Body |
| 选项卡/模块——选中标题 16pt/22pt w600 | `subtitle-m-32-semibold` | `font-semantic.md` §一 Subtitle |
| 选项卡/模块——未选中标题 16pt/22pt w400 | `subtitle-m-32-regular` | `font-semantic.md` §一 Subtitle |
| 模块型副标题 10pt/14pt（选中/未选中色不同） | `caption-s-20-regular` | `font-semantic.md` §一 Caption |
| 行动面板操作项 | `subtitle-m-32-regular` | `font-semantic.md` §一 Subtitle |
| 底部按钮 15pt/22pt | `subtitle-s-30-medium` | `font-semantic.md` §一 Subtitle |
### 10.3 圆角 Token
| 用途 | Token 名称 | 来源 |
|------|-----------|------|
| 弹窗顶部圆角 / 行动面板顶部圆角 / 图片区顶部圆角 | `radius-xl`（20pt） | `radius-semantic.md` §一 Radius |
| 底部按钮圆角 | `radius-full`（9999px 胶囊形） | `radius-semantic.md` §一 Radius（`component-radius.md` 亦收录） |
| 自定义内容——上挂模块圆角 | `radius-xl`（20pt） | `radius-semantic.md` §一 Radius |
| 内容嵌套圆角（完美/灵活型） | `radius-s`（8pt） | `radius-semantic.md` §一 Radius |
| Tab 选中指示器圆角（4pt） | `cr-4`（4pt） | `component-radius.md` §一 |
| Tab 选中指示器圆角（2pt） | `cr-2`（2pt） | `component-radius.md` §一 |
### 10.4 间距 Token

> **使用边界**：页面/模块级间距引用 `spacing-semantic.md`；组件内部 padding / gap 引用 `component-spacing.md`（`cs-{N}`）。

**页面/模块级（`spacing-semantic.md`）：**
| 用途 | Token 名称 | 值 |
|------|-----------|-----|
| 标题区左右内边距（gridPadding=32，简单内容） | `spacing-xl` | 16pt（@2x 32px） |
| 标题区左右内边距（gridPadding=24，复杂内容） | `spacing-l` | 12pt（@2x 24px） |
| 内容区左右边距（简单内容） | `spacing-xl` | 16pt |
| 内容区左右边距（复杂内容） | `spacing-l` | 12pt |
| 按钮区上内边距 | `spacing-s` | 8pt（@2x 16px） |
| 按钮区左右内边距 | `spacing-l` | 12pt（@2x 24px） |
| 内容区顶部 padding | `spacing-xs` | 4pt（@2x 8px） |
| 内容区距底部间距 | `spacing-xl` | 16pt（@2x 32px） |

**组件内部（`component-spacing.md`）：**
| 用途 | Token 名称 | 值 |
|------|-----------|-----|
| 按钮内上下 padding | `cs-9` | 10pt（@2x 约 19px，Button l 上下内边距） |
| 按钮内左右 padding | `cs-20` | 20pt（@2x 40px，Button l 水平内边距） |
| 按钮内图标与文字间距 | `cs-2` | 2pt（@2x 4px） |
| 流程型双按钮之间间距 | `cs-5` | 5pt |
| 操作项上下内边距（行动面板） | `cs-13` | 13pt（@2x 26px） |
| 操作项左右内边距（行动面板） | `cs-16` | 16pt（@2x 32px） |
| 取消按钮与操作项组间距（行动面板） | `cs-8` | 8pt（@2x 16px） |
| 标题栏图标与文字间距（流程型） | `cs-12` | 12pt（@2x 24px） |
---
## 11. Props API（供 AI 生码参考）
```typescript
export type HalfScreenDialogProps = {
  /**
   * 弹窗大类
   * @default "content"
   */
  category?: "content" | "action";
  /**
   * 内容弹窗子类（仅 content 有效）
   * @default "standard"
   */
  contentVariant?: "standard" | "custom";
  /**
   * 标准内容弹窗样式类型
   * @default "basic"
   */
  standardType?: "basic" | "process" | "visual" | "tab" | "module";
  /**
   * 标题区布局
   * @default "center-single"
   */
  titleType?:
    | "center-single"
    | "center-double"
    | "left-single"
    | "left-wrap"
    | "left-double-vertical"
    | "left-double-horizontal";
  /**
   * 左右栅格（内边距）
   * @default "32"
   */
  gridPadding?: "32" | "24";
  /**
   * 是否展示上挂模块（仅 contentVariant=custom 有效）
   * @default false
   */
  hangTop?: boolean;
  /**
   * 弹窗标题
   */
  title?: React.ReactNode;
  /**
   * 副标题 / 辅标题
   */
  subTitle?: React.ReactNode;
  /**
   * 主按钮文案
   */
  primaryLabel?: string;
  /**
   * 次要按钮文案
   */
  secondaryLabel?: string;
  /**
   * 主按钮点击回调
   */
  onPrimary?: () => void;
  /**
   * 次要按钮点击回调
   */
  onSecondary?: () => void;
  /**
   * 关闭回调（点击蒙层或关闭按钮时触发）
   */
  onClose?: () => void;
  /**
   * 是否允许点击蒙层关闭
   * @default true
   */
  maskClosable?: boolean;
  /**
   * 自定义内容区
   */
  children?: React.ReactNode;
};
```
---
## 12. data-attribute 规范
| 属性 | 值 | 说明 |
|------|----|------|
| `data-slot` | `"half-screen-dialog"` | 弹窗根容器 |
| `data-slot` | `"half-screen-dialog-overlay"` | 全屏蒙层 |
| `data-slot` | `"half-screen-dialog-content"` | 弹窗主体 |
| `data-slot` | `"half-screen-dialog-title"` | 标题栏区域 |
| `data-slot` | `"half-screen-dialog-body"` | 内容区域 |
| `data-slot` | `"half-screen-dialog-footer"` | 底部按钮区域 |
| `data-category` | `"content"` / `"action"` | 弹窗大类 |
| `data-content-variant` | `"standard"` / `"custom"` | 内容弹窗子类 |
| `data-standard-type` | `"basic"` / `"process"` / `"visual"` / `"tab"` / `"module"` | 标准内容弹窗样式 |
| `data-modal` | `"true"` / `"false"` | 是否模态型 |
---
## 13. 无障碍（Accessibility）
- 弹窗容器使用 `role="dialog"`，`aria-modal="true"`（模态型）
- 必须设置 `aria-labelledby` 指向标题元素 ID
- 打开时焦点移入弹窗内（模态型）；关闭时焦点返回触发元素
- 模态型 Focus Trap：Tab 键焦点限制在弹窗内部
- 键盘 `Esc` 键关闭弹窗
- 全屏蒙层 `aria-hidden="true"`
---
## 14. 使用约束（AI 生成时的硬性规则）
1. **蒙层不可省略**：所有半页弹窗（content / action / activity）均必须渲染 `mask-default`（60% 黑色）全屏蒙层
2. **顶部圆角固定**：`radius-xl`（20pt），不可自定义
3. **最小高度约束**：弹窗高度不得低于屏幕高度的 25%
4. **内容滚动优先**：有滚动内容时，向下滑动必须先到顶才触发关闭
5. **警示内容禁止点击蒙层关闭**：警示性/破坏性内容或复杂交易流程时，`maskClosable=false`
6. **选项卡数量约束**：`tab` 型支持 4 个及以上选项；`module` 型建议 4 个以下
7. **左右栅格选择**：≤2 级信息层级用 16pt；≥3 级信息层级用 12pt
8. **复杂内容时加大标题字号**：内容层级复杂（多级标题、多种字号）时主标题改为 36号
9. **禁止直接写 hex 颜色**：颜色必须使用 §10.1 中的语义 Token
10. **行动面板取消按钮独立**：取消项与操作项组之间通过 **`bg-surface`（8pt）间隔带**分离，而非分割线；操作项组内相邻项之间才使用 `stroke-weak` 分割线
11. **按钮上方分割线**：当内容区可滚动且用户已向上滚动时，底部按钮上方显示 `stroke-weak` 分割线（`rgba(0,0,0,0.06)`），默认状态下隐藏
12. **视觉引导型标题栏禁止重复关闭图标**：`standardType=visual` 时，关闭图标已浮于顶部图片右上角，**标题栏内（无论 titleType 为何种变体）一律不得放置关闭图标**，❌ 禁止在图片下方的标题栏左侧或右侧渲染任何关闭/取消按钮
---
## 15. 常见组合示例
### 15.1 商品规格选择（基础型内容弹窗）
```
HalfScreenDialog
  category: content
  contentVariant: standard
  standardType: basic
  titleType: center-single        // "选择规格"
  gridPadding: "32"
  maskClosable: true
  primaryLabel: "加入购物车"
  蒙层: mask-default（60% 黑）
```
### 15.2 多步骤表单（流程型内容弹窗）
```
HalfScreenDialog
  category: content
  contentVariant: standard
  standardType: process
  titleType: center-double        // 主标题居中 + 步骤副标题在下，标题栏高度 76pt
  gridPadding: "24"               // 流程型通常 ≥3 级信息层级，用 12pt 内边距
  maskClosable: false             // 流程型禁止蒙层关闭，防止丢失进度
  primaryLabel: "下一步"          // 主按钮（黄色渐变），右侧
  secondaryLabel: "返回"          // 次要按钮（描边型），左侧
  蒙层: mask-default（60% 黑）
  // 标题栏：左侧返回图标（18pt）+ 居中主标题 + 右侧关闭图标（18pt）
  // 副标题示例："第 1 步 / 共 3 步"，字号 14pt，颜色 text-quaternary
```
### 15.3 功能引导图文弹窗（视觉引导型）

**变体 A — 居中单行标题（最常用）：**
```
HalfScreenDialog
  category: content
  contentVariant: standard
  standardType: visual
  titleType: center-single           // 仅居中主标题，❌ 无关闭图标（关闭图标已在图片上）
  gridPadding: "32"                  // 内容区左右 16pt
  primaryLabel: "知道了"
  蒙层: mask-default（60% 黑）
  // 图片：全宽 375pt × 211pt（16:9），顶部圆角 20pt，object-fit:cover
  // 关闭图标浮于图片右上角 top:12pt right:16pt，尺寸 22pt
  // ⚠️ 标题栏内不渲染任何关闭按钮
```

**变体 B — 居中双行标题（含副标题说明）：**
```
HalfScreenDialog
  category: content
  contentVariant: standard
  standardType: visual
  titleType: center-double           // 居中主标题 + 副标题（14pt，text-quaternary），❌ 无关闭图标
  gridPadding: "32"
  primaryLabel: "立即开通"
  蒙层: mask-default（60% 黑）
  // 标题栏高度 76pt（@2x 152px）
  // 副标题 14pt / 20pt body-l-28-regular，颜色 text-quaternary（#888888），居中对齐
  // ⚠️ 标题栏内不渲染任何关闭按钮
```

**变体 C — 居左单行标题：**
```
HalfScreenDialog
  category: content
  contentVariant: standard
  standardType: visual
  titleType: left-single             // 居左主标题，❌ 无关闭图标
  gridPadding: "32"
  primaryLabel: "去使用"
  蒙层: mask-default（60% 黑）
  // 标题栏高度 54pt，左右内边距 18pt（@2x 36px）
  // ⚠️ 标题栏内不渲染任何关闭按钮
```

**变体 D — 居左折行标题（长标题时）：**
```
HalfScreenDialog
  category: content
  contentVariant: standard
  standardType: visual
  titleType: left-wrap               // 居左折行主标题（最多 2 行），❌ 无关闭图标
  gridPadding: "32"
  primaryLabel: "我知道了"
  蒙层: mask-default（60% 黑）
  // 标题栏高度 78pt（@2x 156px），超出 2 行时 text-overflow: ellipsis
  // ⚠️ 标题栏内不渲染任何关闭按钮
```
### 15.4 分享操作面板（行动面板）

**变体 A — 基础操作列表（无标题）：**
```
HalfScreenDialog
  category: action
  maskClosable: true              // 点击蒙层可关闭
  蒙层: mask-default（60% 黑）
  // 操作项：48pt高，16pt/22pt，text-primary，居中，项间 stroke-weak 分割线
  // 取消按钮：独立底部，48pt高，16pt/22pt w500，与操作项组间距 8pt（bg-surface）
```

**变体 B — 带标题行的操作列表：**
```
HalfScreenDialog
  category: action
  maskClosable: true
  蒙层: mask-default（60% 黑）
  // 标题行：44pt高，13pt/18pt，text-quaternary（#888888），辅助说明
  // 操作项：同变体A规格，第一操作项无分割线，第二项起有
```

**变体 C — 带顶部图片的堆叠样式：**
```
HalfScreenDialog
  category: action
  maskClosable: true
  蒙层: mask-default（60% 黑）
  // 顶部图片区：110pt高，顶部圆角 20pt，margin-top: -20pt 叠压在操作面板上方
  // 操作面板：同变体A/B规格
```
### 15.5 自定义内容弹窗（带上挂模块）
```
HalfScreenDialog
  category: content
  contentVariant: custom
  hangTop: true                   // 顶部显示上挂标题
  gridPadding: "32"
  primaryLabel: "确认"
  蒙层: mask-default（60% 黑）
```
---
## 16. 与其他组件的关系
| 关联组件 | 关系说明 |
|----------|----------|
| `dialog` | Dialog 从屏幕中间弹出，强中断；Half Screen Dialog 从底部弹出，中断程度相对较低；蒙层 dialog 为 `mask-default`（60%），营销 dialog 为 `mask-heavy`（80%）；两者均必须有蒙层 |
| `button` | 底部按钮区使用 `button.md` 中的 `size=l`（高度 40pt）按钮 |
| `list` | `category=content` 时内容区常嵌套 List 组件 |
| `select` | `category=content` 时内容区可嵌套 Select 实现规格/选项选择 |
| `toast` | Toast 不使用蒙层，不中断操作，与半页弹窗互斥不同时使用 |
