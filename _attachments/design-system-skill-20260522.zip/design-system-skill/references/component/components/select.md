# Select 单选 & 多选 - 组件规范

> **组件分类**：Component（组件级）
> **定义**：单选 & 多选是支持从一组选项中选择一个或多个选项的组件，选择后选项不一定即时生效。常用于筛选器、购物车等场景。
> **Style 依赖**：`color-semantic.md` · `font-semantic.md` · `component-spacing.md` · `component-radius.md` · `stroke-semantic.md`
---

## 0. 图标 / 间距 / Ownership 约束

- **icon-route（默认）**：Select 的勾选圆、对号等状态图标按正文规则优先使用本组件既定 icon route，不得随意改写。
- **fixed-asset 例外**：若正文明确指定官方 SVG、`assets/*.svg`、PNG/CDN 切图，则该位点必须走 fixed-asset 并记录 `icon-route=fixed-asset`。
- **spacing-owner（Select 自持）**：勾选圆、对号、选中态视觉及组件内部对齐归 Select 拥有。
- **宿主裁决（优先级）**：出现在 `filter-panel` / `list` / `image-selection` 等宿主中时，列表/网格 spacing 与排布归宿主，遵循 `宿主 > 组合场景 > 本组件`。
- **不可跳步**：先回 `references/INDEX.md` 完成区域路由与宿主锁定，再用 `component-quickref.md` 做宿主级收敛；本文件仅承接组件内 ownership 细则，不承担前置路由改判；不得凭语义猜测。


## 1. 组件类型（type）

| type       | 名称    | 适用场景                                  |
| ---------- | ----- | ------------------------------------- |
| `checkbox` | 勾选型   | 单选和多选通用，通过选项高亮直接显示每个选项的选中状态（如筛选器/购物车） |
| `image`    | 图片选择型 | 图片多选，通过数字反馈已选数量，强调总数统计（如图片批量选择、套餐规格等） |

---

## 2. 勾选型尺寸规格（size）

| size      | 名称  | 勾选圆圈直径 | 适用场景                        |
| --------- | --- | ------ | --------------------------- |
| `large`   | 大号  | 20pt   | 常用于文字列表功能项，如购物车等一级页面选项      |
| `small`   | 小号  | 16pt   | 其他紧凑场景                      |
| `special` | 特殊  | 18pt   | 仅用于单选与按钮、步进器在同一页时（如商品规格选择页） |

---

## 3. 状态（state）

| state              | 名称      | 说明                               |
| ------------------ | ------- | -------------------------------- |
| `default`          | 未选      | 选项未被选中时的默认状态                     |
| `highlighted`      | 未选 强化勾选 | 未选中但有视觉引导，显示灰色对号轮廓，仅在选择后对用户有利时使用 |
| `disabled`         | 未选 禁用   | 当前不可操作，如会员专属选项对普通用户禁用            |
| `checked`          | 已选      | 选项已被选中，反馈当前选择结果                  |
| `disabled-checked` | 已选      | 已选中但不可取消，如已提交的订单信息               |

---

## 4. 勾选型样式矩阵

### 4.1 大号（size=large，20×20pt）

| state              | 勾选圆圈样式                                        | 内容（对号）                        |
| ------------------ | --------------------------------------------- | ----------------------------- |
| `default`          | 描边 `stroke-strong`（1pt solid）                 | 无                             |
| `highlighted`      | 描边 `stroke-strong`（1pt solid）                 | 灰色对号（10×10pt，`stroke-strong`） |
| `disabled`         | 背景 `divider-secondary` + 描边 `divider-secondary` | 无                             |
| `checked`          | 背景 `yellow-default`（品牌黄）                      | 黑色对号（10×10pt，`text-primary`）  |
| `disabled-checked` | 背景 `divider-primary`（10%透明黑）                  | 白色对号（`white`）                 |

### 4.2 小号（size=small，16×16pt）

| state              | 勾选圆圈样式                                      | 内容（对号）                      |
| ------------------ | ------------------------------------------- | --------------------------- |
| `default`          | 描边 `stroke-strong`（1pt solid）               | 无                           |
| `highlighted`      | 描边 `stroke-strong`（1pt solid）               | 灰色对号（8×8pt，`stroke-strong`） |
| `disabled`         | 背景 `divider-secondary` + 描边 `divider-secondary` | 无                           |
| `checked`          | 背景 `yellow-default`（品牌黄）                    | 黑色对号（8×8pt，`text-primary`）  |
| `disabled-checked` | 背景 `divider-primary`                        | 白色对号（`white`）               |

### 4.3 特殊（size=special，18×18pt）

| state              | 勾选圆圈样式                                        | 内容（对号）                      |
| ------------------ | --------------------------------------------- | --------------------------- |
| `default`          | 描边 `stroke-strong`（1pt solid）                 | 无                           |
| `highlighted`      | 描边 `stroke-strong`（0.9pt solid）               | 灰色对号（9×9pt，`stroke-strong`） |
| `disabled`         | 背景 `divider-secondary` + 描边 `divider-secondary` | 无                           |
| `checked`          | 背景 `yellow-default`（品牌黄）                      | 黑色对号（9×9pt，`text-primary`）  |
| `disabled-checked` | 背景 `divider-primary`                          | 白色对号（`white`）               |

---

## 5. 图片选择型（type=image）

### 5.1 角标规格

| 属性         | 值                      |
| ---------- | ---------------------- |
| 角标容器尺寸     | 22×22pt                |
| 圆圈圆角       | `radius-full`          |
| 数字字体 Token | `body-s-12-medium` |

### 5.2 图片选择型状态矩阵

| state            | disabled | 组件结构与样式                                                                                                                                           | 内容                   |
| ---------------- | -------- | ------------------------------------------------------------------------------------------------------------------------------------------------- | -------------------- |
| `default`        | `false`  | 背景 `white`（15%透明） + 描边 `white`（1pt）                                                                                                              | 无                    |
| `default`        | `true`   | 双层圆叠加（同为 22pt）：底层圆 背景 `white`（15%透明）+ 描边 `white`（1pt）；顶层圆 背景 `white`（30%透明）+ 无描边                                                               | 无                    |
| `checked-number` | `false`  | 背景 `yellow-default`（品牌黄） + 描边 `white`（1pt）                                                                                                       | 数字序号（`text-primary`） |
| `checked-number` | `true`   | 三层结构（同为 22pt）：底层圆 背景 `white`（15%透明）+ 无描边；中层 数字序号（`white`，居中对齐）；顶层圆 背景 `white`（30%透明）+ 描边 `white`（1pt） | 数字序号（`white`）        |
| `checked-mark`   | `false`  | 背景 `yellow-default`（品牌黄） + 描边 `white`（1pt）                                                                                                       | 黑色对号（`text-primary`） |

---

## 6. 布局结构

### 6.1 勾选型行项（文字列表）

```
Row Container（height: variable，padding-horizontal: cs-10）
├── 勾选圆圈（20/16/18pt，radius-full）
│   └── 对号图标（居中对齐，aria-hidden="true"）
└── 文字内容区
    ├── 主标题（subtitle-m-16-medium，text-primary）
    └── 副标题（可选，body-l-14-regular，text-tertiary）
```

### 6.2 图片选择型卡片

```
图片容器（cr-12，bg-surface）
├── 商品图（cr-12，圆角仅上两角）
├── 角标（position: absolute，top-right，22×22pt）
├── 商品名称（subtitle-m-16-medium，text-primary）
├── 副标题/规格（body-m-13-regular，text-tertiary）
├── 价格（price-18-bold，red-default）
└── 操作区
    ├── 添加按钮（18×18pt，radius-full，yellow-bg-secondary，加号图标 text-primary）
    └── 步进器（见下方规格）
```

### 6.3 步进器（图片选择型）

```
Stepper（flex-direction: row）
├── 减号按钮（18×18pt，radius-full，border: 1pt solid yellow-bg-secondary）
├── 数字（body-l-14-regular，text-primary）
└── 加号按钮（18×18pt，radius-full，bg: yellow-bg-secondary）
```

---

## 7. Props API

```typescript
// 勾选型单个选项
export interface SelectOptionProps {
  value: string | number;
  label: string;
  subLabel?: string;
  disabled?: boolean;
  /** 是否显示强化勾选（灰色对号引导，未选中状态使用） */
  highlighted?: boolean;
  size?: "large" | "small" | "special";
}

// 多选组
export interface CheckboxGroupProps {
  options: SelectOptionProps[];
  value?: (string | number)[];
  defaultValue?: (string | number)[];
  onChange?: (values: (string | number)[]) => void;
  size?: "large" | "small" | "special";
}

// 单选组
export interface RadioGroupProps {
  options: SelectOptionProps[];
  value?: string | number;
  defaultValue?: string | number;
  onChange?: (value: string | number) => void;
  size?: "large" | "small" | "special";
}

// 图片选择型
export interface ImageSelectProps {
  images: Array<{
    id: string;
    src: string;
    alt?: string;
    name?: string;
    price?: number;
    disabled?: boolean;
  }>;
  /** 角标样式：数字序号 or 对号 */
  mode?: "number" | "checkmark";
  value?: string[];
  maxSelect?: number;
  onChange?: (ids: string[]) => void;
}
```

---

## 8. data-attribute 规范

| 属性              | 值                                           | 说明      |
| --------------- | ------------------------------------------- | ------- |
| `data-slot`     | `"select"`                                  | 全局稳定标识  |
| `data-type`     | `"checkbox"` / `"image"`                    | 组件类型    |
| `data-state`    | `"default"` / `"highlighted"` / `"checked"` | 选中状态    |
| `data-disabled` | `"true"` / `"false"`                        | 禁用状态    |
| `data-size`     | `"large"` / `"small"` / `"special"`         | 尺寸（勾选型） |

---

## 9. 状态流转

```
未选态（default）
  → [用户点击] → 已选态（checked）
  → [条件禁用] → 禁用未选（disabled）

未选态（强化勾选 highlighted）
  → [仅视觉引导，不自动选中]
  → [用户点击] → 已选态（checked）

已选态（checked）
  → [用户再次点击 多选模式] → 未选态
  → [单选模式选中另一项]    → 自动取消（→ 未选态）
  → [条件禁用]              → 禁用已选（disabled-checked）
```

---

## 10. 单选 vs 多选行为差异

| 特性        | 单选（Radio）              | 多选（Checkbox） |
| --------- | ---------------------- | ------------ |
| 同时选中数量    | 最多 1 个                 | 不限（可设上限）     |
| 反选取消      | 不支持（选另一项自动取消）          | 支持           |
| ARIA role | `radio` / `radiogroup` | `checkbox`   |
| 设计外观      | 完全相同（通过业务逻辑区分）         | 完全相同         |

---

## 11. Token 引用

### 11.1 颜色 Token

| 用途           | Token 名称             | 语义层来源                                   |
| ------------ | -------------------- | --------------------------------------- |
| 已选圆圈背景（品牌黄）  | `yellow-default`     | `color-semantic.md` §七 Functional Color |
| 未选圆圈/强化勾选描边  | `stroke-strong`      | `color-semantic.md` §四 Stroke Color     |
| 禁用未选背景       | `divider-secondary`  | `color-semantic.md` §五 Divider Color    |
| 禁用已选背景       | `divider-primary`    | `color-semantic.md` §五 Divider Color    |
| 已选对号颜色       | `text-primary`       | `color-semantic.md` §二 Text Color       |
| 强化勾选对号颜色    | `stroke-strong`      | `color-semantic.md` §四 Stroke Color     |
| 禁用已选对号颜色    | `white`              | `color-semantic.md` §一 Neutral Color    |
| 主标题文字        | `text-primary`       | `color-semantic.md` §二 Text Color       |
| 副标题文字        | `text-tertiary`      | `color-semantic.md` §二 Text Color       |
| 图片选择型白色描边/遮罩 | `white`              | `color-semantic.md` §一 Neutral Color    |
| 卡片背景         | `bg-surface`         | `color-semantic.md` §三 Background Color |
| 价格颜色         | `red-default`        | `color-semantic.md` §七 Functional Color |
| 添加按钮/步进器加号背景 | `yellow-bg-secondary`     | `color-semantic.md` §七 Functional Color |
| 添加按钮/步进器图标色   | `text-primary`       | `color-semantic.md` §二 Text Color       |
| 步进器减号描边      | `yellow-bg-secondary`     | `color-semantic.md` §七 Functional Color |

### 11.2 圆角 Token

| 用途           | Token 名称      | 语义层来源                          |
| ------------ | ------------- | ------------------------------ |
| 勾选圆圈         | `radius-full` | `component-radius.md` |
| 添加按钮 / 步进器按钮 | `radius-full` | `component-radius.md` |
| 图片卡片容器       | `cr-12`       | `component-radius.md` |

### 11.3 字体 Token

| 用途       | Token 名称               | 语义层来源                          |
| -------- | ---------------------- | ------------------------------ |
| 行项主标题    | `subtitle-m-16-medium` | `font-semantic.md` §一 Subtitle |
| 行项副标题    | `body-l-14-regular`    | `font-semantic.md` §一 Body     |
| 图片卡片名称   | `subtitle-m-16-medium` | `font-semantic.md` §一 Subtitle |
| 图片卡片副标题  | `body-m-13-regular`    | `font-semantic.md` §一 Body     |
| 图片选择角标数字 | `body-s-12-medium`     | `font-semantic.md` §一 Body |
| 步进器数字    | `body-l-14-regular`    | `font-semantic.md` §一 Body     |
| 图片卡片价格   | `price-18-bold`        | `font-semantic.md` §三 Price Font |

---

## 12. 无障碍（Accessibility）

| 属性                | 值                              |
| ----------------- | ------------------------------ |
| `role`（多选）        | `checkbox`                     |
| `role`（单选）        | `radio`                        |
| `role`（单选组容器）     | `radiogroup`                   |
| `aria-checked`    | `true` \| `false` \| `"mixed"` |
| `aria-disabled`   | `true`（禁用状态）                   |
| `aria-labelledby` | 指向对应的文字标签元素                    |
| `tabIndex`        | `0`（可聚焦）/ `-1`（禁用时）            |

**键盘交互**：

- `Space`：切换选中状态（checkbox）
- `↑/↓ Arrow`：在单选组中移动焦点（radio）
- `Enter`：确认选中

---

## 13. 使用约束（AI 生成时的硬性规则）

1. **禁止直接写 hex 颜色**：颜色必须使用 §11.1 中的 Token 名称
2. **禁止自定义圆圈尺寸**：只能从 §2 表格中选取 size，不能自定义 `width`/`height`
3. **特殊尺寸限制**：`size=special` 仅在单选与按钮、步进器同页使用
4. **强化勾选使用条件**：`highlighted` 仅在选择后对用户有利时使用，不可滥用
5. **单选/多选视觉一致**：两种模式外观完全一致，不允许通过设计区分，仅通过业务逻辑控制
6. **图片选择型数量限制**：通过 `maxSelect` 控制最大选择数，达上限后其余选项禁用
7. **图片选择型角标数字对齐**：角标数字与背景圆圈必须居中对齐，不得偏移
8. **图片选择型角标数字上限**：数字序号建议上限为 9，不允许显示超出此范围的数字（如需超过请改用对号模式 `mode="checkmark"`）
9. **对号图标类型**：对号必须使用**面性**图标，禁止使用线性图标

---

## 14. 使用场景速查

| 场景             | type       | size      | 说明                    |
| -------------- | ---------- | --------- | --------------------- |
| 购物车商品勾选        | `checkbox` | `large`   | 一级页面标准列表              |
| 筛选面板多选项        | `checkbox` | `small`   | 空间紧凑场景                |
| 商品规格单选（与步进器同页） | `checkbox` | `special` | 规格选择页                 |
| 图片批量多选         | `image`    | —         | mode="number"，强调数量    |
| 套餐组合多选         | `image`    | —         | mode="checkmark"，强调状态 |

---

## 15. 与其他组件的关系

| 关联组件           | 关系说明                       |
| -------------- | -------------------------- |
| `filter-panel` | 单选/多选常作为筛选面板的子组件           |
| `button`       | 图片选择型中"改规格"使用操作单按钮         |
| `badge`        | 购物车数量徽标                    |
| `stepper`      | 图片选择型中已选项可切换为步进器（+/- 控制数量） |

---

## 16. 完整设计稿参考

- **印迹设计稿**：https://ingee.meituan.com/#/artboard/1414188/pos_t
- **imageId**：1414188
- **设计稿尺寸基准**：750pt（@3x，设计稿宽度 6800px）
