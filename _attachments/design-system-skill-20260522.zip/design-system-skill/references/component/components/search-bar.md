# search-bar.md — 搜索框 - 组件规范
> **组件分类**：Component（组件级）
> **定义**：搜索框（Search Bar）是用户发起搜索行为的核心输入组件。按高度分为 4 种规格，覆盖强 / 中 / 弱三种类型、白底 / 灰底 / 描边三种样式、未触发 / 触发两种状态及附加图标等全部变体。也可嵌入导航栏形成组合场景。
> **Style 依赖**：`color-semantic.md` · `font-semantic.md` · `spacing-semantic.md` · `component-spacing.md` · `radius-semantic.md` · `component-radius.md` · `stroke-semantic.md` · `shadow-semantic.md`
---
## 0. 图标 / 间距 / Ownership 约束

- **icon-route（默认）**：搜索图标默认走 iconfont，且 `size=60/68/72` 时固定使用 `search-line-medium`。
- **fixed-asset 例外**：清除按钮强制使用 `assets/Round Close Button.svg`，该位点属于 fixed-asset，不得改回 iconfont。
- **spacing-owner（归属）**：本文件仅拥有输入区内部（图标、占位文案、输入文本、清除按钮）的 gap / padding / 对齐。
- **宿主裁决（优先级）**：嵌入 `navigation` 时，外层 style / padding / 高度 / 横向占位由 `navigation.md` 裁决，遵循 `宿主 > 组合场景 > 本组件`。
- **不可跳步**：先回 `references/INDEX.md` 完成区域路由与宿主锁定，再用 `component-quickref.md` 做宿主级收敛；本文件仅承接组件内 ownership 细则，不承担前置路由改判；不得凭语义猜测。


## 1. 规格（size）
搜索框按**高度**区分为 4 种规格，尺寸不可自定义，必须从下表选取。
| size | 高度 | 圆角 | 适用场景 |
|------|------|------|---------|
| `60` | 30pt | `radius-full`（胶囊） | 屏效要求高的场景：商家页头部、嵌于圆底导航内 |
| `68` | 34pt | `radius-full`（胶囊） | **最常用**，首页、搜索页等通用场景 |
| `72` | 36pt | `radius-full`（胶囊） | 旅行 / 酒店业务：需展示多行信息（住店 / 离店日期） |
| `88` | 44pt | `radius-m`（方形感） | 地图业务 / 信息密度低场景，支持多种特殊布局 |
> **圆角**：60 / 68 / 72 为胶囊全圆角，使用 `radius-full`；88 为方正圆角，使用 `radius-m`。
---
## 2. 类型（type）
仅适用于 `size=60` 和 `size=68`。
| type | 名称 | 右侧操作区表现 |
|------|------|-------------|
| `strong` | 强 | 带渐变黄色搜索按钮（`gradient-yellow`） |
| `medium` | 中 | 带垂直分割线 + 文字"搜索"按钮 |
| `weak` | 弱 | 无搜索按钮，点击整体跳转搜索页 |
> `size=72` 和 `size=88` 无此三种 type 区分，各有专属布局变体（见 §6 / §7）。
---
## 3. 样式（style）
| style | 名称 | 背景 Token | 描边 |
|-------|------|-----------|------|
| `white` | 白底 | `white` | 无 |
| `gray` | 灰底 | `bg-fill-tertiary` | 无 |
| `outlined` | 描边 | `white` | 34pt/30pt：`stroke-brand`（黄色，1pt）；36pt：`stroke-blue`（旅行蓝，1pt） |
> **嵌入组合场景时**：搜索框 `style` 由父组件决定，子组件侧不得擅自改写；若父组件未额外声明，默认按 `gray` 处理。嵌入 `navigation.md` 的 34pt 组合场景，嵌套搜索框 style 固定 `gray`（见 §10.1）；`outlined` 仅在父组件主动声明（如旅行业务 36pt 场景）时使用。
---
## 4. 状态（state）
| state | `data-state` | 视觉表现 |
|-------|-------------|---------|
| 未触发 | `default` | 搜索词为占位文字，颜色 `text-quaternary` |
| 触发 / 聚焦 | `active` | 显示用户输入内容（`text-primary`）+ 输入光标（`color-focus`）；`strong` / `medium` / `weak` 类型右侧追加清除按钮；**非触发态展示的附加图标（`hasAddon=true`）在触发态时隐藏，右侧仅保留清除按钮** |
---
## 5. 通用尺寸规格
### 5.1 搜索图标
| size | 图标容器 | 内部路径 | 颜色 Token |
|------|---------|---------|-----------|
| `68` | 16×16pt | 13×13pt | `text-quaternary` | `search-line-medium` |
| `60` | 15×15pt | 12×12pt | `text-quaternary` | `search-line-medium` |
| `72` / `88` | 16×16pt | — | `text-quaternary` | `search-line-medium`（60/68/72 适用，88 另行确认） |
> **图标规范**：搜索图标必须使用**基础图标库（iconfont）**中的图标，字重必须为**中黑体（Medium）**。
> **图标尺寸规则**：搜索图标尺寸须比右侧搜索词文字大 **2pt**。例如：搜索词文字为 14pt，则搜索图标为 **16×16pt**；搜索词文字为 13pt，则搜索图标为 **15×15pt**。
> **`size=60 / 68 / 72` 搜索图标固定使用 `search-line-medium`**：三种规格均引用 iconfont 中的 `search-line-medium` 图标，尺寸以各自组件数据为准（60：15×15pt；68/72：16×16pt），**不得更换图标名、替换为自定义 SVG 或调整字重**。
### 5.2 占位文字 / 输入内容
| size | 占位文字字体 Token | 输入内容字体 Token |
|------|-----------------|-----------------|
| `68` | `body-l-28-regular` | `body-l-28-regular` |
| `60` | `body-s-26-regular`（13pt 常规，`text-quaternary` / #888888） | `body-s-26-regular`（13pt 常规，`text-primary` / #111111） |
| `72` | `body-l-28-regular` | `body-l-28-regular` |
| `88` | `subtitle-m-30-regular` | `subtitle-m-30-regular` |
> 占位文字颜色：`text-quaternary`；输入内容颜色：`text-primary`。
### 5.3 输入光标
| 属性 | 34pt / 36pt / 44pt | 30pt |
|-----|-------------------|------|
| 宽度 | 1.5pt | 1.5pt |
| 高度 | 18pt（= 搜索词 14pt + 4pt） | 17pt（= 搜索词 13pt + 4pt） |
| 圆角 | `radius-full` | `radius-full` |
| 颜色 Token | `color-focus`（`#0A77F5`） | `color-focus`（`#0A77F5`） |
| 位置 | 紧邻输入内容右侧，不留额外间距 | 紧邻输入内容右侧，不留额外间距 |
> **光标尺寸规则**：宽度固定 **1.5pt**；高度 = 左侧搜索词文字字号 + **4pt**。例如：搜索词 14pt → 光标高度 **18pt**；搜索词 13pt → 光标高度 **17pt**。
>
> **布局规则（`size=60` 和 `size=68` 触发态均适用）**：
> - 搜索词文本区域宽度**自适应内容**，不拉伸占满剩余空间（`flex: 0 0 auto` 或 `width: fit-content`），仅包裹文字本身
> - 光标元素紧跟在搜索词文本节点之后，作为 flex 行内的独立子元素，`margin-left: 0`，不插入任何额外间距
> - 剩余空间由搜索词文本区域**左侧的包裹容器**吸收（包裹容器 `flex: 1`），搜索词和光标本身不参与空间分配
> - **HTML 结构示例**（触发态）：
>   ```html
>   <!-- 左侧整体容器：flex: 1，负责吸收剩余空间 -->
>   <div class="search-left" style="display:flex; align-items:center; flex:1; min-width:0;">
>     <span class="search-icon">…</span>
>     <!-- 搜索词 + 光标：同处一个 inline-flex 容器，宽度 fit-content -->
>     <span class="search-input-area" style="display:inline-flex; align-items:center; width:fit-content; flex-shrink:0;">
>       <span class="search-text" style="color:#111111;">美食 汉堡</span>
>       <span class="search-cursor"></span>
>     </span>
>   </div>
>   ```
> - **禁止**将搜索词文本设为 `flex:1` 或 `width:100%`，否则光标会被推至右端，无法紧邻文字
### 5.4 清除按钮（active 状态，type=strong / medium）
| 属性 | 值 | Token |
|-----|-----|-------|
| 热区 | 14×14pt | — |
| 圆形背景 | 12.5×12.5pt | `bg-fill-secondary` |
| 图标（白色 ×） | 嵌于圆形内 | `white` |

> ⚠️ **实现规范（强制）**：所有尺寸（`size=60` 和 `size=68`）的搜索框触发态清除按钮，**必须**使用 `assets/Round Close Button.svg`（2倍图，28×28px，即 14×14pt）。
> - **尺寸固定**：渲染尺寸锁定为 28×28px（`width="28" height="28"`），**不可更改**，不可缩放
> - **样式固定**：不得对该 SVG 添加任何额外背景、边框、滤镜或变换
> - **HTML 用法**：
>   ```html
>   <button class="search-clear-btn" aria-label="清除搜索内容" type="button">
>     <img src="assets/Round Close Button.svg" width="28" height="28" aria-hidden="true" alt="">
>   </button>
>   ```
> - **CSS 容器**：按钮容器尺寸 28×28px，`background: none`，`border: none`，`padding: 0`
>
> ⚠️ **SVG 内部圆形规范（生成或修改 SVG 时必读）**：
> - 圆形背景必须使用 `<circle>` 标签，**禁止使用 `<ellipse>`**
> - `<circle>` 的圆心固定为 `cx="14" cy="14"`，半径固定为 `r="14"`（恰好等于 viewBox 边长的一半）
> - **原因**：`ellipse` 的 `rx/ry` 若超过 14（如 14.625），圆形路径将超出 `viewBox="0 0 28 28"` 边界，SVG 默认 `overflow:hidden` 会将超出部分裁切，导致渲染为不完整的椭圆/被截圆形
> - **正确示例**：`<circle cx="14" cy="14" r="14" fill="#CCCCCC"/>`
> - **错误示例（禁止）**：`<ellipse cx="14" cy="14" rx="14.625" ry="14.625" fill="#CCCCCC"/>` ← 超出边界会被裁切
### 5.5 附加图标（hasAddon=true）
| size | 图标尺寸 | 与左侧元素间距 | 距最右侧 |
|------|---------|-------------|--------|
| `68` | 18×18pt | `spacing-m`（12pt） | — |
| `60` | 17×17pt | `cs-10` | 12pt |
> **附加图标规范**：优先使用**基础图标库**中的图标；颜色使用 `text-primary`（`#111111`）；字重必须为**中黑体（Medium）**；图标尺寸遵循上表，不可自定义。
>
> ⚠️ **状态切换规则（强制）**：附加图标**仅在 `state=default`（非触发态）时显示**。当搜索框进入 `state=active`（触发态）时，附加图标必须隐藏，右侧区域**仅展示清除按钮**（§5.4），不保留附加图标位置。适用于 `size=60` 和 `size=68` 的所有 `type`（`strong` / `medium` / `weak`）。
>
> **清除按钮距右侧间距不变**：触发态时附加图标隐藏后，清除按钮距右侧边缘的距离**以各 type 已有规定为准，不得更改**（`strong`：距搜索按钮 12pt / 10pt；`weak`：距最右侧 12pt / 10pt；`medium`：距分割线左侧按分割线 margin 规则执行）。不得因附加图标消失而额外调整清除按钮的位置或间距。
---
## 6. 34pt 搜索框规格（最常用）
### 6.1 整体容器
| 属性 | 值 |
|-----|-----|
| 整体尺寸 | 351×34pt |
| 圆角 | `radius-full`（胶囊） |
| 内边距（左右） | `spacing-xs`（6pt） |
### 6.2 右侧区域变体
**type = `strong`（强）**
| 触发状态 | 右侧内容 |
|---------|---------|
| 未触发 | 渐变搜索按钮（52×28pt，圆角 `radius-full`，背景 `gradient-yellow`，文字 `body-l-28-medium`，颜色 `text-primary`） |
| 触发 | 清除按钮（14pt）+ `spacing-m`（12pt）间距 + 渐变搜索按钮（52×28pt） |
**type = `medium`（中）**
| 触发状态 | 右侧内容 |
|---------|---------|
| 未触发 | 分割线（线宽 1pt × 高 12pt，`divider-primary` / `#000000` 10%，左右各留 12pt 间距）+ 文字"搜索"（28×20pt，`body-l-28-medium`，`text-primary`） |
| 触发 | 清除按钮（14pt）+ `spacing-m`（12pt）+ 分割线（线宽 1pt × 高 12pt，`divider-primary` / `#000000` 10%，左右各留 12pt 间距）+ 文字"搜索" |

> ⚠️ **实现注意（medium 分割线间距）**：分割线"左右各 12pt 间距"由分割线自身的 `margin-left / margin-right` 统一控制，**不应**在分割线前额外插入间距元素（如独立的 gap div）。若在清除按钮或附加图标后插入了额外间距 div，再叠加分割线 margin-left，会导致左侧间距翻倍（变为 24pt）。正确实现：无论前方是输入占位区、清除按钮还是附加图标，分割线左侧一律只保留 `margin-left: 12pt`，不再额外添加任何间距节点。
**type = `weak`（弱）**
| 触发状态 | 右侧内容 |
|---------|---------|
| 未触发 | 无 |
| 触发 | 清除按钮（14pt） |
> `weak` 类型触发态显示清除按钮，无搜索按钮。
### 6.3 内边距与边缘间距
| 位置 / 元素 | 间距 | 说明 |
|------------|------|------|
| 搜索图标 距最左侧 | 12pt | 左内边距 |
| 搜索图标 与右侧搜索词 间距 | 2pt | `spacing-3xs` |
| strong 胶囊按钮 距最右侧 | 3pt | 右内边距 |
| strong 附加图标 距胶囊按钮 | 12pt | 附加图标与搜索按钮的间距，`spacing-m`；**触发态时附加图标隐藏** |
| strong 触发态取消按钮 距胶囊按钮 | 12pt | active 状态下清除按钮与搜索按钮的间距，`spacing-m` |
| medium 文字按钮 距最右侧 | 14pt | 右内边距，`spacing-2xl` |
| weak 附加图标 距最右侧 | 14pt | 右内边距，`spacing-2xl`；**触发态时附加图标隐藏** |
| weak 触发态取消按钮 距最右侧 | 12pt | 右内边距，active 状态，`spacing-m` |

### 6.4 布局结构
```
34pt 搜索框（351×34pt，radius-full）
├── 左侧（flex-row，gap: spacing-3xs / 2pt）
│   ├── 搜索图标（16×16pt，text-quaternary）
│   └── 搜索词 / 输入内容（body-l-28-regular）
│       └── [光标（1.5×18pt，color-focus）]  ← active 时
└── 右侧
    ├── [清除按钮（14pt）]  ← active 时（所有 type 均显示）
    ├── type=strong → 渐变按钮（52×28pt，gradient-yellow）
    ├── type=medium → 分割线（1pt × 12pt，divider-primary，左右各 12pt 间距）+ 文字"搜索"（28×20pt）
    │               ※ 12pt 间距由分割线 margin-left/right 统一控制，前方元素勿再额外插入 gap
    └── type=weak   → 无
    └── [附加图标（18×18pt）]  ← hasAddon=true 且 state=default 时；触发态（active）时隐藏
```
---
## 7. 30pt 搜索框规格
### 7.1 整体容器
| 属性 | 值 |
|-----|-----|
| 整体尺寸 | 351×30pt |
| 圆角 | `radius-full`（胶囊） |
### 7.2 与 34pt 的差异对照
| 属性 | 30pt | 34pt |
|-----|------|------|
| 高度 | 30pt | 34pt |
| 圆角 | `radius-full` | `radius-full` |
| 搜索图标 | 15×15pt | 16×16pt |
| 占位文字字体 Token | `body-s-26-regular` | `body-l-28-regular` |
| strong 按钮尺寸 | 48×24pt | 52×28pt |
| strong 按钮圆角 | `radius-full` | `radius-full` |
| strong 按钮字体 Token | `body-s-24-medium` | `body-l-28-medium` |
| medium 分割线高 | 11pt（= 文字 13pt − 2pt） | 12pt（= 文字 14pt − 2pt） |
| medium 分割线宽 | 1pt | 1pt |
| medium 分割线颜色 | `divider-primary` / `#000000` 10% | `divider-primary` / `#000000` 10% |
| medium 分割线左右间距 | 10pt | 12pt |
| medium 文字区尺寸 | 26×18pt | 28×20pt |
| 附加图标 | 17×17pt | 18×18pt |
| 光标高度 | 17pt | 18pt |
### 7.3 内边距与边缘间距
| 位置 / 元素 | 间距 | 说明 |
|------------|------|------|
| 搜索图标 距最左侧 | 10pt | 左内边距 |
| 搜索图标 与右侧搜索词 间距 | 2pt | `spacing-3xs` |
| strong 按钮 距最右侧 | 3pt | 右内边距 |
| strong 附加图标 距右侧按钮 | 10pt（`cs-10`） | 图标与搜索按钮的间距；**触发态时附加图标隐藏** |
| strong 触发态清除按钮 距右侧按钮 | 10pt（`cs-10`） | active 状态下清除按钮与搜索按钮的间距 |
| medium 分割线 左右间距 | 10pt | 分割线与左侧输入区、右侧"搜索"文字各留 10pt |
| medium 文字按钮 距最右侧 | 12pt | 右内边距 |
| 附加图标 距最右侧 | 12pt | 右内边距（所有 type 通用）；**触发态时附加图标隐藏** |
| weak 触发态清除按钮 距最右侧 | 10pt | 右内边距（active 状态，type=weak） |
---
## 8. 36pt 搜索框规格（旅行 / 酒店业务）
### 8.1 整体容器
| 属性 | 值 |
|-----|-----|
| 整体尺寸 | 351×36pt |
| 圆角 | `radius-full`（胶囊） |
| 内边距（左右） | `spacing-m`（12pt） |
| 描边（outlined 样式） | 1pt，`stroke-blue`（旅行蓝，区别于 34pt 的黄色描边） |
### 8.2 内部间距
| 区域 | 属性 | 值 | 说明 |
|------|------|-----|------|
| 地址区 与 右侧区域 | `column-gap` | 12pt | 地址区与右侧整体（信息容器起始位置）的间距 |
| 分割线 左侧（信息容器 → 分割线） | `column-gap` | 8pt | 信息容器右边缘到分割线左边缘的间距 |
| 分割线 右侧（分割线 → 搜索区） | `column-gap` | 8pt | 分割线右边缘到搜索区起始元素的间距 |
| 搜索区内部（图标与文字） | `column-gap` | 2pt（`spacing-3xs`） | 搜索图标与占位文字间距 |

> **实现说明**：右侧区域（信息容器 + 分割线 + 搜索区）使用统一 `column-gap: 8pt`（@2x：`16px`）的 flex 行排列，分割线两侧间距均为 8pt，无需对分割线单独设置 margin。省略搜索图标时，搜索词直接作为搜索区起始元素，与分割线的间距仍为 8pt，无需补偿。
### 8.3 内部区域结构
```
36pt 搜索框（351×36pt，radius-full，左右 padding: 12pt）
├── 地址区（左侧，flex-shrink: 0）
│   ├── 3字（单行）：36×16pt，body-s-24-semibold，text-primary
│   ├── 4字（双行）：20×26pt，两行各 20×14pt，caption-l-22-semibold，text-primary，gap: -2pt（行重叠）
│   └── 极限（6字超出）：30pt 宽，截断为"…"
├── 右侧区域（flex-grow: 1，flex-row，column-gap: 8pt）
│   ├── 信息容器（37×26pt，flex-column，gap: -2pt）
│   │   ├── 上行（往 / 住店前缀 + 日期）：37×14pt
│   │   │   ├── 前缀文字（"往"/"住"）：10×14pt，caption-l-20-regular，text-secondary（#555555）
│   │   │   └── 日期数字：25×14pt，caption-l-20-semibold，color-blue（#004099，旅行蓝）
│   │   └── 下行（返 / 离店前缀 + 日期）：37×14pt（同上行结构）
│   ├── 分割线（0.5×20pt，divider-primary / rgba(0,0,0,0.1)）
│   └── 搜索区（flex-row，column-gap: 2pt，flex-grow: 1）
│       ├── 搜索图标（16×16pt，text-quaternary）  ← 可省略
│       └── 搜索词（body-l-28-regular，text-quaternary / #888888，text-overflow: ellipsis）
│           ※ 分割线左侧间距 8pt、右侧间距 8pt，均由右侧区域统一 column-gap: 8pt 控制
│             省略搜索图标时：搜索词直接作为搜索区起始元素，与分割线间距仍为 8pt，无需补偿
```
### 8.4 日期信息区详细规格（2 倍图标注）
| 元素 | 2倍图尺寸 | 1倍pt尺寸 | 字号 | 字重 | 颜色 Token |
|------|---------|---------|------|------|-----------|
| 信息容器（整体） | 自适应×52px | 自适应×26pt | — | — | — |
| 单行（上/下行） | 自适应×28px | 自适应×14pt | — | — | — |
| 前缀文字（"往"/"返"/"住"/"离"） | 20×28px | 10×14pt | 20px（10pt） | Regular（400） | `text-secondary`（`#555555`） |
| 日期数字 | 自适应×28px | 自适应×14pt | 20px（10pt） | SemiBold（600） | `color-blue`（`#004099`） |
| 前缀与日期间距 | `column-gap: 4px` | 2pt | — | — | — |
> **行重叠规则**：上行与下行之间使用负间距 `margin-top: -2pt`（2倍图为 `-4px`），使双行总高度 = 26pt（而非 28pt）。

> **信息容器与日期数字宽度规则**：信息容器整体及内部日期数字的宽度均**自适应内容**，不设固定宽度，由字体实际渲染宽度决定。容器通过 `flex-shrink: 0` 防止被压缩，右边缘紧贴内容，确保与右侧分割线之间的 `column-gap（8pt）` 保持一致，不产生额外空隙。

#### Token 统一使用规则
72px 搜索框中所有 `#004099`（旅行蓝）元素均必须引用语义化 Token，不得直接写入色值：

| 元素 | Token | 色值参考 |
|------|-------|----------|
| 日期数字（住/离店日期） | `color-blue` | `#004099` |
| outlined 描边 | `stroke-blue` | `#004099` |

> **业务色更换规则**：若用户描述需要更换旅行蓝色，应同时更新 `color-blue` 和 `stroke-blue` 两个 Token 的指向色值，**不得只改其中一处**。示例：
> - 更换前：日期数字 `color-blue` = `#004099`，描边 `stroke-blue` = `#004099`
> - 更换后：日期数字 `color-blue` = 新色值，描边 `stroke-blue` = 新色值（两处必须保持一致）

#### 日期格式转换规则
住店日期和离店日期应根据用户描述的内容，转换为组件中规定的展示格式：

| 用户描述形式 | 组件展示形式 | 示例 |
|------------|-----------|------|
| X月Y日 | `MM.DD`（月日各补零至两位） | 1月9日 → `01.09` |
| X/Y、X-Y | `MM.DD` | 3/5 → `03.05` |
| 纯数字月日 | `MM.DD` | 0305 → `03.05` |

> **格式规范**：月和日均需补零至两位，使用英文句点 `.` 分隔，不带年份，不带"月""日"等汉字后缀。例如：`01.09`、`03.25`、`12.01`。
### 8.5 地址区详细规格（2 倍图标注）
| addressLength | 2倍图尺寸 | 1倍pt尺寸 | 字号 | 字重 | 说明 |
|-------------|---------|---------|------|------|------|
| `short`（3字，单行） | 72×32px | 36×16pt | 24px（12pt）| SemiBold（600） | `body-s-24-semibold`，单行 |
| `medium`（4字，双行） | 40×52px | 20×26pt | 20px（10pt）| SemiBold（600） | 两行各 20×14pt，`caption-l-20-semibold`，行重叠 -2pt |
| `long`（4字+） | 60×52px | 30×26pt | 20px（10pt）| SemiBold（600） | **双行**：第一行固定展示前3字（宽60px），第二行展示第4字起的剩余内容，超出截断为"…"；`caption-l-20-semibold`，行重叠 -2pt |
> **注意**：md 规范原文地址4字字体标注为 `caption-l-22-semibold`（11pt），2倍图代码实测为 `font-size: 20px`（10pt）。以规范原文为准，如后续校准以设计稿为准请同步更新。

#### 地址字数自动选择规则
若用户未显式指定 `addressLength`，应根据实际地址字数自动判断并选用对应组件类型：

| 实际字数 | 选用 `addressLength` | 展示方式 |
|---------|-------------------|---------|
| 1 ~ 3 字 | `short` | **单行**，宽度自适应内容（`width: fit-content`），不固定宽度 |
| 4 字 | `medium` | **双行**：前2字为第一行，后2字为第二行，两行均为固定宽度（各2字宽） |
| 5 ~ 6 字 | `medium` | **双行**：前半部分为第一行，后半部分为第二行，两行均定宽，可适当调整分行点 |
| > 6 字 | `long` | **双行**：第一行固定前3字（定宽），第二行为第4字起剩余内容（定宽，超出截断省略） |

> **`short` 实现规则**：字数为 1 ~ 3 字时，使用单行展示，宽度随内容自适应，不设固定宽度，不换行。
>
> **示例**（"北京"，2字 / "吉隆坡"，3字）：
> ```html
> <!-- short：宽度自适应 -->
> <div class="addr-short">北京</div>
> <div class="addr-short">吉隆坡</div>
> ```

> **`medium` 实现规则**：字数为 4 字时，前2字写入第一行，后2字写入第二行，两行均设固定宽度（= 2字 × 字号px），行间距使用负 margin 实现行重叠 -2pt（@2x：-4px）。
>
> **示例**（"德克萨斯"，4字）：
> ```html
> <!-- medium：两行各固定宽度 -->
> <div class="addr-medium">
>   <div class="addr-medium-line">德克</div>
>   <div class="addr-medium-line">萨斯</div>
> </div>
> ```

> **`long` 实现规则**：字数 > 6 字时，第一行固定写入前3字（定宽），第二行写入第4字起的剩余全部内容（定宽），超出宽度由 `text-overflow: ellipsis` 控制省略，**不得手动截断字符串或添加"…"**。
>
> **示例**（"布宜诺斯艾利斯"，7字）：
> ```html
> <!-- long：两行均固定宽度，第二行超出截断 -->
> <div class="addr-long">
>   <div class="addr-long-line1">布宜诺</div>
>   <div class="addr-long-line2">斯艾利斯</div>
> </div>
> ```
### 8.6 Props 变体矩阵
| style | addressLength | 说明 |
|-------|-------------|------|
| `white` | `short`（3字） | 白底，单行地址 |
| `white` | `medium`（4字） | 白底，双行地址 |
| `white` | `long`（6字+） | 白底，截断 |
| `gray` | `short` / `medium` / `long` | 灰底（`#F5F5F5`），同上 |
| `outlined` | `short` / `medium` / `long` | 旅行蓝描边（`stroke-blue`，非黄色） |
---
## 9. 44pt 搜索框规格（地图 / 特殊场景）
### 9.1 整体容器
| 属性 | 值 |
|-----|-----|
| 整体尺寸（大多数变体） | 355×44pt |
| 圆角 | `cr-12`（方正感，非胶囊，`component-radius.md`） |
| 投影 | `shadow-l` |
| 内边距（左右，非 split 变体） | `0px 24px` = **12pt** |
| 内边距（split 搜索框容器） | `0px 20px` = **10pt** |
### 9.2 布局变体（layout）
| layout | 名称 | 说明 |
|--------|------|------|
| `input-only` | 输入框 | 左侧返回 + 搜索词，右侧关闭按钮；最常用 |
| `input-keyword` | 输入框 + 搜索词标签 | 左侧返回，中部胶囊形已选关键词标签 + 清除 |
| `address-search` | 地址 + 搜索框 | 左侧返回 + 地址，右侧 `bg-fill-tertiary` 内嵌搜索框（高32pt，圆角 `cr-6`） |
| `address-date-search` | 地址 + 日期 + 搜索框 | 左侧返回 + 地址 + 日期信息区，右侧内嵌搜索框 |
| `double-input` | 双输入框 | 左侧返回，右侧起点 / 终点双行输入（内框 `bg-fill-tertiary`，圆角 `cr-6`），总高88pt |
| `with-tags` | 带筛选标签 | 上部44pt搜索输入行 + 下部42pt筛选标签栏，总高86pt |
| `split` | 分离样式 | 返回按钮独立容器（38×38pt，圆角 `cr-12`，独立投影）+ 搜索框容器（309×38pt，独立投影）；两者间距 `column-gap: 8pt` |
### 9.3 通用内部元素
| 元素 | 尺寸 | iconfont 图标名 | 颜色 Token |
|------|------|--------------|-----------|
| 返回图标 | 18×18pt（路径 7.5×13.5pt） | `translate-line-medium` | `text-primary` |
| 关闭图标 | 18×18pt（路径 12.5×12.5pt） | `cancel-line-medium` | `text-primary` |
| 内容文字 | `subtitle-m-30-regular`，行高 22pt | — | `text-primary` |
| 搜索词（搜索区） | `body-l-28-regular` | — | `text-quaternary` |
| 图标与内容文字间距 | `column-gap: 8pt`（16px） | — | — |

> **返回图标规范（强制）**：返回图标必须使用 iconfont 中的 **`translate-line-medium`**，图标类型、尺寸（18×18pt）、颜色（`text-primary`）均不可修改，**不得更换图标名、替换为自定义 SVG 或调整尺寸与颜色**。

> **关闭图标规范（强制）**：关闭图标必须使用 iconfont 中的 **`cancel-line-medium`**，图标类型、尺寸（以组件数据为准，18×18pt）、颜色（`text-primary`）均不可修改，**不得更换图标名、替换为自定义 SVG 或调整尺寸与颜色**。

> **内嵌搜索框搜索图标**：`address-search` / `address-date-search` / `split` 变体内嵌搜索框中的搜索图标，尺寸为 **16×16pt**（32×32px），必须使用 iconfont 中的 **`search-line-medium`**，颜色 `text-quaternary`，字重中黑体（Medium），**不得更换图标、替换为自定义 SVG 或修改字重**。

### 9.4 input-keyword 变体详细规格
| 元素 | 2倍图尺寸 | 1倍pt尺寸 | iconfont 图标名 | 说明 |
|------|---------|---------|-------------|------|
| 已选关键词胶囊容器 | 146×58px | 73×29pt | — | 圆角 `radius-full`，padding 左右 12pt，背景 `bg-fill-tertiary` |
| 关键词文字 | — | `subtitle-m-30-regular` | — | 颜色 `text-primary` |
| 标签内清除图标 | 30×30px | 15×15pt | `cancel-line-medium` | 颜色 `text-primary` |
| 搜索图标与胶囊容器间距 | 8px | 4pt | — | `column-gap` |

> **标签内清除图标规范（强制）**：`input-keyword` 变体胶囊标签内的清除图标必须使用 iconfont 中的 **`cancel-line-medium`**，图标类型、尺寸（以组件数据为准，15×15pt）、颜色（`text-primary`）均不可修改，**不得更换图标名、替换为自定义 SVG 或调整尺寸与颜色**。

### 9.5 address-search 变体详细规格
| 元素 | 2倍图尺寸 | 1倍pt尺寸 | iconfont 图标名 | 字号/字重 | 颜色 Token |
|------|---------|---------|-------------|---------|----------|
| 左侧地址区整体 | 136×40px | 68×20pt | — | — | — |
| 定位图标 | 36×36px | 18×18pt | — | — | `text-primary` |
| 地址文字 | 56×40px | 28×20pt | — | 14pt（28px），Regular | `text-primary` |
| 展开箭头图标 | 24×24px | 12×12pt | `expand-line-semibold` | — | `text-primary` |
| 地址文字与箭头间距 | 4px | 2pt | — | — | — |
| 定位图标与文字容器间距 | 16px | 8pt | — | `column-gap` | — |
| 地址区与内嵌搜索框间距 | 24px | 12pt | — | `column-gap` | — |
| 内嵌搜索框 | 514×64px | 257×32pt | — | 圆角 `cr-6`，背景 `bg-fill-tertiary` | — |
| 内嵌框左内边距 | 16px | 8pt | — | — | — |
| 内嵌框搜索图标与占位文字间距 | 4px | 2pt | — | `column-gap` | — |

> **展开箭头图标规范（强制）**：`address-search` / `address-date-search` 变体地址文字右侧的展开箭头必须使用 iconfont 中的 **`expand-line-semibold`**，图标类型、尺寸（以组件数据为准，12×12pt）、颜色（`text-primary`）均不可修改，**不得更换图标名、替换为自定义 SVG 或调整尺寸与颜色**。

### 9.6 address-date-search 变体详细规格
与 `address-search` 地址区相同；额外新增日期信息区和分割线。

| 元素 | 2倍图尺寸 | 1倍pt尺寸 | 字号 | 字重 | 颜色 Token |
|------|---------|---------|------|------|----------|
| 日期信息区（整体） | 74×56px | 37×28pt | — | — | — |
| 单行（上/下行） | 74×28px | 37×14pt | — | — | — |
| 前缀文字（“往”/“返”/“住”/“离”） | 20×28px | 10×14pt | 10pt（20px） | Regular（400） | `text-secondary` |
| 日期数字 | 50×28px | 25×14pt | 10pt（20px） | **Medium（500）** | `color-blue` |
| 前缀与日期间距 | 4px | 2pt | — | — | — |
| 分割线 | 1×40px | 0.5×20pt | — | — | `divider-primary` |
| 内嵌搜索框（含日期时更窄） | 391×64px | 195.5×32pt | 圆角 `cr-6`，背景 `bg-fill-tertiary` | — | — |

> **行重叠规则**：上行与下行之间使用负间距 `margin-top: -2pt`（2倍图为 `-4px`），使双行总高度 = 28pt（而非 32pt）。

> **日期字重说明**：88pt 搜索框中日期数字字重为 **Medium（500）**，与 72px 搜索框（36pt）的 SemiBold（600）不同，实现时请注意区分。

> **日期数字宽度规则**：日期信息区整体及内部日期数字的宽度均**自适应内容**，不设固定宽度，由字体实际渲染宽度决定。容器通过 `flex-shrink: 0` 防止被压缩，右边缘紧贴内容，确保与右侧分割线之间的间距保持一致，不产生额外空隙。

#### Token 统一使用规则
88pt 搜索框 `address-date-search` 变体中所有日期数字元素均必须引用语义化 Token，不得直接写入色值：

| 元素 | Token | 色值参考 |
|------|-------|----------|
| 日期数字（出发/返程日期） | `color-blue` | `#004099`（默认，可随业务更换） |

> **业务色更换规则**：出发日期与返程日期的数字颜色均引用同一个 `color-blue` Token，**上下行必须使用相同颜色**，不得分别指定不同色值。若用户需要更换业务色，只需更新 `color-blue` 的指向色值，上下行同步生效。示例：
> - 更换前：出发日期 `color-blue` = `#004099`，返程日期 `color-blue` = `#004099`
> - 更换后：出发日期 `color-blue` = 新色值，返程日期 `color-blue` = 新色值（**两处必须保持一致**）

#### 日期格式转换规则
出发日期和返程日期应根据用户描述的内容，转换为组件中规定的展示格式：

| 用户描述形式 | 组件展示形式 | 示例 |
|------------|-----------|------|
| X月Y日 | `MM.DD`（月日各补零至两位） | 3月5日 → `03.05` |
| X/Y、X-Y | `MM.DD` | 3/5 → `03.05` |
| 纯数字月日 | `MM.DD` | 0305 → `03.05` |

> **格式规范**：月和日均需补零至两位，使用英文句点 `.` 分隔，不带年份，不带"月""日"等汉字后缀。例如：`03.05`、`01.09`、`12.01`。

### 9.7 double-input 变体详细规格
- **容器总高**：176px = **88pt**，padding: `12px 12px 12px 24px`（上6pt 右6pt 下6pt 左12pt）

| 元素 | 2倍图尺寸 | 1倍pt尺寸 | iconfont 图标名 | 字号/字重 | 颜色 Token |
|------|---------|---------|-------------|---------|----------|
| 左侧图标区 | 36×56px | 18×28pt | — | — | `text-primary` |
| 内嵌双框容器（整体） | 614×152px | 307×76pt | — | 圆角 `cr-6`，padding 左右 12pt，背景 `bg-fill-tertiary` | — |
| 内容区（起/终点） | 84×108px | 42×54pt | — | — | — |
| 起点行 / 终点行 | 84×40px | 42×20pt | — | — | — |
| 点图标（起/终） | 12×12px | 6×6pt | — | — | `text-primary` |
| 起/终点文字 | 56×40px | 28×20pt | — | 14pt（28px），Regular | `text-primary` |
| 点图标与文字间距 | 16px | 8pt | — | `column-gap` | — |
| 起终点行间距（row-gap） | 2px | 1pt | — | — | — |
| 连接线（起终点之间） | 12×24px | 6×12pt | — | — | `text-primary` |
| 右侧切换图标 | 36×36px | 18×18pt | `switch-line-medium` | — | `text-primary` |

> **右侧切换图标规范（强制）**：`double-input` 变体右侧的起终点切换图标必须使用 iconfont 中的 **`switch-line-medium`**，图标类型、尺寸（以组件数据为准，18×18pt）、颜色（`text-primary`）均不可修改，**不得更换图标名、替换为自定义 SVG 或调整尺寸与颜色**。

### 9.8 with-tags 变体详细规格
- **容器总高**：172px = **86pt**，`overflow: hidden`
- 上部搜索行（row-5）：710×88px = **355×44pt**，padding `0px 24px`，底部分隔线 0.5pt，`divider-secondary`

下部筛选标签栏（row-6）：710×84px = **355×42pt**

| 元素 | 2倍图尺寸 | 1倍pt尺寸 | 说明 |
|------|---------|---------|------|
| 标签栏 padding | `16px 32px 16px 16px` | 上下 8pt，右 16pt，左 8pt | — |
| 标签轨道容器（mask） | 726×52px | 363×26pt | `overflow: hidden`，遮罩可滚动区域 |
| 普通标签（tag-1～5） | 自适应×52px | 自适应×26pt | 圆角 `cr-6`（12px），**padding 左右固定 12pt**，整体宽度自适应内容，背景 `bg-fill-tertiary` |
| 标签文字 | 自适应×32px | 自适应×16pt | `font-size: 24px`（12pt），Regular，`text-primary` |
| 标签间距（column-gap） | 12px | 6pt | — |
| 尾部“更多”标签（tag-6/7） | 96×52px | 48×26pt | 背景 `white`，文字颜色 `text-secondary` |
| 右侧渐变遮罩（cover） | 36×52px | 18×26pt | `linear-gradient(270deg, white 0%, bg-fill-tertiary 33%, transparent 100%)` |

---
## 10. 组合场景（嵌入导航栏）
搜索框单独使用时为独立组件；在导航栏内时，嵌入**组合场景**容器，左固定返回按钮，右侧可配置操作区。
### 10.1 34pt 组合场景
| 属性 | 值 |
|-----|-----|
| 导航栏容器 | 375×44pt，`white` |
| 水平内边距 | `spacing-l`（12pt） |
| 左右区域间距（`column-gap`） | `spacing-l`（12pt） |
| 返回按钮热区 | 22×22pt（44×44px） |
| 搜索框与返回按钮间距 | `spacing-xs`（6pt） |
| 嵌套搜索框 style | 固定 `gray`（`bg-fill-tertiary`） |
| 嵌套搜索框内边距 | 左 `spacing-l`（12pt），右 3pt（`padding: 0px 6px 0px 24px`） |
| 嵌套搜索框搜索图标 | 16×16pt（32×32px），`search-line-medium`，`text-quaternary` |
| 嵌套搜索框占位文字 | `body-l-28-regular`（14pt），`text-quaternary` |
| 嵌套搜索框搜索按钮 | 52×28pt（104×56px），圆角 `radius-full`，背景 `gradient-yellow`，文字 `body-l-28-medium`，`text-primary` |

#### 左侧返回图标
与 **30pt 组合场景**完全一致，规则相同：必须使用 iconfont 中的 `translate-line-semibold`，图标本身父级容器需有 **10pt 顶边距**，父级容器距组件顶部 **6pt**；图标尺寸、颜色（`text-primary`）、字重均不可修改，**不得更换图标名或替换为自定义 SVG**。

> 详见 §10.2「30pt 组合场景」中返回图标的完整规范，两者共用同一套规则。

#### 搜索框 Slot
搜索框区域为 **Slot（插槽）**，必须嵌套 `size=68`、`style=gray` 的搜索框；`type` 可为 `strong` / `medium` / `weak`，默认使用 `type=strong`。嵌入 `navigation.md` 的 34pt 组合场景时，`style` 所有权归父组件，子组件不得改写为 `white` / `outlined`。嵌入时搜索框宽度由父容器自适应决定，高度固定为 34pt，其余搜索框内部规格与独立使用时完全一致。

**右侧内容变体（rightContent）：**
| rightContent | 说明 | 右侧区域尺寸 |
|-------------|------|------------|
| `none` | 无右侧操作，搜索框占满剩余空间 | — |
| `icon` | 最多 **2** 个图标，每个 22×22pt，间距 `spacing-xl`（16pt）；**锁定规格**（见下方说明） | 自适应 |
| `text` | 最多 2 个文字按钮，`body-l-28-medium`（14pt），颜色 `text-primary`，间距 `spacing-2xl`（14pt） | 自适应 |
| `icon-text` | 上图（20×20pt）下文（`caption-s-20-regular` / 10pt，`text-primary`）纵向组合；**锁定规格**（见下方说明） | 约24.5×34pt |
| `address` | 地址组件 Slot，嵌套 `navigation.md` 中的地址组件（见下方说明） | 自适应 |
| `tag` | 标签 Slot，嵌套 `tag.md` 中同尺寸标签组件（见下方说明） | 自适应 |

#### 右侧 `icon` 变体规范（强制锁定）
- 图标必须使用 iconfont 中的图标，**尺寸固定 22×22pt**，字重 **Medium**，颜色 **`text-primary`**
- 图标名、字重、颜色、尺寸**均不可修改**，不得替换为自定义 SVG
- 数量：用户可选择展示 **1 个或 2 个**图标，最多 **2 个**

#### 右侧 `icon-text` 变体规范（强制锁定）
- 图标必须使用 iconfont 中的图标，**尺寸固定 20×20pt**，字重 **Medium**，颜色 **`text-primary`**
- 图标名、字重、颜色、尺寸**均不可修改**，不得替换为自定义 SVG
- 文字：`caption-s-20-regular`（10pt），颜色 `text-primary`，用户可修改文字内容

**右侧 `icon-text` 变体详细规格（2倍图）：**
| 元素 | 2倍图尺寸 | 1倍pt尺寸 | 字号/字重 | 颜色 Token |
|------|---------|---------|---------|----------|
| 右侧整体容器（flex-column） | 49×68px | 24.5×34pt | — | — |
| 图标（锁定） | 40×40px | 20×20pt | Medium | `text-primary` |
| 文字标签 | 49×28px | 24.5×14pt | `caption-s-20-regular`（10pt） | `text-primary` |

#### 右侧 `address` 变体规范（Slot）
- 地址区域为 **Slot**，嵌套 **`navigation.md`** 中的地址组件
- 用户可指定地址组件的样式，包括：定位图标的图标名、箭头方向（展开箭头可替换为向下/向右等方向）、地址文字内容等
- 地址组件整体尺寸、与搜索框的间距（`column-gap: 12pt`）由组合容器控制，不随地址组件内部样式变化

**右侧 `address` 变体详细规格（2倍图，默认样式参考）：**
| 元素 | 2倍图尺寸 | 1倍pt尺寸 | 字号/字重 | 颜色 Token |
|------|---------|---------|---------|----------|
| 右侧区域整体 | 230×40px | 115×20pt | — | — |
| 定位图标 | 32×32px | 16×16pt | — | `text-primary` |
| 地址文字 | 约168×40px | 自适应×20pt | `body-l-28-regular`（14pt） | `text-primary` |
| 展开箭头 | 24×24px | 12×12pt | — | `text-primary`，`expand-line-semibold` |
| 定位图标与文字组间距 | `column-gap: 2px` | 1pt | — | — |
| 文字与展开箭头间距 | `column-gap: 4px` | `spacing-3xs`（2pt） | — | — |

#### 右侧 `tag` 变体规范（Slot）
- 标签区域为 **Slot**，嵌套 **`tag.md`** 中同尺寸的标签组件
- 用户可切换标签的**样式**（如颜色、图标、文字），但**不可切换尺寸**（固定使用与当前场景匹配的尺寸规格）
- 标签内部结构（图标、文字、内边距等）以 `tag.md` 组件规范为准
- **外部关闭箭头强制规范**：标签右侧的外部箭头图标**必须**使用 iconfont 中的 **`right-line-semibold`**，尺寸固定 **12×12pt**（2倍图 24×24px），颜色固定 **`text-primary`**（`#111111`），**图标名、尺寸、颜色均不可修改**，不得替换为其他图标（如 `cancel-line-medium`、自定义 SVG 等）

**右侧 `tag` 变体详细规格（2倍图，默认样式参考）：**
| 元素 | 2倍图尺寸 | 1倍pt尺寸 | 字号/字重 | 颜色 Token |
|------|---------|---------|---------|----------|
| 右侧区域整体 | 195×40px | 97.5×20pt | — | — |
| 标签容器（Slot） | 167×40px | 83.5×20pt | — | `bg-fill-danger-light`，圆角 `cr-4` |
| 标签内图标（左侧） | 28×28px | 14×14pt | — | `color-danger` |
| 标签文字 | 约111×32px | 自适应×16pt | `body-s-24-regular`（12pt） | `color-danger` |
| 标签内元素间距 | `column-gap: 4px` | `spacing-3xs`（2pt） | — | — |
| 外部关闭箭头 | 24×24px | 12×12pt | `right-line-semibold`，**锁定** | `text-primary`，**锁定** |
| 标签与外部图标间距 | `column-gap: 4px` | `spacing-3xs`（2pt） | — | — |

**布局结构：**
```
34pt 组合场景（375×44pt，水平 padding: 12pt）
├── 返回图标（22×22pt 热区，`translate-line-semibold`，`text-primary`，规则同 30pt 组合场景）
├── [column-gap: 6pt]
├── 搜索框 Slot（flex-grow: 1，固定 size=68 + style=gray；默认 type=strong）
│   ├── 左内边距 12pt + 搜索图标（16×16pt）+ 占位文字（14pt，text-quaternary）
│   └── 搜索按钮（52×28pt，gradient-yellow，右内边距 3pt）
├── [column-gap: 12pt]  ← 有右侧内容时
└── 右侧内容区（flex-shrink: 0）
    ├── rightContent=none → 无
    ├── rightContent=icon → 图标（最多2个，22×22pt，Medium，text-primary，锁定）
    ├── rightContent=text → 文字组（最多2个，body-l-28-medium，gap spacing-2xl）
    ├── rightContent=icon-text → 上图（20pt，Medium，text-primary，锁定）下文（caption-s-20-regular，24.5×34pt）
    ├── rightContent=address → 地址组件 Slot（navigation.md，用户可指定样式）
    └── rightContent=tag → 标签 Slot（tag.md，用户可切换样式，不可切换尺寸）
```
### 10.2 30pt 组合场景
| 属性 | 值 |
|-----|-----|
| 导航栏容器 | 375×44pt，`white` |
| 水平内边距 | `spacing-l`（12pt） |
| 搜索框与返回按钮间距 | `spacing-xs`（6pt） |
| 搜索框与右侧图标区间距 | `spacing-l`（12pt）；**固定值，不随图标数量变化** |
| 嵌套搜索框 style | 固定 `gray` |
| rightContent | `none` / `icon`（最多 4 个图标，图标间距 `spacing-xl`（16pt）；图标优先使用图标库，颜色 `text-primary`，字重中黑体（Medium）） |
---
## 11. Token 引用
### 11.1 颜色 Token
| 用途 | Token 名称 | 来源 |
|------|-----------|------|
| 白底背景 | `white` | `color-semantic.md` §三 Background Color |
| 灰底背景 | `bg-fill-tertiary` | `color-semantic.md` §三 Background Color |
| 清除按钮圆形背景 | `bg-fill-secondary` | `color-semantic.md` §三 Background Color |
| 危险标签背景（tag 模式） | `bg-fill-danger-light` | `color-semantic.md` §三 Background Color |
| 强按钮渐变背景 | `gradient-yellow` | `color-semantic.md` §八 Gradient Color |
| 占位文字 / 图标 | `text-quaternary` | `color-semantic.md` §二 Text Color |
| 输入内容 / 按钮文字 | `text-primary` | `color-semantic.md` §二 Text Color |
| 右侧自定义图标（附加图标 / 组合场景图标） | `text-primary`（`#111111`） | `color-semantic.md` §二 Text Color |
| 禁用态文字 | `text-disabled` | `color-semantic.md` §二 Text Color |
| 描边（黄色，34pt/30pt） | `stroke-brand` | `color-semantic.md` §四 Stroke Color |
| 描边（旅行蓝，36pt） | `stroke-blue` | `color-semantic.md` §四 Stroke Color |
| 分割线 | `divider-primary` | `color-semantic.md` §五 Divider Color |
| with-tags 搜索行底部分隔线 | `divider-secondary` | `color-semantic.md` §五 Divider Color |
| 输入光标 | `color-focus` | `color-semantic.md` §六 Functional Color |
| 旅行蓝日期数字 | `color-blue` | `color-semantic.md` §六 Functional Color |
| 危险标签文字（tag 模式） | `color-danger` | `color-semantic.md` §六 Functional Color |
| 投影（44pt） | `shadow-l` | `shadow-semantic.md` |
### 11.2 字体 Token
| 用途 | Token 名称 | 来源 |
|------|-----------|------|
| 占位文字 / 输入内容（34pt/36pt） | `body-l-28-regular` | `font-semantic.md` §一 Body |
| 占位文字 / 输入内容（30pt） | `body-s-26-regular` | `font-semantic.md` §一 Body |
| 占位文字 / 输入内容（44pt） | `subtitle-m-30-regular` | `font-semantic.md` §一 Subtitle |
| 搜索按钮文字（34pt strong） | `body-l-28-medium` | `font-semantic.md` §一 Body |
| 搜索按钮文字（30pt strong） | `body-s-24-medium` | `font-semantic.md` §一 Body |
| 地址文字（36pt，3字） | `body-s-24-semibold` | `font-semantic.md` §一 Body |
| 地址文字（36pt，4字+） | `caption-l-22-semibold` | `font-semantic.md` §一 Caption |
| 日期信息（36pt / 44pt） | `caption-l-22-medium` | `font-semantic.md` §一 Caption |
| 右侧文字按钮（组合场景） | `body-l-28-medium` | `font-semantic.md` §一 Body |
| icon-text 标签文字 | `caption-s-20-regular` | `font-semantic.md` §一 Caption |
| 利益标签文字 | `body-s-24-regular` | `font-semantic.md` §一 Body |
### 11.3 间距 Token
| 用途 | Token 名称 | 值 | 语义层来源 |
|------|-----------|-----|---------|
| 搜索图标与文字间距 | `spacing-3xs` | 2pt | `spacing-semantic.md` |
| 清除按钮与搜索按钮间距 | `spacing-m` | 12pt | `spacing-semantic.md` |
| medium 类型右侧间距 | `spacing-2xl` | 14pt | `spacing-semantic.md` |
| 附加图标间距（68pt） | `spacing-m` | 12pt | `spacing-semantic.md` |
| 附加图标间距（60pt） | `cs-10` | 10pt | `component-spacing.md` |
| 30pt strong/weak 附加图标 / 清除按钮 距搜索按钮间距 | `cs-10` | 10pt | `component-spacing.md` |
| 组合场景水平内边距 | `spacing-l` | 12pt | `spacing-semantic.md` |
| 返回与搜索框间距 | `spacing-xs` | 6pt | `spacing-semantic.md` |
| 右侧图标间距 | `spacing-xl` | 16pt | `spacing-semantic.md` |

### 11.4 圆角 Token
| 用途 | Token 名称 | 语义层来源 |
|------|-----------|---------|
| 搜索框容器（30/34/36pt，胶囊） | `radius-full` | `component-radius.md` |
| 搜索框容器（44pt，方正） | `cr-12` | `component-radius.md` |
| split 返回按钮容器 | `cr-12` | `component-radius.md` |
| strong 搜索按钮（胶囊） | `radius-full` | `component-radius.md` |
| 输入光标 | `radius-full` | `component-radius.md` |
| 内嵌搜索框（address-search / double-input） | `cr-6` | `component-radius.md` |
| 44pt 容器圆角（radius-m，整体容器） | `radius-m` | `radius-semantic.md` |
---
## 12. data-attribute 规范
| 属性 | 值 | 说明 |
|------|-----|------|
| `data-slot` | `"search-bar"` | 全局稳定标识，供父容器 CSS 定向选中 |
| `data-size` | `"60"` / `"68"` / `"72"` / `"88"` | 当前高度规格 |
| `data-type` | `"strong"` / `"medium"` / `"weak"` | 搜索框类型（仅 60/68 适用） |
| `data-style` | `"white"` / `"gray"` / `"outlined"` | 背景样式 |
| `data-state` | `"default"` / `"active"` | 当前输入状态 |
| `data-has-addon` | `"true"` / `"false"` | 是否有附加图标 |
| `data-layout` | `"input-only"` / `"input-keyword"` / `"address-search"` / `"address-date-search"` / `"double-input"` / `"with-tags"` / `"split"` | 44pt 布局变体 |
---
## 13. 无障碍（a11y）
- 搜索框整体使用 `role="search"` 或 `<search>` 语义化标签包裹
- 内部输入区使用 `<input type="search">` + `aria-label="搜索"`
- 清除按钮使用 `<button>` + `aria-label="清除搜索内容"`，不可用 `<div>` 模拟
- 搜索按钮使用 `<button>` + `aria-label="搜索"` 或 `type="submit"`
- 附加图标按钮必须有 `aria-label` 描述操作内容；图标加 `aria-hidden="true"`
- 禁用态使用 `aria-disabled="true"`，不使用 HTML `disabled`（保留 focus 能力）
- `active` 状态下输入框应自动获取焦点（`autoFocus` 或 `.focus()` 触发）
---
## 14. 使用场景速查

> ⚠️ **style 独立 vs 嵌入区别**：下表「关键配置」中的 `style` 均为**搜索框独立使用**时的推荐值；嵌入 `navigation.md` 34pt 组合场景时，`style` 所有权归父组件，**固定为 `gray`，不得自行调整**（见 §15 约束第 3 条及 `navigation.md §7`）。

| 场景 | 推荐规格 | 关键配置 |
|------|---------|---------|
| 首页 / 通用搜索页（独立） | `size=68` | `type="strong"`，`style="white"`（独立使用时可选） |
| 导航栏内嵌搜索（首页） | 34pt 组合场景 | `style` 由 navigation.md 锁定为 `gray`，不可改写 |
| 商家页头部搜索 | 30pt 组合场景 | `rightContent="none"`，最简 |
| 圆底导航内嵌 | `size=60` | `type="strong"`，`style="gray"` |
| 酒店 / 旅行日期搜索 | `size=72` | `style="outlined"`（旅行蓝描边） |
| 地图业务顶部 | `size=88` | `layout="input-only"` 或 `"split"` |
| 打车 / 导航起终点 | `size=88` | `layout="double-input"` |
| 搜索结果页带筛选 | `size=88` | `layout="with-tags"` |
| 搜索框 + 利益点 | 34pt 组合场景 | `rightContent="tag"`，`style` 由父组件锁定 |
| 搜索框 + 当前地址 | 34pt 组合场景 | `rightContent="address"`，`style` 由父组件锁定 |
---
## 15. 使用约束
1. **规格不可自定义**：高度固定为 30 / 34 / 36 / 44pt，不可调整
2. **禁止直接写颜色值**：所有颜色必须引用 §11.1 中的语义层 Token
3. **嵌入组合场景时**：`style` 固定为 `gray`，不可覆盖为其他样式
4. **描边颜色区分**：34pt/30pt 描边用黄色（`stroke-brand`）；36pt 描边用旅行蓝（`stroke-blue`），不可混用
5. **44pt 无 type 区分**：`type` 仅适用于 30pt/34pt，44pt 使用 `layout` 区分变体
6. **组合场景不独立存在**：34pt / 30pt 组合场景必须依托导航栏（44pt 高容器），不可脱离使用
7. **清除按钮出现条件**：仅在 `active=true` 时显示，`strong`、`medium`、`weak` 三种 type 均适用
8. **不加投影**：30 / 34 / 36pt 不使用任何 shadow Token；44pt 固定使用 `shadow-l`
9. **搜索图标来源**：`size=60 / 68 / 72 / 88` 搜索图标必须使用 iconfont 中的 **`search-line-medium`**，字重中黑体（Medium），颜色 `text-quaternary`，尺寸以各自组件数据为准（60：15×15pt；68/72/88：16×16pt），**不得更换图标、替换为自定义 SVG 或修改字重**
10. **搜索图标尺寸**：搜索图标尺寸须比右侧搜索词文字大 **2pt**（例如文字 14pt → 图标 16×16pt），不可与文字等大或更小
11. **右侧自定义图标规范**：搜索框右侧出现的所有可自定义图标（附加图标 `hasAddon`、组合场景 `rightContent="icon"` / `"icon-text"` / `"address"` 中的图标）须遵循：优先使用**基础图标库**中的图标；颜色统一使用 `text-primary`（`#111111`）；字重必须为**中黑体（Medium）**；图标尺寸遵循各规格组件定义，不可自定义
---
## 16. 与其他组件的关系
| 关联组件 | 关系说明 |
|---------|---------|
| `navigation.md` | 34pt / 30pt 组合场景在导航栏内使用，搜索框宽度由导航栏右侧内容决定 |
| `button.md` | `strong` 类型的渐变搜索按钮使用 `gradient-yellow`，与 Button `primary` variant 规范一致 |
| `input.md` / `search-field.md` | Search Bar 为组合封装，不直接等价于 input；`search-field.md` 为独立搜索字段组件 |
| `tag.md` | 组合场景 `rightContent="tag"` 利益标签样式参见 `tag.md` |
| `filter-panel.md` | `size=88`（44pt）的 `with-tags` 布局下部筛选标签栏可与 filter-panel 配合使用 |
