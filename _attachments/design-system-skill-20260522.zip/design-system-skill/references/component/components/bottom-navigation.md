# Bottom Navigation 底部导航栏 
> **组件分类**：Component（组件级）
> **定义**：底部导航栏承载产品提供的核心服务，是产品的**一级信息架构**，常用于频道首页。统一使用 **44pt 高度**，部分大促场景局部组件高度可略高于导航栏高度。
> **Style 依赖**：`color-semantic.md` · `font-semantic.md` · `spacing-semantic.md` · `component-spacing.md` · `radius-semantic.md` · `component-radius.md` · `stroke-semantic.md`
---
## 0. 图标 / 间距 / Ownership 约束

- **icon-route（Bottom Navigation 自持）**：Tab 图标与标签堆叠、promo 溢出形态、首 Tab 特例均由 Bottom Navigation 统一裁决。
- **fixed-asset 例外**：正文若指定官方 SVG、`assets/*.svg` 或 PNG/CDN 图标，该位点必须走 fixed-asset，不得强制回 iconfont。
- **spacing-owner（归属）**：底部导航内部图标-标签垂直关系、Tab 间距与对齐归 Bottom Navigation。
- **宿主裁决（优先级）**：叠加 `badge` 时，badge 内部样式归 `badge.md`，挂点位置与偏移归 Bottom Navigation；与底部安全区 / Home Indicator 关系由 `system.md` 裁决。
- **不可跳步**：先回 `references/INDEX.md` 完成区域路由与宿主锁定，再用 `component-quickref.md` 做宿主级收敛；本文件仅承接组件内 ownership 细则，不承担前置路由改判；不得凭语义猜测。


## 1. 组件类型（variant）
| variant | 名称 | 说明 | 变体数 |
|---------|------|------|--------|
| `default` | 通用型 | 常规场景底部导航，含 4 种首Tab状态 × 4 种选项数 | 16 |
| `promo-weak` | 大促型 弱样式 | 大促活动场景，首Tab区域米黄色轻高亮 | 4 |
| `promo-strong` | 大促型 强样式 | 大促活动场景，首Tab上凸溢出区域 | 4 |
---
## 2. 首Tab状态（activeType）
适用于所有 variant，但 `promo-weak` 和 `promo-strong` 仅支持其中 2 种状态（见下方注意）。
| activeType | 名称 | 视觉特征 | 触发条件 |
|------------|------|---------|---------|
| `default` | 默认态 | 38×38pt 黄色渐变圆形胶囊 + 品牌文字 | 用户位于首Tab页面 |
| `recommend` | 推荐态 | 38×38pt 黄色渐变胶囊 + 向下箭头图标 + "推荐"文字 | 上滑首页触发，有新推荐内容 |
| `toTop` | 回顶部 | 38×38pt 黄色渐变胶囊 + 回顶部图标（22×22pt，中粗体） | 推荐 Feed 流置顶后继续上滑 |
| `unselectedFirst` | 未选中首Tab | 首Tab显示品牌 Logo/图形 + 频道名称（无胶囊） | 用户切换到非首Tab |
> **注意**：`promo-weak` 和 `promo-strong` 仅支持 `default` 和 `unselectedFirst` 两种状态。
---
## 3. 选项数量（tabCount）
| tabCount | 每Tab宽度（375pt基准） | 说明 |
|----------|--------------------|------|
| `5` | 75pt | 最常用，美团主要产品标准 |
| `4` | ≈94pt | 轻量产品 |
| `3` | 125pt | 简洁产品 |
| `2` | 187.5pt | 极简产品（较少使用） |
> `promo-weak` 和 `promo-strong` 仅支持 `tabCount=3` 和 `tabCount=5`。
---
## 4. 尺寸规格

> **设计稿基准**：@2x（750px 宽）；实现时所有数值 ÷2 换算为 @1x pt 使用。

| 区域 | @1x（pt） | @2x（px） | 说明 |
|------|----------|----------|------|
| 导航栏高度 | **44pt** | 88px | 统一规范值，不含 Home Indicator |
| 导航栏基准宽度 | **375pt** | 750px | 实际等分适配各屏幕宽度 |
| 首Tab选中胶囊 | **38×38pt** | 76×76px | 圆角 `radius-full`（≈20pt），`gradient-yellow` |
| 首Tab选中品牌文字（special-title） | **14pt** | 28px | 美团体，`font-weight: 400`，`color: text-primary`（`#111111`） |
| 首Tab选中 padding-top | **6pt** | 12px | 胶囊距容器顶部 |
| 图标占位热区（未选中） | **24×24pt** | 48×48px | 未选中态 Tab 图标容器尺寸；规范总高 8+24+5+11=48pt > 44pt，底部约 4pt 超出，实现时 Tab 容器加 `overflow:hidden` 裁切，不得缩小图标尺寸 |
| 未选中Tab padding-top | **8pt** | 16px | 图标距容器顶部 |
| 图标与标签间距 | **0pt** | 0px | 图标与标签紧贴，无间距；CSS 实现使用 `.tab-label { margin-top: 0 }`（禁止用 `flex gap`，flex 空间不足时 gap 会被压缩为 0） |
| 顶部分割线 | **0.5pt** | 1px | 颜色 `divider-primary`（`rgba(0,0,0,0.06)`，透明6%黑） |
| 大促弱样式 Area 占位 | **38×38pt** | 76×76px | 圆角 `radius-full`，`yellow-bg`，无文字标签；padding-top 与首Tab选中一致 |
| 大促弱样式 Area padding-top | **6pt** | 12px | Area 占位距容器顶部（同通用型首Tab选中态） |
| 大促强样式上凸圆 | **55×55pt** | 110×110px | 圆角 `radius-full`，bg: `yellow-bg`，溢出导航栏顶部 11pt |
| 大促强样式内胶囊 | **38×38pt** | 76×76px | 圆角 `radius-full`，`gradient-yellow`；padding top/bottom 9pt（`cs-9`），left/right 5pt（`cs-5`） |
| 大促强样式 Pen 遮挡层 | Tab宽×**13pt** | Tab宽×26px | absolute，top=-13pt；bg: `white`，使用 `cs-13` |
| 大促强样式顶部装饰线 | **375pt**×**13.5pt** | 750px×27px | absolute，top=-13.5pt，全宽；使用 `cs-13.5` |
| 5Tab 每Tab宽度 | **75pt** | 150px | `flex-grow:1` 等分，基准宽度参考值 |
| 4Tab 每Tab宽度 | **≈94pt** | 187.5px | `flex-grow:1` 等分 |
| 3Tab 每Tab宽度 | **125pt** | 250px | `flex-grow:1` 等分 |
| 2Tab 每Tab宽度 | **187.5pt** | 375px | `flex-grow:1` 等分 |
---
## 5. 各类型详解
### 5.1 通用型（variant=default）
#### 默认态（activeType=default）
```
SEC 1（首Tab，选中）padding-top: `spacing-xs`（6pt）
└── 选中胶囊（38×38pt，radius-full，gradient-yellow）
    └── 品牌文字（special-title，text-primary）
SEC 2~5（未选中Tab）padding-top: `spacing-s`（8pt），图标与标签 row-gap: 0pt（紧贴）
├── 图标占位（24×24pt，text-primary）
└── 标签文字（caption-l-11-regular，text-secondary）
```
#### 推荐态（activeType=recommend）
```
SEC 1（首Tab，推荐态）
└── 选中胶囊（38×38pt，radius-full，gradient-yellow，
      flex-direction: column，align-items: center，justify-content: center，
      padding: cs-3(6pt top) cs-9(18pt right) cs-5(10pt bottom) cs-9(18pt left)）
    ├── 向下箭头图标（18×18pt → 36×36px @2x，icon-iconfont-expand-line-semibold）
    └── 文字"推荐"（caption-l-11-medium → 10pt → 20px @2x，text-primary，
          margin-top: -4pt（-8px @2x，子元素间距收紧））
```
> ⚠️ 推荐态为**上下排布**（column），图标在上，文字在下，子元素间距用 `margin-top: -8px` 收紧；与默认态胶囊（仅品牌文字）区别在于方向和内容。
#### 回顶部（activeType=toTop）
```
SEC 1（首Tab，回顶部）
└── 选中胶囊（38×38pt，radius-full，gradient-yellow，padding: `cs-9` `spacing-s` `cs-7` `spacing-s`）
    └── 回顶部图标（22×22pt，中粗体 medium）
```
#### 未选中首Tab（activeType=unselectedFirst）
```
SEC 1（首Tab，未选中）padding-top: `spacing-s`（8pt）
├── 品牌 Logo / 表意图标（24×24pt，text-primary）
└── 频道名称（caption-l-11-regular，text-secondary）
    ⚠️ 除独立 App 和小程序外，不可展示为"首页"
当前选中Tab（非首Tab）：
├── 图标（24×24pt，含选中圆点标记）
└── 标签（caption-l-11-medium，text-primary）
```
### 5.2 大促型 弱样式（variant=promo-weak）

常用于**频道首页营销活动入口**，在不影响一级导航整体观感的前提下，通过首Tab区域的米黄色占位给予轻量的活动提示。仅支持 `activeType="default"` 和 `activeType="unselectedFirst"` 两种状态。

#### 默认态（activeType=default，用户位于首Tab）

首Tab选中时样式与通用型完全一致，显示黄色渐变胶囊 + 品牌文字；其他 Tab（非首Tab）在弱样式中**额外**有一个米黄色 Area 占位替代通常的图标+标签，以此在导航栏中突出营销入口位置。

```
SEC 1（首Tab，选中）padding-top: `spacing-xs`（6pt）
└── 选中胶囊（38×38pt，radius-full，gradient-yellow）
    └── 品牌文字（special-title，text-primary）
SEC N（营销活动入口Tab）padding-top: `spacing-xs`（6pt）
└── Area 占位（38×38pt，radius-full，bg: yellow-bg）
    ⚠️ 无文字标签，仅米黄色圆形色块；视觉权重低于通用型黄色渐变胶囊
其余 SEC（普通未选中Tab）padding-top: `spacing-s`（8pt），row-gap: 5pt
├── 图标占位（24×24pt，text-primary）
└── 标签文字（caption-l-11-regular，text-secondary）
```

#### 未选中首Tab（activeType=unselectedFirst，用户切换到非首Tab）

首Tab变为未选中状态（无胶囊），营销活动入口 Tab 的 Area 占位保持不变，始终可见。

```
SEC 1（首Tab，未选中）padding-top: `spacing-s`（8pt），row-gap: 5pt
├── 品牌 Logo / 表意图标（24×24pt，text-primary）
└── 频道名称（caption-l-11-regular，text-secondary）
    ⚠️ 除独立 App 和小程序外，不可展示为"首页"
SEC N（营销活动入口Tab，当前选中）
└── Area 占位（38×38pt，radius-full，bg: yellow-bg）
    ⚠️ 无文字标签；Area 始终存在，不随首Tab是否选中而消失
其余 SEC（普通 Tab，含选中态）
├── 图标（24×24pt，text-primary）
└── 标签（选中: caption-l-11-medium text-primary；未选中: caption-l-11-regular text-secondary）
```

> **弱样式核心特征**：Area 占位圆形（`yellow-bg`）全程常驻，不受用户所在 Tab 影响；与通用型区别在于**没有品牌文字**，只有色块，视觉提示力弱于强样式的上凸圆形。
### 5.3 大促型 强样式（variant=promo-strong）

常用于**频道首页重要营销活动入口**，通过首Tab圆形区域溢出导航栏顶部的方式形成强视觉聚焦，适合需要突出活动入口的场景。仅支持 `activeType="default"` 和 `activeType="unselectedFirst"` 两种状态。

#### 默认态（activeType=default，用户位于首Tab）

首Tab呈上凸圆形（yellow-bg），内容为黄色渐变胶囊 + 品牌文字；圆形绝对定位，bottom: 0，溢出导航栏顶部 11pt；顶部有 Pen 遮挡层消除锯齿感。

```
底部导航栏（375×44pt，white）
├── 顶部分割线（divider-primary，stroke-thin 0.5pt）
├── SEC 1（首Tab，上凸）
│   ├── [abs] 上凸圆形（55×55pt，radius-full，bg: yellow-bg，
│   │         position: bottom=0，溢出顶部 11pt）
│   │   ├── 黄色渐变胶囊（38×38pt，radius-full，gradient-yellow，
│   │   │     padding: top/bottom `cs-9`=9pt, left/right `cs-5`=5pt）
│   │   │   └── 品牌文字（special-title，text-primary）
│   │   └── [abs] Pen 遮挡层（Tab宽×13pt，top=-13pt，bg: white）
│   │         ⚠️ 使用 `cs-13` 遮挡上凸圆形与导航栏衔接处的锯齿
│   └── [全宽 abs] 顶部装饰线（375pt×13.5pt，top=-13.5pt）
│         ⚠️ 使用 `cs-13.5` 确保上凸区域与导航栏背景颜色平滑衔接
└── SEC 2~N（未选中Tab）padding-top: `spacing-s`（8pt），row-gap: 5pt
    ├── 图标占位（24×24pt，text-primary）
    └── 标签文字（caption-l-11-regular，text-secondary）
```

#### 未选中首Tab（activeType=unselectedFirst，用户切换到非首Tab）

首Tab变为未选中态（品牌Logo + 频道名称），**上凸圆形区域仍然常驻**，保持 Area 占位（yellow-bg）以维持营销入口的视觉权重；当前选中的非首Tab正常显示。

```
SEC 1（首Tab，未选中）
├── [abs] 上凸圆形（55×55pt，radius-full，bg: yellow-bg，
│         position: bottom=0，溢出顶部 11pt）
│   ├── 品牌 Logo / 表意图标（24×24pt）
│   └── [abs] Pen 遮挡层（Tab宽×13pt，top=-13pt，bg: white）
└── [全宽 abs] 顶部装饰线（375pt×13.5pt，top=-13.5pt）
    ⚠️ 首Tab文字标签不显示（上凸圆形区域无标签空间）
    ⚠️ 除独立 App 和小程序外，不可展示"首页"
SEC N（当前选中Tab，非首Tab）
├── 图标（24×24pt，含选中圆点标记）
└── 标签（caption-l-11-medium，text-primary）
其余 SEC（未选中普通Tab）padding-top: `spacing-s`（8pt），row-gap: 5pt
├── 图标（24×24pt，text-primary）
└── 标签（caption-l-11-regular，text-secondary）
```

> **强样式核心特征**：上凸圆形（55×55pt，`yellow-bg`）始终溢出导航栏顶部 11pt；内含黄色渐变胶囊（首Tab选中时）或纯色块（未选中时）；必须配合页面预留上凸安全区（≥11pt）使用。
---
## 6. 布局结构

### 6.1 通用型 5Tab 默认态
```
底部导航栏（375×44pt，white）
├── 顶部分割线（375×0.5pt，divider-primary）
├── SEC 1（75×44pt）← 首Tab 选中，padding-top: spacing-xs（6pt）
│   └── 选中胶囊（38×38pt，radius-full，gradient-yellow）
│       └── 品牌文字（special-title，text-primary）
├── SEC 2（75×44pt）← 未选中（padding-top: spacing-s 8pt，row-gap: cs-5 5pt）
│   ├── 图标占位（24×24pt，text-primary）
│   └── 标签文字（caption-l-11-regular，text-secondary）
├── SEC 3 ← 未选中（同 SEC 2）
├── SEC 4 ← 未选中（同 SEC 2）
└── SEC 5 ← 未选中（同 SEC 2）
```

### 6.2 大促型强样式 5Tab 默认态（promo-strong，activeType=default）
```
底部导航栏（375×44pt，white）
├── [全宽 abs] 顶部装饰线（375pt×13.5pt，top=-13.5pt，white）
├── 顶部分割线（375×0.5pt，divider-primary）
├── SEC 1（75×44pt）← 首Tab，上凸溢出，overflow: visible
│   ├── [abs] 上凸圆形（55×55pt，radius-full，yellow-bg，bottom=0）
│   │   ├── 黄色渐变胶囊（38×38pt，radius-full，gradient-yellow）
│   │   │   └── 品牌文字（special-title，text-primary）
│   │   └── [abs] Pen 遮挡层（75pt×13pt，top=-13pt，white）
│   └── ⚠️ 无文字标签（圆形区域无标签空间）
├── SEC 2（75×44pt）← 未选中（padding-top: spacing-s 8pt，row-gap: cs-5 5pt）
│   ├── 图标（24×24pt，text-primary）
│   └── 标签（caption-l-11-regular，text-secondary）
├── SEC 3 ← 未选中（同 SEC 2）
├── SEC 4 ← 未选中（同 SEC 2）
└── SEC 5 ← 未选中（同 SEC 2）
```
---
## 7. Props API
```typescript
export type BottomNavigationProps = {
  /**
   * 视觉类型
   * @default "default"
   */
  variant?: "default" | "promo-weak" | "promo-strong";
  /**
   * Tab 选项总数
   * @default 5
   */
  tabCount?: 2 | 3 | 4 | 5;
  /**
   * 首Tab激活状态类型
   * @default "default"
   */
  activeType?: "default" | "recommend" | "toTop" | "unselectedFirst";
  /**
   * 当前选中 Tab 的索引（0 为首Tab）
   * @default 0
   */
  activeIndex?: number;
  /**
   * Tab 项配置数组
   */
  tabs: Array<{
    icon: React.ReactNode;
    label: string;
  }>;
  /**
   * 是否包含 Home Indicator（iPhoneX 及以上）
   * @default true
   */
  showHomeIndicator?: boolean;
  /**
   * 回顶部点击回调（activeType=toTop 时有效）
   */
  onToTopPress?: () => void;
};
```
---
## 8. data-attribute 规范
| 属性 | 值 | 说明 |
|------|----|------|
| `data-slot` | `"bottom-navigation"` | 全局稳定标识 |
| `data-variant` | `"default"` / `"promo-weak"` / `"promo-strong"` | 视觉类型 |
| `data-active-type` | `"default"` / `"recommend"` / `"toTop"` / `"unselectedFirst"` | 首Tab状态 |
| `data-tab-count` | `"2"` / `"3"` / `"4"` / `"5"` | Tab 总数 |
---
## 9. Token 引用
### 9.1 颜色 Token
| 用途 | Token 名称 | 语义层来源 |
|------|-----------|-----------|
| 导航栏背景 | `white` | `color-semantic.md` §三 Background Color |
| 顶部分割线颜色 | `divider-primary` | `color-semantic.md` §五 Divider Color |
| 顶部分割线粗细 | `stroke-thin`（0.5pt） | `stroke-semantic.md` |
| 首Tab选中胶囊背景渐变 | `gradient-yellow` | `color-semantic.md` §八 Gradient Color |
| 首Tab选中胶囊/文字 | `text-primary` | `color-semantic.md` §二 Text Color |
| 图标颜色（选中/未选中均适用） | `text-primary` | `color-semantic.md` §二 Text Color |
| 未选中Tab标签文字 | `text-secondary` | `color-semantic.md` §二 Text Color |
| 选中Tab标签文字（非首Tab选中） | `text-primary` | `color-semantic.md` §二 Text Color |
| 大促弱/强样式首Tab占位区域背景 | `yellow-bg` | `color-semantic.md` §七 Functional Color |
| 大促强样式 Pen 遮挡层 | `white` | `color-semantic.md` §三 Background Color |
| 大促强样式顶部装饰线 | `white` | `color-semantic.md` §三 Background Color |
### 9.2 圆角 Token
| 用途 | Token 名称 | 语义层来源 |
|------|-----------|-----------|
| 首Tab选中胶囊（圆形） | `radius-full` | `component-radius.md` |
| 大促弱样式 Area 占位（圆形） | `radius-full` | `component-radius.md` |
| 大促强样式上凸圆形区域 | `radius-full` | `component-radius.md` |

### 9.3 间距 Token

| 用途 | Token 名称 | 值 | 语义层来源 |
|------|-----------|-----|----------|
| 首Tab选中默认态 padding-top | `spacing-xs` | 6pt | `spacing-semantic.md` |
| 大促弱样式 Area 占位 padding-top | `spacing-xs` | 6pt | `spacing-semantic.md`（与首Tab选中态一致） |
| 未选中Tab padding-top | `spacing-s` | 8pt | `spacing-semantic.md` |
| 未选中Tab 图标与标签间距 | — | 0pt | 图标与标签紧贴，无间距；CSS 实现 `.tab-label { margin-top: 0 }` |
| 推荐态胶囊 padding: top | `cs-3` | 3pt | `component-spacing.md` |
| 推荐态胶囊 padding: right/left | `cs-9` | 9pt | `component-spacing.md` |
| 推荐态胶囊 padding: bottom | `cs-5` | 5pt | `component-spacing.md` |
| 回顶部态胶囊 padding: top | `cs-9` | 9pt | `component-spacing.md` |
| 回顶部态胶囊 padding: right/left | `spacing-s` | 8pt | `spacing-semantic.md` |
| 回顶部态胶囊 padding: bottom | `cs-7` | 7pt | `component-spacing.md` |
| 大促强样式内胶囊 padding: top/bottom | `cs-9` | 9pt | `component-spacing.md` |
| 大促强样式内胶囊 padding: left/right | `cs-5` | 5pt | `component-spacing.md` |
| 大促强样式 Pen 遮挡层高度 | `cs-13` | 13pt | `component-spacing.md` |
| 大促强样式顶部装饰线高度 | `cs-13.5` | 13.5pt | `component-spacing.md` |

### 9.4 字体 Token
| 用途 | Token 名称 | 值 | 语义层来源 |
|------|-----------|-----|----------|
| 未选中Tab标签文字 | `caption-l-11-regular` | **font-size: 20px；line-height: 28px**（规范11pt/16pt，实现按Figma标注取20px/28px） | `font-semantic.md` §一 Caption，`font-reference.md` §一 Text Font |
| 推荐态"推荐"文字 | `caption-l-11-medium` | 同上，20px / 行高28px（Figma标注） | `font-semantic.md` §一 Caption |
| 选中Tab标签文字（非首Tab） | `caption-l-11-medium` | 同上，20px | `font-semantic.md` §一 Caption |
| 首Tab选中品牌业务文字 | `special-title` | **14pt → 28px @2x**，`font-weight: 400` | `font-semantic.md` §四 Special Font（美团体，`/Library/Fonts/meituantype-Regular.TTF`） |

> ⚠️ `special-title` 的 CSS `font-family` 必须单独在品牌文字元素上声明，将 `'美团体'` 置于链首，系统有即自动调用，无需手动判断：
> ```css
> .brand-text {
>   font-family: '美团体', 'PingFang SC', 'Noto Sans SC', sans-serif;
> }
> ```
> ❌ 禁止在 `body` 全局声明 `'美团体'`，避免非品牌文字意外使用美团体字形。
---
## 10. 屏幕适配规范
```
纵向高度适配：
  ├── iPhoneX 及以上（刘海屏）：导航栏直接与 Home Indicator 组件相连，间距 0
  └── iPhoneSE 及其他非刘海屏 / Android：底部增加 8pt 间距
横向宽度适配：
  └── 每个 Tab 的宽度根据屏幕宽度做等分适配（flex: 1 均分）
```
---
## 11. 无障碍（Accessibility）
- 导航栏容器使用 `<nav>` 标签，`aria-label="底部导航"`
- 每个 Tab 项使用 `role="tab"`，选中项 `aria-selected="true"`
- 图标添加 `aria-hidden="true"`，标签文字提供语义
- 回顶部态按钮：`aria-label="回到顶部"`
---
## 12. 使用约束（AI 生成时的硬性规则）
1. **禁止直接写 hex 颜色**：颜色必须使用 §9.1 中的 Token 名称
2. **导航栏高度固定**：不可自定义高度，始终为 44pt（不含 Home Indicator）
3. **大促型 tabCount 限制**：`promo-weak` 和 `promo-strong` 仅支持 `tabCount=3` 或 `tabCount=5`
4. **品牌文字字体**：首Tab胶囊内必须使用 `special-title` Token，对应 CSS 须单独在品牌文字元素上声明 `font-family: '美团体', 'PingFang SC', 'Noto Sans SC', sans-serif`，`'美团体'` 置于链首（系统已安装即自动生效，未安装自动降级 PingFang SC）；❌ 不得在 `body` 全局声明 `'美团体'`，❌ 不得直接裸写 `meituan type` 字体名
5. **频道名称限制**：未选中首Tab文字须使用频道名称，除独立 App 和小程序外不能展示"首页"
6. **上凸区域超出规范**：大促强样式上凸圆（55×55pt）溢出导航栏顶部 11pt，需确保上层页面留出安全区（≥11pt）；必须配合 Pen 遮挡层（Tab宽×13pt，top=-13pt，white）和全宽顶部装饰线（750pt×13.5pt，top=-13.5pt，white）消除锯齿
7. **大促型 activeType 限制**：`promo-weak` 和 `promo-strong` 仅支持 `activeType="default"` 和 `activeType="unselectedFirst"`；`recommend` 和 `toTop` 仅适用于 `variant="default"`
8. **禁止裸写字体名称**：字体必须使用 §9.4 中的 Token 名称，不得直接写 `meituan type`、`苹方` 等原始字体名称
9. **同一组普通 Tab 图标家族必须一致**：除首 Tab 特殊品牌/推荐/回顶部态外，其余普通 Tab 必须来自同一视觉家族。默认整组使用 `*-line-medium`；若业务确实要求选中态与未选中态使用成对图标，则必须在声明与 HTML 中一一对应写出 `selectedIcon` / `unselectedIcon` 配对，且所有普通 Tab 统一遵循同一切换策略。❌ 禁止同一底部导航里出现部分 Tab 为 `line`、部分 Tab 为 `fill` 的线面混搭（如 `分类=line`、`订单=line`、`我的=fill`）。
10. **图标与标签间距必须用 `margin-top` 而非 `flex gap`**：flex 容器高度固定 88px，flex 在空间不足时会将 `gap` 压缩为 0。即便当前间距为 0，也应统一使用 `margin-top: 0` 写法，保持代码语义清晰且未来修改更安全：
   ```css
   /* ✅ 正确：使用 margin-top 控制间距，当前值为 0（图标与标签紧贴） */
   .tab-item.normal {
     padding-top: 16px;    /* spacing-s(8pt)×2 */
     overflow: hidden;     /* 裁切底部超出，不让 flex 压缩内容 */
   }
   .tab-icon {
     display: inline-block;
     height: 48px;         /* 24pt × 2 = 48px */
     line-height: 48px;
     font-size: 48px !important;
     flex-shrink: 0;
   }
   .tab-icon::before { line-height: 48px; display: block; }
   .tab-label {
     font-size: 20px;      /* caption-l-11-size */
     line-height: 28px;    /* caption-l-11-line-height（Figma标注） */
     margin-top: 0;        /* 图标与标签紧贴，无间距 */
     flex-shrink: 0;
   }
   /* ❌ 错误：.tab-item.normal { gap: 10px; } — gap 在空间不足时会被压缩为 0 */
   ```
---
## 13. 交互动效规范（HTML 原型实现）

### 13.1 点击反馈（Press State）

> 🚫 **禁止点击缩放动效**。底部导航属于高频按钮区，按压反馈只能使用遮罩或透明度，❌ 不得出现 `transform: scale(...)`、位移动效或回弹超调。

| 阶段 | 效果 | 时长 |
|------|------|------|
| 按下（mousedown / touchstart） | 叠加白色半透明遮罩或整体 `opacity: 0.72` | `80ms ease-out` |
| 松开（mouseup / touchend） | 遮罩淡出 / `opacity` 回到 `1` | `120ms ease-out` |
| 归位 | 保持原尺寸、原位置 | `80ms ease-out` |

```css
.tab-item {
  position: relative;
  cursor: pointer;
  -webkit-tap-highlight-color: transparent; /* 消除移动端默认蓝色高亮 */
  user-select: none;
}
.tab-item::after {
  content: "";
  position: absolute;
  inset: 0;
  background: rgba(255, 255, 255, 0.2);
  opacity: 0;
  transition: opacity 80ms ease-out;
  pointer-events: none;
  border-radius: inherit;
}
.tab-item:active::after {
  opacity: 1;
}
```

### 13.2 选中态切换动效

非首 Tab 切换时，图标与标签做颜色渐变过渡，避免状态跳变感：

```css
.tab-item .tab-icon,
.tab-item .tab-label {
  transition: color 200ms ease, opacity 200ms ease;
}
```

首 Tab 胶囊（`gradient-yellow` 圆形）出现/消失时仅允许做 `opacity` 渐变，禁止缩放：

```css
.tab-capsule {
  transition: opacity 200ms ease;
}
/* 首Tab未选中时胶囊隐藏 */
.tab-capsule.hidden {
  opacity: 0;
}
/* 首Tab选中时胶囊显示 */
.tab-capsule.visible {
  opacity: 1;
}
```

### 13.3 JS 切换逻辑（HTML 原型完整实现）

```js
const tabs = document.querySelectorAll('.tab-item');

tabs.forEach((tab, index) => {
  tab.addEventListener('click', () => {
    // 移除所有选中态
    tabs.forEach(t => {
      t.classList.remove('active');
      t.querySelector('.tab-capsule')?.classList.replace('visible', 'hidden');
      t.setAttribute('aria-selected', 'false');
    });
    // 激活当前 Tab
    tab.classList.add('active');
    tab.querySelector('.tab-capsule')?.classList.replace('hidden', 'visible');
    tab.setAttribute('aria-selected', 'true');
  });
});
```

### 13.4 约束与禁止项

- ❌ 禁止用 `background-color` 高亮整个 Tab 区域作为点击反馈（与规范背景 `white` 冲突）
- ❌ 禁止使用 `outline` 或 `box-shadow` 作为焦点/按压态样式
- ❌ 首 Tab 胶囊动效时长不得超过 320ms，超出会感觉迟钝
- ❌ 禁止任何 `transform` / `scale` / 位移动效；点击反馈仅允许遮罩或透明度变化
- ✅ `-webkit-tap-highlight-color: transparent` 为强制要求，消除移动端浏览器默认高亮

---
## 14. AI 决策树
```
用户说"底部导航" / "tabbar" / "底部tab"
  ├── 大促/活动场景？
  │   ├── 需要强视觉冲击 → variant="promo-strong"（首Tab上凸 55×55pt 圆形溢出 11pt，yellow-bg）
  │   └── 轻微提示即可 → variant="promo-weak"（首Tab米黄色轻高亮，yellow-bg）
  │
  └── 普通业务场景 → variant="default"
        ├── 首Tab是当前页 → activeType="default"
        │     └── gradient-yellow 胶囊 + special-title 品牌文字
        ├── 有推荐内容 → activeType="recommend"
        │     └── gradient-yellow 胶囊 + 向下箭头 + "推荐"文字
├── 需要回顶 → activeType="toTop"
│     └── gradient-yellow 胶囊 + 回顶部图标（22×22pt，中粗体）
        └── 用户在其他Tab → activeType="unselectedFirst"
              └── 首Tab显示品牌Logo + 频道名称
选项数判断：
  5个Tab → tabCount=5，每Tab宽75pt
  4个Tab → tabCount=4，每Tab宽≈94pt
  3个Tab → tabCount=3，每Tab宽125pt
  2个Tab → tabCount=2，每Tab宽187.5pt
```
---
## 15. 常见组合示例
### 15.1 通用型 5Tab 默认态
```
BottomNavigation
  variant: default
  tabCount: 5
  activeType: default
  activeIndex: 0
  tabs: [首页, 美食, 酒店, 娱乐, 我的]
```
### 15.2 通用型 4Tab 推荐态
```
BottomNavigation
  variant: default
  tabCount: 4
  activeType: recommend
  activeIndex: 0
```
### 15.3 大促型强样式 5Tab（首Tab选中）
```
BottomNavigation
  variant: promo-strong
  tabCount: 5
  activeType: default
  activeIndex: 0
  tabs: [首页, 美食, 酒店, 娱乐, 我的]
  // SEC 1 首Tab：上凸圆形（55×55pt，yellow-bg，溢出11pt）
  //   内含黄色渐变胶囊（38×38pt，gradient-yellow）+ 品牌文字（special-title）
  //   Pen 遮挡层（75pt×13pt，top=-13pt，white）消除锯齿
  // 其余 4 个Tab正常显示图标+标签，padding-top: spacing-s（8pt）
```
### 15.3b 大促型强样式 3Tab（用户切换到非首Tab）
```
BottomNavigation
  variant: promo-strong
  tabCount: 3
  activeType: unselectedFirst
  activeIndex: 2
  tabs: [首页, 美食, 我的]
  // SEC 1 首Tab：上凸圆形（55×55pt，yellow-bg）仍然常驻，溢出11pt
  //   内容仅显示品牌Logo（24×24pt），无文字标签
  // SEC 3（我的，当前选中）：图标 + caption-l-11-medium（text-primary）
  // SEC 2（美食，未选中）：图标（text-primary）+ caption-l-11-regular（text-secondary）
```
### 15.4 大促型弱样式 5Tab（首Tab选中，营销活动入口在第3位）
```
BottomNavigation
  variant: promo-weak
  tabCount: 5
  activeType: default
  activeIndex: 0
  tabs: [首页, 美食, 活动, 酒店, 我的]
  // 第3个Tab（活动）显示 Area 占位（yellow-bg，无标签）
  // 其余未选中Tab正常显示图标+标签
```
### 15.5 大促型弱样式 3Tab（用户在非首Tab）
```
BottomNavigation
  variant: promo-weak
  tabCount: 3
  activeType: unselectedFirst
  activeIndex: 2
  // 首Tab变为未选中态（品牌Logo + 频道名称）
  // 营销活动入口Tab Area 占位始终可见
```
---
## 16. 与其他组件的关系
| 关联组件 | 关系说明 |
|----------|----------|
| `badge` | Tab 图标右上角可叠加数字徽标或红点 |
| `home-indicator` | 导航栏正下方衔接，刘海屏间距 0px |
---
## 17. 完整设计稿参考

- **底部导航栏区域**：y=20200，h=5899
| 组件 | Figma objectId 区域 |
|------|-------------------|
| 通用型 | y=21565，16个变体（4状态×4选项数） |
| 大促型 弱样式 | y=22790，4个变体（2状态×2选项数） |
| 大促型 强样式 | y=23565，4个变体（2状态×2选项数） |
