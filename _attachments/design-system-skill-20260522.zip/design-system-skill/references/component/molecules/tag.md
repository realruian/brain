# Tag 标签

> **组件分类**：Molecule（分子级组件）
> **定义**：标签（Tag）用于对信息进行标记、分类或补充说明，是美团 C 端最高频的原子组件之一。共包含 **6 种子类型**，总计 **232 个变体**。
> **Style 依赖**：`color-semantic.md` · `font-semantic.md` · `spacing-semantic.md` · `component-spacing.md` · `radius-semantic.md` · `component-radius.md` · `stroke-semantic.md`
> **单位说明**：本文件所有数值均为 **@1x 逻辑像素（pt）**，直接对应 CSS 输出值，无需换算。
> **维护人**：luyang40
> **最新版本**：2026-4-9

---

## 模型总览

```
Tag = Structure (type × slot × variant × size)
    + Constraint (适配规则)
    + Style (token)
```

---

## 一、Structure — 结构层

### 1. 形态（type）：结构根类型

| type     | 名称   | 结构描述                                       |
| -------- | ---- | ------------------------------------------ |
| `tag`    | 常规标签 | 最通用形态，支持 6 种样式 × 6 种尺寸 × 2 种箭头 = 72 个变体    |
| `splice` | 拼接标签 | 左右两段文字分别显示不同颜色，常见于"立减｜¥10"等优惠信息展示，共 48 个变体 |
| `coupon` | 券标签  | 展示优惠券信息，支持左右两段异色文字，可选缺角和箭头效果，共 72 个变体      |
| `outer`  | 外挂角标 | 悬挂在其他元素（如商品图片）角落的标签，带尖角指向元素，共 4 个变体        |
| `bubble` | 气泡角标 | 带气泡尾巴的角标，常用于商品卡片左上角，共 36 个变体               |
| `corner` | 常规角标 | 尺寸及属性整体与常规标签保持一致，内嵌于容器的内容角落（左上、右上、左下、右下）   |

---

### 2. 变体（variant）：视觉差异分叉

> variant 仅改变视觉样式，**不改变 slot 骨架**。

#### 2.1 常规标签 / 气泡角标 variant

| variant          | 名称   | 背景            | 边框                          | 文字               |
| ---------------- | ---- | ------------- | --------------------------- | ---------------- |
| `dark`           | 深色背景 | `red-default` | 无                           | `white`          |
| `light`          | 浅色背景 | `red-bg`      | 无                           | `red-default`    |
| `gray-bg`        | 灰色背景 | `bg-page`     | 无                           | `text-secondary` |
| `black-bg`       | 黑色背景 | `mask-light`  | 无                           | `white`          |
| `colored-border` | 彩色描边 | 透明            | `1pt solid` `red-bg-secondary`   | `red-default`    |
| `gray-border`    | 灰色描边 | 透明            | `1pt solid` `stroke-strong` | `text-secondary` |

#### 2.2 拼接标签 variant

| variant | 区域      | 背景            | 文字            |
| ------- | ------- | ------------- | ------------- |
| `dark`  | 左侧（主标签） | `red-default` | `white`       |
| `dark`  | 右侧（副标签） | `red-bg`      | `red-default` |
| `light` | 左侧（主标签） | `red-bg`      | `red-default` |
| `light` | 右侧（副标签） | 透明            | `red-default` |

> `dark` 与 `light` 在拼接标签的色值表现上相同，差异体现在整体投影/对比度策略上（设计稿保留两种枚举以便后续差异化）。

#### 2.3 券标签 variant

| variant          | 左侧背景          | 左侧文字          | 右侧背景    | 右侧文字          |
| ---------------- | ------------- | ------------- | ------- | ------------- |
| `dark`           | `red-default` | `white`       | `red-default` | `white`       |
| `split-dark`     | `red-bg`      | `red-default` | `white` | `red-default` |
| `colored-border` | `white`       | `red-default` | `white` | `red-default` |

> `outer` 外挂角标颜色固定（`red-default` 背景 + `white` 文字），❌ 不支持 variant 切换。

#### 2.4 常规角标 variant

> `corner` 常规角标与常规标签（`tag`）共用相同的 variant 枚举，样式规则完全一致，参见 §2.1。

---

### 3. Slot 骨架：内容构成

#### 3.1 常规标签

```
[ icon-left（可选）] → [ label ] → [ arrow-right（arrow=true 时）]

display: flex; flex-direction: row; align-items: center;
```

| slot          | 必须  | 说明                        |
| ------------- | --- | ------------------------- |
| `icon-left`   | 否   | 左侧图标，`aria-hidden="true"` |
| `label`       | 是   | 主文字内容                     |
| `arrow-right` | 否   | 右侧箭头，`arrow=true` 时显示     |

#### 3.2 拼接标签

```
[ 左侧标签（icon-left + label-left）] → [ 右侧标签（label-right + arrow-right）]

display: flex; flex-direction: row; align-items: center;
gap: -3pt;  /* 产生拼接重叠效果 */
```

| slot          | 必须  | 说明                         |
| ------------- | --- | -------------------------- |
| `icon-left`   | 否   | 左侧区域图标                     |
| `label-left`  | 是   | 左侧主文字                      |
| `label-right` | 是   | 右侧副文字                      |
| `arrow-right` | 否   | 右侧箭头，`rightArrow=true` 时显示 |

#### 3.3 券标签

```
[ 左侧内容（label-left）] → [ mid（分隔区）] → [ 右侧内容（label-right + arrow-right）]
└── notch=true 时：mid 内含缺角装饰（左右半背景填充 + 虚线 + 上下遮盖线）

/* 外层容器 */
display: flex; flex-direction: row; align-items: center;

/* label-left */
flex-shrink: 0;
height: <标签高度>;
border-radius: <cr> 0 0 <cr>;      /* 仅左侧两角有圆角，右侧两角为 0 */
padding: <上下> 0 <上下> <左>;       /* 右侧 padding = 0，左侧 padding 见 §4.5 */
display: flex; flex-direction: row; align-items: center;

/* label-right（无箭头） */
flex-shrink: 0;
height: <标签高度>;
border-radius: 0 <cr> <cr> 0;      /* 仅右侧两角有圆角，左侧两角为 0 */
padding: <上下> <右> <上下> 0;       /* 左侧 padding = 0，右侧 padding 见 §4.5 */
display: flex; flex-direction: row; align-items: center;

/* label-right（有箭头，arrow=true） */
padding: <上下> <右-arrow> <上下> 0; /* 右侧 padding 更小，见 §4.5 */
gap: 0;  /* label-right 内文字与 arrow-right 之间 gap = 0，❌ 禁止添加间距 */

/* mid 分隔区（notch=false，即无缺角时） */
flex-shrink: 0;
width: <mid宽度>;  /* 固定宽度，按 size 取值：small=6pt，extra large=12pt，其余=8pt；❌ 禁止修改 */
height: <标签高度>;
/* 无背景色、无边框、无内容；纯空白间隔，视觉上分隔左右两段 */

/* mid 分隔区（notch=true，即有缺角时）—— 内部分层结构 */
position: relative;  /* 开启相对定位，子元素绝对定位叠加 */
/* ① left-half：覆盖左侧背景，与 label-left 背景色一致 */
  position: absolute; top: 0; left: 0; width: 50%; height: 100%;
/* ② right-half：覆盖右侧背景，与 label-right 背景色一致 */
  position: absolute; top: 0; right: 0; width: 50%; height: 100%;
/* ③ dash：中央垂直虚线（视觉分隔线） */
  position: absolute; top: 2px; left: 50%; width: 2px; height: calc(100% - 4px);
  transform: translateX(-50%);
/* ④ top-cap / bottom-cap：上下两端遮盖线（与 label-left/right 边框或背景齐平，遮住 dash 端点） */
  position: absolute; left: 0; width: 100%; height: 1px;
```

| slot          | 必须  | 说明                                          |
| ------------- | --- | --------------------------------------------- |
| `label-left`  | 是   | 左侧主文字；右侧 padding = 0，左侧有 padding            |
| `mid`         | 是   | 中间分隔区；宽度固定（`small`=6pt，`extra large`=12pt，其余=8pt），高度与标签等高；无缺角时为背景填充+分割线，有缺角时含虚线+半圆镂空 |
| `label-right` | 是   | 右侧副文字；左侧 padding = 0，右侧有 padding            |
| `arrow-right` | 否   | 右侧箭头，`arrow=true` 时显示；有箭头时右侧 padding 更小；与文字之间 gap = 0 |

#### 3.4 外挂角标

```
[ label ]

尖角位于下方，通过伪元素或 SVG 实现；颜色固定，无 variant。
```

#### 3.6 常规角标

```
[ icon-left（可选）] → [ label ] → [ arrow-right（arrow=true 时）]

/* 与常规标签结构完全一致，定位由父容器的 position 属性控制 */
display: flex; flex-direction: row; align-items: center;
```

| slot          | 必须  | 说明                        |
| ------------- | --- | ------------------------- |
| `icon-left`   | 否   | 左侧图标，`aria-hidden="true"` |
| `label`       | 是   | 主文字内容                     |
| `arrow-right` | 否   | 右侧箭头，`arrow=true` 时显示     |

#### 3.5 气泡角标

```
[ label ]

display: flex; flex-direction: column; justify-content: center;
/* 气泡尾巴通过圆角 "左下角=cr-1" 实现 */
```

---

### 4. 尺寸级别（size）

尺寸不可自定义，必须从下表选取。

#### 4.1 常规标签 / 气泡角标尺寸

| size          | 名称   | 字体 Token               | 高度   | 内边距（有箭头 / 无箭头）                    | gap    | 圆角     |
| ------------- | ---- | ---------------------- | ---- | --------------------------------- | ------ | ------ |
| `small`             | 紧凑   | `caption-s-10-regular` | 14pt | `0 cs-1 0 cs-3` / `0 cs-3`        | `cs-1` | `cr-3` |
| `standard alternative` | 标准备选 | `caption-s-10-regular` | 16pt | `cs-1 cs-2 cs-1 cs-4`/`cs-1 cs-4` | `cs-2` | `cr-3` |
| `standard`          | 标准   | `caption-l-11-regular` | 16pt | `0 cs-2 0 cs-4` / `0 cs-4`        | `cs-2` | `cr-3` |
| `large alternative` | 宽松备选 | `caption-l-11-regular` | 18pt | `cs-1 cs-2 cs-1 cs-4`/`cs-1 cs-4` | `cs-2` | `cr-4` |
| `large`             | 宽松   | `body-s-12-regular`    | 18pt | `cs-1 cs-2 cs-1 cs-4`/`cs-1 cs-4` | `cs-2` | `cr-4` |
| `extra large`       | 加大   | `body-s-12-regular`    | 20pt | `cs-2 cs-3 cs-2 cs-6`/`cs-2 cs-6` | `cs-2` | `cr-4` |

#### 4.2 气泡角标尺寸（非对称圆角）

> 气泡角标左下角为尖角（`cr-1`），其余三角为大圆角，各角分别引用 `component-radius.md`。

| size          | 整体宽×高   | 字体 Token               | 内边距         | 圆角（左下为尖角）                |
| ------------- | ------- | ---------------------- | ----------- | ------------------------ |
| `small`             | 26×14pt | `caption-s-10-regular` | `0 cs-3`    | `cr-7 cr-7 cr-7 cr-1`    |
| `standard alternative` | 28×16pt | `caption-s-10-regular` | `cs-1 cs-4` | `cr-8 cr-8 cr-8 cr-1`    |
| `standard`          | 30×16pt | `caption-l-11-regular` | `0 cs-4`    | `cr-8 cr-8 cr-8 cr-1`    |
| `large alternative` | 30×18pt | `caption-l-11-regular` | `cs-1 cs-4` | `cr-9 cr-9 cr-9 cr-1`    |
| `large`             | 32×18pt | `body-s-12-regular`    | `cs-1 cs-4` | `cr-9 cr-9 cr-9 cr-1`    |
| `extra large`       | 36×20pt | `body-s-12-regular`    | `cs-2 cs-6` | `cr-10 cr-10 cr-10 cr-1` |

#### 4.3 外挂角标尺寸

| size          | 整体尺寸    | 字体 Token               | 说明                   |
| ------------- | ------- | ---------------------- | -------------------- |
| `small`    | 26×16pt | `caption-s-10-regular` | 尖角位于下方，通过伪元素或 SVG 实现 |
| `standard` | 30×18pt | `caption-l-11-regular` | 同上                   |

#### 4.5 券标签尺寸规格

> 设计稿画布为 @2x（750px 宽），下表数值已换算为 **@1x pt**。
> mid 分隔区宽度按 size 固定：`small` = **6pt**，`extra large` = **12pt**，其余所有 size = **8pt**；❌ 禁止修改。

| size                   | 高度  | 圆角（左/右）         | 上下 padding | 左侧 padding（label-left 左）| 右侧 padding（label-right 右，无箭头） | 右侧 padding（label-right 右，有箭头） |
| ---------------------- | ---- | ----------------- | ----------- | ------------------------- | --------------------------------- | --------------------------------- |
| `small`                | 14pt | `cr-3` / `cr-3`   | 0           | `cs-3`（3pt）               | `cs-3`（3pt）                      | `cs-1`（1pt）                      |
| `standard alternative` | 16pt | `cr-3` / `cr-3`   | `cs-1`（1pt）| `cs-4`（4pt）               | `cs-4`（4pt）                      | `cs-2`（2pt）                      |
| `standard`             | 16pt | `cr-3` / `cr-3`   | 0           | `cs-4`（4pt）               | `cs-4`（4pt）                      | `cs-2`（2pt）                      |
| `large alternative`    | 18pt | `cr-4` / `cr-4`   | `cs-1`（1pt）| `cs-4`（4pt）               | `cs-4`（4pt）                      | `cs-2`（2pt）                      |
| `large`                | 18pt | `cr-4` / `cr-4`   | `cs-1`（1pt）| `cs-4`（4pt）               | `cs-4`（4pt）                      | `cs-2`（2pt）                      |
| `extra large`          | 20pt | `cr-4` / `cr-4`   | `cs-2`（2pt）| `cs-6`（6pt）               | `cs-6`（6pt）                      | `cs-3`（3pt）                      |

> **圆角写法**：
> - `label-left`：`border-radius: <cr> 0 0 <cr>`（左上、右上为0、右下为0、左下 → 即仅左侧两角）
> - `label-right`：`border-radius: 0 <cr> <cr> 0`（左上为0、右上、右下、左下为0 → 即仅右侧两角）

> **描边 variant（colored-border / split-dark）边框写法**：
> - `label-left`：`border-width: 1pt 0 1pt 1pt`（上、无右、下、左）
> - `label-right`：`border-width: 1pt 1pt 1pt 0`（上、右、下、无左）
> - mid 分隔区左右两侧继承各自相邻区块的边框色（无独立边框）

---

#### 4.4 券标签字重说明

> 券标签文字一律使用 **Semibold（600）**，字体 Token 后缀为 `-semibold`：

| size          | 字体 Token                |
| ------------- | ----------------------- |
| `small`             | `caption-s-10-semibold` |
| `standard alternative` | `caption-s-10-semibold` |
| `standard`          | `caption-l-11-semibold` |
| `large alternative` | `caption-l-11-semibold` |
| `large`             | `body-s-12-semibold`    |
| `extra large`       | `body-s-12-semibold`    |

---

## 二、Constraint — 适配规则层

### 1. Slot 适配约束

```
when: type = outer
→ variant: 不可用（颜色固定为 red-default + white）
→ icon-left slot: 不可用
→ arrow-right slot: 不可用

when: type = bubble
→ arrow-right slot: 不可用
→ icon-left slot: 不可用

when: type = corner
→ 尺寸 / variant / slot 规则与 type = tag 完全一致
→ 默认使用 tag 的样式（variant 枚举同 §2.1）
→ ⚠️ 不建议展示 icon-left 和 arrow-right
→ position 由父容器控制，corner 本身不设置绝对定位
→ 仅可用于容器圆角为 6pt / 8pt / 12pt 的场景
→ ⚠️ 其他圆角值的容器不推荐使用 corner

/* 容器圆角适配规则
   圆角说明：与容器圆角重合的标签角 = A，A 的对角线位置 = C，其余两角 = 0
   示例（placement=top-left）：左上=A，右下=C，右上=0，左下=0
*/

when: type = corner AND 容器圆角 = 6pt
→ 标签圆角：A = `cr-6`，C = `cr-6`，其余两角 = 0
→ 内边距（左右间距）：
   small                → 左右各 `cs-3`
   standard alternative → 左右各 `cs-4`
   standard             → 左右各 `cs-4`
   large alternative    → 左右各 `cs-4`
   large                → 左右各 `cs-4`
   extra large          → 左右各 `cs-6`

when: type = corner AND 容器圆角 = 8pt
→ 标签圆角：A = `cr-8`，C = `cr-8`，其余两角 = 0
→ 内边距（左右间距）：
   small                → 左右各 `cs-3`
   standard alternative → 左右各 `cs-4`
   standard             → 左右各 `cs-4`
   large alternative    → 左右各 `cs-4`
   large                → 左右各 `cs-4`
   extra large          → 左右各 `cs-6`

when: type = corner AND 容器圆角 = 12pt
→ 标签圆角：A = `cr-12`，C = `cr-8`，其余两角 = 0
→ 内边距（左右间距）：
   small                → 左右各 `cs-5`
   standard alternative → 左右各 `cs-6`
   standard             → 左右各 `cs-6`
   large alternative    → 左右各 `cs-6`
   large                → 左右各 `cs-6`
   extra large          → 左右各 `cs-6`

when: type = splice OR coupon
→ label slot: 拆分为 label-left + label-right，缺一不可

when: type = coupon
→ label-left（左侧内容）：❌ 无 padding-right（右侧内边距为 0）
→ label-right（右侧内容）：❌ 无 padding-left（左侧内边距为 0）
→ 左右两段内容之间的视觉间隙由 mid 分隔区承载，❌ 禁止在 label-left / label-right 上补偿间距
```

### 2. 尺寸适配约束

```
when: type = outer
→ size: 仅支持 small / standard，❌ 其余档位不可用

when: type = bubble
→ size: 不支持 standard alternative
```

### 3. 颜色适配约束

```
when: variant = dark / light / gray-bg / black-bg
→ border: 无（❌ 禁止添加描边）

when: variant = colored-border / gray-border
→ background: 透明（❌ 禁止添加背景色）

when: type = coupon AND variant = colored-border
→ 左右两侧均透明背景，文字均用 red-default
```

### 4. 字重适配约束

```
when: type = coupon
→ 字体 Token 后缀必须为 -semibold（600）
→ ❌ 禁止使用 -regular / -medium

when: type = tag / splice / outer / corner / bubble
→ 字体 Token 后缀为 -regular（400）
```

### 5. 多标签并列约束

```
when: 同行并列多个 tag
→ 优先级从高到低：dark → light → gray-border
→ ❌ 禁止同行出现两个 dark 标签
```

### 6. 宽度适配约束

```
所有标签（tag / splice / coupon / outer / corner / bubble）
→ 宽度必须根据标签内部的图标、文字等内容自适应（width: fit-content）
→ ❌ 不存在固定宽度的情况，禁止设置固定宽度（fixed width）
→ ❌ 禁止拉伸填充父容器（width: 100% / flex: 1）
```

### 7. 水平排列间距约束

```
when: 多个标签连续水平排列
→ 默认间距：gap = cs-1（2pt）
→ 如用户指定了特定数值，则以该数值为准（使用对应 cs-{N} Token，❌ 禁止写裸 pt 值）
```

### 8. 箭头图标约束

```
when: type = tag / splice（常规标签 / 拼接标签）
→ arrow-right 图标必须使用 iconfont: right-line-medium
→ ❌ 禁止替换为其他图标

when: type = coupon（券标签）
→ arrow-right 图标必须使用 iconfont: right-line-semibold
→ ❌ 禁止替换为其他图标

所有箭头图标
→ 尺寸 = 当前 size 左侧字号 token 对应 pt 值 − 2pt（固定值，❌ 禁止修改）
  small / standard alternative       → 10 − 2 = 8pt
  standard / large alternative       → 11 − 2 = 9pt
  large / extra large                → 12 − 2 = 10pt
→ ❌ 禁止自定义 width / height（必须使用上表固定值）
```

---

## 三、Style — 样式层（Token）

### 3.1 颜色 Token

| 用途                 | Token            | 来源                     |
| ------------------ | ---------------- | ---------------------- |
| 深色背景 / 主色文字 / 描边文字 | `red-default`    | `color-semantic.md` §七 |
| 浅色背景               | `red-bg`         | `color-semantic.md` §七 |
| 彩色描边边框             | `red-bg-secondary`    | `color-semantic.md` §七 |
| 灰色背景               | `bg-page`        | `color-semantic.md` §三 |
| 黑色半透明背景            | `mask-light`     | `color-semantic.md` §六 |
| 白色文字               | `white`          | `color-semantic.md` §一 |
| 灰色文字               | `text-secondary` | `color-semantic.md` §二 |
| 灰色描边边框             | `stroke-strong`  | `color-semantic.md` §四 |

### 3.2 字体 Token

> 完整属性（字号/行高/字重）见 `semantic/font-semantic.md`，此处直接引用语义名称。

| size                       | 常规 / 气泡 / outer / corner Token | 券标签 Token               |
| -------------------------- | ------------------------------ | ----------------------- |
| `small` / `standard alternative`  | `caption-s-10-regular`         | `caption-s-10-semibold` |
| `standard` / `large alternative`  | `caption-l-11-regular`         | `caption-l-11-semibold` |
| `large`                           | `body-s-12-regular`            | `body-s-12-semibold`    |
| `extra large`                     | `body-s-12-regular`            | `body-s-12-semibold`    |

### 3.3 mid 分隔区样式规则

> mid 是券标签（`coupon`）专属的中间分隔区，❌ 其他类型标签不包含此 slot。

| variant | notch | mid 样式说明 |
| ------- | ----- | ----------- |
| `dark` | `false`（无缺角） | mid 背景 = `red-default`（与左右两侧同色，整体连为一块）；中央竖向分割线：宽 `0.5pt`、颜色 `red-bg-secondary`、长度 = 当前 size 字号 token 对应 pt 值 − 2pt（`small`/`standard alternative` → 8pt，`standard`/`large alternative` → 9pt，`large`/`extra large` → 10pt）；分割线绝对定位于 mid 水平居中、垂直居中；❌ 无虚线、无 cap 线、无缺角结构 |
| `split-dark` | `false`（无缺角） | mid 左半背景 = `red-bg`（与 label-left 同色）、右半背景 = `white`（与 label-right 同色）；❌ 无中央分割线；顶部与底部各有 `0.5pt` 内描边，颜色 = `red-bg-secondary`（描边仅限上下两侧，❌ 左右无描边） |
| `colored-border` | `false`（无缺角） | mid 背景 = `white`（与左右两侧同色，整体连为一块）；中央竖向分割线：宽 `0.5pt`、颜色 `red-bg-secondary`、长度 = 当前 size 字号 token 对应 pt 值 − 2pt（`small`/`standard alternative` → 8pt，`standard`/`large alternative` → 9pt，`large`/`extra large` → 10pt）；分割线绝对定位于 mid 水平居中、垂直居中；❌ 无虚线、无 cap 线、无缺角结构 |
| `dark` | `true`（有缺角） | mid 左半背景 = `red-default`（与 label-left 同色）、右半背景 = `red-default`（与 label-right 同色）；中央竖向虚线：粗细 `0.5pt`、颜色 `red-bg-secondary`、长度 = 当前 size 字号 token 对应 pt 值 − 2pt（`small`/`standard alternative` → 8pt，`standard`/`large alternative` → 9pt，`large`/`extra large` → 10pt），绝对定位于 mid 水平居中、垂直居中；缺角：顶部与底部各一个半圆缺口，直径 `3pt`，左右居中于 mid，上下各超出 tag `2pt`，通过 mid 图形减去两个圆实现镂空（❌ 非描边模拟） |
| `split-dark` | `true`（有缺角） | mid 左半背景 = `red-bg`（与 label-left 同色）、右半背景 = `white`（与 label-right 同色）；中央竖向虚线：粗细 `0.5pt`、颜色 `red-bg-secondary`、长度 = 标签高度 − 3pt（适用所有 size：`small`=11pt「14−3」、`standard alternative`/`standard`=13pt「16−3」、`large alternative`/`large`=15pt「18−3」、`extra large`=17pt「20−3」），绝对定位于 mid 水平居中、垂直居中；**mid 顶部与底部轮廓必须与 label-left/right 上下边框完全连续、无断点**：实现方式为将上下轮廓各用一条连续 `<path>` 描边，路径形式：`M 0,H L Lx,H A r,r 0 0 Sf Rx,H L W,H`，其中 H=tag上/下边y坐标、Lx=弧左端 x、Rx=弧右端 x、W=mid宽度，弧的起止点紧贴 tag 边界上，swept 朝 tag 内侧弯入（实现为缺口向内凹的视觉）；描边 `0.5pt`，颜色 = `red-bg-secondary`；❌ 不能用多段分离的 `<line>` 拼接（会产生断点间隙）**；缺角：顶部与底部各一个半圆缺口，直径 `3pt`，左右居中于 mid，上下各超出 tag `2pt`，镂空后透明（露出页面底色）；缺口弧就是上述轮廓路径的弧线段，颜色 = `red-bg-secondary`，与两侧水平线共同构成不断指轮廓；❌ 非独立弧边描边，❌ 非描边模拟 |
| `colored-border` | `true`（有缺角） | mid 左半背景 = `white`（与 label-left 同色）、右半背景 = `white`（与 label-right 同色）；中央竖向虚线：粗细 `0.5pt`、颜色 `red-bg-secondary`、长度 = 标签高度 − 3pt（适用所有 size：`small`=11pt「14−3」、`standard alternative`/`standard`=13pt「16−3」、`large alternative`/`large`=15pt「18−3」、`extra large`=17pt「20−3」），绝对定位于 mid 水平居中、垂直居中；**mid 顶部与底部轮廓必须与 label-left/right 上下边框完全连续、无断点**：实现方式为将上下轮廓各用一条连续 `<path>` 描边，路径形式：`M 0,H L Lx,H A r,r 0 0 Sf Rx,H L W,H`，弧的起止点紧贴 tag 边界上，swept 朝 tag 内侧弯入（实现为缺口向内凹的视觉）；描边 `0.5pt`，颜色 = `red-bg-secondary`；❌ 不能用多段分离的 `<line>` 拼接（会产生断点间隙）**；缺角：顶部与底部各一个半圆缺口，直径 `3pt`，左右居中于 mid，上下各超出 tag `2pt`，镂空后透明（露出页面底色）；缺口弧就是上述轮廓路径的弧线段，颜色 = `red-bg-secondary`，与两侧水平线共同构成不断指轮廓；❌ 非独立弧边描边，❌ 非描边模拟；缺角：顶部与底部各一个半圆缺口，直径 `3pt`，左右居中于 mid，上下各超出 tag `2pt`，镂空后透明（露出页面底色）；缺口弧边沿路径描边 `0.5pt`，颜色 = `red-bg-secondary`（与左右外侧描边颜色一致，视觉上形成连续轮廓）；❌ 非描边模拟，需路径级描边 |

> **关键约束**：
> - ❌ mid 本身不设置 `border-left` / `border-right`（左右无边框，边框由 `label-left` 右侧和 `label-right` 左侧均为 0 来自然断开）
> - ❌ mid 不设置 `padding`
> - ✅ `notch=true` 时，mid 需 `overflow: visible`，缺角圆形可超出 tag 边界
> - ✅ 虚线（dash）：绝对定位于 mid 水平居中、垂直居中，长度见各 variant 说明，粗细 `0.5pt`（@2x = 1px）；❌ 不贯穿全高
> - ✅ 虚线节奏：**线段 `1.5pt` + 间距 `1.5pt`，依次循环**（@2x CSS 实现：`background: repeating-linear-gradient(to bottom, <色值> 0, <色值> 3px, transparent 3px, transparent 6px)`，宽度 `1px`）

> **缺角镂空实现规范（SVG `<mask>` 方案，必须严格遵守）**：
>
> ✅ 必须使用 SVG `<mask>` 实现缺角镂空，❌ 禁止使用 `clipPath + evenodd path` 方案（因 SVG 弧线路径的缠绕方向难以保证，极易导致镂空失效）。
>
> **实现步骤**：
> 1. SVG 元素：`width` = mid宽度（@2x px），`height` = 40px（含上下各4px溢出空间），`style="position:absolute; top:-4px; left:0; overflow:visible;"`
> 2. `<mask>` 内：先用**白色矩形**覆盖背景显示区域，再用**黑色圆形**在上下缺角位置镂空
> 3. 背景 `<rect>` 应用 `mask="url(#mask-id)"`，❌ 不能直接写 `clip-path`
>
> **坐标计算（@2x，1pt = 2px）**：
>
> | variant | 有无 border | 白色 rect y | 白色 rect height | 上圆 cy | 下圆 cy | 圆半径 r |
> | ------- | ---------- | ---------- | --------------- | ------ | ------ | ------- |
> | `dark`  | 无 border  | `4`        | `32`（tag高16pt×2）| `3`（顶边4 − 外移1） | `37`（底边36 + 外移1） | `3` |
> | `split-dark` / `colored-border` | 有 1px border | `4.5`（border中线） | `31` | `4.5`（border中线，即圆心贴border中线） | `35.5`（border中线） | `3` |
>
> > 圆心外移量推导：缺口超出 tag 边缘 `2pt`（4px），圆半径 `1.5pt`（3px），外移 = `4 − 3 = 1px`（0.5pt）
> > `split-dark` / `colored-border` 有 1px border，tag 视觉边线在 border 中线（`y=4.5` / `y=35.5`），圆心与 border 中线齐平（外移量已被 border 半像素抵消）
>
> **标准代码模板**（以 `dark` 为例，standard size @2x）：
>
> ```html
> <svg viewBox="0 0 16 40" width="16" height="40"
>      style="position:absolute;top:-4px;left:0;overflow:visible;pointer-events:none;">
>   <defs>
>     <mask id="mask-dark-xxx" maskUnits="userSpaceOnUse">
>       <rect x="0" y="4" width="16" height="32" fill="white" />   <!-- 显示区域 -->
>       <circle cx="8" cy="3"  r="3" fill="black" />               <!-- 镂空上缺角 -->
>       <circle cx="8" cy="37" r="3" fill="black" />               <!-- 镂空下缺角 -->
>     </mask>
>   </defs>
>   <rect x="0" y="4" width="16" height="32" fill="<背景色>" mask="url(#mask-dark-xxx)" />
> </svg>
> ```
>
> **标准代码模板**（以 `split-dark` / `colored-border` 为例，standard size @2x）：
>
> ```html
> <svg viewBox="0 0 16 40" width="16" height="40"
>      style="position:absolute;top:-4px;left:0;overflow:visible;pointer-events:none;">
>   <defs>
>     <mask id="mask-split-xxx" maskUnits="userSpaceOnUse">
>       <rect x="0" y="4.5" width="16" height="31" fill="white" />  <!-- 显示区域（border中线到border中线）-->
>       <circle cx="8" cy="4.5"  r="3" fill="black" />              <!-- 镂空上缺角 -->
>       <circle cx="8" cy="35.5" r="3" fill="black" />              <!-- 镂空下缺角 -->
>     </mask>
>   </defs>
>   <!-- split-dark：左半/右半分别填色，各自引用同一 mask -->
>   <rect x="0" y="4.5" width="8"  height="31" fill="<左半背景色>" mask="url(#mask-split-xxx)" />
>   <rect x="8" y="4.5" width="8"  height="31" fill="<右半背景色>" mask="url(#mask-split-xxx)" />
>   <!-- 上轮廓描边：水平线 + 向tag内凹弧（sweep-flag=0 表示向下凹） -->
>   <path d="M 0,4.5 L 5.17,4.5 A 3,3 0 0 0 10.83,4.5 L 16,4.5" fill="none" stroke="#FFC6C1" stroke-width="1" />
>   <!-- 下轮廓描边：水平线 + 向tag内凹弧（sweep-flag=1 表示向上凹） -->
>   <path d="M 0,35.5 L 5.17,35.5 A 3,3 0 0 1 10.83,35.5 L 16,35.5" fill="none" stroke="#FFC6C1" stroke-width="1" />
> </svg>
> ```
>
> > 轮廓路径弧端点 x 坐标推导：圆心 `cx=8`，半径 `r=3`，圆心在边界线上（`cy=H`），水平切点 `x = 8 ± √(3²−0²) = 8 ± 3`，但因圆心仅在线上（非内侧），取 tag 边界方向的水平切点：弦长 = `2×√(r²−d²)`，`d=0`，故 `x = 8±3`，然而实际需弧在 **mid 内部**可见的部分，即弦的两端在 tag 边线上，取 `x = 8 ± 2√2 ≈ 5.17 / 10.83`（圆与 tag 边线的两个交点）
> > **注意**：mask 方案中 `<circle>` 负责镂空，`<path>` 负责描边，两者独立，不互相依赖

### 3.4 间距 Token（原 §3.3）

> 全部来自 `component-spacing.md`（`cs-{N}`），❌ 禁止写裸 pt 值。

| 用途                                    | Token  | 值   |
| ------------------------------------- | ------ | --- |
| 图标与文字 gap（紧凑）                         | `cs-1` | 1pt |
| 图标与文字 gap（standard / large alternative / large / extra large） | `cs-2` | 2pt |
| small 水平内边距（无箭头）                                           | `cs-3` | 3pt |
| small 右侧内边距（有箭头）                                           | `cs-1` | 1pt |
| standard alternative/standard、large alternative/large 水平内边距   | `cs-4` | 4pt |
| standard alternative/standard、large alternative/large 右侧内边距（有箭头） | `cs-2` | 2pt |
| extra large 左侧内边距                                             | `cs-6` | 6pt |
| extra large 右侧内边距（有箭头）                                      | `cs-3` | 3pt |
| 气泡角标 small 水平内边距                                            | `cs-3` | 3pt |
| 气泡角标 standard 水平内边距                                         | `cs-4` | 4pt |
| 气泡角标 large alternative/large 水平内边距                          | `cs-4` | 4pt |
| 气泡角标 extra large 水平内边距                                      | `cs-6` | 6pt |

### 3.5 圆角 Token（原 §3.4）

> 全部来自 `component-radius.md`（`cr-{N}`），❌ 禁止写裸 pt 值。

| size                                      | Token                              | 值      |
| ----------------------------------------- | ---------------------------------- | ------ |
| `small` / `standard alternative` / `standard` | `cr-3`                             | 3pt    |
| `large alternative` / `large` / `extra large` | `cr-4`                             | 4pt    |
| 气泡角标尖角（左下角）                               | `cr-1`                             | 1pt    |
| 气泡角标其余三角（因 size 而异）                       | `cr-7` / `cr-8` / `cr-9` / `cr-10` | 见 §4.2 |

---

## 四、Props API（供 AI 生码参考）

### 常规标签

```typescript
export type TagProps = {
  /** 尺寸档位 @default "standard" */
  size?: "small" | "standard alternative" | "standard" | "large alternative" | "large" | "extra large";
  /** 样式变体 @default "light" */
  variant?: "dark" | "light" | "gray-bg" | "black-bg" | "colored-border" | "gray-border";
  /** 是否显示右侧箭头 @default false */
  arrow?: boolean;
  children: React.ReactNode;
};
```

### 拼接标签

```typescript
export type SpliceTagProps = {
  /** 尺寸档位 @default "standard" */
  size?: "small" | "standard alternative" | "standard" | "large alternative" | "large" | "extra large";
  /** 样式变体 @default "dark" */
  variant?: "dark" | "light";
  /** 是否显示左侧图标 @default false */
  leftIcon?: boolean;
  /** 是否显示右侧箭头 @default false */
  rightArrow?: boolean;
  leftText: string;
  rightText: string;
};
```

### 券标签

```typescript
export type CouponTagProps = {
  /** 尺寸档位 @default "standard" */
  size?: "small" | "standard alternative" | "standard" | "large alternative" | "large" | "extra large";
  /** 样式变体 @default "dark" */
  variant?: "dark" | "light" | "split-dark" | "colored-border";
  /** 是否显示缺角效果 @default false */
  notch?: boolean;
  /** 是否显示右侧箭头 @default false */
  arrow?: boolean;
  leftText: string;
  rightText: string;
};
```

### 外挂角标

```typescript
export type OuterTagProps = {
  /** 尺寸档位 @default "small" */
  size?: "small" | "standard";
  /** 尖角朝向 @default "right" */
  pointDirection?: "left" | "right";
  children: React.ReactNode;
};
```

### 常规角标

```typescript
export type CornerTagProps = {
  /** 尺寸档位 @default "standard" */
  size?: "small" | "standard alternative" | "standard" | "large alternative" | "large" | "extra large";
  /** 样式变体 @default "light" */
  variant?: "dark" | "light" | "gray-bg" | "black-bg" | "colored-border" | "gray-border";
  /** 是否显示右侧箭头 @default false */
  arrow?: boolean;
  /** 角落位置 @default "top-left" */
  placement?: "top-left" | "top-right" | "bottom-left" | "bottom-right";
  children: React.ReactNode;
};
```

### 气泡角标

```typescript
export type BubbleTagProps = {
  /** 尺寸档位 @default "standard" */
  size?: "small" | "standard" | "large alternative" | "large" | "extra large";
  /** 样式变体 @default "dark" */
  variant?: "dark" | "light" | "gray-bg" | "black-bg" | "colored-border" | "gray-border";
  children: React.ReactNode;
};
```

---

## 五、data-attribute 规范

| 属性             | 值                                                                                         | 说明                   |
| -------------- | ----------------------------------------------------------------------------------------- | -------------------- |
| `data-slot`    | `"tag"`                                                                                   | 全局稳定标识，供父组件 CSS 定向选中 |
| `data-type`    | `"tag"` / `"splice"` / `"coupon"` / `"outer"` / `"corner"` / `"bubble"`                   | 子类型                  |
| `data-variant` | 各 variant 枚举值                                                                             | 当前样式变体               |
| `data-size`    | `"small"` / `"standard alternative"` / `"standard"` / `"large alternative"` / `"large"` / `"extra large"` | 当前尺寸级别               |

---

## 六、与其他组件的关系

| 关联组件            | 关系说明                                            |
| --------------- | ----------------------------------------------- |
| `product-card`  | 商品卡片左上角通常使用 `bubble`（气泡角标）或 `tag`（常规标签 small） |
| `coupon`        | 券列表页单独使用 `coupon`（券标签），可配合 `notch=true`         |
| `list-and-form` | 列表行内辅助标记使用 `tag`（常规标签 gray-border / light）      |
| `notice-bar`    | 通知栏内嵌标签时使用 `tag` compact，避免过大标签影响可读性            |

---

## 完整设计稿参考

- **印迹设计稿**：https://ingee.meituan.com/#/artboard/1413851/pos_t
- **imageId**：1413851
- **画布尺寸**：5998 × 39070（包含所有变体的完整规范页）
