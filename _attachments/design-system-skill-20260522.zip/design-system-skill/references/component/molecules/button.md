# Button 按钮

> **组件分类**：Molecule（分子级组件）
> **定义**：按钮继承自物理世界，用户通过按钮完成即时操作。由图标、文字、状态等原子元素组合而成。
> **Style 依赖**：`color-semantic.md` · `font-semantic.md` · `spacing-semantic.md` · `component-spacing.md` · `radius-semantic.md` · `component-radius.md` · `stroke-semantic.md`
> **单位说明**：本文件规范值均为 **@1x 逻辑像素（pt）**；§8 CSS 速查表已换算为 @2x px，直接复制使用。

---

<!-- COMP-NAV-START -->

## 🗺️ Button — 模型 / variant / 章节速查

> 先定 type（icon/text/…），再定 variant（primary/secondary/…），再定 size（xl/l/m/s）。

| 维度 | 枚举值 | 说明 | 规格行 |
|------|------|------|------|
| `**type（形态）**` | icon / text / icon-text / pure-icon | 结构根类型 | L22 |
| `**variant（视觉）**` | primary / secondary / ghost / text / danger | 配色差异分叉 | L45 |
| `**size**` | xl / l / m / s / xs | 5 档尺寸 | L141 |
| `**state**` | default / hover / pressed / disabled / loading | 交互状态 | L168 |
| `**slot**` | icon-left / label / sub-label / icon-right | 内容骨架构成 | L60 |

**其他关键章节直达：**

- **颜色 Token**：跳转 → L313
- **字体 Token**：跳转 → L331
- **间距 Token**：跳转 → L354
- **与其他组件关系**：跳转 → L375
- **Props API**：跳转 → L398
- **HTML CSS 速查（§8）**：跳转 → L428
- **Price Font 覆盖 CSS**：跳转 → L687

<!-- COMP-NAV-END -->

## 模型总览

```
Button = Structure (slot × variant × size)
       + Constraint (适配规则)
       + Style (token)
```

---

## 一、Structure — 结构层

### 1. 形态（type）：结构根类型

| type | 名称 | 结构描述 |
|------|------|---------|
| `capsule` | 胶囊按钮 | 有背景/描边，全圆角，承载主/次操作 |
| `text` | 文字按钮 | 无背景无边框，仅文字，用于次要或密集操作场景 |

> `text` 类型无 variant，**有 icon-left / icon-right slot**（可选），字重 Regular 400。

---

### 1.1 文字按钮尺寸（text type 专属）

| size | 名称 | label Token | icon-left 尺寸 | icon-right 尺寸 | gap | 适用场景 |
|------|------|-------------|---------------|----------------|-----|----------|
| `l` | 大号 | `body-l-14-regular`（14pt/20pt/400） | 16×16pt | 12×12pt | `cs-2` | 常与胶囊按钮组合使用 |
| `m` | 中号 | `body-m-13-regular`（13pt/18pt/400） | 15×15pt | 11×11pt | `cs-2` | 超大号和小号不能满足的特殊场景 |
| `s` | 小号 | `body-s-12-regular`（12pt/16pt/400） | 14×14pt | 10×10pt | `cs-2` | **推荐**，常与表单组合，也可作为组件的一部分 |

> 文字色默认 `#111111`（`text-primary`）；无 padding，高度等于行高；❌ 禁止设置背景或描边。

---

### 2. 变体（variant）：视觉差异分叉

> variant 仅改变视觉样式，**不改变 slot 骨架**，仅适用于 `capsule` 类型。

| variant | 名称 | 背景 | 文字色 | 使用场景 |
|---------|------|------|--------|---------|
| `primary` | 黄色面性 | `gradient-yellow` | `text-primary`（#111111）⚠️ 禁用白色 | 页面主操作、核心引导 |
| `colorful` | 彩色面性 | 业务渐变色（见 三.§1 颜色 Token） | `white`（#FFFFFF） | 营销 / 业务强调 |
| `colorful-outline` | 彩色线性 | 透明 + 彩色描边 | 与描边色一致（见 二.§2 颜色适配约束） | 卡片/列表/提示栏内需强调或警示的行动点 |
| `secondary` | 灰色线性 | 透明 + 灰色描边（`#CCCCCC`） | `#111111` | 次要操作，搭配 primary 并列 |

> **渐变方向**：统一 `to bottom right`；支付（DPT14）例外用 `to bottom left`。

---

### 3. Slot 骨架：内容构成

胶囊按钮内容区从左到右固定顺序：

```
[ icon-left ] → [ label ] → [ price / sub-label ] → [ icon-right ]
```

| slot | 必须 | 说明 |
|------|------|------|
| `icon-left` | 否 | 左图标，`aria-hidden="true"`；类名格式见 一.§3.2 |
| `label` | 是（icon-only 除外） | 主操作文字 |
| `price` | 否 | label 行内跟随的价格数字；xl / l 用美团新数字体 `price-set-*`；m / s / xs / xxs 用 PingFang，通过 `btn-sub-label` 实现 |
| `sub-label` | 否 | 纯文字副文字（满减、剩余件数等），m / s / xs / xxs 可用 |
| `icon-right` | 否 | 右图标，xl / l / xxs 不支持（见 二.§1 Slot 适配约束） |

> **双行布局（xl / l 专属）**：label 行 + row2 行垂直堆叠，总高不变；详见 一.§3.3。

---

### 3.1 单行 slot 规则

- `icon-left` 与 `label` 之间间距：全部尺寸统一 `cs-2`（2pt），CSS 实现用 `icon-left` 的 `margin-right: 4px`
- `label` 与 `icon-right` 之间间距：**0（紧贴）**，容器设 `gap: 0`，icon-right 无需任何 margin
- `label` 与 `price` / `sub-label` 之间间距：见 三.§3 间距 Token（`label-price gap` 列）
- icon-only 按钮必须补充 `aria-label`

---

### 3.2 图标（icon-left / icon-right）规范

图标必须来自 `component/atoms/icon.md`，格式：`font icon-iconfont-{name}-{weight}`
❌ 禁止 SVG 内联 ❌ 禁止 mtdicon

> ⚠️ **iconfont 渲染陷阱（HTML 预览必读）**：
> 1. **字体文件必须引入**：iconfont 依赖 `@font-face`，未引入字体文件时图标字符渲染为空白，与 CSS 类名写法无关。HTML 预览文件须在 `<head>` 中通过 `<link>` 或 `<style>@import</style>` 引入字体 CSS（如 `_iconfont_inlined.css`），缺少此步骤图标必然丢失。
> 2. **图标 `<span>` 必须 `display:inline-block`**：iconfont 通过 `::before` 伪元素注入字符，父元素若为默认 `inline`（无实际宽高），伪元素字符无法正常渲染。必须保证图标 `<span>` 是 `display:inline-block`，❌ 禁止使用 `display:inline-flex`（会破坏伪元素渲染）。
> 3. **宽字符图标需要外层 wrapper**：部分图标字符的 advance width（字形本身宽度）超出所设 px 尺寸，在按钮设有 `overflow:hidden` 时会挤压相邻文字。解决方案：在图标 `<span>` 外套一层宽高固定的 `inline-block` wrapper 并加 `overflow:hidden`，由 wrapper 锁死占位宽度，内层图标 `<span>` 本身 ❌ 不加 `overflow:hidden`。
>
> 🚨 **优先级例外**：以上规则仅适用于 Button / 普通行内 iconfont 场景；**不适用于 Navigation（导航栏）返回按钮和右侧操作区图标**。NavBar icon span 写法以 `references/component/components/navigation.md` 为准，❌ 不得把本节的 `display:inline-block` 规则直接套到导航栏。
>
> ```html
> <!-- ✅ 正确写法：wrapper 锁宽 + 内层 inline-block -->
> <span class="btn-icon-wrap-32" aria-hidden="true">
>   <span class="font icon-iconfont-askrider-line-medium btn-icon-left"></span>
> </span>
> ```
> ```css
> /* wrapper：固定宽高，overflow:hidden 锁死字符 advance width，flex-shrink:0 防压缩 */
> .btn-icon-wrap-32 { display: inline-block; width: 32px; min-width: 32px; height: 32px; overflow: hidden; flex-shrink: 0; margin-right: 4px; vertical-align: middle; }
> /* 内层图标 span：必须 display:inline-block，❌ 禁止 overflow:hidden，❌ 禁止 font-weight */
> .font[class*="icon-iconfont-"] { display: inline-block !important; font-style: normal; }
> ```

| size | icon-left 尺寸 | icon-left 字重 | icon-right 尺寸 | icon-right 字重 | icon-right 语义 |
|------|--------------|--------------|----------------|----------------|----------------|
| `xl` | 20×20pt | **Medium 500** | 不支持 | — | — |
| `l` | 17×17pt | **Medium 500** | 不支持 | — | — |
| `m` | 16×16pt | **Medium 500** | 12×12pt | Bold 700 | **固定向右** `icon-iconfont-right-line-bold` |
| `s` | 16×16pt | **Medium 500** | 12×12pt | Bold 700 | **固定向右** `icon-iconfont-right-line-bold` |
| `xs` | 14×14pt | 面性 **Semibold 600** / 线性 **Medium 500** | 10×10pt | 面性 **Bold 700** / 线性 **Semibold 600** | 面性 `icon-iconfont-right-line-bold` / 线性 `icon-iconfont-right-line-semibold` |
| `xxs` | 11×11pt | 面性 Bold 700 / 线性 Medium 500 | 不支持 | — | — |

> **icon-left 语义规则**：m / s / xs 左侧图标表达该按钮的**操作语义**（如购物车、定位、搜索等），❌ 禁止用装饰性图案。
> **icon-right 固定规则**：m / s / xs 右侧图标**固定为向右箭头**，不得替换为其他图标；与左侧文字间距为 0（紧贴）。
> **icon-left 字重规则**：xl / l / m / s 统一用 **Medium 500**（`-line-medium`）；xs 按 variant 区分：面性用 **Semibold 600**（`-line-semibold`），线性用 **Medium 500**（`-line-medium`）；xxs 面性用 Bold 700，线性用 Medium 500。
> **icon-right 字重规则（xs）**：面性用 **Bold 700**（`icon-iconfont-right-line-bold`），线性用 **Semibold 600**（`icon-iconfont-right-line-semibold`）。❗图标粗细由 class 名后缀决定，❗❗禁止用 `font-weight` 控制图标粗细。

---

### 3.3 双行布局（xl / l 专属）

**双行时按钮总高度不变**（xl 仍 48pt，l 仍 40pt），两行整体垂直居中，行间距为负值。上下 padding 在双行时单独收窄（xl: `cs-6`=6pt↔12px，l: `cs-3`=3pt↔6px），以保持总高不变。

| size | 第一行（label 行） | 第二行（row2） | 行间距 |
|------|-----------------|-------------|-------|
| `xl` | `subtitle-s-15-semibold`（15pt/22pt/600）→@2x 30px/44px/600 + price `price-set-16` | `caption-l-11-regular`（11pt/16pt/400）→@2x 22px/32px/400，纯文字 | −2pt↔−4px |
| `l` | `subtitle-s-15-semibold`（15pt/22pt/600）→@2x 30px/44px/600 + price `price-set-16` | `caption-s-10-regular`（10pt/14pt/400）→@2x 20px/28px/400，纯文字 | −2pt↔−4px |

> 第二行**仅支持纯文字**，❌ 禁止在第二行展示价格数字。

---

### 3.4 尺寸级别（size）

尺寸不可自定义，必须从下表选取：

| size | 名称 | 总高 | label 字体 Token | 上下 padding | 水平 padding | icon-text gap |
|------|------|------|----------------|-------------|-------------|---------------|
| `xl` | 一级 | 48pt | `title-s-18-medium` | 单行 `cs-11`（11pt）/ 双行 `cs-6`（6pt） | `cs-24`（24pt） | `cs-2`（2pt） |
| `l` | 二级 | 40pt | `subtitle-s-15-medium` | 单行 `cs-9`（9pt）/ 双行 `cs-3`（3pt） | `cs-20`（20pt） | `cs-2`（2pt） |
| `m` | 三级 | 34pt | `body-l-14-medium` | `cs-7`（7pt） | `cs-15`（15pt） | `cs-2`（2pt） |
| `s` | 四级 | 30pt | `body-l-14-medium` | `cs-5`（5pt） | `cs-15`（15pt） | `cs-2`（2pt） |
| `xs` | 五级 | 24pt | `body-s-12-medium` | `cs-4`（4pt） | `cs-12`（12pt） | `cs-2`（2pt） |
| `xxs` | 六级 | 20pt | `caption-l-11-medium` | `cs-2`（2pt） | `cs-10`（10pt） | `cs-2`（2pt） |

> 上下 padding 来自 `component-spacing.md`（`cs-{N}`），❌ 禁止用 `spacing-*` 替代。
> 圆角：`radius-full`（`border-radius: 9999px`），来自 `component-radius.md`，❌ 禁止写裸 px 数值。

| size | 适用场景 |
|------|---------|
| `xl` | 页面**中部**核心 CTA（❌ 非底部——底部操作栏用 `l` 级） |
| `l` | 底部工具栏次要按钮 |
| `m` | 模块内主要操作，页面中部 |
| `s` | 卡片内操作按钮 |
| `xs` | 紧凑小操作 |
| `xxs` | 极小场景（视频侧边栏等） |

---

### 3.5 状态（state）

| state | data-state | 视觉表现 |
|-------|-----------|---------|
| 默认 | `default` | 正常展示 |
| 按压 | `pressed` | 面性：在原渐变背景上叠加 `linear-gradient(rgba(255,255,255,0.5))` 白色遮罩（整体变亮）；线性：**整体** `opacity: 0.5`（描边 + 文字 + 图标同步变淡），同时描边色降至 50% 透明度（`secondary` 灰色线性 → `rgba(204,204,204,0.5)`；`colorful-outline` 红色线性 → `rgba(255,45,25,0.5)`），CSS 写法见 八.§8.1 |
| 禁用 | `disabled` | 面性：背景→`bg-disabled`（`#F0F0F0`），文字→`text-disabled`（`#C2C2C2`）；线性：描边→`stroke-disabled`（`#CCCCCC`），文字→`text-disabled`（`#C2C2C2`） |

> 禁用态用 `aria-disabled="true"` + 拦截点击，❌ 不使用原生 `disabled`（会移除 focus）。

---

## 二、Constraint — 适配规则层

### 1. Slot 适配约束

```
when: size = xl OR l OR xxs
→ icon-right slot: 不可用（❌ 禁止渲染右图标）

when: size = m OR s OR xs
→ icon-right slot: 可用
```

```
when: size = m OR s，AND icon-right 存在（向右箭头）
→ 右侧水平 padding 从 cs-15（15pt）收窄为 cs-10（10pt）
→ 左侧水平 padding 保持 cs-15（15pt）不变
→ CSS: padding-right: 20px（@2x），class 写法：btn-m.has-icon-right / btn-s.has-icon-right

when: size = xs，AND icon-right 存在（向右箭头）
→ 右侧水平 padding 从 cs-12（12pt）收窄为 cs-8（8pt）
→ 左侧水平 padding 保持 cs-12（12pt）不变
→ CSS: padding-right: 16px（@2x），class 写法：btn-xs.has-icon-right

when: icon-right 不存在
→ 两侧 padding 保持默认：m: 14px 30px；s: 10px 30px；xs: 8px 24px（均为 @2x）
```

```
when: type = text
→ variant: 无（不适用）
→ icon-left slot: 可用（可选）
→ icon-right slot: 可用（可选）
→ price / sub-label / double-row: 不可用
```

```
when: layout = double-row (xl / l)
→ label slot: 降级为 subtitle-s-15-semibold（非 label 默认 Token）
→ price slot: 固定用 price-set-16，❌ 禁止继承 label Token
→ sub-label slot: 不可用（双行第二行 row2 已承担该职责）
```

---

### 2. 颜色适配约束（variant × color）

```
when: variant = primary (gradient-yellow)
→ color: #111111（text-primary）
→ ❌ 禁止白色（黄底亮度高，白字对比度不达标）

when: variant = colorful（红/橙/到餐等深色渐变）
→ color: #FFFFFF（white）

when: variant = colorful-outline（彩色线性描边）
→ 描边色：业务彩色（默认红色 #FF2D19，@2x 1px solid）
→ 文字色 = 图标色 = 描边色
→ 按压态描边：rgba(255, 45, 25, 0.5)
→ 其他业务色描边 → 文字/图标跟随对应业务色

when: variant = secondary（灰色线性描边）
→ 描边色：`stroke-default`（@2x 1px solid）
→ 文字色 = 图标色 = `text-primary`
→ 按压态描边：rgba(204, 204, 204, 0.5)
```

---

### 3. 价格字体适配约束

```
when: size = xl（单行）
→ 价格用 price-set-20 medium（美团新数字体）
   · ¥ 符号：price-13-medium → @2x 26px/36px/500，margin-right: 2px
   · 整数/小数：price-20-medium → @2x 40px/56px/500
   · margin-left: 4px（label 与价格组间距，cs-2）

when: size = xl（双行 btn-row1）OR size = l（单行 OR 双行 btn-row1）
→ 价格用 price-set-16 medium（美团新数字体）
   · ¥ 符号：price-11-medium → @2x 22px/32px/500，margin-right: 2px
   · 整数/小数：price-16-medium → @2x 32px/44px/500
   · 单行 margin-left: 4px；双行 btn-row1 通过 gap:8px 控制

when: size = m OR s OR xs OR xxs，行内出现价格数字
→ ❌ 禁止用 price-set-* 美团数字体
→ 价格直接用 PingFang SC，与 btn-label 字号、字重、行高完全相同
→ ¥ 符号与数字之间不留额外间距（浏览器默认 0）
→ 价格整体通过 btn-sub-label（margin-left: 4px）跟随 label
→ 推荐拆分写法：<span class="btn-label">立即支付</span><span class="btn-sub-label">¥18.5</span>（btn-sub-label 自带 margin-left:4px = cs-2，控制间距）
→ 合并写法：<span class="btn-label">立即支付¥18.5</span>（¥ 与文字无额外间距，适用于不需要独立控制价格样式的场景）

when: 多按钮并列
→ 主操作 primary，次操作 secondary
→ ❌ 禁止两个 primary 并列
```

---

### 4. 阴影禁用约束

```
按钮组件 ❌ 禁止使用 box-shadow（任何形式的弥散投影、扩散投影、颜色光晕投影）

原因：
  · 弥散投影（如 box-shadow: 0 4px 16px rgba(255,45,125,0.3)）会让按钮在视觉上
    「浮起来」，与平面化设计语言相冲突，破坏页面层次感
  · 按钮的视觉强调通过 色彩渐变 + 全圆角（radius-full）+ 尺寸比例 实现，
    不需要也不允许依赖投影增加视觉重量
  · 唯一允许的阴影场景：浮层类组件（Modal / Sheet / Tooltip 等），
    这些场景阴影定义在其自身规范文件中，与按钮无关

正确做法：删除 box-shadow；按压态通过 active 伪元素白色遮罩或 opacity 实现
```

---

### 5. 宽度适配约束（最小安全边距原则）

```
when: 按钮内文字过长，导致内容区宽度 > (按钮宽度 - 水平padding×2)
→ 水平 padding 保持不变，❌ 禁止压缩
→ 按钮宽度自动拉伸以容纳内容
→ 计算公式：按钮宽度 = 内容区宽度 + 水平padding × 2
```

> **核心原则**：文字与按钮左右边缘的距离永远不得小于该尺寸规定的水平 padding 值。按钮宽度由内容撑开，padding 是不可压缩的最小安全边距。

> ⚠️ **尺寸比例约束**：卡片内行内按钮（与价格并排）高度跟随对应 `size` 档位（s=60px / m=68px），❌ 禁止将按钮宽高设为相等的正方形（如 144×144px）——正方形按钮会破坏行内布局的比例，导致视觉失衡。

---

## 三、Style — 样式层（Token）

### 1. 颜色 Token

| 用途 | Token | 来源 |
|------|-------|------|
| primary 背景 | `gradient-yellow` | `color-semantic.md` §八 |
| colorful 背景（橙） | `gradient-orange` | `color-semantic.md` §八 |
| colorful 背景（红） | `gradient-red` | `color-semantic.md` §八 |
| colorful 背景（到餐 DPT5） | `dpt5-g-or` | `color-business.md` |
| secondary 描边 | `stroke-default` / 业务色 | `color-semantic.md` §四 |
| secondary 描边（禁用） | `stroke-disabled` | `color-semantic.md` §四 |
| 面性禁用背景 | `bg-disabled` | `color-semantic.md` §三 |
| 禁用文字 | `text-disabled` | `color-semantic.md` §二 |
| 按压态（面性） | 叠加 `linear-gradient(rgba(255,255,255,0.5))` | 在渐变背景上追加白色遮罩层 |
| 按压态（线性） | 描边透明度 50% | rgba 方式，无需额外 Token |
| `colorful-outline` 描边 | `#FF2D19`（默认）/ 业务彩色 | 实测值，@2x 1px |
| text 按钮文字（默认） | `text-primary`（`#111111`） | `color-semantic.md` §二 |
| text 按钮文字（禁用） | `text-disabled`（`#C2C2C2`） | `color-semantic.md` §二 |

### 2. 字体 Token

> 完整属性（字号/行高/字重）见 `semantic/font-semantic.md`；字重体系：Semibold 600 / Medium 500 / Regular 400。

**Capsule 按钮（type=capsule）**

| size | label Token | 双行第一行 Token |
|------|------------|----------------|
| `xl` | `title-s-18-medium` | `subtitle-s-15-semibold` |
| `l` | `subtitle-s-15-medium` | `subtitle-s-15-semibold` |
| `m` | `body-l-14-medium` | — |
| `s` | `body-l-14-medium` | — |
| `xs` | `body-s-12-medium` | — |
| `xxs` | `caption-l-11-medium` | — |

**Text 按钮（type=text）**

| textSize | label Token |
|----------|-------------|
| `l` | `body-l-14-regular`（14pt/20pt/400） |
| `m` | `body-m-13-regular`（13pt/18pt/400） |
| `s` | `body-s-12-regular`（12pt/16pt/400） |

### 3. 间距 Token

> 全部来自 `component-spacing.md`（`cs-{N}`），❌ 禁止用 `spacing-*` 替代。

**Capsule 按钮（type=capsule）**

| size | 上下 padding | 水平 padding | icon-text gap | label-price gap |
|------|------------|-------------|--------------|----------------|
| `xl` | 单行 `cs-11`（11pt）/ 双行 `cs-6`（6pt） | `cs-24`（24pt） | `cs-2`（2pt） | 单行 `cs-2`（2pt）/ 双行 row1 `cs-4`（4pt） |
| `l` | 单行 `cs-9`（9pt）/ 双行 `cs-3`（3pt） | `cs-20`（20pt） | `cs-2`（2pt） | 单行 `cs-2`（2pt）/ 双行 row1 `cs-4`（4pt） |
| `m` | `cs-7`（7pt） | `cs-15`（15pt）；有右图标时右侧收窄为 `cs-10`（10pt） | `cs-2`（2pt） | `cs-2`（2pt） |
| `s` | `cs-5`（5pt） | `cs-15`（15pt）；有右图标时右侧收窄为 `cs-10`（10pt） | `cs-2`（2pt） | `cs-2`（2pt） |
| `xs` | `cs-4`（4pt） | `cs-12`（12pt）；有右图标时右侧收窄为 `cs-8`（8pt） | `cs-2`（2pt） | `cs-2`（2pt） |
| `xxs` | `cs-2`（2pt） | `cs-10`（10pt） | `cs-2`（2pt） | `cs-2`（2pt） |

**Text 按钮（type=text）**

> 无 padding；icon-text gap 三档统一 `cs-2`（2pt）。

---

## 四、与其他组件的关系

| 父组件 | Constraint |
|--------|-----------|
| `bottom-action-bar` | 🚨 内部按钮**必须用 `size=l`（@1x 40pt / @2x 80px，class: `btn-l`）**，❌ 严禁用 `size=xl`（96px）——这是最高频重复错误；必须先读 `bottom-action-bar.md` |
| `dialog` / `half-screen-dialog` | 主操作 `primary`，取消 `secondary` |
| `list` 行内 | 优先用 `size=s` / `size=m` + `secondary` |
| `stepper` | 内部 +/- 用极小尺寸 |
| `filter-panel` 底部 | 确定 `primary`，重置 `secondary` 或 `text` |
| **并列按钮（≥2 个按钮横排）** | **必须先读 `bottom-action-bar.md`**，按其规则决定尺寸、间距、比例；❌ 禁止自行设定并列按钮的宽度和间距 |

---

## 五、无障碍（Accessibility）

- 使用 `<button>` 元素，❌ 不用 `<div>` 模拟
- 禁用态：`aria-disabled="true"` + 拦截点击
- icon-only：`aria-label="操作名称"`，图标加 `aria-hidden="true"`
- 加载态：`aria-busy="true"` + `aria-label`
- focus 样式：`:focus-visible` 显示 1pt outline，颜色 `blue-default`

---

## 六、Props API（供 AI 生码参考）

```typescript
export type ButtonProps = React.ComponentProps<"button"> & {
  type?: "capsule" | "text";          // 形态，默认 capsule
  variant?: "primary" | "colorful" | "colorful-outline" | "secondary"; // 视觉变体，仅 capsule 适用
  size?: "xl" | "l" | "m" | "s" | "xs" | "xxs";  // capsule 尺寸，默认 m
  textSize?: "l" | "m" | "s";          // text 按钮尺寸，默认 s
  disabled?: boolean;
  loading?: boolean;
  iconLeft?: React.ReactNode;
  iconRight?: React.ReactNode;
  subLabel?: React.ReactNode;
};
```

---

## 七、data-attribute 规范

| 属性 | 值 |
|------|----|
| `data-slot` | `"button"` |
| `data-state` | `"default"` / `"pressed"` / `"disabled"` |
| `data-variant` | `"primary"` / `"colorful"` / `"colorful-outline"` / `"secondary"` |
| `data-size` | `"xl"` / `"l"` / `"m"` / `"s"` / `"xs"` / `"xxs"` |
| `data-loading` | `"true"` / `"false"` |

---

## 八、HTML 输出速查（AI 生成预览文件时直接复制）

<!-- BTN-NAV-START -->

## 🗺️ §8 尺寸 × 内容 快速定位（按需 offset 跳转，❌ 禁止从头扫描）

> 只生成部分尺寸时，直接跳对应行读 CSS，无需通读全文。

| 需要的内容 | 直接跳 | 说明 |
|-----------|--------|------|
| 基础结构 + 按压态（所有尺寸必读） | L434 | `button.btn` 共用基类，全局按压态 |
| XL 单行 / 双行 CSS | L463 | height:96px，双行 L479 |
| L 单行 / 双行 CSS | L484 | height:80px，双行 L500 |
| M CSS（含 icon-right 收窄） | L505 | height:68px |
| S CSS | L520 | height:60px |
| XS CSS | L535 | height:48px |
| XXS CSS | L554 | height:40px |
| Variant 颜色（primary/orange/dpt5/outline/secondary） | L567 | 所有配色 class |
| Text Button CSS（btn-text-l/m/s） | L601 | 无背景无描边文字按钮 |
| §8.2 双行 XL/L HTML 模板 + 价格规则 | L643 | 双行 HTML 结构，price-set-16 |
| §8.3 Price Font @2x 覆盖 CSS | L687 | price-set-20 / price-set-16 覆盖 |

<!-- BTN-NAV-END -->


> **单位说明**：规范值为 @1x pt，CSS 写入时 ×2 = @2x px（750px 画布）。下方均已换算，❌ 禁止手动推导或修改。

### §8.1 全尺寸 CSS 速查

```css
/* Button 基础结构（所有尺寸共用）
   圆角 Token: radius-full (component-radius.md) → border-radius: 9999px
   间距 Token: cs-{N} (component-spacing.md) → 各尺寸见下方注释 */
button.btn {
  display: flex; flex-direction: row; align-items: center; justify-content: center;
  border-radius: 9999px; /* radius-full (component-radius.md) */
  border: none; cursor: pointer; outline: none;
  width: 100%; box-sizing: border-box;
  font-family: 'PingFang SC','Noto Sans SC','Source Han Sans SC','Microsoft YaHei','WenQuanYi Micro Hei',sans-serif;
  -webkit-tap-highlight-color: transparent;
  position: relative; overflow: hidden;

}
button.btn:focus-visible { outline: 2px solid #0066FF; outline-offset: 2px; }

/* 按压态：面性按钮叠加白色遮罩（伪元素实现），线性按钮降低描边透明度 */
button.btn-primary:active::after,
button.btn-colorful-red:active::after,
button.btn-colorful-orange:active::after,
button.btn-colorful-dpt5:active::after {
  content: ''; position: absolute; inset: 0;
  background: rgba(255, 255, 255, 0.5);
  transition: background 0.1s;
}
button.btn-secondary:active { border-color: rgba(204, 204, 204, 0.5); opacity: 0.5; transition: border-color 0.1s, opacity 0.1s; }
button.btn-colorful-outline:active,
button.btn-secondary-red:active { border-color: rgba(255, 45, 25, 0.5); opacity: 0.5; transition: border-color 0.1s, opacity 0.1s; }

/* ---- XL ----
   Token: cs-11(11pt)↔22px cs-24(24pt)↔48px cs-2(2pt)↔4px | radius-full
   @1x: 高48pt | padding(单行): cs-11 cs-24 | icon 20pt
   @2x: 高96px | padding(单行): 22px 48px  | icon 40px
   icon-left→label 间距: cs-2(2pt)↔4px，由 btn-icon-left 的 margin-right:4px 实现，gap 设 0
   label: title-s-18-medium → @2x 36px/52px/500
   高度验证: 22+52+22=96px ✅ */
button.btn-xl { height: 96px; padding: 22px 48px; gap: 0; }
button.btn-xl .btn-icon-left { display: inline-block; font-size: 40px; width: 40px; height: 40px; line-height: 40px; flex-shrink: 0; margin-right: 4px; }
button.btn-xl .btn-label { font-size: 36px; line-height: 52px; font-weight: 500; }
button.btn-xl .btn-sub-label { font-size: 36px; line-height: 52px; font-weight: 500; color: inherit; margin-left: 4px; }
/* 双行 XL：上下 padding 收窄为 cs-6(6pt)↔12px，行间距 -2pt↔-4px
   第一行 btn-row1：subtitle-s-15-semibold @2x 30px/44px/600，价格间距 cs-4→8px
   第二行 caption-l-11-regular @2x 22px/32px/400
   高度验证: 12+44+(-4)+32+12=96px ✅ */
button.btn-xl.btn-double { flex-direction: column; justify-content: center; gap: 0; padding: 12px 48px; }
button.btn-xl .btn-row1 { display: flex; align-items: baseline; gap: 8px; }
button.btn-xl .btn-row1-text { font-size: 30px; line-height: 44px; font-weight: 600; }
button.btn-xl .btn-row2 { margin-top: -4px; font-size: 22px; line-height: 32px; font-weight: 400; }

/* ---- L ----
   Token: cs-9(9pt)↔18px cs-20(20pt)↔40px cs-2(2pt)↔4px | radius-full
   @1x: 高40pt | padding(单行): cs-9 cs-20 | icon 17pt
   @2x: 高80px | padding(单行): 18px 40px  | icon 34px
   icon-left→label 间距: cs-2(2pt)↔4px，由 btn-icon-left 的 margin-right:4px 实现，gap 设 0
   label: subtitle-s-15-medium → @2x 30px/44px/500
   高度验证: 18+44+18=80px ✅ */
button.btn-l { height: 80px; padding: 18px 40px; gap: 0; }
button.btn-l .btn-icon-left { display: inline-block; font-size: 34px; width: 34px; height: 34px; line-height: 34px; flex-shrink: 0; margin-right: 4px; }
button.btn-l .btn-label { font-size: 30px; line-height: 44px; font-weight: 500; }
button.btn-l .btn-sub-label { font-size: 30px; line-height: 44px; font-weight: 500; color: inherit; margin-left: 4px; }
/* 双行 L：上下 padding 收窄为 cs-3(3pt)↔6px，行间距 -2pt↔-4px
   第一行 btn-row1：subtitle-s-15-semibold @2x 30px/44px/600，价格间距 cs-4→8px
   第二行 caption-s-10-regular @2x 20px/28px/400
   高度验证: 6+44+(-4)+28+6=80px ✅ */
button.btn-l.btn-double { flex-direction: column; justify-content: center; gap: 0; padding: 6px 40px; }
button.btn-l .btn-row1 { display: flex; align-items: baseline; gap: 8px; }
button.btn-l .btn-row1-text { font-size: 30px; line-height: 44px; font-weight: 600; }
button.btn-l .btn-row2 { margin-top: -4px; font-size: 20px; line-height: 28px; font-weight: 400; }

/* ---- M ----
   Token: cs-7(7pt)↔14px cs-15(15pt)↔30px cs-2(2pt)↔4px | radius-full
   @1x: 高34pt | padding: cs-7 cs-15 | icon-left 16pt（Medium 500）| icon-right 12pt（Bold 700）
   @2x: 高68px | padding: 14px 30px  | icon-left 32px | icon-right 24px
   label: body-l-14-medium → @2x 28px/40px/500
   gap 拆分: icon-left→label 用 icon-left.margin-right:4px(cs-2)；label→icon-right 间距0（紧贴），不设 gap
   有右图标（向右箭头）时: padding-right 收窄为 cs-10(10pt)↔20px，class 加 .has-icon-right */
button.btn-m { height: 68px; padding: 14px 30px; gap: 0; }
button.btn-m.has-icon-right { padding-right: 20px; }
button.btn-m .btn-icon-left  { display: inline-block; font-size: 32px; width: 32px; height: 32px; line-height: 32px; flex-shrink: 0; margin-right: 4px; }
button.btn-m .btn-icon-right { display: inline-block; font-size: 24px; width: 24px; height: 24px; line-height: 24px; flex-shrink: 0; }
button.btn-m .btn-label { font-size: 28px; line-height: 40px; font-weight: 500; }
button.btn-m .btn-sub-label { font-size: 28px; line-height: 40px; font-weight: 500; color: inherit; margin-left: 4px; }

/* ---- S ----
   Token: cs-5(5pt)↔10px cs-15(15pt)↔30px cs-2(2pt)↔4px | radius-full
   @1x: 高30pt | padding: cs-5 cs-15 | icon-left 16pt（Medium 500）| icon-right 12pt（Bold 700）
   @2x: 高60px | padding: 10px 30px  | icon-left 32px | icon-right 24px
   label: body-l-14-medium → @2x 28px/40px/500
   gap 拆分: icon-left→label 用 icon-left.margin-right:4px(cs-2)；label→icon-right 间距0（紧贴），不设 gap
   有右图标（向右箭头）时: padding-right 收窄为 cs-10(10pt)↔20px，class 加 .has-icon-right */
button.btn-s { height: 60px; padding: 10px 30px; gap: 0; }
button.btn-s.has-icon-right { padding-right: 20px; }
button.btn-s .btn-icon-left  { display: inline-block; font-size: 32px; width: 32px; height: 32px; line-height: 32px; flex-shrink: 0; margin-right: 4px; }
button.btn-s .btn-icon-right { display: inline-block; font-size: 24px; width: 24px; height: 24px; line-height: 24px; flex-shrink: 0; }
button.btn-s .btn-label { font-size: 28px; line-height: 40px; font-weight: 500; }
button.btn-s .btn-sub-label { font-size: 28px; line-height: 40px; font-weight: 500; color: inherit; margin-left: 4px; }

/* ---- XS ----
   Token: cs-4(4pt)↔8px cs-12(12pt)↔24px cs-2(2pt)↔4px | radius-full
   @1x: 高24pt | padding: cs-4 cs-12 | icon-left 14pt | icon-right 10pt
   @2x: 高48px | padding: 8px 24px   | icon-left 28px | icon-right 20px
   label: body-s-12-medium → @2x 24px/32px/500
   gap 拆分: icon-left→label 用 icon-left.margin-right:4px(cs-2)；label→icon-right 间距0（紧贴），不设 gap
   有右图标时: padding-right 收窄为 cs-8（8pt）↔16px，class 加 .has-icon-right */
button.btn-xs { height: 48px; padding: 8px 24px; gap: 0; }
button.btn-xs.has-icon-right { padding-right: 16px; }
button.btn-xs .btn-icon-left { display: inline-block; font-size: 28px; width: 28px; height: 28px; line-height: 28px; flex-shrink: 0; margin-right: 4px; }
button.btn-xs .btn-icon-right { display: inline-block; font-size: 20px; width: 20px; height: 20px; line-height: 20px; flex-shrink: 0; }
button.btn-xs .btn-label { font-size: 24px; line-height: 32px; font-weight: 500; }
button.btn-xs .btn-sub-label { font-size: 24px; line-height: 32px; font-weight: 500; color: inherit; margin-left: 4px; }

/* ---- XXS ----
   Token: cs-2(2pt)↔4px cs-10(10pt)↔20px cs-2(2pt)↔4px | radius-full
   @1x: 高20pt | padding: cs-2 cs-10 | icon 11pt
   @2x: 高40px | padding: 4px 20px  | icon 22px
   icon-left→label 间距: cs-2(2pt)↔4px，由 btn-icon-left 的 margin-right:4px 实现，gap 设 0
   label: caption-l-11-medium → @2x 22px/32px/500
   高度验证: 4+32+4=40px ✅ */
button.btn-xxs { height: 40px; padding: 4px 20px; gap: 0; }
button.btn-xxs .btn-icon-left { display: inline-block; font-size: 22px; width: 22px; height: 22px; line-height: 22px; flex-shrink: 0; margin-right: 4px; }
button.btn-xxs .btn-label { font-size: 22px; line-height: 32px; font-weight: 500; }
button.btn-xxs .btn-sub-label { font-size: 22px; line-height: 32px; font-weight: 500; color: inherit; margin-left: 4px; }

/* Variant 颜色（渐变方向统一 to bottom right；支付 DPT14 例外用 to bottom left）*/
/* primary：黄色渐变，文字 #111111，❌ 禁止白色 */
button.btn-primary {
  background: linear-gradient(to bottom right, rgba(255, 231, 77, 1) 0%, rgba(255, 221, 0, 1) 100%);
  color: #111111;
}
/* colorful-red */
button.btn-colorful-red {
  background: linear-gradient(to bottom right, rgba(255, 102, 25, 1) 0%, rgba(255, 45, 25, 1) 100%);
  color: #FFFFFF;
}
/* colorful-orange */
button.btn-colorful-orange {
  background: linear-gradient(to bottom right, rgba(255, 146, 51, 1) 0%, rgba(255, 85, 0, 1) 100%);
  color: #FFFFFF;
}
/* colorful-dpt5 到餐橙红 */
button.btn-colorful-dpt5 {
  background: linear-gradient(to bottom right, rgba(255, 119, 0, 1) 0%, rgba(255, 75, 16, 1) 100%);
  color: #FFFFFF;
}
/* colorful-outline 文字跟描边色，❌ 禁止写 #111111 */
button.btn-colorful-outline { background: transparent; border: 1px solid #FF2D19; color: #FF2D19; }
/* secondary 描边 #CCCCCC，文字 #111111 */
button.btn-secondary { background: transparent; border: 1px solid #CCCCCC; color: #111111; }
/* secondary-red（colorful-outline 别名）*/
button.btn-secondary-red { background: transparent; border: 1px solid #FF2D19; color: #FF2D19; }
/* disabled-solid */
button.btn-disabled-solid { background: #F0F0F0; color: #C2C2C2; pointer-events: none; }
/* disabled-outline */
button.btn-disabled-outline { background: transparent; border: 1px solid #CCCCCC; color: #C2C2C2; pointer-events: none; }

/* Text Button（无背景无边框，高度=行高，gap cs-2=4px）*/
button.btn-text { background: none; border: none; padding: 0; cursor: pointer; outline: none;
  display: inline-flex; flex-direction: row; align-items: center; gap: 4px;
  font-family: 'PingFang SC','Noto Sans SC','Source Han Sans SC','Microsoft YaHei','WenQuanYi Micro Hei',sans-serif; color: #111111;
  -webkit-tap-highlight-color: transparent; }
button.btn-text:focus-visible { outline: 2px solid #0066FF; outline-offset: 2px; }
button.btn-text[aria-disabled="true"] { color: #C2C2C2; pointer-events: none; }
/* icon-right 颜色：固定 #999999（不继承父级 color）*/
button.btn-text .btn-icon-right { color: #999999; }
/* label→icon-right 间距：向右图标（right）紧贴 gap:0，加 has-right-arrow；展开等其他图标保持默认 gap:4px */
button.btn-text.has-right-arrow { gap: 0; }

/* icon-right 只能搭配「向右（right）」或「展开（expand）」类图标
   向右 → class 加 has-right-arrow（gap:0）；展开 → 不加（gap:4px）*/

/* ---- Text L ----
   Token: body-l-14-regular → @2x 28px/40px/400 | icon-left 16pt↔32px | icon-right 12pt↔24px
   @1x: 高20pt | @2x: 高40px */
button.btn-text-l { height: 40px; }
button.btn-text-l .btn-label { font-size: 28px; line-height: 40px; font-weight: 400; }
button.btn-text-l .btn-icon-left  { display: inline-block; font-size: 32px; width: 32px; height: 32px; line-height: 32px; flex-shrink: 0; }
button.btn-text-l .btn-icon-right { display: inline-block; font-size: 24px; width: 24px; height: 24px; line-height: 24px; flex-shrink: 0; }

/* ---- Text M ----
   Token: body-m-13-regular → @2x 26px/36px/400 | icon-left 15pt↔30px | icon-right 11pt↔22px
   @1x: 高18pt | @2x: 高36px */
button.btn-text-m { height: 36px; }
button.btn-text-m .btn-label { font-size: 26px; line-height: 36px; font-weight: 400; }
button.btn-text-m .btn-icon-left  { display: inline-block; font-size: 30px; width: 30px; height: 30px; line-height: 30px; flex-shrink: 0; }
button.btn-text-m .btn-icon-right { display: inline-block; font-size: 22px; width: 22px; height: 22px; line-height: 22px; flex-shrink: 0; }

/* ---- Text S ----（推荐，常与表单组合）
   Token: body-s-12-regular → @2x 24px/32px/400 | icon-left 14pt↔28px | icon-right 10pt↔20px
   @1x: 高16pt | @2x: 高32px */
button.btn-text-s { height: 32px; }
button.btn-text-s .btn-label { font-size: 24px; line-height: 32px; font-weight: 400; }
button.btn-text-s .btn-icon-left  { display: inline-block; font-size: 28px; width: 28px; height: 28px; line-height: 28px; flex-shrink: 0; }
button.btn-text-s .btn-icon-right { display: inline-block; font-size: 20px; width: 20px; height: 20px; line-height: 20px; flex-shrink: 0; }
```

---

### §8.2 双行 XL / L 按钮：HTML 结构模板

> XL 和 L 双行按钮的价格字体**固定搭配 `price-set-16`**（Medium 500），❌ 禁止继承 label 字体。

**XL 双行**：

```html
<!-- btn-row1 为 btn-row1-text + price-set-16（flex row，baseline 对齐）；gap:8px 控制文案与价格组间距 -->
<button class="btn btn-xl btn-double btn-colorful-dpt5"
  data-slot="button" data-variant="colorful" data-size="xl" data-state="default">
  <div class="btn-row1">
    <span class="btn-row1-text">去结算</span>
    <span class="price-set-16">
      <span class="price-set-16__symbol">¥</span>
      <span class="price-set-16__integer">200</span>
    </span>
  </div>
  <div class="btn-row2">免配送费</div>
</button>
```

**L 双行**（结构相同，替换尺寸 class）：

```html
<button class="btn btn-l btn-double btn-colorful-dpt5"
  data-slot="button" data-variant="colorful" data-size="l" data-state="default">
  <div class="btn-row1">
    <span class="btn-row1-text">去结算</span>
    <span class="price-set-16">
      <span class="price-set-16__symbol">¥</span>
      <span class="price-set-16__integer">200</span>
    </span>
  </div>
  <div class="btn-row2">免配送费</div>
</button>
```

> **XL / L 双行第一行价格固定搭配**：`price-set-16`（两个尺寸均相同）
> - ¥ 符号：`price-11-medium` → @1x 11pt/16pt/500 → @2x `font-size:22px; line-height:32px; font-weight:500; margin-right:2px`
> - 整数：`price-16-medium` → @1x 16pt/22pt/500 → @2x `font-size:32px; line-height:44px; font-weight:500`
> - ⚠️ **间距控制**：`btn-row1` 用 `gap:8px` 控制文案与价格组之间的间距；`price-set-16` 内部 `gap:0`，¥ 用自身 `margin-right:2px` 控制与整数间距。

---

### §8.3 Price Font @2x 覆盖 CSS

> 粘贴在 `mt-price-font-tokens.css` 内容之后，用 @2x px 值覆盖原始 @1x pt 值。
> ⚠️ `font-family` 和 `font-size` 必须加 `!important`：按钮的父级选择器（`button.btn-xl .btn-row1`）特异性高于裸 class，不加 `!important` 会被覆盖导致美团数字体失效。

```css
/* ── 单行 XL 价格：price-set-20 medium
   ¥ = price-13-medium  13pt→26px / line-height 18pt→36px / 500，margin-right 1pt→2px
   整数 = price-20-medium 20pt→40px / line-height 28pt→56px / 500
   小数 = price-20-medium 20pt→40px / line-height 28pt→56px / 500（与整数相同，❌ 禁止降档为 36px）
   ⚠️ 仅用于 btn-xl 单行（非双行）按钮内行内价格 */
.price-set-20 { display: inline-flex; align-items: baseline; gap: 0; }
.price-set-20__symbol  { font-family: '美团新数字体','MT New Digital Display',sans-serif !important; font-size: 26px !important; line-height: 36px; font-weight: 500; margin-right: 2px; }
.price-set-20__integer { font-family: '美团新数字体','MT New Digital Display',sans-serif !important; font-size: 40px !important; line-height: 56px; font-weight: 500; }
.price-set-20__decimal { font-family: '美团新数字体','MT New Digital Display',sans-serif !important; font-size: 40px !important; line-height: 56px; font-weight: 500; }

/* ── 单行 L 价格 / 双行 XL·L 价格：price-set-16 medium
   ¥ = price-11-medium  11pt→22px / line-height 16pt→32px / 500，margin-right 1pt→2px
   整数 = price-16-medium 16pt→32px / line-height 22pt→44px / 500
   用途：① btn-l 单行按钮内行内价格  ② btn-xl / btn-l 双行第一行（btn-row1）价格 */
.price-set-16 { display: inline-flex; align-items: baseline; gap: 0; }
.price-set-16__symbol  { font-family: '美团新数字体','MT New Digital Display',sans-serif !important; font-size: 22px !important; line-height: 32px; font-weight: 500; margin-right: 2px; }
.price-set-16__integer { font-family: '美团新数字体','MT New Digital Display',sans-serif !important; font-size: 32px !important; line-height: 44px; font-weight: 500; }
.price-set-16__decimal { font-family: '美团新数字体','MT New Digital Display',sans-serif !important; font-size: 32px !important; line-height: 44px; font-weight: 500; }

/* 其余 price-set-* 尺寸（price-set-12/14/18/24 等）定义在 mt-price-font-tokens.css，
   按钮组件不直接使用，此处不重复展示。 */
```
