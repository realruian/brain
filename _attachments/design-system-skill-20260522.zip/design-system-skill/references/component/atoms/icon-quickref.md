# 🖼️ 图标速查表

> **类名格式**：`font icon-iconfont-{name}-{weight}`
> **字重后缀**：`-line-light` / `-line-regular` / `-line-medium` / `-line-semibold`（推荐）/ `-line-bold` / `-fill`（填充体）
> ❌ 禁止在图标元素上设置 `font-weight`（`.font` 基类已用 `!important` 锁死，设了也无效）
> 🚨 **找不到名称 → 留空注释，❌ 严禁猜测拼接**
> **图例**：`✅fill` = 有线框体+填充体；`只fill` = 仅有填充体；`⬜` = 仅有线框体各字重
> **返回按钮专用**：`icon-iconfont-translate-line-semibold`（纯箭头）❌ 禁用 `leftturn`（带圆圈）

## 方向 / 操作
`leftturn`✅fill · `rightturn`✅fill · `right`⬜ · `expand`✅fill · `retract`✅fill · `upcircle`✅fill · `downcircle`✅fill · `backtop`⬜ · `leftslide`⬜ · `listexpand`⬜ · `listretract`⬜ · `pullup`⬜

## 通用操作
`search`⬜ · `add`✅fill · `pluscircle`✅fill · `delete`✅fill · `edit`⬜ · `copy`⬜ · `close`⬜ · `cancel`⬜ · `cancelcircle`✅fill · `check`✅fill · `more`✅fill · `filter`✅fill · `sort`只fill · `refresh`⬜ · `download`⬜ · `share`✅fill · `reset`⬜ · `change`⬜ · `scan`⬜ · `translate`⬜ · `select`✅fill · `multi`✅fill

## 导航 / 底部 Tab
`home`✅fill · `order`⬜ · `cart`✅fill · `shopping`✅fill · `personal`✅fill · `my`⬜ · `allorders`⬜ · `moreservices`⬜

## 位置 / 地图
`position`✅fill · `locate`✅fill · `currentlocate`⬜ · `navigation`✅fill · `routelocate`⬜ · `aroundmerchant`✅fill

## 用户 / 账户
`identity`✅fill · `lock`✅fill · `secure`✅fill · `securitycenter`✅fill · `visitor`⬜ · `family`⬜ · `contacts`⬜ · `student`⬜ · `blacklist`⬜

## 内容 / 社交
`comment`✅fill · `like`✅fill · `thumbsup`✅fill · `tread`✅fill · `collect`✅fill · `collection`⬜ · `evaluate`✅fill · `writeevaluate`⬜ · `report`✅fill · `vote`⬜ · `at`⬜ · `picture`✅fill · `video`✅fill · `livebroadcast`✅fill · `videocreat`✅fill · `shootvideo`✅fill · `emote`✅fill · `label`✅fill · `browse`⬜ · `footprint`⬜ · `history`⬜ · `commonuse`✅fill · `contentpreference`⬜

## 通知 / 消息
`message`✅fill · `notice`✅fill · `news`✅fill · `inform`✅fill · `announcement`⬜ · `messagesettings`⬜ · `subscribe`⬜ · `subscribesusess`⬜

## 商业 / 支付
`wallet`⬜ · `money`✅fill · `coin`⬜ · `bankcard`⬜ · `invoice`⬜ · `redpacket`⬜ · `redenvelope`⬜ · `voucher`⬜ · `cardcoupons`⬜ · `couponcircle`⬜ · `fastpayment`✅fill · `repayment`⬜ · `repaymentremind`⬜ · `repaymentset`⬜ · `setrepaymentday`⬜ · `bystages`⬜ · `cobrandcard`⬜ · `refund`⬜ · `refundsuccess`⬜ · `refundfailed`⬜ · `seckill`✅fill · `discount`⬜ · `servicefee`⬜ · `deliverygoods`⬜

## 订单 / 服务
`sendorder`⬜ · `deleteorder`⬜ · `downloadorder`⬜ · `findreservation`⬜ · `reappoint`⬜ · `orderconsult`✅fill · `serveprogress`⬜ · `reception`⬜ · `end`⬜ · `reach`⬜

## 店铺 / 商家
`shop`✅fill · `shopmanage`⬜ · `shopcontribute`⬜ · `claimstore`⬜ · `addpoi`⬜ · `addshop`⬜ · `businessplace`⬜ · `business`⬜ · `enterprise`⬜ · `company`⬜

## 出行 / 场景
`taketaxi`✅fill · `ride`✅fill · `metro`⬜ · `hotel`⬜ · `aircraft`⬜ · `trainstation`⬜ · `futuretravel`⬜ · `scenicspot`⬜ · `visitattractions`⬜ · `ticket`✅fill · `guide`⬜ · `meetingroom`⬜

## 餐饮 / 外卖
`eat`⬜ · `delicacy`⬜ · `fruit`⬜ · `icecream`⬜ · `tea`⬜ · `tavern`⬜ · `roast`⬜ · `oftenbuy`⬜

## 医疗 / 健康
`doctor`✅fill · `prescription`⬜
> ⚠️ **`medicine-line-semibold` 不存在于字体库**，❌ 严禁使用；医药健康图标统一用 `icon-iconfont-doctor-line-semibold`

## 工具 / 设置
`setup`✅fill · `setting`✅fill · `calendar`⬜ · `timing`⬜ · `addcalendar`⬜ · `schedule`只fill · `qrcode`⬜ · `barcode`⬜ · `wrench`⬜ · `catalog`⬜ · `classify`⬜ · `feedback`⬜ · `question`✅fill · `questionnaire`⬜ · `further`⬜ · `much`⬜ · `hide`⬜ · `address`⬜ · `phone`⬜ · `phonecustomer`⬜ · `phonerider`⬜ · `phonestore`⬜ · `bytelephone`✅fill · `customer`⬜ · `askmerchant`⬜ · `askrider`⬜

## 媒体 / 创作
`microphone`✅fill · `voiceinput`✅fill · `sound`✅fill · `soundoff`⬜ · `mute`✅fill · `play`只fill · `pause`只fill · `playcircle`✅fill · `pausecircle`✅fill · `previous`✅fill · `triplespeed`✅fill · `playlist`⬜ · `playguide`✅fill · `horizontal`⬜ · `fullscreen`⬜ · `smallscreen`⬜ · `camera`✅fill · `lianmai`⬜

## 状态 / 反馈
`success` · `warning`✅fill · `errors`⬜ · `error`（用 `errors`）· `inform`✅fill · `newserror`⬜ · `alarmlamp`⬜ · `prohibit`⬜ · `rejection`⬜ · `numberdamage`⬜ · `numberprotect`✅fill · `network`⬜

## 社区 / 其他
`link`⬜ · `key`⬜ · `keyboard`✅fill · `imkeyboard`⬜ · `facedetect`⬜ · `workbenches`⬜ · `award`⬜ · `invitesuccess`⬜ · `meituanpublicwelfare`⬜ · `sun`✅fill · `moon`✅fill · `gift`⬜ · `pilot`（用 `colonel`）· `colonel`⬜ · `add`✅fill · `adddesktop`⬜ · `addfriend`⬜
