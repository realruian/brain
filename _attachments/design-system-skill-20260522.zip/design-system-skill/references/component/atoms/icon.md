# Icon 图标

> **图标库**：美团 iconfont（仓库 ID 142）
> **字体族名**：`font`
> **类名格式**：`icon-iconfont-{name}-{weight}`
> **字重变体**：`line-light` / `line-regular` / `line-medium` / `line-semibold`（推荐）/ `line-bold` / `fill`（填充体）

---

## 1. 使用方式

### HTML
```html
<!-- 基础类 + 具体图标类 -->
<span class="font icon-iconfont-leftturn-line-semibold"></span>
<span class="font icon-iconfont-search-line-regular"></span>
```

> ⚠️ **flex 容器内必须加 `display:inline-block`**：图标通过 `::before` 伪元素渲染字形，在 flex 子项中若缺少 `display:inline-block`，伪元素可能不渲染或宽高塌缩。正确写法：
> ```html
> <span class="font icon-iconfont-search-line-regular" style="display:inline-block;"></span>
> ```

### CSS 基础类（必须同时添加）
```css
/* 项目中定义一次 */
.font {
  font-family: "font" !important;
  font-style: normal;
  font-weight: normal !important;  /* ← 已通过 !important 锁死，任何额外的 font-weight 声明均无效 */
  -webkit-font-smoothing: antialiased;
  -moz-osx-font-smoothing: grayscale;
}
```

> 🚨 **图标字重禁止规则（不可违反）**：
> - ❌ **严禁在图标元素（`btn-icon-left`、`btn-icon-right`、`tab-icon`、导航图标等任何承载 iconfont 的节点）上设置 `font-weight`**
> - `.font` 基类已用 `font-weight: normal !important` 锁死——任何 CSS `font-weight` 声明对图标字形**完全无效**，只会误导阅读代码的人
> - ✅ **图标粗细的唯一正确控制方式：class 名后缀**，如 `icon-iconfont-right-line-bold`、`icon-iconfont-search-line-medium`
> - 常见后缀对应关系：`-line-light`（细）/ `-line-regular`（常规）/ `-line-medium`（中）/ `-line-semibold`（粗）/ `-line-bold`（最粗）/ `-fill`（填充）

### 字重选型原则
| 字重 | 类名后缀 | 对应视觉 | 使用场景 |
|------|---------|---------|---------|
| Bold | `-line-bold` | 最粗 | 极强调，慎用 |
| Semibold | `-line-semibold` | 粗 | 导航标题、主操作 |
| Medium | `-line-medium` | 中 | 次级操作、标签 |
| Regular | `-line-regular` | 常规 | 正文、列表行 |
| Light | `-line-light` | 细 | 弱提示、辅助文字 |
| Fill | `-fill` | 填充体 | 选中 / 激活态 |

---

## 2. 常见场景速查

| 场景 | 类名（semibold 示例） | 有 fill |
|------|---------------------|---------|
| 返回按钮 | `icon-iconfont-leftturn-line-semibold` | ✅ |
| 向右箭头 | `icon-iconfont-right-line-semibold` | ❌ |
| 向下展开 | `icon-iconfont-expand-line-semibold` | ❌ |
| 向上收起 | `icon-iconfont-retract-line-semibold` | ❌ |
| 搜索 | `icon-iconfont-search-line-semibold` | ❌ |
| 关闭 | `icon-iconfont-close-line-semibold` | ❌ |
| 分享 | `icon-iconfont-share-line-semibold` | ❌ |
| 下载 | `icon-iconfont-download-line-semibold` | ❌ |
| 发票 | `icon-iconfont-invoice-line-semibold` | ❌ |
| 首页 Tab | `icon-iconfont-home-line-regular` | ✅ |
| 购物车（车形） | `icon-iconfont-cart-line-regular` | ✅ |
| 购物车（袋形） | `icon-iconfont-shopping-line-regular` | ✅ |
| 订单 | `icon-iconfont-order-line-regular` | ✅ |
| 个人中心 | `icon-iconfont-personal-line-regular` | ✅ |
| 设置 | `icon-iconfont-setting-line-regular` | ✅ |
| 定位 | `icon-iconfont-position-line-semibold` | ✅ |
| 编辑 | `icon-iconfont-edit-line-semibold` | ❌ |
| 删除 | `icon-iconfont-delete-line-semibold` | ❌ |
| 更多 | `icon-iconfont-more-line-semibold` | ❌ |
| 收藏 | `icon-iconfont-collect-line-regular` | ✅ |
| 通知 | `icon-iconfont-announcement-line-regular` | ❌ |
| 银行卡 | `icon-iconfont-bankcard-line-regular` | ❌ |
| 扫码 | `icon-iconfont-barcode-line-regular` | ❌ |
| 刷新 | `icon-iconfont-refresh-line-regular` | ❌ |
| 成功 | `icon-iconfont-success-fill` | ✅ |
| 警告 | `icon-iconfont-warning-fill` | ✅ |
| 错误 | `icon-iconfont-error-fill` | ✅ |

---

## 3. 完整图标目录

> 类名前缀统一为 `icon-iconfont-`，表格中省略前缀。字重：S=semibold R=regular M=medium L=light B=bold F=fill

| 图标名（前缀省略） | 中文 | 有字重线框 | 有 fill |
|-------------------|------|-----------|---------|
| `add` | — | ✅ | ✅ |
| `addcalendar` | — | ✅ | ❌ |
| `adddesktop` | — | ✅ | ❌ |
| `addfriend` | — | ✅ | ❌ |
| `addpoi` | — | ✅ | ❌ |
| `address` | — | ✅ | ❌ |
| `addshop` | — | ✅ | ❌ |
| `aircraft` | — | ✅ | ❌ |
| `alarmlamp` | — | ✅ | ❌ |
| `allorders` | — | ✅ | ❌ |
| `announcement` | — | ✅ | ❌ |
| `aroundmerchant` | — | ✅ | ✅ |
| `askmerchant` | — | ✅ | ❌ |
| `askrider` | — | ✅ | ❌ |
| `at` | — | ✅ | ❌ |
| `award` | — | ✅ | ❌ |
| `backtop` | — | ✅ | ❌ |
| `bankcard` | — | ✅ | ❌ |
| `barcode` | — | ✅ | ❌ |
| `blacklist` | — | ✅ | ❌ |
| `browse` | — | ✅ | ❌ |
| `business` | — | ✅ | ❌ |
| `businessplace` | — | ✅ | ❌ |
| `bystages` | — | ✅ | ❌ |
| `bytelephone` | — | ✅ | ✅ |
| `calendar` | — | ✅ | ❌ |
| `camera` | — | ✅ | ✅ |
| `cancel` | — | ✅ | ❌ |
| `cancelcircle` | — | ✅ | ✅ |
| `cardcoupons` | — | ✅ | ❌ |
| `cart` | — | ✅ | ✅ |
| `catalog` | — | ✅ | ❌ |
| `certificate` | — | ✅ | ✅ |
| `change` | — | ✅ | ❌ |
| `charts` | — | ✅ | ❌ |
| `check` | — | ✅ | ✅ |
| `claimstore` | — | ✅ | ❌ |
| `classify` | — | ✅ | ❌ |
| `closecomment` | — | ✅ | ❌ |
| `closedwheat` | — | ✅ | ❌ |
| `cobrandcard` | — | ✅ | ❌ |
| `coin` | — | ✅ | ❌ |
| `collect` | — | ✅ | ✅ |
| `collection` | — | ✅ | ❌ |
| `colonel` | — | ✅ | ❌ |
| `comment` | — | ✅ | ✅ |
| `commonlanguage` | — | ✅ | ❌ |
| `commonuse` | — | ✅ | ✅ |
| `company` | — | ✅ | ❌ |
| `contacts` | — | ✅ | ❌ |
| `contentpreference` | — | ✅ | ❌ |
| `copy` | — | ✅ | ❌ |
| `couponcircle` | — | ✅ | ❌ |
| `createsession` | — | ✅ | ❌ |
| `currentlocate` | — | ✅ | ❌ |
| `customer` | — | ✅ | ❌ |
| `delete` | — | ✅ | ✅ |
| `deleteorder` | — | ✅ | ❌ |
| `delicacy` | — | ✅ | ❌ |
| `deliverygoods` | — | ✅ | ❌ |
| `discount` | — | ✅ | ❌ |
| `doctor` | — | ✅ | ❌ |
| `downcircle` | — | ✅ | ✅ |
| `download` | — | ✅ | ❌ |
| `downloadorder` | — | ✅ | ❌ |
| `eat` | — | ✅ | ❌ |
| `edit` | — | ✅ | ❌ |
| `emote` | — | ✅ | ✅ |
| `end` | — | ✅ | ❌ |
| `enterprise` | — | ✅ | ❌ |
| `errors` | — | ✅ | ❌ |
| `evaluate` | — | ✅ | ✅ |
| `expand` | — | ✅ | ✅ |
| `facedetect` | — | ✅ | ❌ |
| `family` | — | ✅ | ❌ |
| `fastpayment` | — | ✅ | ✅ |
| `feedback` | — | ✅ | ❌ |
| `filter` | — | ✅ | ✅ |
| `findreservation` | — | ✅ | ❌ |
| `flashlightoff` | — | ✅ | ❌ |
| `flashlightopen` | — | ✅ | ❌ |
| `footprint` | — | ✅ | ❌ |
| `fruit` | — | ✅ | ❌ |
| `fullscreen` | — | ✅ | ❌ |
| `further` | — | ✅ | ❌ |
| `futuretravel` | — | ✅ | ❌ |
| `gift` | — | ✅ | ❌ |
| `guide` | — | ✅ | ❌ |
| `hide` | — | ✅ | ❌ |
| `history` | — | ✅ | ❌ |
| `home` | — | ✅ | ✅ |
| `horizontal` | — | ✅ | ❌ |
| `hotel` | — | ✅ | ❌ |
| `icecream` | — | ✅ | ❌ |
| `identity` | — | ✅ | ✅ |
| `imkeyboard` | — | ✅ | ❌ |
| `inform` | — | ✅ | ✅ |
| `invitesuccess` | — | ✅ | ❌ |
| `invoice` | — | ✅ | ❌ |
| `key` | — | ✅ | ❌ |
| `keyboard` | — | ✅ | ✅ |
| `label` | — | ✅ | ✅ |
| `leftslide` | — | ✅ | ❌ |
| `leftturn` | — | ✅ | ✅ |
| `lianmai` | — | ✅ | ❌ |
| `like` | — | ✅ | ✅ |
| `link` | — | ✅ | ❌ |
| `listexpand` | — | ✅ | ❌ |
| `listretract` | — | ✅ | ❌ |
| `livebroadcast` | — | ✅ | ✅ |
| `locate` | — | ✅ | ✅ |
| `lock` | — | ✅ | ✅ |
| `meetingroom` | — | ✅ | ❌ |
| `meituanpublicwelfare` | — | ✅ | ❌ |
| `message` | — | ✅ | ✅ |
| `messagesettings` | — | ✅ | ❌ |
| `metro` | — | ✅ | ❌ |
| `microphone` | — | ✅ | ✅ |
| `money` | — | ✅ | ✅ |
| `moon` | — | ✅ | ✅ |
| `more` | — | ✅ | ✅ |
| `moreservices` | — | ✅ | ❌ |
| `much` | — | ✅ | ❌ |
| `multi` | — | ✅ | ✅ |
| `mute` | — | ✅ | ✅ |
| `my` | — | ✅ | ❌ |
| `navigation` | — | ✅ | ✅ |
| `network` | — | ✅ | ❌ |
| `news` | — | ✅ | ✅ |
| `newserror` | — | ✅ | ❌ |
| `notice` | — | ✅ | ✅ |
| `numberdamage` | — | ✅ | ❌ |
| `numberprotect` | — | ✅ | ✅ |
| `oftenbuy` | — | ✅ | ❌ |
| `order` | — | ✅ | ❌ |
| `orderconsult` | — | ✅ | ✅ |
| `pause` | — | ❌ | ✅ |
| `pausecircle` | — | ✅ | ✅ |
| `personal` | — | ✅ | ✅ |
| `phone` | — | ✅ | ❌ |
| `phonecustomer` | — | ✅ | ❌ |
| `phonerider` | — | ✅ | ❌ |
| `phonestore` | — | ✅ | ❌ |
| `picture` | — | ✅ | ✅ |
| `play` | — | ❌ | ✅ |
| `playcircle` | — | ✅ | ✅ |
| `playguide` | — | ✅ | ✅ |
| `playlist` | — | ✅ | ❌ |
| `plus` | — | ✅ | ❌ |
| `pluscircle` | — | ✅ | ✅ |
| `prescription` | — | ✅ | ❌ |
| `previous` | — | ✅ | ✅ |
| `prohibit` | — | ✅ | ❌ |
| `pullup` | — | ✅ | ❌ |
| `qrcode` | — | ✅ | ❌ |
| `question` | — | ✅ | ✅ |
| `questionnaire` | — | ✅ | ❌ |
| `reach` | — | ✅ | ❌ |
| `reappoint` | — | ✅ | ❌ |
| `reception` | — | ✅ | ❌ |
| `redenvelope` | — | ✅ | ❌ |
| `redpacket` | — | ✅ | ❌ |
| `refresh` | — | ✅ | ❌ |
| `refund` | — | ✅ | ❌ |
| `refundfailed` | — | ✅ | ❌ |
| `refundsuccess` | — | ✅ | ❌ |
| `rejection` | — | ✅ | ❌ |
| `repayment` | — | ✅ | ❌ |
| `repaymentremind` | — | ✅ | ❌ |
| `repaymentset` | — | ✅ | ❌ |
| `report` | — | ✅ | ✅ |
| `reset` | — | ✅ | ❌ |
| `retract` | — | ✅ | ✅ |
| `ride` | — | ✅ | ✅ |
| `right` | — | ✅ | ❌ |
| `rightturn` | — | ✅ | ✅ |
| `roast` | — | ✅ | ❌ |
| `routelocate` | — | ✅ | ❌ |
| `scan` | — | ✅ | ❌ |
| `scenicspot` | — | ✅ | ❌ |
| `search` | — | ✅ | ❌ |
| `seckill` | — | ✅ | ✅ |
| `secure` | — | ✅ | ✅ |
| `securitycenter` | — | ✅ | ✅ |
| `select` | — | ✅ | ✅ |
| `selection` | — | ✅ | ❌ |
| `sendorder` | — | ✅ | ❌ |
| `serveprogress` | — | ✅ | ❌ |
| `servicefee` | — | ✅ | ❌ |
| `setrepaymentday` | — | ✅ | ❌ |
| `setup` | — | ✅ | ✅ |
| `share` | — | ✅ | ✅ |
| `shootvideo` | — | ✅ | ✅ |
| `shop` | — | ✅ | ✅ |
| `shopcontribute` | — | ✅ | ❌ |
| `shopmanage` | — | ✅ | ❌ |
| `shopping` | — | ✅ | ✅ |
| `showcomments` | — | ✅ | ❌ |
| `smallscreen` | — | ✅ | ❌ |
| `sort` | — | ❌ | ✅ |
| `sound` | — | ✅ | ✅ |
| `soundoff` | — | ✅ | ❌ |
| `student` | — | ✅ | ❌ |
| `subscribe` | — | ✅ | ❌ |
| `subscribesusess` | — | ✅ | ❌ |
| `sun` | — | ✅ | ✅ |
| `switch` | — | ✅ | ❌ |
| `taketaxi` | — | ✅ | ✅ |
| `tavern` | — | ✅ | ❌ |
| `tea` | — | ✅ | ❌ |
| `thumbsup` | — | ✅ | ✅ |
| `ticket` | — | ✅ | ✅ |
| `timing` | — | ✅ | ❌ |
| `trainstation` | — | ✅ | ❌ |
| `translate` | — | ✅ | ❌ |
| `tread` | — | ✅ | ✅ |
| `triplespeed` | — | ✅ | ✅ |
| `uninterested` | — | ✅ | ❌ |
| `upcircle` | — | ✅ | ✅ |
| `uselimit` | — | ✅ | ❌ |
| `userule` | — | ✅ | ❌ |
| `video` | — | ✅ | ✅ |
| `videocreat` | — | ✅ | ✅ |
| `visitattractions` | — | ✅ | ❌ |
| `visitor` | — | ✅ | ❌ |
| `voiceinput` | — | ✅ | ✅ |
| `vote` | — | ✅ | ❌ |
| `voucher` | — | ✅ | ❌ |
| `wallet` | — | ✅ | ❌ |
| `warning` | — | ✅ | ✅ |
| `workbenches` | — | ✅ | ❌ |
| `wrench` | — | ✅ | ❌ |
| `writeevaluate` | — | ✅ | ❌ |

---

## 4. 字体文件

> 字体文件来源：iconfont.sankuai.com 仓库 ID 142，资源包含 TTF / WOFF / WOFF2 / EOT / SVG。
> 项目使用时通过 `@font-face` 引入，或直接将字体 base64 内联到 CSS 中（推荐，避免 file:// 协议跨域问题）。