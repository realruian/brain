# 📦 高频组件速查卡

> 所有数值为 **@1x pt**，写 CSS 时 **×2 = px**（如 40pt → 80px）
> ❌ 禁止插值：各组件规格档位固定（按钮 xxs/xs/s/m/l/xl 共 6 档），不得自造中间值（如 48pt、42pt 等）
> ⚠️ 本文件仅做高频尺寸速查 + **宿主级收敛**，**不能替代 `references/INDEX.md` 的区域路由，也不能替代对应组件规范正文**；variant、结构、数量限制、禁用规则等仍必须回到对应 `.md` 文件核对
> 🚨 使用顺序：先在 `references/INDEX.md` 完成区域/候选路由，再用本页把已命中的候选集收敛到宿主级结论，最后回对应组件正文。**未经过 `INDEX.md` 路由，不得直接拿本页当独立路由源。**

## 🧭 高混淆宿主收敛卡（仅保留最易串型组）

> 这里只保留**最容易串型的宿主 / 叶子组**，用于承接 `INDEX.md` 已经给出的候选结果再做一次收窄；完整相邻候选仍以 `references/INDEX.md` 的「区域化强关联路由表 / 高混淆组件图谱」为准。

| `INDEX.md` 已命中的候选组 | 收敛结论 | 优先证据槽位 | 必须排除 / owner 提示 |
|--------------------------|----------|--------------|------------------------|
| 顶部导航语义 | `navigation` | `position=top` + 承担返回 / 标题 / 右操作任一导航任务 | 不是 `list/form/裸 header`；顶部外层布局 owner = `navigation` |
| 导航宿主内搜索 | `navigation + search-bar` | 顶部区已锁 `navigation`，且搜索只是子槽位入口 | `search-bar` 不是 `text-input`；嵌入导航时 `size/style/layout` 归 `navigation` |
| 搜索入口 / 正文输入 / 行级表单 | `search-bar` / `text-input` / `form` | `primary_task=搜索入口 / 文本录入 / 表单行承载` | 搜索入口不得降成普通输入；`form` 拥有整行结构，子控件不得反客为主 |
| 底部固定 CTA / 价格+操作 | `bottom-action-bar` | `position=bottom` + `fixed=true` + `primary_task=submit/purchase/confirm` | 若主任务是 2~5 项页面切换则不是它；底部布局 owner = `bottom-action-bar` |
| 底部 2~5 项切页 | `bottom-navigation` | `position=bottom` + `fixed=true` + `tab_count=2~5` + `primary_task=page-switch` | 若含主 CTA / 价格+操作则不是它；不得与 CTA Bar 共占同一主区域 |
| 筛选入口 / 筛选展开承载 | `filter` / `filter-panel` | `trigger=collapsed-entry / expanded-panel` | 入口不等于已展开；展开容器与操作区 owner = `filter-panel`；选择态叶子仍回 `select` |
| 结构化行承载 / 叶子控件 | `list` / `form` + `tag/badge/select/button` | 行内存在 `prefix / content / suffix / helper` 结构 | `tag/badge/select/button` 只做叶子，不替代宿主；需要 label/value/error 时优先看 `form` |
| 选择态叶子槽位 | `select` | `interactivity=single/multi/checked`，常出现在 `suffix-control / inline-status` | 勾选 / 单选 / 多选不是 `icon` 或手写 CSS；宿主仍由 `list/form/filter-panel/image-selection` 保留 |
| 行内标签 / 宿主角标 | `tag` / `badge` | `primary_task=状态权益` vs `unread/count/corner` | 内容流内 = `tag`；贴角、未读、数量提醒 = `badge`；角标锚点 owner 归宿主 |
| 阻断确认 | `dialog` | `mask=true` + `blocking=true` + 通常居中 | 不是 `toast/snackbar`；若从底部滑出承载复杂内容，回看 `bottom-sheets` |
| 底部半页承载 | `bottom-sheets` | `position=bottom` + `mask=true` + 承载列表 / picker / 复杂内容 | 不是 `dialog/popover`；半页容器与避让 owner = `bottom-sheets` |
| 短时轻反馈 | `toast` / `snackbar` | `duration=short` + `blocking=false`；居中无操作 vs 底部可撤销 | `toast` 不带蒙层；底部短暂且可操作优先 `snackbar` |

> **执行纪律**：本卡的作用，是把 `INDEX.md` 已经给出的候选集继续收窄到合法宿主或叶子，不是直接跳过正文，更不是替代 `INDEX.md` 重新路由。完成收敛后，仍必须回到对应组件 `.md` 确认 `variant / size / state / ownership / 限制项`。
> 🚨 **首轮收敛留痕**：命中任一混淆组时，在当前最小决策集中至少写出 `chosen_because / not_component / evidence_slots / owner_decision` 四段；这里是首轮收敛留痕，不是 `checklist.md §B` 的最终验收替代，但缺任一段时，`A3/W1` 不得继续靠感觉补判。
> 🚨 **补充纪律**：若本卡收敛结论与 `INDEX.md` 的区域路由结论不一致，必须回 `INDEX.md` 重做，不得在本页强行改判；若宿主里出现任何非文字 icon，必须同步形成 `icon-route`；若在判断间距时分不清是页面层还是组件层，先停在 ownership 判定，不得继续按感觉写 spacing。

## 🚫 高频错配黑名单（首轮即阻断）

> 本表不是新增路由器，而是给已经完成 `INDEX.md` 路由和本页宿主收敛后的结果，加一层“最常错的禁止组合”阻断。命中任一条时，不得继续凭感觉写 HTML，必须回到对应组件正文重核 `variant / size / state / ownership`。

| 常见错配 | 正确落点 / 纠正方式 | 阻断原因 |
|----------|----------------------|----------|
| `bottom-action-bar` 内按钮写 `size=xl` / `btn-xl` | 改回 `button size=l` / `btn-l` | 栏内按钮只允许 `l`；`xl` 仅正文独立 CTA |
| 导航内搜索先落成 `text-input` 或独立裸 input | 收敛为 `navigation + search-bar`，并由 `navigation` 锁 `size/style/layout` | 搜索入口不是普通输入；子组件不得反客为主 |
| `list/form/filter-panel` 的选择态叶子只写宿主，不单独绑 `select` | 在 `slot_binding_map` 单独绑定 `select`，补 `data-type + size/state` | 宿主正确 ≠ 叶子自动完成 |
| 行内业务标签写成 `badge`，或角标/未读数写成 `tag` | 内容流标签 = `tag`；贴角/数量提醒 = `badge` | 两者语义与 owner 完全不同 |
| 收起态筛选入口和展开层都写成 `filter` | 入口 = `filter`；展开承载 = `filter-panel` | 触发器与承载容器不可混用 |
| 阻断确认 / 半页承载 / 轻反馈混写 | `dialog` = 阻断居中；`bottom-sheets` = 底部半页复杂承载；`toast/snackbar` = 短时轻反馈 | 蒙层、位置、交互强度不同 |
| `bottom-navigation` 与 `bottom-action-bar` 共占同一主底区 | 只保留一个宿主，按 `page-switch` vs `CTA` 重新路由 | 底部固定区职责不可双占 |
| `stepper` 加减号用 iconfont / 普通 icon | 改回 `stepper.md` 指定 inline SVG | 这是 fixed-asset 例外，不能走普通 icon-route |
| 已写合法 `data-variant/size/state`，又在业务 `<style>` 用高特异性覆盖内部样式 | 删除覆盖，改选规范已有 `variant/size/state` | 页面层只能放置组件，不得偷改组件内部值 |

---

## 🔴 最高优先级

**Button 按钮** （→ 详见 `button.md §8`，CSS 必须直接复制）
| size | 高度 | @2x px | 圆角(胶囊) | 场景 |
|------|------|--------|-----------|------|
| `xxs` | 20pt | 40px | 10pt→20px | 极小行内 |
| `xs` | 24pt | 48px | 12pt→24px | 小行内 |
| `s` | 30pt | 60px | 15pt→30px | 卡片内操作 |
| `m` | 34pt | 68px | 17pt→34px | 模块内主要操作 |
| `l` | 40pt | 80px | 20pt→40px | **bottom-action-bar 专用** |
| `xl` | 48pt | 96px | 24pt→48px | 页面独立全宽 CTA，❌ 禁入 bottom-action-bar |
> variant: `primary`(渐变黄) / `colorful`(彩色渐变) / `colorful-outline`(彩色描边) / `secondary`(灰色描边)
> 🚨 **口诀：栏内 = l（80px），独立 CTA = xl（96px）**

**Tag 标签** （→ `component/molecules/tag.md`）
| size | 高度 | @2x px | 左右padding | 圆角 |
|------|------|--------|------------|------|
| `s` | 20pt | 40px | 4pt→8px | 4pt→8px |
| `m` | 24pt | 48px | 6pt→12px | 6pt→12px |
| `l` | 28pt | 56px | 8pt→16px | 8pt→16px |
> type: `tag` / `splice` / `coupon` / `outer` / `bubble` / `corner`；常规 `tag` 高频 variant: `dark` / `light` / `gray-bg` / `black-bg` / `colored-border` / `gray-border`

---

## 🔴 P0 组件

**System 系统骨架** （→ `references/component/components/system.md`）
- **Status Bar**：44pt → 88px；手机页面默认必须渲染完整状态栏，右侧图标必须直接复用官方 SVG
- **Home Indicator**：34pt → 68px；手机页面默认必须渲染底部胶囊条，业务元素不得叠压其区域
- 页面骨架顺序固定：`Status Bar → Navigation/Search → 内容区 → bottom-navigation 或 bottom-action-bar → Home Indicator`
- ⚠️ `bottom-navigation` 与 `bottom-action-bar` 默认二选一；局部修改时若会触碰系统栏/底栏/内联 SVG，按高风险任务处理

**Navigation 导航栏** （→ `references/component/components/navigation.md`）
- 容器高度：44pt（不含状态栏）→ 88px；`avatar` 双行例外：54pt → 108px
- 标题字号：`secondary` 17pt Medium → 34px；左右内边距 12pt → 24px
- 返回按钮：`icon-iconfont-translate-line-semibold`，**热区 22×22pt → 44px**（图标字体自然撑开，不需固定 width/height）
- 右侧操作区图标：22×22pt，字重 `line-medium`，不可修改（详见 `navigation.md §5.2`）
- 背景：`#FFFFFF`（`white`），❌ 禁用 `bg-page`（#F5F5F5）

**Bottom Action Bar** （→ `references/component/components/bottom-action-bar.md`）
- 容器高度：48pt → 96px（单层）；96pt → 192px（双层 stack / capsule-combo）
- **内部按钮必须 `size=l`（40pt→80px）**，❌ 严禁 `size=xl`
- 顶部 padding：8pt → 16px；左右 padding：12pt → 24px
- 顶部描边 0.5pt `divider-secondary`
- variant 主集：`single` / `double` / `triple` / `asymmetric` / `stack` / `icon-action` / `icon-double` / `icon-action-double` / `icon-action-split` / `icon-action-triple` / `price-split` / `capsule-combo` / `icon-capsule-combo` / `double-icon-capsule-combo` / `triple-icon-capsule-combo`
- 胶囊非等分不是新 variant：保持 `variant="capsule-combo"` 或 `variant="icon-capsule-combo"`，再配 `capsuleLayout="asymmetric"`

**Bottom Navigation 底部导航栏** （→ `references/component/components/bottom-navigation.md`）
- 容器高度：44pt → 88px（+ Home Indicator 34pt → 68px，整套占位 78pt → 156px）
- 图标：24pt → 48px；标签字号：10pt Regular → 20px
- 顶部描边 0.5pt `divider-secondary`
- 普通 Tab 图标需整组保持同一家族；默认优先整组使用 `line-medium`，若组件正文明确要求选中/未选中成对切换，则必须整组按配对规则一致落地，❌ 禁止局部线/面混搭
- ⚠️ 与 `bottom-action-bar` 功能不同：前者承载主导航切换，后者承载页面 CTA；默认不可串型、不可叠加
- 🚨 **收敛提示**：`首页/分类/订单/我的` 这类 2~5 项切页 = `bottom-navigation`；`去支付/加入购物车/立即购买` = `bottom-action-bar`

**List 列表** （→ `references/component/components/list.md`）
| type | 名称 | 行高 | @2x px |
|------|------|------|--------|
| `single-line-s` | 单行小号 | 50pt | 100px |
| `single-line-l` | 单行大号 | 56pt | 112px |
| `double-line-s` | 双行小号 | 66pt | 132px |
| `double-line-l` | 双行大号 | 76pt | 152px |
| `message` | 消息列表 | 72pt | 144px |
> 左padding 16pt→32px；主标题默认 Regular（❌ 不擅自改 Medium）；`l` 类主标题 16pt，`s` 类 14pt
> 同一列表内 **不可大小号混排**；默认单行截断 ellipsis，超 15 字可折行最多 2 行

**Search Bar 搜索栏** （→ `references/component/components/search-bar.md`）
| size | 高度 | @2x px | 圆角 | 典型场景 |
|------|------|--------|------|---------|
| `60` | 30pt | 60px | `radius-full`（胶囊） | 商家页头部、嵌入圆底导航 |
| `68` | 34pt | 68px | `radius-full`（胶囊） | 首页、搜索页（**最常用**） |
| `72` | 36pt | 72px | `radius-full`（胶囊） | 旅行/酒店多行信息 |
| `88` | 44pt | 88px | `radius-m`（方形感） | 地图业务/信息密度低 |
> type（仅限 60/68）：`strong`(渐变黄按钮) / `medium`(文字搜索) / `weak`(无按钮)
> 组合场景 style 由父组件决定，子组件不得擅自改写；嵌入 `navigation.md` 的 34pt 组合场景固定 `gray`（见 `search-bar.md §10.1`）；其他父组件未额外声明时按 `gray` 处理；`outlined` 仅限父组件主动声明（如旅行业务 36pt 场景）
> 🚨 **收敛提示**：导航里出现搜索入口，宿主应收敛到 `navigation + search-bar`；❌ 不要先写成 `text-input` 再补壳

**Stepper 步进器** （→ `references/component/components/stepper.md`）
- **stepperType**：`segmented` / `integrated` / `integrated-input` / `add-button`
- **分段型 size**：`large`（26pt→52px）/ `standard`（22pt→44px）/ `small`（18pt→36px）；✅ 默认优先 `standard`
- **连体型 size**：仅 `large`（26pt）/ `standard`（22pt）；❌ **无 `small`**
- 数字区宽度**弹性自适应**，不固定；步进器在容器内始终**右对齐**
- ⚠️ **加减号必须直接复用 `stepper.md §6.5` 的 inline SVG**；❌ 严禁任意 iconfont 加减号
- ⚠️ `add-button`：`plus` 型背景固定 `yellow-default`；商品列表卡片内必须锚定**卡片容器右下角**，不是图片右下角

---

## 🟡 P1 组件

**Filter 筛选** （→ `references/component/components/filter.md`）
- **大类 type**：`text`（文字筛选）/ `button`（按钮筛选）；**必须与 filter-panel.md 配套使用**
- **按钮筛选 size**：`loose`（34pt→68px）/ `standard`（30pt→60px）/ `compact`（26pt→52px）；圆角 `radius-s`(8pt)/`radius-xs`(6pt)
- **选中态 selectedState**：`unselected-gray` / `unselected-white` / `weak-selected` / `selected` / `multi-selected` / `strong-selected` / `custom`
- 左右 padding：12pt → 24px；展开箭头与文字 gap `spacing-3xs`（2pt）

**Filter Panel 筛选面板** （→ `references/component/components/filter-panel.md`）
- 右侧抽屉宽：280pt → 560px；底部弹窗顶部圆角：12pt → 24px
- 头部高度：48pt → 96px；确认按钮高：44pt → 88px
- position: `right` / `bottom`；底部需避让 Home Indicator（+68px）
- 🚨 **收敛提示**：筛选入口是 `filter`，展开承载层才是 `filter-panel`；两者不是一个组件的两种写法

**Form 表单** （→ `references/component/components/form.md`）
- **type**：`input`（键盘输入）/ `selection`（右箭头进弹层选值）
- **行高**：默认单行 **50pt → 100px**；输入折行或有错误提示 **70pt → 140px**
- **标题区宽**：≤5字 固定 82pt→164px；>5字 固定 154pt→308px；❌ 同一表单不可混用两种宽度
- 左右 padding：`spacing-xl`（16pt → 32px）×2
- 标题字体：`body-l-14-medium`（`text-primary`）；必填标记 `*` 红色 `error-default`

**Badge 徽标** （→ `references/component/components/badge.md`）
- **dot 红点**：standard=6pt→12px / large=8pt→16px（全圆 `radius-full`）
- **number 数字**：small=12pt / standard=14pt / large=16pt（高度）；字号 10pt（small/standard）/ 11pt（large）
- **text 文字**：small=12pt / standard=14pt / large=16pt（高度）
- 可选尖角（`tip=true`）：左下角 2px，贴合宿主元素角落时使用
- 白色外描边：2px solid `white`，通过绝对定位覆盖层实现，容器不加 border
- type: `dot` / `number` / `text`；背景色 `red-default`，文字色 `white`
- 🚨 **收敛提示**：贴在角上、表达未读/数量提醒的是 `badge`；写在内容流里的业务标签才是 `tag`

---

## 🟢 P2 组件

**Switch 开关** （→ `references/component/components/switch.md`）
| size | 滑轨（宽×高） | @2x px | 滑块直径 | 圆角 | 场景 |
|------|------------|--------|---------|------|------|
| `l` | 46×28pt | 92×56px | 24pt→48px | `radius-full` | 页面级功能开关 |
| `m` | 39×24pt | 78×48px | 20pt→40px | `radius-full` | 模块级功能开关 |
| `s` | 26×16pt | 52×32px | 12pt→24px | `radius-full` | 精细组件级开关 |
> **on态滑轨**：`yellow-default`（可替换为业务品牌色）；**off态滑轨**：`stroke-default`
> **禁用态**：滑轨浅色（on-disabled: `yellow-bg-deep`，off-disabled: `bg-page`），⚠️ 不是透明度 0.5；滑块始终 `white`
> state: `on` / `off` / `on-disabled` / `off-disabled`；❌ 禁止设置 border/outline/box-shadow

**Select 选择器** （→ `references/component/components/select.md`）
- 输入框高度：44pt → 88px；下拉面板圆角：8pt → 16px
- 选项行高：44pt → 88px；下拉面板最大高度：280pt → 560px，超出滚动
- variant: `single` / `multi`；多选选中项以 Tag 形式展示

**Bottom Sheets 底部抽屉** （→ `references/component/components/bottom-sheets.md`）
- 顶部圆角：`radius-xl`（**20pt → 40px**）；内容 padding：16pt → 32px
- size: `auto` / `full`；需避让 Home Indicator（底部 +34pt → 68px）
- **全屏蒙层必须**：`mask-default`（`rgba(0,0,0,0.6)`，**60% 黑色**）；❌ 禁止省略
