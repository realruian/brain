#!/usr/bin/env python3
"""
Design System Skill — 字体 & 资源注入脚本（隔离块版 v2）
用法：python3 inject.py "/path/to/output.html"

核心机制：
  字体数据写入独立的 <style id="ds-font-inject"> 块，与业务 CSS 物理隔离。
  AI 的 string_replace / MultiEdit / write 操作只会改业务 <style>，
  字体块完全不在修改路径上，100% 不会被覆盖。
  
  每次运行：先删除旧的 <style id="ds-font-inject"> → 在 <head> 末尾重新插入。
  幂等：无论运行多少次，结果相同。

兼容旧格式：
  若文件仍使用旧式 /* FONT-INJECT-HERE */ 锚点（历史文件），
  自动清理旧注入块，改为新格式独立块。
"""
import re, os, base64, sys

# ── 参数校验 ──────────────────────────────────────────────────
if len(sys.argv) < 2:
    print("❌ 用法：python3 inject.py \"/path/to/output.html\"")
    sys.exit(1)

HTML_PATH = sys.argv[1]
if not os.path.exists(HTML_PATH):
    print(f"❌ 文件不存在：{HTML_PATH}")
    sys.exit(1)

# ── 路径配置 ─────────────────────────────────────────────────
SKILL_DIR    = os.path.dirname(os.path.abspath(__file__))
ASSETS       = SKILL_DIR
DEMO_DIR     = os.path.expanduser("~/Desktop/Design Demo")
FONT_DIRS    = [os.path.expanduser("~/Library/Fonts"), "/Library/Fonts"]
inlined_path = os.path.join(DEMO_DIR, "_iconfont_inlined.css")

# 新格式标记（独立 style 块）
FONT_BLOCK_ID    = "ds-font-inject"
FONT_BLOCK_OPEN  = f'<style id="{FONT_BLOCK_ID}">'
FONT_BLOCK_CLOSE = "</style>"

# 旧格式标记（向后兼容清理）
ANCHOR       = "/* FONT-INJECT-HERE */"
INJECT_BEGIN = "/* FONT-INJECT-BEGIN */"
INJECT_END   = "/* FONT-INJECT-END */"

# ── 读取 HTML ────────────────────────────────────────────────
with open(HTML_PATH, "r", encoding="utf-8") as f:
    html = f.read()

# ── Step 0：清除旧注入（幂等保证）────────────────────────────

# 清除新格式独立 style 块（完整删除 <style id="ds-font-inject">...</style>）
# 这里必须只删“真实注入块”，不能把模板里的空占位块一起删掉；
# 否则后续 replace(</head>) 可能仍保留旧占位块，导致视觉上像“没注入成功”。
html = re.sub(
    rf'\s*{re.escape(FONT_BLOCK_OPEN)}.*?{re.escape(FONT_BLOCK_CLOSE)}\s*',
    '', html, flags=re.DOTALL
)

# 清除旧格式 FONT-INJECT-BEGIN/END 标记块
html = re.sub(
    rf'{re.escape(INJECT_BEGIN)}.*?{re.escape(INJECT_END)}\s*',
    '', html, flags=re.DOTALL
)
# 清除旧格式 /* FONT-INJECT-HERE */ 行内锚点（仅注释本身，不影响周边 CSS）
html = html.replace(ANCHOR, '')

# 清理历史遗留的无标记价格字体 @font-face 块
html = re.sub(
    r'@font-face\s*\{\s*font-family:\s*"美团新数字体".*?\}\s*',
    '', html, flags=re.DOTALL
)

# ── Step 1：iconfont ─────────────────────────────────────────
woff2_path = os.path.join(ASSETS, "iconfont.woff2")
css_path   = os.path.join(ASSETS, "iconfont.css")
iconfont_block = ""

if os.path.exists(woff2_path) and os.path.exists(css_path):
    b64 = base64.b64encode(open(woff2_path, "rb").read()).decode()
    icon_css = "".join(open(css_path).readlines()[17:])
    iconfont_block = (
        f'@font-face{{font-family:"font";font-display:block;'
        f'src:url("data:font/woff2;base64,{b64}")format("woff2");}}\n'
        f'.font{{font-family:"font"!important;font-style:normal;-webkit-font-smoothing:antialiased;}}\n'
        f'{icon_css}'
    )
    print("✅ iconfont 准备完成")
elif os.path.exists(inlined_path):
    inlined_css = open(inlined_path, "r", encoding="utf-8").read().strip()
    iconfont_block = inlined_css.replace(
        '@font-face {font-family:"font";src:',
        '@font-face {font-family:"font";font-display:block;src:'
    )
    print("✅ iconfont 准备完成（备用 _iconfont_inlined.css）")
else:
    print("⚠️  iconfont 文件缺失，跳过")

# ── Step 2：美团新数字体 Medium + Bold ────────────────────────
price_block = ""
PRICE_B64_MAP = {
    "700": os.path.join(DEMO_DIR, "price_bold_b64.txt"),
    "500": os.path.join(DEMO_DIR, "price_medium_b64.txt"),
}
for weight, fname in [("700", "MTNewDigitalDisplay-Bold.otf"), ("500", "MTNewDigitalDisplay-Medium.otf")]:
    injected = False
    for d in FONT_DIRS:
        p = os.path.join(d, fname)
        if os.path.exists(p):
            b64 = base64.b64encode(open(p, "rb").read()).decode()
            price_block += (
                f'@font-face{{font-family:"美团新数字体";font-weight:{weight};font-display:block;'
                f'src:url("data:font/otf;base64,{b64}")format("opentype");}}\n'
            )
            print(f"✅ 价格字体 weight={weight} 完成")
            injected = True; break
    if not injected:
        b64_txt = PRICE_B64_MAP.get(weight)
        if b64_txt and os.path.exists(b64_txt):
            b64 = open(b64_txt).read().replace("\n","").replace("\r","").replace(" ","").strip()
            price_block += (
                f'@font-face{{font-family:"美团新数字体";font-weight:{weight};font-display:block;'
                f'src:url("data:font/woff2;base64,{b64}")format("woff2");}}\n'
            )
            print(f"✅ 价格字体 weight={weight} 完成（备用 b64 txt）")
        else:
            print(f"⚠️  价格字体 {fname} 未找到，跳过")

# ── Step 3：写入独立字体块 ──────────────────────────────────
if not (iconfont_block or price_block):
    print("⚠️  无字体资源可注入，跳过写入")
else:
    font_style_block = (
        f'\n{FONT_BLOCK_OPEN}\n'
        f'/* 字体资源隔离块 — 由 inject.py 自动管理，请勿手动编辑此块 */\n'
        f'{iconfont_block}{price_block}'
        f'{FONT_BLOCK_CLOSE}\n'
    )

    if "</head>" in html:
        # 首选：插入到 </head> 之前，物理隔离于业务 <style>
        html = html.replace("</head>", font_style_block + "</head>", 1)
        print("✅ 字体块注入至 </head> 前（物理隔离）")
    elif "<body" in html:
        # 兜底：插入到 <body> 之前
        html = re.sub(r'(<body[\s>])', font_style_block + r'\1', html, count=1)
        print("⚠️  未找到 </head>，注入至 <body> 前")
    else:
        print("❌ 未找到注入位置（</head> 或 <body>），注入失败")
        sys.exit(1)

    # 写入后强校验：不允许只剩空块/注释块，也不允许缺失真实字体数据
    if FONT_BLOCK_ID not in html:
        print("❌ 字体块写入校验失败：缺少 ds-font-inject 节点")
        sys.exit(1)
    if "woff2;base64," not in html:
        print("❌ 字体块写入校验失败：缺少 iconfont woff2 数据")
        sys.exit(1)
    if 'font-family:"美团新数字体"' not in html:
        print("❌ 字体块写入校验失败：缺少价格字体数据")
        sys.exit(1)

# ── Step 4：图片占位符替换 {B64:~/path/to/file} ───────────────
for m in re.findall(r'\{B64:([^}]+)\}', html):
    p = os.path.expanduser(m)
    if os.path.exists(p):
        ext = p.rsplit(".", 1)[-1].lower()
        mime = {"webp": "image/webp", "png": "image/png", "jpg": "image/jpeg", "jpeg": "image/jpeg"}.get(ext, "image/jpeg")
        b64 = base64.b64encode(open(p, "rb").read()).decode()
        html = html.replace("{B64:" + m + "}", f"data:{mime};base64,{b64}")
        print(f"✅ 图片注入：{m}")
    else:
        html = html.replace("{B64:" + m + "}", "")
        print(f"⚠️  图片不存在，占位符已清空：{m}")

# ── 写回文件 ──────────────────────────────────────────────────
with open(HTML_PATH, "w", encoding="utf-8") as f:
    f.write(html)

# 最终兜底校验：写回后再次读取磁盘文件确认，防止内存态成功、落盘态失败
with open(HTML_PATH, "r", encoding="utf-8") as f:
    written_html = f.read()
if FONT_BLOCK_ID not in written_html:
    print("❌ 注入完成后校验失败：磁盘文件缺少 ds-font-inject 节点")
    sys.exit(1)
if "woff2;base64," not in written_html:
    print("❌ 注入完成后校验失败：磁盘文件缺少 iconfont woff2 数据")
    sys.exit(1)
if 'font-family:"美团新数字体"' not in written_html:
    print("❌ 注入完成后校验失败：磁盘文件缺少价格字体数据")
    sys.exit(1)

print(f"🎉 注入完成 → {HTML_PATH}")
